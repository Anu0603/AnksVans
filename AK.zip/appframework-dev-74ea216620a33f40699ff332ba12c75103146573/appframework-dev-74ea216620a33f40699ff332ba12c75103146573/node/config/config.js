exports.config = {
    protocol: "https",
    port: "3000",
    minify: true,
    apiTimeoutInSeconds: 15000,
    publicKey: "3bc0caa8d3c248d7821d3ee483202175",
    loggerHost: "127.0.0.1",
    loggerPort: 3001,
    accessPort: 3002,
    loggerFile: "log/node-serverlog/node-server.log",
    accessFile: "log/accesslog/access.log",
    logLevel: "INFO",
    serverTimezone: "America/Los_Angeles", // NON-DOCKER - dev/QA - 'Asia/Calcutta'
    nodeInstance: "node",
    authTestingEnabled: false,
    stub: false,
    enableNewRelic: true,
    uniqueTrackingIdEnabled: true,
    enableCSPReport: false,
    cdnUrl: "https://yodlee-1.hs.llnwd.net",
    abuseServiceDetectionURL:'http://192.168.57.66:8060/sps/sps/operation',
	abuseServiceTimeout : 1000,
    esLoggingEndPoint: "", // elastic search site url
    apiCacheEnabled: false,
    apiCacheIntervalType : "HOUR", // DAY, HOUR, MINUTE
    siteImageExpireTime : 86400000 // format is in milliseconds, default value is 1 DAY
};
