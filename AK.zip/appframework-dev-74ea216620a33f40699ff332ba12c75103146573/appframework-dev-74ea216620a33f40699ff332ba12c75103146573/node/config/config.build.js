exports.config = {
	enableNewRelic: false,
	buildMode: true,
	logLevel: 'DEBUG'
}
