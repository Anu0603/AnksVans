exports.nodefin1 = {
	brandId: '10000004',
	applicationId: 'FINCHECKA42161A3FF450E47CF4C1A00',
	resturl: 'https://restnextgenfl.corp.yodlee.com:2443/services/srest/finchk',
	yslurl: 'https://10.79.6.72/ysl/finchk'
}

exports.nodefin = {
	brandId: '10000004',
	applicationId: '21CBE222A42161A3FF450E47CF4C1A00',
	resturl: 'https://192.168.57.94:10443/services/srest/timelymc1',
	yslurl: 'http://192.168.112.179:10080/ysl/timelymc1'
}
exports.daflqa = {
	brandId: '50000001',
	applicationId: 'DAFLYES1A251A845FF0F20CF0405C600',
	resturl:
		'https://rest1dafl.yodleeinteractive.qa.yodlee.cloud/services/srest/daflqa',
	yslurl: 'http://192.168.112.179:10080/ysl/daflqa',
	finappId: '10003700',
	productType: 'daflqa'
}

exports.schwabiav = {
	brandId: '10018820',
	applicationId: '0880F878FF86CF16FFB4CFA00573E500',
	resturl:
		'https://rest1dafl.yodleeinteractive.qa.yodlee.cloud/services/srest/schwabiav',
	logoutRedirection: 'home',
	yslurl: 'https://10.79.6.69/ysl/schwabiav',
	finappId: '10003700',
	productType: 'schwabiav'
}

exports.daflChannel = {
	brandId: '10007176',
	applicationId: 'AAA858283463F32EFF3CFF615313F000',
	resturl: 'https://10.79.8.30/services/srest/daflChannel',
	yslurl: 'https://10.79.6.69/ysl/daflChannel',
	labelIdentifier: 'fl4channel',
	isChannel: true
}
