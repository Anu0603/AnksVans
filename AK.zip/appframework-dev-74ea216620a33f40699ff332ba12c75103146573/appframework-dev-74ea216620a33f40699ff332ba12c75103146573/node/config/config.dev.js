exports.config = {
    "protocol" : "https",
    "port" : "3000",
    "apiTimeoutInSeconds" : 60000,
    "enableNewRelic" : false,
    "developmentMode": true,
    "logLevel": "INFO",
    "numCpus" : 2,
    "authTestingEnabled" : true,
    "apiDebug" : false,
    "buildWatch" : true,
    "autoAuthSaveEnabled" : true,
    "yslAuth" : true
}