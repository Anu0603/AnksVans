const path = require('path');

global.paths = {};
global.paths.NODE_MODULES_PATH = path.resolve('./node-modules/n10/node_modules');
global.defaultErrorMessage = 'Internal Server Error';
module.paths = [ global.paths.NODE_MODULES_PATH ];
process.env.NODE_ENV = 'build';

const appConfig = require('./framework/v1/common/app-config');

require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'build')).initialize()
    .then(() => {
        logger.info('Build All is completed successfully');
    })
    .catch(_err => {
        logger.error('Build All is failed due to errors ', _err);
        setTimeout(function() {
            process.exit(1);
        }, 5000);
    });

