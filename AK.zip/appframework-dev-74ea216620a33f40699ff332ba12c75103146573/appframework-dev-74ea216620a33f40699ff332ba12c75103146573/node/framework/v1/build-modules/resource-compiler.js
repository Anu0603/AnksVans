
module.paths = module.parent.paths;

const path = require('path');
const fs = require('fs');
// const _ = require('underscore');
const uglify = require("uglify-js");
const sass = require("node-sass");

const appConfig = require(global.paths.APP_CONFIG_PATH);
const logger = global.logger;

const GLOBAL_CBDK_PATH = path.join(global.paths.BRAND_DEFAULT_PATH, 'css/scss/global_cbdk.scss');

var compileSCSS = ( appContext, resourcePath ) => {
    return new Promise((resolve, reject) => {

        var compressed = '';

        if( appConfig.get('minify') === true ) {
            compressed = 'compressed';
        }

        let cssBrandPaths = appContext.getBrandCssPaths();

        let content = [];
        cssBrandPaths['cbdkBrandPath'].map( cbdkPath => {
            content.push(_getImportPath(path.join(cbdkPath, 'css/scss/cob_cbdk.scss')));
        });
        content.push(_getImportPath(GLOBAL_CBDK_PATH));

        if( resourcePath == '/css/base.css' ) {
            content.push(_getImportPath(path.join(cssBrandPaths['fontsBrandPath'][0], 'fonts/font.scss')));
            content.push(_getImportPath(path.join(global.paths.BRAND_DEFAULT_PATH, 'font-icon/font.scss')));
        } else if( resourcePath == '/css/cobrand.css' ) {
            cssBrandPaths['styleBrandPath'].map( stylePath => {
                content.push(_getImportPath(path.join(stylePath, 'css/scss/cob_style.scss')));
            });
        } else {
            content.push(_getImportPath(path.join(global.paths.BLOCK_APP_PATH, resourcePath.replace(/css/g, 'scss'))));
        }

        logger.debug('Scss source code to compile', content);
        sass.render({
            data: content.join('\n'),
            outputStyle: compressed,
        }, function (error, result) { // node-style callback from v3.0.0 onwards
            if (error) {
                logger.error("SASS compilation is failed.", error);
                reject(error);
            } else {
                let finalCode = result.css.toString();
                //logger.debug('Sass compilation data', finalCode);
                resolve(finalCode);
            }
        });
    })
};

var minifyJS = ( appContext, resourcePaths ) => {
    return new Promise(( resolve, reject) => {
        let minifiedContent = [], error;
        resourcePaths.map( resourcePath => {
            let content = fs.readFileSync(resourcePath).toString()
            if( appConfig.get('minify') === true ) {
                var result = uglify.minify(content);
    
                if( result.error ) {
                    error = result.error;
                } else {
                    minifiedContent.push(result.code);
                }
            } else {
                minifiedContent.push(content);
            }
        });
        if( !error ) {
            resolve(minifiedContent.join(';'));
        } else {
            reject(error)
        }
    })
};

var _getImportPath = ( cssPath ) => {
    return "@import '" + cssPath.replace(/\\/g,'/') + "';";
}

//exports.compileScss = _compileScss;
module.exports = {
    minifyJS,
    compileSCSS
}
