module.paths = module.parent.paths;

const logger = global.logger;

const brandContext = require('./core/brand-context');
const appContext = require('./core/app-context');

class BrandInfo {
	static getInstance(args) {
		if( !args || !args.brandId ) {
			args = args || {};
			args.brandId = 'brand';
			args.applicationId = 'default';
		}
		return new BrandInfo(args);
	}

	static triggerBrandRefresh(args) {
		brandContext.reloadBrand(args);
	}

	constructor(args) {
		this.args = args;
		this._brandInfo = brandContext.getBrandInfo(args);
		this._appInfo = appContext.getAppInfo(this._brandInfo, args);
	}

	getAppContext() {
		return this._appInfo;
	}

	getBrandAppResourceKey() {
		logger.debug('cacheid is ', this.getAppContext().getBrandAppAppResourceKey());
		return this.getAppContext().getBrandAppAppResourceKey() || 'static';
	}
}

module.exports = BrandInfo;
