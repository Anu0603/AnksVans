module.paths = module.parent.paths;

const logger = global.logger;

const path = require('path');
const fs = require('fs');
const _ = require('underscore');

const cacheHelper = require('../cache/brand-cache');

const appConfig = require(global.paths.APP_CONFIG_PATH);

var defaultBrandFiles = {
	"config": "config",
	"params": "params.js",
	"strings": "locale",
	"css_scss": "css/scss",
	"cob_cbdk": "cob_cbdk.scss",
	"cob_style": "cob_style.scss",
	"fontscss" : "fonts/_fonts.scss",
	"assets": ["fonts", "img", "pfile", "font-icon"]
};

var BRAND_CACHE = {};

var getBrandInfo = (args) => {
	let forceRefresh = false;
	args.brandAppKey = args.brandId + '-' + args.applicationId;
	if( args.channelId > 0 ) {
		args.channelBrandAppKey = args.channelId + '-' + args.applicationId;
	}

	logger.debug('Arguments for brandinfo', args);

	if( !BRAND_CACHE[args.brandAppKey] || BRAND_CACHE[args.brandAppKey] == 'TRIGGER_REFRESH' ) {
		BRAND_CACHE[args.brandAppKey] = 'REFRESHED';
		forceRefresh = true;
	}
	var brandInfo = cacheHelper.getBrandInfo(args, forceRefresh);

	if (!brandInfo) {
		BRAND_CACHE[args.brandAppKey] = 'REFRESHED';
		brandInfo = _loadBrandInfo(args);
	}

	return brandInfo;
};

var _loadBrandInfo = (args) => {

	logger.info('CRITICAL IF THIS MESSSAGE IS SHOWING MULTIPLE TIMES');

	let brandInfo = {
		brandId: args.brandId,
		applicationId: args.applicationId,
		channelId : args.channelId,
		brandAppKey: args.brandAppKey,
		channelBrandAppKey: args.channelBrandAppKey,
		hasCobrandLabel: false,
		allLocales: [],
		allPFiles: [],
		supportedAssets: defaultBrandFiles['assets'],
		assets: []
	}

	logger.info('Loading brand info for cobrand : ', brandInfo.brandAppKey);

	if (args.brandAppKey == 'brand-default') {
		_updateDefaultBrandInfo(brandInfo);
	} else {
		if (args.channelId > 0) {
			brandInfo.isSubrand = true;
			brandInfo.channelId = args.channelId;
		}

		_updateBrandInfo(brandInfo);
	}

	brandInfo = cacheHelper.setBrandInfo(brandInfo);
	return brandInfo;
};

var _updateDefaultBrandInfo = (brandInfo) => {
	brandInfo.path = 'brand-default';
	brandInfo.isDefault = true;
};

var _updateBrandInfo = (brandInfo) => {
	var brandPath = path.join(global.paths.BRANDS_PATH, brandInfo.brandAppKey);
	if (fs.existsSync(brandPath)) {
		brandInfo.hasCobrandLabel = true;
		brandInfo.path = brandInfo.brandAppKey;
		_loadBrandFiles(brandInfo);
		_loadSegmentBrandInfo(brandInfo);
		brandInfo.allLocales = brandInfo.locales || [];
	} else {
		logger.info("Label doesn't exist for brandApp : ", brandPath)
	}
};

var _loadSegmentBrandInfo = (brandInfo) => {
	var segmentPath = path.join(global.paths.BRANDS_PATH, brandInfo.path, 'segment');
	if( !fs.existsSync(segmentPath) ) {
		logger.debug("Segment Label doesn't exist for cobrand : ", segmentPath);
		return brandInfo;
	}

	var files = fs.readdirSync(segmentPath);
	if( files.length > 0 ) {
		brandInfo.hasSegmentLabel = true;
		brandInfo.segments = {};
		files.map( segmentName => {
			let segPath = path.join(segmentPath, segmentName);
			if (!fs.statSync(segPath).isFile()) {
				let segmentBrandInfo = { name : segmentName, isSegment : true };
				segmentBrandInfo.path = path.join( brandInfo.path, 'segment', segmentName).replace(/\\/g, '/');
				_loadBrandFiles( segmentBrandInfo, brandInfo );
				brandInfo.segments[segmentName] = segmentBrandInfo;
			} else {
				logger.debug('Segment is not a folder, '+ segmentName);
			}
		})
	}
}

var _loadBrandFiles = (brandInfo, parentBrandInfo) => {
	logger.info('Loading brand files for brandApp', brandInfo.path)

	brandInfo.hasParams = false;
	brandInfo.hasLocales = false;

	var rootFolderPath = path.join(global.paths.BRANDS_PATH, brandInfo.path);
	var configPath = path.join(rootFolderPath, defaultBrandFiles['config']);

	if (fs.existsSync(configPath)) {
		let paramsFile = defaultBrandFiles['params'];
		let paramsPath = path.join(configPath, paramsFile);
		if (fs.existsSync(paramsPath)) {
			brandInfo.hasParams = true;
			brandInfo.paramsPath = paramsPath.replace(/\\/g, '/');
		} else {
			logger.debug("params file doesn't exist for cobrand :", paramsPath)
		}

	} else {
		logger.debug("Config folder doesn't exist for cobrand :", configPath)
	}

	var localesPath = path.join(rootFolderPath, defaultBrandFiles['strings']);

	if (fs.existsSync(localesPath)) {
		let files = fs.readdirSync(localesPath);
		if (files.length > 0) {
			brandInfo.hasLocales = true;
			brandInfo.localesPath = localesPath.replace(/\\/g, '/');
			brandInfo.locales = [];
			for (let i = 0; i < files.length; i++) {
				let locale = files[i].replace('.js', '');
				let localePath = localesPath + '/' + locale + '.js';
				if (fs.existsSync(localePath)) {
					if (brandInfo.locales.indexOf(locale) == -1) {
						brandInfo.locales.push(locale);
					}
					if (parentBrandInfo) {
						if (parentBrandInfo.allLocales.indexOf(locale) == -1) {
							parentBrandInfo.allLocales.push(locale);
						}
					}
				} else {
					logger.debug("Invalid locale :", locale);
				}
			}
		} else {
			logger.debug("Locales are empty", pfilesPath);
		}
	} else {
		logger.debug("Locale folder doesn't exist for cobrand :", localesPath)
	}

	let scssPath = path.join(rootFolderPath, defaultBrandFiles['css_scss']);
	if (fs.existsSync(scssPath)) {
		let cobCbdkPath = path.join(scssPath, defaultBrandFiles['cob_cbdk']);
		if (fs.existsSync(cobCbdkPath)) {
			brandInfo.hasCobCbdk = true;
			brandInfo.cobCbdkPath = path.join(global.paths.BRANDS_PATH, brandInfo.path).replace(/\\/g, '/');
		} else {
			logger.debug("cob_cbdk file doesn't exist for cobrand :", cobCbdkPath);
		}

		let cobStylePath = path.join(scssPath, defaultBrandFiles['cob_style']);
		if (fs.existsSync(cobStylePath)) {
			brandInfo.hasCobStyle = true;
			brandInfo.cobStylePath = path.join(global.paths.BRANDS_PATH, brandInfo.path).replace(/\\/g, '/');
		} else {
			logger.debug("cob_style file doesn't exist for cobrand :", cobStylePath);
		}
	} else {
		logger.debug("scss file doesn't exist for cobrand :", scssPath);
	}

	brandInfo.assets = {};
	(parentBrandInfo || brandInfo).supportedAssets.map(assetValue => {
		var assetsPath = path.join(rootFolderPath, assetValue);

		if (fs.existsSync(assetsPath)) {
			let files = fs.readdirSync(assetsPath);
			if (!_.isEmpty(files)) {
				let val = {};
				val.assetsPath = rootFolderPath.replace(/\\/g, '/');
				brandInfo.assets[assetValue] = val;
			} else {
				logger.debug(assetValue + " are empty", assetsPath);
			}
		} else {
			logger.debug(assetValue + " folder doesn't exist for cobrand :", assetsPath)
		}
	});

	// fontscss
	let fontScssPath = path.join(rootFolderPath,  defaultBrandFiles["fontscss"]);
	if (fs.existsSync(fontScssPath)) {
		brandInfo.hasFontsStyle = true;
		brandInfo.fontsBrandPath = path.join(global.paths.BRANDS_PATH, brandInfo.path).replace(/\\/g, '/');
	} else {
		logger.debug("fontscss doesn't exist for cobrand :", fontScssPath);
	}

	return brandInfo;
};

var reloadBrand = args => {
	if( args && args.cobAppKey ) {
		logger.info('Brand-Cache-Refresh is triggered ', args);
		if( args.cobAppKey == 'ALL' ) {
			_.each(BRAND_CACHE, (value, key) => {
				BRAND_CACHE[key] = 'TRIGGER_REFRESH';
			});
			appConfig.set('serverStartupTime', args.serverStartupTime);
		} else {
			BRAND_CACHE[args.cobAppKey] = 'TRIGGER_REFRESH';
		}
		appConfig.set('resourceCacheFolder', args.resourceCacheFolder);
		// setting static resource cached values in cache in abstractResourceController.js file
		global.RESOURCE_CACHE = {};
	} else {
		logger.error('Missing arguments for clear brand-cache', args);
	}
}

module.exports = {
	getBrandInfo,
	reloadBrand
}