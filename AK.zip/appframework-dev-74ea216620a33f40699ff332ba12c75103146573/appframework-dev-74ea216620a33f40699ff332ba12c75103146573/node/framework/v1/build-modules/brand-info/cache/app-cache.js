module.paths = module.parent.paths;

const path = require('path');

const cacheHelper = require('./cache-helper');

const CONTENT_CACHE_PATH = path.join(global.paths.FRAMEWORK_VERSION_PATH, 'resource-cache/content');

var setAppInfo = ( appInfo ) => {
	let filePath = _getAppInfoCacheFilePath(appInfo.appKey);
	appInfo = cacheHelper.set(filePath, appInfo);
	return appInfo;
}

var getAppInfo = ( args ) => {
	return cacheHelper.get(_getAppInfoCacheFilePath(args.appKey), args.brandCacheKey);
}

var setParams = ( appInfo, params ) => {
	let filePath = _getParamsCacheFilePath(appInfo.appKey);
	params = cacheHelper.set(filePath, params);
	appInfo.paramsPath = filePath;
	return params;
}

var setLocales = ( appInfo, locales ) => {
	let filePath = _getLocalesCacheFilePath(appInfo.appKey);
	locales = cacheHelper.set(filePath, locales);
	appInfo.localesPath = filePath;
	return locales;
}

var forceRequire = ( filePath ) => {
	cacheHelper.remove(filePath);
	return require(filePath);
}

var _getAppInfoCacheFilePath = ( appKey ) => {
	logger.debug('CacheKey Path', appKey);
	return path.join(CONTENT_CACHE_PATH, appKey, 'app-info.json');
}

var _getParamsCacheFilePath = ( appKey ) => {
	return path.join(CONTENT_CACHE_PATH, appKey, 'params.json');
}

var _getLocalesCacheFilePath = ( appKey ) => {
	return path.join(CONTENT_CACHE_PATH, appKey, 'locale.json');
}
module.exports = {
	setAppInfo,
	getAppInfo,
	setParams,
	setLocales,
	forceRequire
}