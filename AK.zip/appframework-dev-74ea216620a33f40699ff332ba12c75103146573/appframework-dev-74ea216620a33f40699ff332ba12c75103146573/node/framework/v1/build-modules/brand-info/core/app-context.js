
module.paths = module.parent.paths;

const logger = global.logger;

const path = require('path');
const fs = require('fs');
const _ = require('underscore');
const lodash = require('lodash');

const cacheHelper = require('../cache/app-cache');
const brandContext = require('./brand-context');

const appConfig = require(global.paths.APP_CONFIG_PATH);

const DEFAULT_LOCALE = 'en_US';

var DEFAULT_BRAND_DATA = {};

var _getApplInfo = (brandInfo, appParams) => {

	appParams.appKey = _getAppKey(brandInfo, appParams);
	appParams.brandCacheKey = brandInfo.cacheKey;

	var appInfo = cacheHelper.getAppInfo(appParams);

	if (!appInfo) {
		appInfo = _loadAppInfo(brandInfo, appParams);
	}

	return new AppInfo(brandInfo, appInfo, appParams);
};

var _loadAppInfo = (brandInfo, appParams) => {
	let appInfo = {
		appKey: appParams.appKey,
		cacheKey: appParams.brandCacheKey,
		brandAppResourceKey: _getBrandAppResourceKey(brandInfo, appParams)
	}

	let channelBrandInfo = segmentBrandInfo = {};
	if (brandInfo.channelId > 0) {
		let channelArgs = {
			brandId: brandInfo.channelId, applicationId: brandInfo.applicationId,
			locale: appParams.locale
		};
		channelBrandInfo = brandContext.getBrandInfo(channelArgs);
	} else if( !_.isEmpty(appParams.segmentBrandName) ) {
		if( brandInfo.hasSegmentLabel && brandInfo.segments[appParams.segmentBrandName] ) {
			segmentBrandInfo = brandInfo.segments[appParams.segmentBrandName];
		}
	}

	// array order indicates the inheritance of params, locale etc..
	let brandInfoArray = [ segmentBrandInfo, brandInfo, channelBrandInfo ];
	_setMergedParamsPath(appInfo, brandInfoArray);
	_setMergedLocalesPath(appInfo, brandInfoArray, { allLocales : brandInfo.allLocales });
	_setCssPaths(appInfo, brandInfoArray);
	_setAssetsPaths(appInfo, brandInfoArray, { supportedAssets : brandInfo.supportedAssets });

	logger.info('AppInfo json is ', appInfo);
	appInfo = cacheHelper.setAppInfo(appInfo);
	return appInfo;
}

var _getAppKey = (brandInfo, appParams) => {
	var appInfoKeys = [brandInfo.brandAppKey];
	if( !_.isEmpty(appParams.segmentBrandName) ) {
		appInfoKeys.push('segment');
		appInfoKeys.push(appParams.segmentBrandName);
	}
	return appInfoKeys.join('/');
}

var _getBrandAppResourceKey = (brandInfo, appParams) => {
	var data = [];
	data.push(brandInfo.resourceCacheId);
	if( appConfig.get('stub') === true ) {
		data.push(encodeURIComponent(brandInfo.brandId));
	} else if( !_.isEmpty(appParams.segmentBrandName) ) {
		data.push(encodeURIComponent(appParams.segmentBrandName));
	}
	return encodeURIComponent(data.join(":"));
}

var _loadDefaultBrandData = () => {
	DEFAULT_BRAND_DATA['params'] = require(path.join(global.paths.BRAND_DEFAULT_PATH, 'config/params'));

	let locales = fs.readdirSync(path.join(global.paths.BRAND_DEFAULT_PATH, 'locale'));

	DEFAULT_BRAND_DATA['locales'] = {};
	locales.map(locale => {
		DEFAULT_BRAND_DATA['locales'][locale.split('.')[0]] = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, '/brand-default/locale', locale));
	});

	DEFAULT_BRAND_DATA['default'] = global.paths.BRAND_DEFAULT_PATH;
}

var _setMergedLocalesPath = (appInfo, brandInfoArray, options) => {

	var localeFiles = [], mergedLocales = {};
	logger.info('Setting locale paths for app', appInfo.appKey);

	brandInfoArray.map( brandInfo => {
		if (brandInfo.hasLocales) {
			localeFiles.push(brandInfo.localesPath);
		}
	});
	
	if (!_.isEmpty(localeFiles)) {

		logger.debug("Merged Locale Files", localeFiles, appInfo.appKey);
		localeFiles = localeFiles.reverse();

		options.allLocales.map(locale => {

			let mergedLocaleStrings = DEFAULT_BRAND_DATA.locales[locale] || {};
			if (locale !== DEFAULT_LOCALE) {
				mergedLocaleStrings = lodash.merge({}, mergedLocaleStrings, DEFAULT_BRAND_DATA.locales[DEFAULT_LOCALE]);
			}

			localeFiles.map(localeFilePath => {

				let distLocalePath = path.join(localeFilePath, locale + ".js");
				if (fs.existsSync(distLocalePath)) {
					logger.info('merging locale from file', distLocalePath, appInfo.appKey);
					let distLocaleStrings = cacheHelper.forceRequire(distLocalePath);
					if (!_.isEmpty(distLocaleStrings)) {
						logger.debug("merging locales", mergedLocaleStrings, distLocaleStrings);
						mergedLocaleStrings = lodash.merge({}, mergedLocaleStrings, distLocaleStrings);
					}
				} else {
					logger.info('locale file doen\'t exist', distLocalePath, appInfo.appKey);
				}
			});

			if (!_.isEmpty(mergedLocaleStrings)) {
				mergedLocales[locale] = mergedLocaleStrings;
			} else {
				logger.error("Content in locale file is empty.", locale);
			}
		});

		if (!_.isEmpty(mergedLocales)) {
			cacheHelper.setLocales(appInfo, mergedLocales);
		} else {
			logger.error("Content in all locale files are empty.");
		}
	} else {
		logger.error("No locale files for generating localePath", appInfo.appKey);
	}
}

var _setMergedParamsPath = (appInfo, brandInfoArray) => {

	var paramFiles = [];
	logger.info('Setting Merged params paths for app', appInfo.appKey);

	brandInfoArray.map( brandInfo => {
		if (brandInfo.hasParams) {
			paramFiles.push(brandInfo.paramsPath);
		}
	});

	if (!_.isEmpty(paramFiles)) {
		logger.debug("Merged Param Files", paramFiles, appInfo.appKey);
		let mergedParams = DEFAULT_BRAND_DATA['params'];

		paramFiles.reverse().map(distParamsPath => {
			if (fs.existsSync(distParamsPath)) {
				logger.info('merging params from filie', distParamsPath, appInfo.appKey);
				let distParams = cacheHelper.forceRequire(distParamsPath);
				if (!_.isEmpty(distParams)) {
					mergedParams = lodash.merge({}, mergedParams, distParams);
				}
			} else {
				logger.info('param file doen\'t exist', distParamsPath, appInfo.appKey);
			}
		});

		if (!_.isEmpty(mergedParams)) {
			cacheHelper.setParams(appInfo, mergedParams);
			appInfo.cssOverrideEnabled = !mergedParams['block.common'].cssOverrideDisabled;
		} else {
			logger.error("Content in param file is empty.");
		}
	} else {
		logger.error("No param files for generating paramsPath", appInfo.appKey);
	}
}

var _setCssPaths = (appInfo, brandInfoArray) => {

	var cssPaths = { cbdkBrandPath : [], fontsBrandPath : [global.paths.BRAND_DEFAULT_PATH], styleBrandPath : [] }, 
		includeCbdk = true, includeStyle = true, includeFontsBrand = true;
	logger.info('Loading Css files for app', appInfo.appInfoKey);

	brandInfoArray.map( brandInfo => {
		if ( includeFontsBrand && brandInfo.fontsBrandPath ) {
			cssPaths['fontsBrandPath'][0] = brandInfo.fontsBrandPath;
			includeFontsBrand = false;
		}

		if( includeCbdk && brandInfo.hasCobCbdk ) {
			cssPaths['cbdkBrandPath'].splice(0, 0, brandInfo.cobCbdkPath);
			includeCbdk = appInfo.cssOverrideEnabled;
		};

		if( includeStyle && brandInfo.hasCobStyle ) {
			cssPaths['styleBrandPath'].splice(0, 0, brandInfo.cobStylePath);
			includeStyle = appInfo.cssOverrideEnabled;
		};
	});

	appInfo.cssPaths = cssPaths;
}

var _setAssetsPaths = (appInfo, brandInfoArray, options) => {

	var assetPaths = {};
	options.supportedAssets.map(assetName => {
		logger.info(assetName + "assets paths updatings");
		assetPaths[assetName] = [];
		brandInfoArray.map( brandInfo => {
			if (brandInfo.assets && brandInfo.assets[assetName] && brandInfo.assets[assetName].assetsPath) {
				assetPaths[assetName].push(brandInfo.assets[assetName].assetsPath);
			}
		});
		assetPaths[assetName].push(global.paths.BRAND_DEFAULT_PATH);
	})
	logger.info('Loading Assets files for app', appInfo.appInfoKey);

	appInfo.assetPaths = assetPaths;
}

class AppInfo {

	constructor(brandInfo, appInfo, options) {
		logger.info('AppParams for AppContext', options);
		this._appInfo = appInfo;
		this._brandInfo = brandInfo;
		this._appOptions = options;
	}

	getParams() {
		if (!this._params) {
			if (this._appInfo.paramsPath) {
				this._params = require(this._appInfo.paramsPath);
			} else {
				this._params = DEFAULT_BRAND_DATA['params'];
			}
		}
		return this._params;
	}

	getParam(key, moduleName) {
		var value = (this.getParams()['block.' + moduleName] || {})[key];
		if( _.isUndefined(value) ) {
			value = this.getParams()['block.common'][key];
		}
		return value;
	}

	getLocaleStrings() {
		if (!this._localeStrings) {
			logger.info("Locale strings for locale", this._appOptions.locale);
			let allLocales = {};
			if (this._appInfo.localesPath) {
				allLocales = require(this._appInfo.localesPath) || {};
			}
			this._localeStrings = allLocales[this._appOptions.locale] || allLocales[DEFAULT_LOCALE]
				|| DEFAULT_BRAND_DATA.locales[this._appOptions.locale] || DEFAULT_BRAND_DATA.locales[DEFAULT_LOCALE];
		}
		return this._localeStrings;
	}

	getLocaleString(key, moduleName) {
		var value = (this.getLocaleStrings(this._appOptions.locale)['block.' + moduleName] || {})[key];
		if( _.isUndefined(value) ) {
			value = this.getLocaleStrings(this._appOptions.locale)['block.common'][key];
		}
		if( _.isUndefined(value) && this._appOptions.locale != DEFAULT_LOCALE ) {
			value = this.getLocaleStrings(DEFAULT_LOCALE)['block.common'][key];
		}
		return value;
	}

	getBrandCssPaths() {
		return this._appInfo.cssPaths;
	}

	getAssetPath(assetRelativePath, assetType) {
		var assetPath;
		let assetBrandPaths = this._appInfo.assetPaths[assetType];
		logger.info("assetBrandPaths", assetBrandPaths, assetType, assetRelativePath);
		for (let i = 0; i < assetBrandPaths.length; i++) {
			let assetFullPath = path.join(assetBrandPaths[i], assetRelativePath);
			if (fs.existsSync(assetFullPath)) {
				assetPath = assetFullPath;
				logger.info('Asset path found for assetType', assetPath);
				break;
			}
		}
		return assetPath;
	}

	getBrandAppAppResourceKey() {
		return this._appInfo.brandAppResourceKey;
	}
}

_loadDefaultBrandData();

exports.getAppInfo = _getApplInfo;
