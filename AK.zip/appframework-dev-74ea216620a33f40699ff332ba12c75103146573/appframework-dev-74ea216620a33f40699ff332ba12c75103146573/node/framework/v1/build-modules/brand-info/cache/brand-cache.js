module.paths = module.parent.paths;

const path = require('path');
const fs = require('fs');
const crypto = require('crypto');

const cacheHelper = require('./cache-helper');

const appConfig = require(global.paths.APP_CONFIG_PATH);

const CONTENT_CACHE_PATH = path.join(global.paths.FRAMEWORK_VERSION_PATH, 'resource-cache/content');

var getBrandInfo = (args, forceRefresh) => {
	let cacheKey = forceRefresh ? _getHashKey(args.brandAppKey, _getResourceCacheId(args.brandAppKey, args.channelBrandAppKey)) : '';
	return cacheHelper.get(_getBrandInfoCacheFilePath(args.brandAppKey), cacheKey);
};

var setBrandInfo = (brandInfo) => {
	let filePath = _getBrandInfoCacheFilePath(brandInfo.brandAppKey);
	brandInfo.resourceCacheId = _getResourceCacheId(brandInfo.brandAppKey, brandInfo.channelBrandAppKey);
	brandInfo.cacheKey = _getHashKey(brandInfo.brandAppKey, brandInfo.resourceCacheId);
	logger.debug('Setting newBrandInfo', brandInfo.brandAppKey, brandInfo.resourceCacheId);
	brandInfo = cacheHelper.set(filePath, brandInfo);
	return brandInfo;
}

var _getBrandInfoCacheFilePath = (brandAppKey) => {
	logger.debug('CacheKey Path', brandAppKey);
	return path.join(CONTENT_CACHE_PATH, brandAppKey, 'brand-info.json');
}

var _getResourceCacheId = (brandAppKey, channelBrandAppKey) => {
	let cacheIdPath = path.join(global.paths.BRANDS_PATH, brandAppKey, 'cache-key.txt');
	let fmtime = channelFTime = 0;
	if( fs.existsSync(cacheIdPath)) {
		fmtime = fs.readFileSync(cacheIdPath).toString();
	}

	// comparing mtime between channel and sub-brand if channel label is uploaded and no change in sub-brand label
	if (channelBrandAppKey) {
		let channelCacheIdPath = path.join(global.paths.BRANDS_PATH, channelBrandAppKey, 'cache-key.txt');
		if( fs.existsSync(channelCacheIdPath)) {
			channelFTime = fs.readFileSync(channelCacheIdPath).toString();
			if (channelFTime > fmtime) {
				fmtime = channelFTime;
			}
		}
	}

	logger.info('%s - lastupdated times brand:channel:node', brandAppKey, fmtime, channelFTime, appConfig.get('serverStartupTime'));

	return parseInt(appConfig.get('serverStartupTime'))+parseInt(fmtime);
}

var _getHashKey = (brandAppKey, lastUpdatedTime) => {
	return crypto.createHash('md5').update('brand-info' + brandAppKey + lastUpdatedTime).digest("hex");
}

module.exports = {
	setBrandInfo,
	getBrandInfo
}