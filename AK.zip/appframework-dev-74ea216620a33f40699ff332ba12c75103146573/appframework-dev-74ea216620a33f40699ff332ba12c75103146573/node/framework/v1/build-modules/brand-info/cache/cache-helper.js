module.paths = module.parent.paths;

const path = require('path');
const fs = require('fs');

const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));

var get = ( cacheFilePath, cacheKey ) => {
	
	var cacheData;
	try {
		cacheData = require(cacheFilePath);
		if( cacheData && cacheKey ) {
			if( cacheData.cacheKey !== cacheKey ) {
				logger.info("Cache keys are not matched", cacheData.cacheKey, cacheKey);
				remove(cacheFilePath);
				cacheData = require(cacheFilePath);
				if( cacheData.cacheKey !== cacheKey ) {
					logger.info('Brand-info cache key is not matched so reloading cache')
					cacheData = null;
				}
			} else {
				data = cacheData;
			}
		}
	} catch(e) {
		if( fs.existsSync(cacheFilePath) ) {
			logger.error('Unable to get cache object due to error', e);
			throw e;
		}
	}
	return cacheData;

};

var set = ( cacheFilePath, data ) => {
	logger.debug('writing data to file initiated', cacheFilePath, data.length);

	let textData = JSON.stringify(data, null, 4);

	if( !fs.existsSync(cacheFilePath) ) {
		yutils.createFolder(path.dirname(cacheFilePath));
	}

	fs.writeFileSync(cacheFilePath, textData);
	logger.debug('writing data to file completed', cacheFilePath);
	
	remove(cacheFilePath);
	return require(cacheFilePath);
}

var remove = ( cacheFilePath ) => {
	try {
		delete require.cache[cacheFilePath];
		logger.debug('Deleted cache for path', cacheFilePath);
	} catch(e) {
		logger.debug('require-clear cache error', e);
	}
}

module.exports = {
	set,
	get,
	remove
}