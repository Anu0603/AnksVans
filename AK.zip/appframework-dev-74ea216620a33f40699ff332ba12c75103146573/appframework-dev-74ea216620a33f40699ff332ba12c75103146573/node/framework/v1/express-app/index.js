module.paths = module.parent.paths;

const express = require('express');
const path = require('path');
const _ = require('underscore');
const qs = require('querystring');

const yerrorHandler = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

var _initializeApp = () => {
    var app = express();

    let log4js = require('log4js')
        , cookieParser = require('cookie-parser')
        , bodyParser = require('body-parser');

    var app = express();
    app.set("view engine", "hbs");
    app.use(_initializeDefaultParameters);

    app.use(log4js.connectLogger(log4js.getLogger('access'), {
        level: log4js.levels.INFO,
        format: function (req, res, format) {
            var trackId = '';
            if (req.attr.loggerPrefix) {
                trackId = req.attr.loggerPrefix;
            }
            return format(trackId + '" :method :url HTTP/:http-version" :status :content-length ":referrer" ":user-agent" "::response-time"');
        }
    }));

    app.use(express.static(path.join(global.paths.BASE_PATH, 'dist/public')));

    app.use(cookieParser());
    app.use(bodyParser.json({
        limit: '10mb',
        type: ['json', 'application/csp-report']

    }));
    app.use(bodyParser.urlencoded({ limit: '10mb', extended: false, keepExtensions: true, uploadDir: './tmp' }));

    app.use(_validateRequestUrl)
    app.use(_securityHeaders);
    app.use(_parseAuthorizationHeader)
    app.use(_loggerPrefix);

    require("./routes").initialize(app);

    require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/hbs-helpers'));

    app.use(_errorHandler);

    return app;
}

var _securityHeaders = (req, res, next) => {
    if (appConfig.get('developmentMode') === true) {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PUT');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type,Authorization');
        res.setHeader('Access-Control-Expose-Headers', 'Content-Type,Authorization');
    }

    res.setHeader('X-XSS-Protection', '1;mode=block');
    res.setHeader("Strict-Transport-Security", "max-age=16070400; includeSubDomains");
    res.setHeader('p3p', "CP='This does not have a P3P policy. Please contact your financial institution for information regarding their privacy policy'");
    res.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
    res.setHeader("Pragma", "no-cache");
    res.setHeader("Expires", "0");

    if (appConfig.get('enableCSPReport') === true) {
        res.setHeader("X-Content-Type-Options", "nosniff");
        res.setHeader("Content-Security-Policy-report-only", "script-src 'self' 'unsafe-inline' *.yodlee.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: *.yodlee.com; report-uri /csp-report/?");
        res.setHeader("X-Content-Security-Policy-Report-Only", "'self'; script-src 'self' 'unsafe-inline' *.yodlee.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: *.yodlee.com; report-uri /csp-report/?");
        res.setHeader("X-WebKit-CSP-Report-Only", "'self'; script-src 'self' 'unsafe-inline' *.yodlee.com; style-src 'self' 'unsafe-inline'; img-src 'self' data: *.yodlee.com; report-uri /csp-report/?");
        res.setHeader("X-Content-Type-Options", "nosniff");
    }

    next();
}

var _initializeDefaultParameters = (req, res, next) => {
    req.attr = {};
    next();
}

var _parseAuthorizationHeader = (req, res, next) => {
    let val = req.header('Authorization');
    if (!_.isEmpty(val)) {
        // apis - cookie disabled and mobile bundle
        let params = val.split(';');
        if (!_.isEmpty(params)) {
            for (let i = 0; i < params.length; i++) {
                let keyVals = params[i].split("=");
                req.cookies[keyVals[0]] = decodeURIComponent(keyVals[1]);
            }
        }
    } else if( _.isEmpty(req.cookies) ) {
        logger.info('Setting cookies from post data');
        req.cookies['rsession'] = req.body.rdata;
        req.cookies['udata'] = req.body.udata;
        //req.cookies['nsession'] = req.body.ndata;
    }
    next();
}

var _validateRequestUrl = (req, res, next) => {
    res.removeHeader("X-Powered-By");
    let vDecodedURIComp = decodeURIComponent(req.url);

    if (vDecodedURIComp.indexOf('../') >= 0 || vDecodedURIComp.indexOf('/..') >= 0) {
        var ipAddress = 'IPAddress : ' + (req.headers['x-forwarded-for'] || req.connection.remoteAddress);
        var vHostName = 'HostName : ' + req.headers.host;
        let error500 = '500 error reported, URL: ' + vDecodedURIComp + ', ' + ipAddress + ', ' + vHostName;
        logger.error(req.attr.loggerPrefix, error500)
        res.send(global.defaultErrorMessage, 500)
        return;
    }

    next();
};

function _loggerPrefix(req, res, next) {

    var userId = 'u0000',
        cobAppName = 'COB_APP',
        userTrackId = req.query._utid,
        cip = req.headers['x-cip'] || req.headers['cip'] || (req.headers['x-forwarded-for'] || req.connection.remoteAddress || '').replace('::ffff:', '');

    if (req.path.indexOf('/authenticate/') != -1) {
        userTrackId = req.attr._utid = 'u' + Math.random().toString(36).substr(2, 8);
    } else {
        if (!userTrackId && req.headers['referer']) {
            let refererParams = qs.parse(req.headers['referer']);
            userTrackId = refererParams['utid'] || 'UTID';
        }
        var prefsData = req.cookies.udata;
        if (prefsData) {
            try {
                req.attr.userData = JSON.parse(prefsData);
                userId = req.attr.userData.userId || userId;

            } catch (e) {
                logger.error('Invalid prefs');
            }
        }
    }

    // userId ==> if not set, actual value is replaced in abstractAuthController ==> login success
    // cobAppName ==> if not set, actual value is replaced in routes.js ==> handleContext urls
    req.attr.loggerPrefix = '[' + [cip, cobAppName, userTrackId, userId].join(':') + ']';

    next();
}

var _errorHandler = (err, req, res, next) => {
    yerrorHandler.handleError(err, req, res);
};

exports.initialize = _initializeApp;

