module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const ycontext = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, "libraries/ycontext"));
const { TechError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

var initialize = expressApp => {

    expressApp.post('/services/:cobAppName/:service/:method/', function (req, res, next) {
        _handleRequest('common/dataProviderController', req, res, next);
    });

    expressApp.get('/resource/:cobAppName/:brandKey/:type/*', function (req, res, next) {
        _handleRequest('resource/abstractResourceController', req, res, next);
    });

    expressApp.post('/authenticate/:cobAppName/:app/', function (req, res, next) {
        _handleRequest('auth/abstractAuthController', req, res, next);
    });

    expressApp.route('/app/:cobAppName/:app/')
        .post(function(req, res, next) {
            _handleRequest('view/homeViewController', req, res, next);
        })
        .get(function(req, res, next) {
            _handleRequest('view/homeViewController', req, res, next);
        });

    expressApp.get('/apperror/:cobAppName/', function (req, res, next) {
        _handleRequest('view/errorViewController', req, res, next);
    });

    expressApp.get('/authenticate/:cobAppName/logout/', function (req, res, next) {
        _handleRequest('common/logoutController', req, res, next);
    });

    expressApp.get('/authenticate/:cobAppName/keepSessionAlive/', function (req, res, next) {
        _handleRequest('common/keepSessionAliveController', req, res, next);
    });

    if (appConfig.get('authTestingEnabled') === true) {
        expressApp.get(['/','/authtest/:cobAppName/'], function (req, res, next) {
            _handleRequest('view/loginViewController', req, res, next);
        });
        expressApp.get(['/','/authtest/:cobAppName/:app/'], function (req, res, next) {
            _handleRequest('view/loginViewController', req, res, next);
        });
    }

    if( appConfig.get('enableCSPReport') === true ) {
        expressApp.post('/csp-report/', function (req, res, next) {
            _handleRequest('common/cspReportController', req, res, next);
        });
    }

    expressApp.get(['/node','/status/index.html'], function (req, res, next) {
        _handleRequest('view/indexViewController', req, res, next);
    });

    // Handling 404 error codes
    expressApp.all('/*', function (req, res, next) {
        logger.error('Invalid url access', req.path);
        res.end(global.defaultErrorMessage);
    });
}

var _handleRequest = (controllerPath, req, res, next) => {
    try {
        // setting cobAppName in logger prefix
        req.attr.loggerPrefix = req.attr.loggerPrefix.replace('COB_APP', req.params.cobAppName);
        let controller = require('./controllers/' + controllerPath).getInstance(req, res);
        if (controller) {
            controller.initialize(req, res);
            ycontext.createContext(req, res)
                .then((context) => {
                    return controller.validate(context)
                        .then((data) => {
                            if (_.isEmpty(data)) {
                                try {
                                    controller.handle(context, next);
                                } catch (e) {
                                    logger.error(req.attr.loggerPrefix, "Controller.handle is failed for path", req.path);
                                    next(e);
                                }
                            }
                        })
                        .catch(_err => {
                            logger.error(req.attr.loggerPrefix, "Validation is failed for path", req.path);
                            next(_err);
                        })
                })
                .catch(_err => {
                    logger.error(req.attr.loggerPrefix, "Context initilization is failed for path", req.path);
                    next(_err);
                })
        } else {
            logger.error(req.attr.logger, 'Invalid access url', req.path);
            next(new TechError("INVALID_ACCESS"));
        }
    } catch (e) {
        logger.error(req.attr.loggerPrefix, 'Routes - Uncaught Error : ', e);
        next(new TechError("UNCAUGHT_ERROR"));
    }
}

exports.initialize = initialize;