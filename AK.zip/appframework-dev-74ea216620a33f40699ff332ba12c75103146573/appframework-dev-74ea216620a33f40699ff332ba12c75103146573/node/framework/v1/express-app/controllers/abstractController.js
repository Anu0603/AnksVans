module.paths = module.parent.paths;

class AbstractController {

    initialize(req, res) {}

    validate(context) {
         return Promise.resolve({});
    }

    handle(context) {
        throw "Handle Method is not implemented";
    }
}

module.exports = AbstractController;