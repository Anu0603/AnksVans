module.paths = module.parent.paths;

const path = require('path');

const AbstractResourceController = require('./abstractResourceController');
const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));
const resourceCompiler = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'build-modules/resource-compiler'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

class jsResourceController extends AbstractResourceController {

    constructor() {
        super();
    }

    initialize(req, res) {
    	super.initialize(req, res);
    }

    getResourceContent(context) {
        let resourcePath = context.get('req').attr.resourcePath;
        let resources = this.getResources(context, resourcePath);
        return resourceCompiler.minifyJS(context.getBrandContext().getAppContext(), resources)
            .then(content => {
                return { data : content };
            })
    }

    getContentType(req) {
        return 'text/javascript';
    }

    getResourceCacheKey(req) {
        var resourceCacheKey = super.getResourceCacheKey(req);
        if( req.query.cjs != '1' ) {
            if( !appConfig.get('developmentMode') ) {
                resourceCacheKey = req.attr.resourcePath;
            }
            req.attr.resourceCacheFolder = 'common';
        }
        return resourceCacheKey;
    }

    getResourceCacheFolder(context) {
        return context.get('req').attr.resourceCacheFolder || super.getResourceCacheFolder(context);
    }

    getResources(context, resourcePath) {
        let resources = [];
        if( context.get('req').query.cjs == '1' ) {
            if( context.get('req').query.polyfill == '1' ) {
                resources.push(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'public/js/polyfill.min.js'))
            }
        }
        resources.push(path.join(global.paths.BLOCK_APP_PATH, resourcePath));
        return resources;
    }
}

module.exports = jsResourceController;