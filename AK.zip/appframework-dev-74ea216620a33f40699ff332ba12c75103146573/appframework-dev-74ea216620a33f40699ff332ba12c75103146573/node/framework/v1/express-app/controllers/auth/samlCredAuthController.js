module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');
const qs = require('querystring');

const AbstractAuthController = require('./abstractAuthController');
const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));
const { LoginError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));
const ProviderTypes = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest/config/provider-types'));

class SamlCredAuthController extends AbstractAuthController {

    constructor() {
        super();
        this.type = 'saml';
    }

    initialize(req, res) {
        super.initialize(req, res);
        if( _.isEmpty(req.attr.eparams) ) {
            var samlTargetUrl =  req.body.RelayState || req.body.TARGET;

            if( !_.isEmpty(samlTargetUrl) ) {
                let queryParams = samlTargetUrl.split('?')[1];
                if( !_.isEmpty(queryParams) ) {
                    logger.debug(req.attr.loggerPrefix, "SAML Query Params: ", queryParams);
                    req.attr.eparams = qs.parse(queryParams);
                }
            }
        }
        this.updateQueryParams(req);
    }

    
    validate(context) {
        return super.validate(context)
            .then(() => {
                let req = context.get('req');
                let samlIssuer = req.body.issuerId || context.get('issuerId');
                if( _.isEmpty(samlIssuer) ) {
                    logger.error(context.loggerPrefix, "Saml Issuer is Mandatory");
                    throw new LoginError('EMPTY_SAML_ISSUER', { loginType: this.type });
                } else {
                    req.body.samlIssuer = samlIssuer;
                }

                let samlResponse = req.body.samlResponse || req.body.SAMLResponse;
                if (_.isEmpty(samlResponse)) {
                    logger.error(context.loggerPrefix, "Saml Response is mandatory.");
                    throw new LoginError('EMPTY_SAML_RESPONSE', { loginType: this.type });
                } else {
                    req.body.samlResponse = samlResponse;
                }

                let samlsource = req.body.source || context.get('source');
                if (_.isEmpty(samlsource)) {
                    logger.error(context.loggerPrefix, "Saml Source is mandatory.");
                    throw new LoginError('EMPTY_SAML_SOURCE', { loginType: this.type });
                } else {
                    req.body.samlsource = samlsource;
                }

                return {};
            });
    }

    constructRequestData(context) {
        var req = context.get('req');
        var inputReq = { url: "/v1.1/user/finAppLogin", serviceType : ProviderTypes.YSL, headers : {} };
        inputReq.headers['x-request-source'] = yutils.getYslNodeHeader();
        inputReq.data = { "issuer" : req.body.samlIssuer, "samlResponse" : req.body.samlResponse, "source" : req.body.samlsource };
        return inputReq;
    }
}

module.exports = SamlCredAuthController;