
module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');
const qs = require('querystring');

const AbstractViewController = require("./abstractViewController");
const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));
const cookieHelper = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'common/cookie-helper'));
const errorHandler = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler'));
const { SessionError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));
const internalProviderService = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/internal-provider'));
const ProviderTypes = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest/config/provider-types'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

var newrelic, enableNewRelic = false, homeViewController;

if( appConfig.get('enableNewRelic') === true ) {
    newrelic = require('newrelic');
    enableNewRelic = true;
}

class HomeViewController extends AbstractViewController {

    static getInstance(req, res) {
        if( !homeViewController ) {
            homeViewController = new HomeViewController()
        }
        return homeViewController;
    }

    constructor() {
        super();
        this.homeViewPath = path.join(__dirname, '../../views/home.hbs');
        this.demoViewPath = path.join(__dirname, '../../views/demo.hbs');
    }

    initialize(req, res) {
        super.initialize(req, res);
        req.attr.app = req.params.app;
    }

    validate(context) {
        return super.validate(context)
            .then(() => {
                let token = context.get('req').query._s;
                if( _.isEmpty(token) ) {
                    if( appConfig.get('stub') === true ) {
                        return {};
                    } else {
                        logger.error(context.loggerPrefix, '_s token is mandatory to access application');
                        throw new SessionError("MANDATORY_FIELDS");
                    }
                } else {
                    let _token = context.generateSessionToken(context.getUserContext().userId);
                    if( token !== _token ) {
                        logger.error(context.loggerPrefix, "Session Ids are not matched", token, _token);
                        throw new SessionError("MISMATCH_SESSION");
                    } else {
                        return {};
                    }
                }
            })
    }

    handle(context, next) {

        var inputReq;
        if( !appConfig.get('yslAuth') ) {
            let headers = { 'Authorization' : 'rsession=' + cookieHelper.getCookie(context.get('req'), 'rsession') }
            inputReq = { url : '/v1.0/authenticator/renew', headers : headers, data : {}, serviceType : ProviderTypes.REST };
        } else {
            inputReq = { url : '/v1.1/user/finAppRenewSession', data : {}, method : 'PUT', serviceType : ProviderTypes.YSL };
        }

        return internalProviderService.makeCall(context, inputReq)
            .then(_httpResponse => {
                if( context.get('req').params.app == 'demo' ) {
                    let viewData = {};
                    viewData.cobAppName = context.get('cobAppName');
                    viewData.token = context.get('req').query._s;
                    viewData.rdata = cookieHelper.getCookie(context.get('req'), 'rsession');
                    viewData.callbackUrl = context.get('req').query.callbackUrl;
                    let url = '/app/' + context.get('cobAppName') + '/fastlink/';
                    let urlParams = {};
                    urlParams._s = context.generateSessionToken(context.getUserContext().userId, 'fastlink');
                    urlParams._utid = context.get('req').query._utid;
                    viewData.fastlinkUrl = url + '?' + qs.stringify(urlParams);
                    logger.info(context.loggerPrefix, "Rendering Demo Page");
                    context.get('res').render(this.demoViewPath, { viewData : viewData, context : context });
                } else {
                    let viewData = { userInfo : JSON.stringify(context.getUserContext()) };
                    viewData.cobAppName = context.get('cobAppName');
                    viewData.newrelicTimingHeader = ( enableNewRelic ) ? newrelic.getBrowserTimingHeader() : '';
                    viewData.apiParams = this._constructApiParams(context);
                    viewData.baseParams = this._constructBaseParams(context);
                    viewData.cookieDisabled = !context.get('req').cookies.isCookie;
                    viewData.browser = yutils.getBrowser(context.get('req'));
                    viewData.postExtraParams = context.get('req').body.postExtraParams || '{}';
                    if( context.getParam('ssoErrorHandleEnabled') ) {
                        viewData.clientKeepAliveUrl = errorHandler.getSSORedirectUrlConfig(context).keepalive_url || '';
                    }
                    logger.info(context.loggerPrefix, "Rendering Home Page");
                    context.get('res').render(this.homeViewPath, { viewData : viewData, context : context });
                }
            })
            .catch(_err => {
                logger.error(context.loggerPrefix, "Session validation is failed.");
                next(_err);
            });
    }

    _constructApiParams(context) {
        let params = {};
        params['token'] = context.get('req').query._s;
        return qs.stringify(params);
    }

    _constructBaseParams(context) {
        let params = {};
        let postSource = context.get('req').query.postSource;
        if( postSource ) {
            params['postSource'] = postSource;
        }
        let ssoDomain = context.get('req').query.ssoDomain;
        if( ssoDomain ) {
            params['ssoDomain'] = ssoDomain;
        }
        params['app'] = context.get('app');
        params['_utid'] = context.get('req').query._utid;
        return qs.stringify(params);
    }
}

module.exports = HomeViewController;