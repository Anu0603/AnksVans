module.paths = module.parent.paths;

const _ = require('underscore');
const path = require('path');

const AbstractAuthController = require('./abstractAuthController');
const { LoginError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));
const ProviderTypes = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest/config/provider-types'));

class OauthCredAuthController extends AbstractAuthController {

    constructor() {
        super();
        this.type = 'oauth';
    }

    validate(context) {
        return super.validate(context)
            .then(() => {
                if (_.isEmpty(context.get('req').body.accessToken)) {
                    logger.error("OauthAccess Token is mandatory.");
                    throw new LoginError('EMPTY_TOKEN', { loginType: this.type });
                } else if( context.get('req').body.accessToken.indexOf('Bearer') != 0 ) {
                    logger.error("Bearer is missing in oauthToken.");
                    throw new LoginError('INVALID_BEARER_TOKEN', { loginType: this.type });
                } else {
                    return {};
                }
            });
    }

    constructRequestData(context) {
        var inputReq = { url: "/v1.1/user/finAppLogin", serviceType : ProviderTypes.APG, headers : {} };
        inputReq.headers['Authorization'] = decodeURIComponent(context.get('req').body.accessToken);
        return inputReq;
    }
}

module.exports = OauthCredAuthController;