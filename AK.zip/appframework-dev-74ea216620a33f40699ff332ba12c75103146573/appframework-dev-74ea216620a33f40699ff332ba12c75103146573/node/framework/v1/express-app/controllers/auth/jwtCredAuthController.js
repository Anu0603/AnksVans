module.paths = module.parent.paths;

const _ = require('underscore');
const path = require('path');

const ProviderTypes = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest/config/provider-types'));
const { LoginError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));

const AbstractAuthController = require('./abstractAuthController');

class JwtCredAuthController extends AbstractAuthController {

    constructor() {
        super();
        this.type = 'jwt';
    }

    validate(context) {
        return super.validate(context)
            .then(() => {
                if (_.isEmpty(context.get('req').body.jwtToken)) {
                    logger.error("JWT Token is mandatory.");
                    throw new LoginError('EMPTY_TOKEN', { loginType: this.type });
                }  else if( context.get('req').body.jwtToken.indexOf('Bearer') != 0 ) {
                    logger.error("Bearer is missing in jwtToken.");
                    throw new LoginError('INVALID_BEARER_TOKEN', { loginType: this.type });
                } else {
                    return {};
                }
            });
    }

    constructRequestData(context) {
        var inputReq = { url: "/v1.1/user/finAppLogin", serviceType : ProviderTypes.YSL, headers : {} };
        inputReq.headers['Authorization'] = decodeURIComponent(context.get('req').body.jwtToken);
        return inputReq;
    }
}

module.exports = JwtCredAuthController;