
module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const AbstractController = require("../abstractController");
const cookieHelper = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'common/cookie-helper'));
const internalProviderService = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/internal-provider'));
const { SessionError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));

let keepSessionAliveController;

class KeepSessionAliveController extends AbstractController {

    static getInstance(req, res) {
        if (!keepSessionAliveController) {
            keepSessionAliveController = new KeepSessionAliveController()
        }
        return keepSessionAliveController;
    }

    initialize(req, res) {
        super.initialize(req, res);
    }

    validate(context) {
        return super.validate(context)
            .then(() => {
                let sessionToken = cookieHelper.getCookie(context.get('req'), 'rsession');
                if (_.isEmpty(sessionToken)) {
                    logger.error(context.loggerPrefix, 'session-token is mandatory to renew the session.');
                    throw new SessionError("MANDATORY_FIELDS");
                } else {
                    return {};
                }
            });
    }

    handle(context, next) {

        logger.debug(context.loggerPrefix, "KeepAlive API request initiated ....")

        let reqInput = {
            url : '/v1.1/user/finAppRenewSession',
            method : 'PUT'
        }
        internalProviderService.yslCall(context, reqInput)
            .then(_httpResponse => {
                logger.info(context.loggerPrefix, "User's session is renewed successfully.")
                context.get('res').status(204).end();
            }). catch(_error => {
                logger.error(context.loggerPrefix, "Renew user's session is failed ");
                next(_error)
            });
    }
}

module.exports = KeepSessionAliveController;