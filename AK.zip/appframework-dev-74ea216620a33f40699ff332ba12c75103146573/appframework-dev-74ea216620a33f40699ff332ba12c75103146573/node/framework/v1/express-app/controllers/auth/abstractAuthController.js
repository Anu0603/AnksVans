module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');
const qs = require('querystring');

const AbstractController = require("../abstractController");
const cookieHelper = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'common/cookie-helper'));
const internalProviderService = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/internal-provider'));
const { TechError, LoginError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));

const INSTANCES = {};

class AbstractAuthController extends AbstractController {

    static getInstance(req, res) {

        var controllerName;

        if (req.body.authType == 'pwd' || !_.isUndefined(req.body.password)) {
            controllerName = 'pwdCredAuthController';
        } else if (!_.isUndefined(req.body.jwtToken)) {
            controllerName = 'jwtCredAuthController';
        } else if (!_.isUndefined(req.body.accessToken)) {
            controllerName = 'oauthCredAuthController';
        } else if (!_.isUndefined(req.body.rsession)) {
            controllerName = 'sessionCredAuthController';
        } else if ( !_.isUndefined(req.body.samlResponse) || !_.isUndefined(req.body.SAMLResponse) ) {
            controllerName = 'samlCredAuthController';
        } else {
            logger.error("Invalid authentication request", req.body);
        }

        let instance = INSTANCES[controllerName];
        if (!INSTANCES[controllerName]) {
            let Controller = require(path.resolve(__dirname, controllerName));
            INSTANCES[controllerName] = instance = new Controller(req, res);
        }

        logger.debug(req.attr.loggerPrefix, 'Auth Controller is ', controllerName);
        return instance;
    }

    constructor() {
        super();
        this.postDataViewPath = path.join(__dirname, '../../views/post-data.hbs');
    }

    initialize(req, res) {
        super.initialize(req, res);
        cookieHelper.clearAllCookies(req, res);
        req.attr.eparams = qs.parse(req.body.extraParams || '');
        logger.info(req.attr.loggerPrefix, 'Extra Parameters ', req.attr.eparams);
        req.attr.view = true;
        req.attr.app = req.params.app;
        this.updateQueryParams(req);
    }

    validate(context) {
        return super.validate(context)
            .then(() => {
                let appName = context.get('app');
                if( _.isEmpty(appName) || context.getParam("supportedApps").indexOf(appName) == -1 ) {
                    logger.error(context.loggerPrefix, "%s app is not suppored for cobrand %s", appName, context.get('cobAppName'))
                    throw new TechError("INVALID_APP_ACCESS", { appName : appName });
                } else {
                    return {};
                }
            });
    }

    handle(context, next) {
        let req = context.get('req');
        let reqInput = this.constructRequestData(context);        
        
        internalProviderService.makeCall(context, reqInput)
            .then(_httpResponse => {
                let data = JSON.parse(_httpResponse.data);
                context.loggerPrefix = req.attr.loggerPrefix = req.attr.loggerPrefix.replace("u0000", data.userId)
                logger.info(req.attr.loggerPrefix, 'User is logged in successfully', data);
                this.parsePostExtraParams(context);
                this.setUserLevelCookies(context, data);
                if( req.params.app == 'demo' ) {
                    context.get('res').redirect(this.constructAppUrl(context, data));
                } else {
                    let viewData = {};
                    viewData.postExtraParams = JSON.stringify(req.attr.postExtraParams);
                    viewData.appUrl = this.constructAppUrl(context, data);
                    viewData.rdata = cookieHelper.getCookie(req, 'rsession');
                    viewData.udata = cookieHelper.getCookie(req, 'udata');
                    viewData.cobAppName = context.get('cobAppName');
                    context.get('res').render(this.postDataViewPath, { viewData: viewData, context : context });
                }
            })
            .catch(error => {
                next(new LoginError(error, { loginType: this.type }));
            })
    }

    updateQueryParams(req) {
        var eparams = req.attr.eparams;
        if( !_.isEmpty(eparams) ) {
            if( !_.isEmpty(eparams.postSource) ) {
                req.query.postSource = eparams.postSource;
            }

            if( !_.isEmpty(eparams.ssoDomain) ) {
                req.query.ssoDomain = eparams.ssoDomain;
            }
        }
    }

    setUserLevelCookies (context, data) {
        let userData = {};
        userData.prefs = data.i18nBean || data.preferences;
        userData.segmentInfo = data.segmentInfo || {};
        if( !_.isEmpty(userData.segmentInfo.segmentName) ) {
            if( context.getParam('segmentBrandType') == 'ID' ) {
                userData.segmentInfo.segmentBrandName = userData.segmentInfo.segmentId;
            } else {
                userData.segmentInfo.segmentBrandName = userData.segmentInfo.segmentName;
            }
        }
        userData.userId = data.userId;
        let cookieUserData = JSON.stringify(userData);
        cookieHelper.setCookie(context.get('res'), 'udata', cookieUserData);
        context.get('req').cookies.udata = cookieUserData;
        cookieHelper.setCookie(context.get('res'), 'rsession', data.rsession);
        context.get('req').cookies.rsession = data.rsession;
        cookieHelper.setCookie(context.get('res'), 'isCookie', '1', { httpOnly: false });
    }
    
    constructAppUrl (context, data) {
        let url = '/app/' + context.get('cobAppName') + '/' + context.get('app');
        let urlParams = context.get('req').attr.eparams;
        urlParams._s = context.generateSessionToken(data.userId);
        urlParams._utid = context.get('req').attr._utid;
        return url + '/?' + qs.stringify(urlParams);
    }

    parsePostExtraParams (context) {
        var req = context.get('req');
        var eparams = req.attr.eparams;
        req.attr.postExtraParams = {};
        if( !_.isEmpty(eparams) ) {
            context.getParam('postQueryParams').map(pname => {
                req.attr.postExtraParams[pname] = eparams[pname];
                delete eparams[pname];
            });
        }
    }
}

module.exports = AbstractAuthController;