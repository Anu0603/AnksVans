module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');
const qs = require('querystring');

const AbstractAuthController = require('./abstractAuthController');
const cookieHelper = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'common/cookie-helper'));
const internalProviderService = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/internal-provider'));
const { LoginError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));
const ProviderTypes = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest/config/provider-types'));
const finappConfig = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'config/finapp-config'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

class PwdCredAuthController extends AbstractAuthController {

    constructor() {
        super();
        this.type = 'pwd';
    }

    initialize(req, res) {
        req.attr.view = true;
        // no implementation
    }

    validate(context) {
        if (_.isEmpty(context.get('req').body.login) || _.isEmpty(context.get('req').body.password)) {
            logger.error("User Credentails are mandatory.");
            throw new LoginError('EMPTY_CREDENTAILS', { loginType: this.type });
        } else {
            return Promise.resolve({});
        }
    }

    handle(context, next) {
        let req = context.get('req');
        let reqInput = this.constructRequestData(context);        
        
        internalProviderService.makeCall(context, reqInput)
            .then(_httpResponse => {
                
                let userSession;
                if (_httpResponse.headers && _httpResponse.headers["set-cookie"]) {
                    // setting server cookies into browser cookies - start
                    let scookies = _httpResponse.headers["set-cookie"];
                    scookies.forEach(val => {
                        var scookie = val.split(';')[0].split('=');
                        if (scookie) {
                            // scookie[1] value is '"value"' - decode it and remove double quotes
                            logger.debug(context.loggerPrefix, 'Server Cookies ', scookie);
                            if (scookie[0] == 'rsession') {
                                let scookieVal = decodeURIComponent(scookie[1].substr(1, scookie[1].length - 2));
                                userSession = scookieVal;
                            }
                        }
                    });
                }

                if( !appConfig.get('yslAuth') ) {
                    req.attr.eparams = qs.parse(req.body.extraParams || '');
                    let data = JSON.parse(_httpResponse.data);
                    data.rsession = userSession;
                    context.loggerPrefix = req.attr.loggerPrefix = req.attr.loggerPrefix.replace("u0000", data.userId)
                    logger.info(req.attr.loggerPrefix, 'User is logged in successfully', data);

                    this.setUserLevelCookies(context, data);
                    cookieHelper.setCookie(context.get('res'), 'isCookie', '1', { httpOnly: false });
                    context.get('res').redirect(this.constructAppUrl(context, data));
                } else {
                    logger.info(req.attr.loggerPrefix, 'User is logged in successfully');
                    let viewData = { pwdLogin : true };
                    viewData.extraParams = req.body.extraParams;
                    viewData.appUrl = req.url;
                    viewData.rdata = userSession;
                    context.get('res').render(this.postDataViewPath, { viewData: viewData, context : context });
                }
            })
            .catch(error => {
                next(new LoginError(error, { loginType: this.type }));
            })
    }

    constructRequestData(context) {
        var req = context.get('req');
        var inputReq = { url: "/v1.0/authenticator/authenticate", isFormData : true, serviceType : ProviderTypes.REST };
        inputReq.data = {};
        inputReq.data['finAppId'] = finappConfig.getFinappId(req.params.app);
        inputReq.data['cobSessionToken'] = '12345';
        inputReq.data['login'] = req.body.login;
        inputReq.data['password'] = req.body.password;
        return inputReq;
    }
}

module.exports = PwdCredAuthController;