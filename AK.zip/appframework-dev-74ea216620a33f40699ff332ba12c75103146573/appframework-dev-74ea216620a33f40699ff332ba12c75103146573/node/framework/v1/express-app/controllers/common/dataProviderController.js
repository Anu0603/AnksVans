
module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const AbstractController = require("../abstractController");
const { TechError, SessionError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));
const serviceRegistry = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/service-registry'));


const appConfig = require(global.paths.APP_CONFIG_PATH);
let dataProviderController;

class DataProviderController extends AbstractController {

    static getInstance(req, res) {
        if (!dataProviderController) {
            dataProviderController = new DataProviderController()
        }
        return dataProviderController;
    }

    initialize(req, res) {
        super.initialize(req, res);
        req.attr.dataAccess = true;

        res.setHeader('Content-Type', 'application/json');
    }

    validate(context) {
        return super.validate(context)
            .then(() => {
                let token = context.get('req').query.token;
                if (_.isEmpty(token)) {
                    if( appConfig.get('stub') === true ) {
                        return {};
                    } else {
                        logger.error(context.loggerPrefix, 'api-token is mandatory to access api');
                        throw new SessionError("EMPTY_TOKEN");
                    }
                } else {
                    
                    let _token = context.generateSessionToken(context.getUserContext().userId);
                    if( token !== _token ) {
                        logger.error(context.loggerPrefix, "Session Ids are not matched for accessing api", token, _token);
                        throw new SessionError("SESSION_MISMATCH");
                    } else {
                        return {};
                    }
                }
            })
    }

    handle(context, next) {

        let req = context.get('req');

        try {
            let servicePath = req.path;
            let service = serviceRegistry.getDataService(context, servicePath);
            let _validateionError;
            if (service) {
                logger.debug(context.loggerPrefix, "DataService API is initaited : ", servicePath);
                service.call(this, context, req.body)
                    .then(_res => {
                        logger.debug(context.loggerPrefix, "DataService is API completed - ", servicePath);
                        context.get('res').end(_res.data);
                    })
                    .catch(_err => {
                        logger.error(context.loggerPrefix, "DataService API is failed - ", servicePath);
                        next(_err);
                    });
            } else {
                logger.error(context.loggerPrefix, "Invalid data-service path : ", servicePath);
                _validateionError = new Error("INVALID_API_SERVICE", servicePath);
                next(_validateionError);
            }

        } catch (e) {
            logger.error(context.loggerPrefix, "DataService API is failed due to uncaugh error - ", context.get('req').path);
            next(new TechError("UNCAUGHT_ERROR", e));
        }
    }
}

module.exports = DataProviderController;