module.paths = module.parent.paths;

const AbstractResourceController = require('./abstractResourceController');

const MIME_TYPES = {
    "image" : { "jpg": "jpeg", "svg": "svg+xml", "ico" : "x-icon" },
    "font" : { "eot" : "x-font-eot", "svg" : "x-font-svg", "ttf" : "x-font-ttf", "woff" : "x-font-woff", "woff2" : "x-font-woff2" }
};

class AssetsResourceController extends AbstractResourceController {

    constructor() {
        super();
    }

    initialize(req, res) {
        super.initialize(req, res);
    }

    getResourceCachePath(context) {
        return new Promise(resolve => {
            let cachePath = context.getBrandContext().getAppContext().
                    getAssetPath(context.get('req').attr.resourcePath, this.resourceType);
            resolve({ cachePath : cachePath });
        })
       
    }

    getContentType(req) {
        var contentType;
        var extension = req.attr.resourcePath.split('.').pop().toLowerCase();
        if( req.params.type == 'img' ) {
            contentType =  'image/' + ( MIME_TYPES['image'][extension] || extension );
        } else {
            contentType = 'application/' + ( MIME_TYPES['font'][extension] || 'x-font-'+extension );
        }
        return contentType;
    }
}

module.exports = AssetsResourceController;