
module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const AbstractController = require("../abstractController");
const cookieHelper = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'common/cookie-helper'));
const internalProviderService = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/internal-provider'));
const { SessionError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));

let logoutController;

class LogoutController extends AbstractController {

    static getInstance(req, res) {
        if (!logoutController) {
            logoutController = new LogoutController()
        }
        return logoutController;
    }

    initialize(req, res) {
        super.initialize(req, res);
        req.attr.view = true;
    }

    validate(context) {
        return super.validate(context)
            .then(() => {
                let sessionToken = cookieHelper.getCookie(context.get('req'), 'rsession');
                if (_.isEmpty(sessionToken)) {
                    logger.error(context.loggerPrefix, 'session-token is mandatory to renew the session.');
                    throw new SessionError("MANDATORY_FIELDS");
                } else {
                    return {};
                }
            });
    }

    handle(context, next) {

        logger.debug(context.loggerPrefix, "Logout API request initiated ....")

        var reqInput = {
            url : '/v1.1/user/logout',
            method : 'POST'
        }
        internalProviderService.yslCall(context, reqInput)
            .then(_httpResponse => {
                logger.info(context.loggerPrefix, "User is logged out successfully.")
                cookieHelper.clearAllCookies(context.get('req'), context.get('res'));

                let err;
                if( context.get('req').query.sessionTimedOut == 'true' ) {
                    logger.info(context.loggerPrefix, "User session is timedout.");
                    err = new SessionError("USER_SESSION_TIMED_OUT");
                } else {
                    err = new SessionError('USER_LOGOUT');
                }

                next(err);
            }). catch(_error => {
                logger.error(context.loggerPrefix, 'User Logout is failed ', _error);
                next(_error);
            });
    }
}

module.exports = LogoutController;