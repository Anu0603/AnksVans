module.paths = module.parent.paths;

const path = require('path');
const fs = require('fs');

const AbstractResourceController = require('./abstractResourceController');

class AnalyticsResourceController extends AbstractResourceController {

    constructor() {
        super();
    }

    initialize(req, res) {
        super.initialize(req, res);
        res.setHeader('Content-Type', 'text/javascript');
        this.analyticsFolderPath = path.join(global.paths.FRAMEWORK_VERSION_PATH, 'public/js/analytics');
    }

    handle(context, next) {
        var appContext = context.getBrandContext().getAppContext();
        logger.info(context.loggerPrefix, "Cobrand Resouce Controller handle method");

        var anlyticJsContent = [];
        anlyticJsContent.push(fs.readFileSync(path.join(this.analyticsFolderPath, 'test1.js')));
        anlyticJsContent.push(fs.readFileSync(path.join(this.analyticsFolderPath, 'test2.js')));
        var content = anlyticJsContent.join(';');
        context.get('res').end(content);
        // push required files based on 
    }
}

module.exports = AnalyticsResourceController;