
module.paths = module.parent.paths;

const path = require('path');
const fs = require('fs');

const AbstractViewController = require("./abstractViewController");
const { TechError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));

const appConfig = require(global.paths.APP_CONFIG_PATH);
const SERVER_UP_RUNNING_TEXT = "<b>Node Server is up and running.</b>";

let nodeIndexController, cachedHtml = '';

class NodeIndexController extends AbstractViewController {

    static getInstance(req, res) {
        if (!nodeIndexController) {
            nodeIndexController = new NodeIndexController()
        }
        return nodeIndexController;
    }

    initialize(req, res) {
        super.initialize(req, res);
    }

    handle(context, next) {

        var hostName = context.get('req').get('host');
        if( hostName.indexOf('localhost') == 0 ) {
            context.get('res').send(SERVER_UP_RUNNING_TEXT).status(200);

        } else if ( hostName.match(/[0-9]*\.[0-9]*\.[0-9]*\.[0-9]*/) ) {

            if( !cachedHtml ) {

                let dockerName = ( appConfig.get('devOpsEnabled') === true ) ? ' (D)' : '';

                let htmlStrArray = [SERVER_UP_RUNNING_TEXT];

                htmlStrArray.push('<div style="color:white;font-family:monospace"><h2><u>Configured CobApps' + dockerName + ' :</u></h2><ul>')
                let cobApps = appConfig.getAllCobApps();

                for(let key in cobApps) {
                    let cobAppInfo = cobApps[key];

                    let htmlStr = '<li><h3>' + key +  '</h3><ul>';
                    let brandsPath = path.join(global.paths.BRANDS_PATH, cobAppInfo.brandId+"-"+cobAppInfo.applicationId);
                    htmlStr += '<li><h4 style="display:inline">Brand ID : </h4> : '+ cobAppInfo.brandId + '</li>'
                    htmlStr += '<li><h4 style="display:inline">Application ID : </h4> : '+ cobAppInfo.applicationId + '</li>'
                    htmlStr += '<li><h4 style="display:inline">Label : </h4> : '+ ( fs.existsSync(brandsPath) === true ? 'Y' :  'N' ) + '</li>'
                    htmlStr += '<li><h4 style="display:inline">isChannel : </h4> : '+ ( cobAppInfo.isChannel ? 'Y' : 'N' ) + '</li>'
                    htmlStr += '</ul><br/></li>'
                    htmlStrArray.push(htmlStr);
                }
                htmlStrArray.push('</ul></div>');

                cachedHtml = htmlStrArray.join('');
            }

            context.get('res').send(cachedHtml).status(200);
        } else {
            logger.error('Devops Status - Invalid Access', hostName);
            throw new TechError('INVALID_ACCESS');
        }
    }
}

module.exports = NodeIndexController;