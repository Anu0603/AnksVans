module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');
const AbstractResourceController = require('./abstractResourceController');
const { TechError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));
const internalProviderService = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/internal-provider'));
const appConfig = require(global.paths.APP_CONFIG_PATH);

class SiteImageResourceController extends AbstractResourceController {

    constructor() {
        super();
        this.imageExpireTime = appConfig.get('siteImageExpireTime');
    }

    initialize(req, res) {
        super.initialize(req, res);
    }

    validate(context) {
        return super.validate(context)
            .then(() => {
                if(_.isEmpty(context.get('req').query.contentType) || _.isEmpty(context.get('req').query.cdnImageUrl)) {
                    logger.error("CDN Image url and contentType are mandatory", context.get('req').query.cdnImageUrl);
                    throw new TechError("MANDATORY_FIELDS");
                } else if (context.get('req').query.cdnImageUrl.indexOf(appConfig.get('cdnUrl')) != 0) {
                    logger.error("Invalid cdnFavicon url", context.get('req').query.cdnImageUrl);
                    throw new TechError("INVALID_ACCESS");
                }
                return {};
            });
    }

    getResourceContent(context) {
        let cdnImageUrl = context.get('req').query.cdnImageUrl;
        logger.info(context.loggerPrefix, 'Cdn image url', cdnImageUrl, context.get('req').attr.resourcePath);
        return internalProviderService.vendorCall(context, { url: cdnImageUrl, data: {}, method: 'GET', dataType : 'binary' })
            .then(_httpResponse => {
                let lastModifiedTime = _httpResponse.headers['last-modified'];
                return { data : _httpResponse.data, fileType : 'binary', lastModifiedTime : lastModifiedTime }
            })
            .catch(_err => {
                logger.error(context.loggerPrefix, "Logo/Favicon download is failed", context.get('req').attr.resourcePath);
                throw _err;
            })
    }

    getContentType(req) {
        let contentType = 'image/' + req.query.contentType;
        logger.info(req.attr.loggerPrefix, 'Setting content type is ', contentType)
        return contentType;
    }

    getResourceCacheKey(req) {
        return req.attr.resourcePath + ":" + req.query.cdnImageUrl;
    }

    getResourceCacheFolder(context) {
        return 'common';
    }

    isExpired(context, cacheValue) {
        var expired = super.isExpired(context, cacheValue);
        if( context.get('req').query.cache == '1' ) {
            expired = true;
            if( cacheValue ) {
                var lastUpdatedTime = cacheValue.lastUpdatedTime;
                var currentTime = new Date().getTime();
                let timeDiff = currentTime - lastUpdatedTime;
                if( timeDiff < this.imageExpireTime ) {
                    expired = false;
                } else {
                    logger.info("Site-image is expired", lastUpdatedTime, currentTime);
                }
            } else {
                logger.info("Site-image-cache is empty");
            }
        }
        return expired;
    }
}

module.exports = SiteImageResourceController;