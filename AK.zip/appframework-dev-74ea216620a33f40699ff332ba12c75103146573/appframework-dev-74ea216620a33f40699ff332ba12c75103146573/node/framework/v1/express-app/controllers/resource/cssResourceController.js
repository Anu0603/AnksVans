module.paths = module.parent.paths;

const path = require('path');

const AbstractResourceController = require('./abstractResourceController');
const resourceCompiler = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'build-modules/resource-compiler'));

class cssResourceController extends AbstractResourceController {

    constructor() {
        super();
    }

    initialize(req, res) {
    	super.initialize(req, res);
    }

    getResourceContent(context) {
        let resourcePath = context.get('req').attr.resourcePath;
        return resourceCompiler.compileSCSS(context.getBrandContext().getAppContext(), resourcePath)
            .then(content => {
                return { data : content };
            })
    }

    getContentType(req) {
        return 'text/css';
    }
}

module.exports = cssResourceController;