module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const AbstractAuthController = require('./abstractAuthController');
const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));
const { LoginError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));
const ProviderTypes = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest/config/provider-types'));

class SessionCredAuthController extends AbstractAuthController {

    constructor() {
        super();
        this.type = 'rsession';
    }

    validate(context) {
        return super.validate(context)
            .then(() => {
                if (_.isEmpty(context.get('req').body.rsession)) {
                    logger.error("Session Token is mandatory.");
                    throw new LoginError('EMPTY_TOKEN', { loginType: this.type });
                } else {
                    return {};
                }
            });
    }

    constructRequestData(context) {
        var userSession = context.get('req').body.rsession;
        var inputReq = { url: "/v1.1/user/finAppLogin", serviceType : ProviderTypes.YSL, headers : {} };
        inputReq.headers['Authorization'] = '{cobSession=token:' + yutils.getYslNodeHeader(userSession) + ',userSession=' + userSession + '}';
        return inputReq;
    }
}

module.exports = SessionCredAuthController;