module.paths = module.parent.paths;

const path = require('path');
const hbs = require('hbs');
const fs = require('fs');

const AbstractResourceController = require('./abstractResourceController');

class brandResourceController extends AbstractResourceController {

    constructor() {
        super();
    }

    initialize(req, res) {
        super.initialize(req, res);
        this.template = hbs.handlebars.compile(fs.readFileSync(path.join(__dirname, '../../views/brand-script.hbs')).toString(), { noEscape: true });
    }

    getResourceContent(context) {
        return new Promise((resolve, reject) => {
            var appContext = context.getBrandContext().getAppContext();
            logger.info(context.loggerPrefix, "Cobrand Resouce Controller handle method");

            let paramsData = appContext.getParams();
            let localeData = appContext.getLocaleStrings();
            let app = context.get('app');

            let brandData = { app: context.get('app'), isParent: context.get('req').query.isParent == "1" };

            if (brandData.isParent) {
                brandData.brandId = context.get('brandId');
                brandData.applicationId = context.get('applicationId');
                brandData.cobAppName = context.get('cobAppName');
            }

            brandData.params = { 'common': paramsData['block.common'], [app]: paramsData['block.' + app] };
            brandData.localeStrings = { 'common': localeData['block.common'], [app]: localeData['block.' + app] };

            try {
                logger.info(context.loggerPrefix, 'compiling brand data', app);
                let content = this.template({ brandData: JSON.stringify(brandData), isParentApp: brandData.isParent });
                resolve({ data: content });
            }
            catch (e) {
                logger.error(context.loggerPrefix, 'Error while writing static variales', e);
                reject(e);
            }
        });
    }

    getContentType(req) {
        return 'text/javascript';
    }

}

module.exports = brandResourceController;