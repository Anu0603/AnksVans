
module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const AbstractController = require("../abstractController");

let cspReportController;

class CspReportController extends AbstractController {

    static getInstance(req, res) {
        if (!cspReportController) {
            cspReportController = new CspReportController()
        }
        return cspReportController;
    }

    handle(context, next) {

        logger.error('CSP Report violated :', context.get('req').body);
        context.get('res').end();
    }
}

module.exports = CspReportController;