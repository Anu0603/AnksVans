module.paths = module.parent.paths;

const path = require('path');
const fs = require('fs');
const zlib = require('zlib')
const crypto = require('crypto');
const _ = require('underscore');

const AbstractController = require("../abstractController");
const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

const CONTROLLERS = {
    "brand": "brandResourceController",
    "css": "cssResourceController",
    "js": "jsResourceController",
    "fonts": "assetsResourceController",
    "font-icon": "assetsResourceController",
    "img": "assetsResourceController",
    "pfile": "pfileResourceController",
    "favicon": "faviconResourceController",
    "site-image": "siteImageResourceController",
    "analytics": "analyticsResourceController",


}
const INSTANCES = {};

global.RESOURCE_CACHE = {};

class AbstractResourceController extends AbstractController {

    static getInstance(req, res) {

        var controllerName = CONTROLLERS[req.params.type];

        logger.debug(req.attr.loggerPrefix, 'Resource Controller is %s for resource type %s', controllerName, req.params.type);

        var instance = INSTANCES[controllerName];

        if (!INSTANCES[controllerName]) {
            if (controllerName) {
                let controllerPath = path.resolve(__dirname, controllerName);
                logger.info(req.attr.loggerPrefix, 'Controller path is ', path.resolve(__dirname, controllerName));
                if (fs.existsSync(controllerPath + ".js")) {
                    let Controller = require(controllerPath);
                    INSTANCES[controllerName] = instance = new Controller(req, res);
                    instance.resourceType = req.params.type;
                    logger.info(req.attr.loggerPrefix, 'Instance is created for controller', controllerName);
                } else {
                    logger.error(req.attr.loggerPrefix, "Controller is not existed", controllerPath);
                }
            } else {
                logger.error(req.attr.loggerPrefix, "Invalid Resource Path", controllerName);
            }
        }

        return instance;
    }

    initialize(req, res) {
        super.initialize();
        req.attr.resourcePath = req.path.substr(req.path.indexOf('/' + req.params.type + '/'));
    }

    handle(context, next) {
        let req = context.get('req');
        let cacheKey = this._getCacheKey(req);
        let cacheValue = this._getResourceCache(cacheKey);
        if (_.isEmpty(cacheValue) || this.isExpired(context, cacheValue)) {
            this.getResourceCachePath(context, cacheValue)
                .then(data => {
                    logger.debug(context.loggerPrefix, 'Cached Resource path', data.cachePath, req.path);
                    data.contentType = this.getContentType(req);
                    cacheValue = this._setResourceCache(cacheKey, data);
                    this._writeResource(context, cacheKey, cacheValue);
                })
                .catch(_err => {
                    logger.error(context.loggerPrefix, 'Constructing data is failed, ', req.path);
                    next(_err);
                })
        } else {
            logger.debug(context.loggerPrefix, 'Cache Value', cacheValue, req.path);
            this._writeResource(context, cacheKey, cacheValue);
        }
    }

    getResourceCachePath(context, cacheValue) {
        return new Promise((resolve, reject) => {
            let req = context.get('req');
            let cacheKey = this._getCacheKey(req);
            let cacheRootFolderPath = this._getResourceCacheRootFolderPath(context);
            let cacheFileFullPath = path.join(cacheRootFolderPath, cacheKey);
            if (!fs.existsSync(cacheFileFullPath) || this.isExpired(context, cacheValue)) {
                logger.info(context.loggerPrefix, 'Cache file doen\'t exist so fetching data of url', req.path);
                this.getResourceContent(context)
                    .then(contentResponse => {
                        yutils.createFolder(cacheRootFolderPath);
                        fs.writeFileSync(cacheFileFullPath, contentResponse.data, contentResponse.fileType);
                        resolve({ cachePath : cacheFileFullPath, lastModifiedTime : contentResponse.lastModifiedTime });
                    })
                    .catch(err => {
                        logger.error(context.loggerPrefix, 'Fetching resource-content is failed, ', req.path);
                        reject(err);
                    })
            } else {
                resolve({ cachePath : cacheFileFullPath });
            }
        })
    }

    getResourceCacheKey(req) {
        return req.url;
    }

    getResourceCacheFolder(context) {
        return appConfig.get('resourceCacheFolder');
    }

    isExpired(context, cacheValue) {
        return false;
    }

    _getCacheKey(req) {
        let resourceCacheKey = this.getResourceCacheKey(req);
        let cacheKey = crypto.createHash('md5').update(resourceCacheKey).digest("hex");
        logger.debug(req.attr.loggerPrefix, 'cacheKey for resource path', resourceCacheKey, req.url);
        return cacheKey;
    }

    _writeResource(context, cacheKey, cacheValue) {

        var req = context.get('req'), res = context.get('res');

        var ifNoneMatch = req.headers['if-none-match'];
        var etag = '"' + cacheValue.hashKey + '"';

        res.setHeader('ETag', '"' + cacheValue.hashKey + '"');
        res.setHeader('Last-Modified', (new Date()).getTime());
        res.setHeader('Content-Type', cacheValue.contentType);
        res.setHeader('Cache-Control', 'public, max-age=31556000')
        res.setHeader("Pragma", "public");
        res.setHeader("Expires", new Date((new Date()).getTime() + 31556000000));

        if (!ifNoneMatch || etag != ifNoneMatch) {
            let cacheFileFullPath = cacheValue.cachePath;
            let fileStream = fs.createReadStream(cacheFileFullPath);

            let acceptEncoding = req.headers['accept-encoding']
            if (!acceptEncoding) {
                acceptEncoding = ''
            }

            if (acceptEncoding.match(/\bgzip\b/)) {
                res.setHeader('Content-Encoding', 'gzip')
                fileStream.pipe(zlib.createGzip()).pipe(res)
            } else {
                fileStream.pipe(res)
            }

            fileStream.on('error', function(_err) {
                logger.error("Error occurred while streaming file to browser", cacheFileFullPath, _err);
                delete global.RESOURCE_CACHE[cacheKey];
                res.status(404).end();
            });
        } else {
            res.sendStatus(304)
            res.end();
        }
    }

    _getResourceCache(cacheKey) {
        let cacheValue = global.RESOURCE_CACHE[cacheKey];
        if (cacheValue) {
            logger.debug('Fetching resouce content from cache for cacheKey', cacheKey);
        } else {
            logger.debug('Cache is empty for cacheKey ', cacheKey);
        }
        return cacheValue;
    }

    _setResourceCache(cacheKey, data) {
        let cacheValue = {};
        cacheValue.cachePath = data.cachePath;
        cacheValue.hashKey = data.lastModifiedTime;
        cacheValue.lastUpdatedTime = new Date(fs.statSync(data.cachePath).mtime).getTime();
        cacheValue.contentType = data.contentType;
        global.RESOURCE_CACHE[cacheKey] = cacheValue;
        return cacheValue;
    }

    _getResourceCacheRootFolderPath(context) {
        return path.join(global.paths.RESOURCE_CACHE_PATH, 'static/' + this.getResourceCacheFolder(context), this.resourceType);
    }

}

module.exports = AbstractResourceController;