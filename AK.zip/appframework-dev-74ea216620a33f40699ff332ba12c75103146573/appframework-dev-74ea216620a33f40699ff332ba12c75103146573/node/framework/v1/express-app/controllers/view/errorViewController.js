
module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const AbstractViewController = require("./abstractViewController");
const errorHandler = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

var errorViewController;

class ErrorViewController extends AbstractViewController {

    static getInstance(req, res) {
        if (!errorViewController) {
            errorViewController = new ErrorViewController()
        }
        return errorViewController;
    }

    constructor() {
        super();
        this.errorViewPath = path.join(__dirname, '../../views/error.hbs');
    }

    initialize(req, res) {
        super.initialize(req, res);
    }

    handle(context, next) {

        var errorViewData = { cobAppName : context.get('cobAppName') },
            req = context.get('req'),
            defaultError = true;

        try {

            var ssoErrorHandleEnabled = context.getParam('ssoErrorHandleEnabled') === true;
            var errorCode = req.query.code;
        
            errorViewData.errorCode = errorCode;

            if( ssoErrorHandleEnabled ) {
                errorViewData.postMessageEnabled = context.getParam('ssoRedirectPostMessageEnabled') === true;
                let redirectUrl = errorHandler.getSSORedirectUrl(context, errorCode);
        
                if (!_.isEmpty(redirectUrl)) {
                    // if (errorCode == 'N104') {
                    //     redirectUrl = redirectUrl + 'cookieDisabled=true';
                    // }

                    errorViewData.redirectUrl =  redirectUrl;
                    defaultError = errorViewData.postMessageEnabled;
                } else {
                    if (!errorViewData.postMessageEnabled) {
                        logger.error(req.attr.loggerPrefix, 'SSO urls are not configured');
                    } else {
                        errorViewData.fnToCall = context.getParam('ssoRedirectPostMessageName');
                    }
                }
            } else {
                errorViewData.postMessageEnabled = true;
            }
            
            if( defaultError === true ) {
                errorViewData.title = context.getString('error_title_' + errorCode);
                if( !errorViewData.description ) {
                    errorViewData.title = context.getString('error_title_default');
                    errorViewData.description = context.getString('error_description_default');
                } else {
                    errorViewData.description = context.getString('error_description_' + errorCode);
                }
                if( appConfig.get('authTestingEnabled') === true && req.query.details ) {
                    errorViewData.details = decodeURIComponent(req.query.details);
                }
                if( !errorViewData.fnToCall ) {
                    errorViewData.fnToCall = 'launchErrorHandler';
                }
                logger.info(context.loggerPrefix, "Error View Details", errorViewData);
                context.get('res').render(this.errorViewPath, { viewData: errorViewData, context : context });
            } else {
                logger.info(context.loggerPrefix, "Redirect to configured url", errorViewData.redirectUrl);
                context.get('res').redirect(errorViewData.redirectUrl);
            }
            
        } catch(e) {
            logger.error(context.loggerPrefix, 'Uncaught Error', e);
            errorViewData.title = global.defaultErrorMessage;
            context.get('res').render(this.errorViewPath, { viewData: errorViewData, context : context });
        }
       
    }
}

module.exports = ErrorViewController;