
module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const AbstractController = require("./abstractViewController");
const cookieHelper = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'common/cookie-helper'));
const { TechError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

var loginViewController;

class LoginViewController extends AbstractController {


    static getInstance(req, res) {
        if( !loginViewController ) {
            loginViewController = new LoginViewController()
        }
        return loginViewController;
    }

    constructor() {
        super();
        this.loginViewPath = path.join(__dirname, '../../views/login.hbs');
    }

    initialize(req, res) {
        super.initialize(req, res);
        cookieHelper.clearAllCookies(req, res);
    }

    handle(context, next) {
        var cobAppName = context.get('req').params.cobAppName;
        logger.info('Rendering login view hbs.', cobAppName);
        let viewData = { cobAppName : context.get('req').params.cobAppName };
        viewData.app = context.get('req').params.app || 'fastlink';
        if( !_.isEmpty(cobAppName) ) {
            viewData.cobAppName = cobAppName
        } else {
            if( appConfig.get('autoAuthSaveEnabled') === true ) {
                viewData.cobAppName = 'default'
                viewData.cobApps = appConfig.getAllCobApps();
            } else {
                context.get('res').end(global.defaultErrorMessage);
                return;
            }
        }

        var authType = context.get('req').query.authType || 'pwd';
        if( authType == 'oauth' ) {
            viewData.oauthAuth = true;
        } else if( authType == 'rsession' ) {
            viewData.sessionAuth = true;
        } else if( authType == 'jwt' ) {
            viewData.jwtAuth = true;
        } else if( authType == 'saml' ) {
            viewData.samlAuth = true;
        } else {
            viewData.pwdAuth = true;
        }
        
        context.get('res').render(this.loginViewPath, { viewData : viewData });
    }
}

module.exports = LoginViewController;