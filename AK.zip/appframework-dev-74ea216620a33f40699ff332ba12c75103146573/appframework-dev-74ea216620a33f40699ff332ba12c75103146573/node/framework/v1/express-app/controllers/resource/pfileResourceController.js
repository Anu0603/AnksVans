module.paths = module.parent.paths;

const fs = require('fs');

const AbstractResourceController = require('./abstractResourceController');

class pfileResourceController extends AbstractResourceController {

    constructor() {
        super();
    }

    initialize(req, res) {
        super.initialize(req, res);
    }

    getResourceContent(context) {
        logger.debug(context.loggerPrefix, "PFile Resouce Controller handle method");
        return new Promise((resolve, reject) => {
            let req = context.get('req');
            let appContext = context.getBrandContext().getAppContext(),
                userLocale = req.query.locale,
                pfileContent = '',
                pfileReleativePath = req.attr.resourcePath;

            let pfilePath = appContext.getAssetPath(pfileReleativePath + "_" + userLocale + "." + this.resourceType, this.resourceType);
            if (!fs.existsSync(pfilePath)) {
                logger.info(context.loggerPrefix, 'Fetching default pfile path', pfilePath);
                pfilePath = appContext.getAssetPath(pfileReleativePath + "_" + userLocale.split('_')[0] + "." + this.resourceType, this.resourceType);
            }
            if (pfilePath) {
                pfileContent = fs.readFileSync(pfilePath).toString();
                pfileContent = pfileContent.replace(/{{(.*?)\}}/g, function (value, dataKey) { return appContext.getLocaleString(dataKey, context.get('app')) || '' })
            } else {
                logger.error(context.loggerPrefix, 'Pfile doen\'t exist')
            }
            logger.debug(context.loggerPrefix, 'Pfilepath is ', pfilePath);
            resolve({ data: pfileContent });
        });
    }

    getContentType(req) {
        return 'text/html';
    }
}

module.exports = pfileResourceController;