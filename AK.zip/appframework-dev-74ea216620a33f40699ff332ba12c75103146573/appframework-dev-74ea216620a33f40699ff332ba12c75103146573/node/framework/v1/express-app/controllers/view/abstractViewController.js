module.paths = module.parent.paths;

const AbstractController = require("../abstractController");

class AbstractViewController extends AbstractController {

    initialize(req, res) {
        super.initialize(req, res);
        req.attr.view = true;
    }
}

module.exports = AbstractViewController;