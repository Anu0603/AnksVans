module.paths = module.parent.paths;

const FINAPP_IDS = {
	"fastlink" : "10003600",
	"enrich" : "10003700",
	"demo" : "10003600"
}

exports.getFinappId = (app) => {
	return FINAPP_IDS[app];
}