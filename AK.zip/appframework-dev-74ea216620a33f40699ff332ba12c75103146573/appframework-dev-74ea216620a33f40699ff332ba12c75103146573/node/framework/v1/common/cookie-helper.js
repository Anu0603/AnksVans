module.paths = module.parent.paths;

const _ = require('underscore');
const path = require('path');

const logger = global.logger;
const appConfig = require(global.paths.APP_CONFIG_PATH);

var clearAllCookies = ( req, res ) => {
	deleteRequestCookie(req, 'rsession');
	deleteCookie(res, 'rsession', true);
	deleteRequestCookie(req, 'udata');
	deleteCookie(res, 'udata', true);
};

var deleteCookie = ( res, name ) => {
	res.clearCookie( name );
};

var getCookie = ( req, name ) => {
	var cVal = req.cookies[name];
	if( !_.isEmpty(cVal) ) {
		cVal = decodeURIComponent(cVal);
	}
	return cVal;
};

var setCookie = ( res, name, value, options ) => {
	var options = getCookieOptions(options);
	res.cookie( name, value, options );
};

var deleteRequestCookie = ( req, name ) => {
	delete req.cookies[name];
};

var getCookieOptions = (options={}) => {
	var val = options;
	val.path = '/';
	if( appConfig.get('protocol') == 'https' ) {
		if( options.httpOnly !== false ) {
			val.httpOnly = true;
		}
		val.secure = true;
		val.sameSite='none'
	}

	return val;
}

module.exports = {
	clearAllCookies,
	deleteCookie,
	getCookie,
	setCookie
}