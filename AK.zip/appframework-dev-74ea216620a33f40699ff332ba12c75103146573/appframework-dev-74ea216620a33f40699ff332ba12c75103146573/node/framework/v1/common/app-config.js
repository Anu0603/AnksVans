module.paths = module.parent.paths

const path = require('path')
const log4js = require('log4js')
const cluster = require('cluster')
const fs = require('fs')
const _ = require('underscore')
const lodash = require('lodash')

var _logger = log4js.getLogger('app')
var _config,
	_cobAppConfig,
	_cobAppInfo = {}

var get = (key) => {
	return _config[key]
}

var set = (key, value) => {
	logger.info('set app-config value', key, value)
	if (key == 'serverStartupTime' || key == 'resourceCacheFolder') {
		if (value) {
			logger.info('app-config : ', key, value)
			_config[key] = value
		}
	}
}

var getCobAppInfo = (cobAppName) => {
	let cobAppInfo = _cobAppInfo[cobAppName]
	if (!_cobAppInfo[cobAppName]) {
		try {
			logger.info(
				"Fetching '%s' cobAppName details from cobApp cache ",
				cobAppName
			)
			let cobAppPath = path.join(
				global.paths.COBAPP_CONFIG_CACHE_PATH,
				cobAppName + '.json'
			)
			if (fs.existsSync(cobAppPath)) {
				cobAppInfo = _cobAppInfo[cobAppName] = require(cobAppPath)
				logger.info(
					'Set cobApp cache to cobAppInfo Object ',
					cobAppName,
					cobAppInfo
				)
			} else {
				logger.info(
					"Creating cobAppConfig for cobaAppName '%s' as it is not availble in cache '%s'",
					cobAppName,
					cobAppPath
				)
				cobAppInfo = _cobAppConfig[cobAppName]
				if (!cobAppInfo) {
					logger.info(
						'Checking whether it is a sub-brand request or not...'
					)
					let vals = cobAppName.split(':')
					if (vals.length == 2) {
						let channelAppName = vals[0]
						let subbrandAppName = vals[1]
						let channelAppInfo = _cobAppConfig[channelAppName]
						if (
							channelAppInfo &&
							channelAppInfo.isChannel === true &&
							!_.isEmpty(subbrandAppName)
						) {
							cobAppInfo = _constructTempSubbrandAppConfig(
								cobAppName,
								subbrandAppName,
								channelAppInfo
							)
						} else {
							logger.info(
								'Invalid request parameters, channelAppInfo, vals',
								channelAppInfo,
								vals
							)
						}
					}
				}
			}
		} catch (e) {
			logger.error(
				"Getting uncaught Error while fetching cobrandAppInfo '%s'",
				cobAppName,
				e
			)
		}
	}
	return cobAppInfo
}

var setCobAppInfo = (cobAppInfo) => {
	logger.info('Creating cobApp cache for cobAppName ', cobAppInfo.cobAppName)
	let cobAppPath = path.join(
		global.paths.COBAPP_CONFIG_CACHE_PATH,
		cobAppInfo.cobAppName + '.json'
	)
	cobAppInfo.isValid = true
	fs.writeFileSync(cobAppPath, JSON.stringify(cobAppInfo, null, 4))
	logger.info('Setting cobApp cache to cobAppInfo Object ', cobAppInfo)
	cobAppInfo = _cobAppInfo[cobAppInfo.cobAppName] = require(cobAppPath)
	return cobAppInfo
}

var getAllCobApps = () => {
	return JSON.parse(JSON.stringify(_cobAppConfig))
}

var _constructTempSubbrandAppConfig = (
	cobAppName,
	subbrandAppName,
	channelAppInfo
) => {
	var subbrandAppInfo = _.clone(channelAppInfo)
	subbrandAppInfo.channelId = channelAppInfo.brandId
	if (!_.isEmpty(channelAppInfo.resturl)) {
		subbrandAppInfo.resturl =
			channelAppInfo.resturl.substr(
				0,
				channelAppInfo.resturl.lastIndexOf('/') + 1
			) + subbrandAppName
	} else {
		logger.error(
			'REST url is not configured for channel "%s" so it is not configured for sub-brand "%s" also',
			subbrandAppInfo.channelId,
			cobAppName
		)
	}
	if (!_.isEmpty(channelAppInfo.yslurl)) {
		subbrandAppInfo.yslurl =
			channelAppInfo.yslurl.substr(
				0,
				channelAppInfo.yslurl.lastIndexOf('/') + 1
			) + subbrandAppName
	} else {
		logger.error(
			'YSL url is not configured for channel "%s" so it is not configured for sub-brand "%s" also',
			subbrandAppInfo.channelId,
			cobAppName
		)
	}
	subbrandAppInfo.channelAppName = channelAppInfo.cobAppName
	subbrandAppInfo.cobAppName = cobAppName
	subbrandAppInfo.isSubbrand = true
	subbrandAppInfo.isChannel = false
	logger.info(
		'Creating temporary cobApp for subrand ',
		cobAppName,
		subbrandAppName,
		channelAppInfo
	)
	return subbrandAppInfo
}

var _initialize = () => {
	// global.paths is already initiated in server.js file
	_logger.level = 'debug'
	global.paths = global.paths || {}
	global.paths.BASE_PATH = path.resolve('.')

	_config = require(path.join(global.paths.BASE_PATH, 'config/config')).config

	let _overrideConfig = require(path.join(
		global.paths.BASE_PATH,
		'devops/config'
	))
	if (_.isEmpty(_overrideConfig)) {
		if (process.env.NODE_ENV === 'production') {
			_overrideConfig = require(path.join(
				global.paths.BASE_PATH,
				'config/config'
			).config)
		} else if (process.env.NODE_ENV === 'build') {
			_overrideConfig = require(path.join(
				global.paths.BASE_PATH,
				'config/config.build'
			)).config
		} else {
			_overrideConfig = require(path.join(
				global.paths.BASE_PATH,
				'config/config.dev'
			)).config
		}
	} else {
		_setDevOpsDefaultPropreties()
	}
	_overrideConfiguration(_overrideConfig)

	if (_config.devOpsEnabled === true) {
		_cobAppConfig = {}
		require(path.join(global.paths.BASE_PATH, 'devops/cob-app-config')).map(
			(value) => {
				if (!_.isEmpty(value.cobAppName)) {
					_cobAppConfig[value.cobAppName] = value
				} else {
					_logger.error('CobAppName is empty', value)
				}
			}
		)
	} else {
		_cobAppConfig = require(path.join(
			global.paths.BASE_PATH,
			'config/cob-app-config'
		))
		_.each(_cobAppConfig, (value, key) => {
			value.cobAppName = key
		})
	}

	if (cluster.isMaster) {
		_logger.info('CobApp : ', _cobAppConfig)
		console.log(_cobAppConfig)
	}

	global.paths.FRAMEWORK_PATH = path
		.join(global.paths.BASE_PATH, 'framework')
		.replace(/\\/g, '/')
	global.paths.FRAMEWORK_VERSION_PATH = path
		.join(global.paths.FRAMEWORK_PATH, 'v1')
		.replace(/\\/g, '/')
	global.paths.APP_CONFIG_PATH = path
		.join(global.paths.FRAMEWORK_VERSION_PATH, 'common/app-config')
		.replace(/\\/g, '/')
	global.paths.BLOCK_APP_PATH = path
		.join(global.paths.BASE_PATH, 'dist')
		.replace(/\\/g, '/')
	global.paths.BRANDS_PATH = path
		.join(global.paths.BASE_PATH, 'brands')
		.replace(/\\/g, '/')
	global.paths.DEVOPS_BRANDS_PATH = path
		.join(global.paths.BASE_PATH, 'devops/brands')
		.replace(/\\/g, '/')
	global.paths.BRAND_DEFAULT_PATH = path
		.join(global.paths.FRAMEWORK_VERSION_PATH, 'brand-default')
		.replace(/\\/g, '/')
	global.paths.RESOURCE_CACHE_PATH = path
		.join(global.paths.FRAMEWORK_VERSION_PATH, 'resource-cache')
		.replace(/\\/g, '/')
	global.paths.COBAPP_CONFIG_CACHE_PATH = path
		.join(global.paths.RESOURCE_CACHE_PATH, 'cob-app-config')
		.replace(/\\/g, '/')

	_initializeLogger()
	_setDefaultProperties()
}

var _initializeLogger = () => {
	_logger.info('Initialzing logger')
	global.logger = _logger

	if (cluster.isMaster) {
		if (get('developmentMode') === true || get('buildMode') === true) {
			let logAppFile = path.join(
				global.paths.NODE_MODULES_PATH,
				'../config/log4js/server-log-config-master-dev.json'
			)
			_configureLogger('development', logAppFile, true)
		} else {
			let logAppFile = path.join(
				global.paths.NODE_MODULES_PATH,
				'../config/log4js/server-log-config-master.json'
			)
			_configureLogger('production', logAppFile)
		}
	} else {
		var mode = process.env.NODE_ENV || 'development'
		if (get('developmentMode') === true) {
			let logAppFile = path.join(
				global.paths.NODE_MODULES_PATH,
				'../config/log4js/server-log-config-worker-dev.json'
			)
			_configureLogger('development', logAppFile)
		} else {
			let logAppFile = path.join(
				global.paths.NODE_MODULES_PATH,
				'../config/log4js/server-log-config-worker.json'
			)
			_configureLogger('production', logAppFile)
		}
		_logger.info(
			'Process [' +
				process.pid +
				'] : Worker Starting server in ' +
				mode +
				' mode'
		)
	}
}

var _configureLogger = (logMode, logAppFile) => {
	var logConfigfile = JSON.parse(fs.readFileSync(logAppFile, 'utf8')),
		loggerFile = get('loggerFile'),
		accessFile = get('accessFile')

	if (get('devOpsEnabled') === true) {
		let devopsFilePattern =
			'nodefastlink_' +
			(process.env.STACKNAME || 'nostack') +
			'_' +
			require('os').hostname() +
			'.log'
		loggerFile = loggerFile
			.substr(0, loggerFile.lastIndexOf('/'))
			.concat('/server_' + devopsFilePattern)
		accessFile = accessFile
			.substr(0, accessFile.lastIndexOf('/'))
			.concat('/access_' + devopsFilePattern)
	}

	if (!_.isEmpty(logConfigfile.appenders.server)) {
		logConfigfile.appenders.server.loggerPort = get('loggerPort')
		logConfigfile.appenders.server.loggerHost = get('loggerHost')
		logConfigfile.appenders.access.loggerPort = get('accessPort')
		logConfigfile.appenders.access.loggerHost = get('loggerHost')
		logConfigfile.appenders['server-log'].filename = loggerFile
		logConfigfile.appenders['access-log'].filename = accessFile
	}

	logConfigfile.categories.app.level = get('logLevel')
	logConfigfile.categories.access.level = get('logLevel')

	log4js.configure(logConfigfile, {})
	logger.info('Log4j is initiated for %s mode', logMode)
}

var _overrideConfiguration = (overrideConfig) => {
	if (!_.isEmpty(overrideConfig)) {
		_logger.info('Overriding config data', overrideConfig)
		lodash.mergeWith(_config, overrideConfig)
	}
	_overrideConfigWithProcessArgs()
}

var _setDevOpsDefaultPropreties = () => {
	_config.devOpsEnabled = true
	let appName = process.env.NEW_RELIC_APP_NAME
	if (!_.isEmpty(appName) && _.isUndefined(_config.environmentType)) {
		_config.environmentType = appName.split('.')[1]
		_logger.info('Environment Type is ', _config.environmentType)
	} else {
		_logger.error(
			'Environment Type is not available',
			process.env.NEW_RELIC_APP_NAME
		)
	}
	if (process.env.HTTP_PROXY_HOST) {
		let httpProxyUrl = 'http://' + process.env.HTTP_PROXY_HOST
		if (process.env.HTTP_PROXY_PORT) {
			httpProxyUrl = httpProxyUrl + ':' + process.env.HTTP_PROXY_PORT
		}
		_config.httpProxyUrl = httpProxyUrl
		_logger.info('Proxy url is ', _config.httpProxyUrl)
	} else {
		_logger.error('Proxy is not configured')
	}
}

var _setDefaultProperties = () => {
	_config.serverStartupTime = process.env['serverStartupTime']
	_config.resourceCacheFolder = process.env['resourceCacheFolder']
	process.env.TZ = get('serverTimezone')
	_logger.info('Server Timezone : ', process.env.TZ)
	var interfaces = require('os').networkInterfaces()
	for (var k in interfaces) {
		for (let k2 in interfaces[k]) {
			let address = interfaces[k][k2]
			if (address.family === 'IPv4' && !address.internal) {
				global.uniqueIPAddress = address.address
			}
		}
	}
}

var _overrideConfigWithProcessArgs = () => {
	var cargs = require('yargs').argv
	_.each(cargs, (value, key) => {
		if (value == 'true' || value == 'false') {
			_config[key] = value == 'true'
		} else if (!isNaN(value)) {
			_config[key] = parseInt(value)
		} else {
			_config[key] = value
		}
	})
	_logger.info('Command line args', cargs)
}

_initialize()

module.exports = {
	get,
	set,
	getCobAppInfo,
	setCobAppInfo,
	getAllCobApps
}
