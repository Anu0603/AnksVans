module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const { TechError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));

const AbstactInterceptor = require('./abstract');

class MemPrefInteceptor extends AbstactInterceptor {

    preHandle(context, reqData) {
        return super.preHandle(context, reqData)
            .then(parseReqData => {
                var isValid = false;
                if( !_.isEmpty(parseReqData.data) ) {
                    console.log(parseReqData.data.preference);
                    let preferencs = parseReqData.data.preference;
                    for(let i=0; i<preferencs.length; i++) {
                        if( _isValidKey(preferencs[i].key) ) {
                            isValid = true;
                        } else {
                            logger.error(context.loggerPrefix, 'Mem pref Tampered : ', preferencs[i].key);
                            break;
                        }
                    }
                }
		
                if( !isValid ) {
                    throw new TechError("MEM_PREF_KEY_TAMPERED");
                } else {
                    return parseReqData;
                }
            });
    }

    postHandle(context, resData) {
        return super.postHandle(context, resData);
    }
}

module.exports = MemPrefInteceptor;

const WHITELIST_KEYS = {
	"equal-keys" : [
        "externalAccTncRevision"
	],

	"index-of-keys" : [
	]
};

// private methods
function _isValidKey( prefKey ) {
	var isValid = false;

	if( WHITELIST_KEYS['equal-keys'].indexOf(prefKey) != -1 ) {
		isValid = true;
	} else {
		let length =  WHITELIST_KEYS['index-of-keys'].length;
		for(let i=0; i<length; i++) {
			if( prefKey.indexOf(WHITELIST_KEYS['index-of-keys'][i]) != -1 ) {
				isValid = true;
				break;
			}
		}
	}
	return isValid;
}