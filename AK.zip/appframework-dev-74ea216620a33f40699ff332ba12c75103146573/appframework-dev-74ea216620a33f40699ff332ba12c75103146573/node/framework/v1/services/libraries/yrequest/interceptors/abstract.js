module.paths = module.parent.paths;

class AbstractInteceptor {

    constructor() {}

    preHandle(context, reqData) {
        return Promise.resolve(reqData);
    }

    postHandle(context, resData) {
        return Promise.resolve(resData);
    }
}

module.exports = AbstractInteceptor;