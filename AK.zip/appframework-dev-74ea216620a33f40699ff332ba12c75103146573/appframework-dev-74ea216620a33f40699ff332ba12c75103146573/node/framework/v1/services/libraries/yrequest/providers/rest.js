module.paths = module.parent.paths;

const _ = require('underscore');
const path = require('path');
const xml2js = require('xml2js');

const AbstactProvider = require('./abstract');
const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));
const errorCodeConfig = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/error-code-config'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

class RestProvider extends AbstactProvider {

    constructor(providerType) {
        super(providerType);
        this.isFormInputProvider = true;
    }

    service(context, inputReq) {
        //logger.info('REST Call is invoked');
        return super.service(context, inputReq)
            .then(_httpResponse => {
                //logger.info('Response', _httpResponse);
                let contentType = _httpResponse.headers['content-type'] || '';
                if( contentType.indexOf('application/json') != -1 ) {
                    if( !_httpResponse.data ) {
                        return "{}";
                    } else if( _httpResponse.data[0] == '{' ) {
                        if( _httpResponse.data.substr(0, 9) != '{"Error":' ) {
                            logger.info("Rest API is completed", inputReq.url);
                            return _httpResponse;
                        } else {
                            logger.info('Rest API Error Response : ',  _httpResponse.data);
                        }
                    }
                }

                logger.error("Rest API is failed", inputReq.url, _httpResponse.data);
                return this._parseXmlErrorResponse(_httpResponse.data);
            });
    }

    createRequest(context, inputReq) {
        logger.debug("Constructing rest-request input for url", inputReq.url);

        var _request = super.createRequest(context, inputReq);
        _request.headers.uniqueTrackingId = this.generateUniqueTrackId(context);

        var publicKey = appConfig.get('publicKey')
            , userSession = context.getUserAuthToken();

        if( !_.isEmpty(userSession) ) {
            publicKey = userSession + '' + publicKey;
        }

        _request.headers['x-request-source'] = yutils.encryptDataAES128ECB('NODE_DEVOPS', publicKey );

        if( !_.isEmpty(userSession) ) {
            _request.headers.Cookie = 'rsession="' + userSession + '"'
        }

        return _request;
    }

    _parseXmlErrorResponse(xmlResponse) {

        var _errorResponse = (errorResponse) => {
            logger.debug("Error Response", errorResponse);
            let error = {}, message, errorType, groupErrorType, errorCode;
            if( errorResponse.Errors ) {
                message = errorResponse.Errors.Error[0].errorDetail[0];
            } else if( errorResponse.Error ) {
                if( _.isArray(errorResponse.Error) ) {
                    message = errorResponse.Error[0].errorDetail;
                } else {
                    message = errorResponse.Error.errorDetail;
                }
            } else {
                message = xmlResponse || global.defaultErrorMessage;
            }

            if( !_.isEmpty(message) ) {
                
                if (message.indexOf("Unknown Issuer ID") != -1 || message.indexOf('INVALID_ISSUER_ID') != -1 ) {
                    errorType = 'UNKNOWN_ISSUER_ID';
                } else if (message.indexOf("Failed to parse XmlString") != -1) {
                    errorType = 'XML_PARSE_ERROR';
                } else if (message.indexOf("Invalid SAML response") != -1 || message.indexOf('com.yodlee.saml.exception.SAMLResponseException') != -1) {
                    errorType = 'INVALID_SAML_RESPONSE';
                } else if (message.indexOf("Stale session found") != -1 || message.indexOf('Unable to retrieve User Context') != -1) {
                    errorType = 'STALE_SESSION';
                    groupErrorType = "SESSION_ERROR";
                } else if (message.indexOf('Invalid User Credentials') != -1) {
                    errorType = 'INVALID_USER_CREDENTIALS';
                } else {
                    let yslCode = message.match(/Y\d{3}/g);
                    if( yslCode ) {
                        errorType = errorCodeConfig.getMappingErrorType(yslCode);
                    }
                }
                error.errorMessage = message;
                error.errorCode = 'R100';
            }
            error.errorType = errorType;
            error.groupErrorType = groupErrorType;
            return this.createErrorResponse(error);
        }

        return new Promise((resolve, reject) => {
            let isString = false, errRes;
            try {
                errRes = JSON.parse(xmlResponse);
            } catch(e) {
                isString = true;
            }

            if( isString ) {
                let xmlJsonResponse = xml2js.parseString(xmlResponse, function(err, result) {
                    if( err ) {
                        logger.error('Parsing xml error', err);
                        result = {};
                    }
                    reject(_errorResponse(result));
                });
            } else {
               reject(_errorResponse(errRes));
            }
        });
    }
}

module.exports = RestProvider;