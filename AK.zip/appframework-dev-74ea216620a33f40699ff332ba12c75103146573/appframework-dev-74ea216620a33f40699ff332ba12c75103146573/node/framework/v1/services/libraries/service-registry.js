module.paths = module.parent.paths;

const _ = require('underscore');
const path = require('path');

const cacheDataService = {};

const serviceDataMapping = {
    "/services/internal-provider/rest": {
        path: "internal-provider:restCall"
    },
    "/services/internal-provider/ysl": {
        path: "internal-provider:yslCall"
    },
    "/services/internal-provider/ess": {
        path: "internal-provider:essCall"
    },
    "/services/internal-provider/graph": {
        path: "internal-provider:graphCall"
    }

}


exports.getDataService = (context, serviceReqPath) => {
    servicePath = serviceReqPath.replace("/" + context.get('cobAppName') + "/", "/");
    let service = cacheDataService[servicePath];
    if (!service) {
        if (!_.isEmpty(servicePath)) {
            let serviceInfo = serviceDataMapping[servicePath.toLowerCase()];
            if (!_.isEmpty(serviceInfo)) {
                let servicePath = serviceInfo.path;
                let parts = servicePath.split(':');
                try {
                    let serviceClass = require(path.resolve(global.paths.FRAMEWORK_VERSION_PATH + '/services/' + parts[0] + ".js"));
                    service = serviceClass[parts[1]];
                    cacheDataService[path] = service;
                } catch (e) {
                    logger.error(context.loggerPrefix, "Service invokation is failed ", e);
                }
            } else {
                logger.error(context.loggerPrefix, 'Service path is not registered', servicePath.toLowerCase());
            }
        } else {
            logger.error(context.loggerPrefix, 'Invalid service : ', path);
        }
    }
    return service;
}