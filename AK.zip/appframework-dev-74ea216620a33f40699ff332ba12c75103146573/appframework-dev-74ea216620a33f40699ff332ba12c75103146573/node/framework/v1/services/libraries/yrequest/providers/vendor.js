module.paths = module.parent.paths;

const _ = require('underscore');

const AbstactProvider = require('./abstract');

const appConfig = require(global.paths.APP_CONFIG_PATH);

class VendorProvider extends AbstactProvider {

    constructor(providerType) {
        super(providerType);
    }

    service(context, inputReq) {
        //logger.info('YSL Call is invoked');
        return super.service(context, inputReq)
            .then(_httpResponse => {
                //logger.info('Response', _httpResponse);
                return _httpResponse;
            })
    }

    parseErrorResponse(data) {
        return data;
    }

    createRequest(context, inputReq) {
        logger.debug("Constructing cdn-request input for url", inputReq.url);

        let _request = super.createRequest(context, inputReq);
        if( inputReq.dataType == 'binary' ) {
            _request.encoding = null;
        }
        if( _.isUndefined(inputReq.proxy) || inputReq.proxy !== false ) {
            _request.proxy = appConfig.get('httpProxyUrl');
        }
        return _request;
    }
}

module.exports = VendorProvider;