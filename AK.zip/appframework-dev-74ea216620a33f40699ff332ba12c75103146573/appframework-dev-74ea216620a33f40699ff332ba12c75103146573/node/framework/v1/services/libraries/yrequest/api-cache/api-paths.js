module.exports = {
    
}

// example:
// module.exports = {
//     "/1.1/providers" : {}
// }