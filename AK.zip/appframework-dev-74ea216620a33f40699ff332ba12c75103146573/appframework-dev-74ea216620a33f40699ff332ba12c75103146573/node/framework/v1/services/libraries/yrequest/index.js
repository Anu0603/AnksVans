module.paths = module.parent.paths;

const path = require('path');
const fs = require('fs');
const _ = require('underscore');

const providerTypes = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest/config/provider-types'));

const PROVIDER_INSTANCE_CACHE = {};
const INTERCEPTOR_INSTANCE_CACHE = {};

function yrequest(context, reqData) {

	var provider = PROVIDER_INSTANCE_CACHE[reqData.serviceType];
	if (!provider) {
		let providerPath = path.join(__dirname, 'providers', providerTypes[reqData.serviceType].toLowerCase() + '.js');
		if (fs.existsSync(providerPath)) {
			let Provider = require(providerPath);
			provider = new Provider(reqData.serviceType);
			PROVIDER_INSTANCE_CACHE[reqData.serviceType] = provider;
			logger.info(context.loggerPrefix, 'Initiating object for provider', providerPath);
		} else {
			logger.error(context.loggerPrefix, "Invalid Provider Path", providerPath);
			throw "INVALID_PROVIDER";
		}
	}

	var inteceptors = provider.getInteceptors(context, reqData);
	return inteceptors.reduce((p, interceptorName) => {
				logger.info(context.loggerPrefix, "Inteceptor.preProcess %s is initiated", interceptorName, reqData.url);
				return p.then((parseReqData) => {
					return _getInterceptor(interceptorName).preHandle(context, parseReqData);
				})
			}, Promise.resolve(reqData))
		.then(parseReqData => {
			return provider.service(context, parseReqData)
				.then(resData => {
					resData.reqData = parseReqData;
					return resData;
				})
		})
		.then(resData => {
			return inteceptors.reduce((p, interceptorName) => {
				logger.info(context.loggerPrefix, "Inteceptor.postProcess %s is initiated", interceptorName, reqData.url);
				return p.then((parseResponse) => {
					return _getInterceptor(interceptorName).postHandle(context, parseResponse);
				})
			}, Promise.resolve(resData));
		});
};

const _getInterceptor = interceptorName => {
	let interceptorInstance = INTERCEPTOR_INSTANCE_CACHE[interceptorName];
	if (!interceptorInstance) {
		let interceptorPath = path.join(__dirname, 'interceptors', interceptorName.toLowerCase() + '.js');
		if (fs.existsSync(interceptorPath)) {
			let Interceptor = require(interceptorPath);
			interceptorInstance = new Interceptor();
			INTERCEPTOR_INSTANCE_CACHE[interceptorName] = interceptorInstance;
			logger.info('Initiating object for interceptor', interceptorPath);
		} else {
			logger.error("Invalid interceptor", interceptorName, interceptorPath);
			throw "INVALID_INCEPTOR";
		}
	}
	return interceptorInstance;
}

module.exports = yrequest;