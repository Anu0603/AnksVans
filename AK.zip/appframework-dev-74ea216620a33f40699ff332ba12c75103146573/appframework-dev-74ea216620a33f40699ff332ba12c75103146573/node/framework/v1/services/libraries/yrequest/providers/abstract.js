module.paths = module.parent.paths;

const _ = require('underscore');
const path = require('path');
const request = require('request');
const fs = require('fs');
const crypto = require('crypto');

const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));
const apiCache = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest/api-cache'));
const { ApiError, SessionError, ServerError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

class AbstractProvider {

    constructor(providerType) {
        this.stubFolderPath = path.join(global.paths.FRAMEWORK_VERSION_PATH, 'stubs');
        this.type = providerType;
    }

    service(context, inputReq) {
        if (appConfig.get('stub') === true) {
            return this.stubServiceRequest(context, inputReq);
        } else {
            if( appConfig.get('apiCacheEnabled') === true && inputReq.cache === true ) {
               return this.cacheServiceRequst(context, inputReq)
                    .catch(e => {
                        if(e) {
                            logger.error("Error while fetching api-response from cache", e);
                        }
                        return this.serviceRequest(context, inputReq);
                    });
            } else {
                return this.serviceRequest(context, inputReq);
            }
        }
    }

    createRequest(context, inputReq) {
        logger.info(context.loggerPrefix, 'Creating Reqeust', inputReq.url);
        var _request = {
            uri: (inputReq.baseUrl || '') + inputReq.url,
            timeout: appConfig.get('apiTimeoutInSeconds'),
            method: inputReq.method || 'POST',
            forever: true,
            headers: inputReq.headers || {},
            agentOptions: {
                maxSockets: 999999,
                keepAliveMsecs: 500
            }
        };

        if (_request.method == 'POST' || _request.method == 'PUT') {
            if (inputReq.isFormData === true) {
                _request.headers['content-type'] = 'application/x-www-form-urlencoded';
                _request.form = inputReq.data;
            } else if( !_.isEmpty(inputReq.data) ) {
                _request.headers['content-type'] = 'application/json;charset=UTF-8';
                _request.body = JSON.stringify(inputReq.data);
            }
        } else if (_request.method == 'GET' || _request.method == 'DELETE') {
            _request.qs = inputReq.data
        } else {
            _request.data = inputReq.data
        }

        _request.headers['Accept'] = 'application/json';
        _request.headers.Cookie = '';
        _request.time = true;

        return _request
    }

    createErrorResponse(errRes) {
        let error;
        if (errRes.groupErrorType) {
            if (errRes.groupErrorType == 'SERVER_ERROR') {
                error = new ServerError(errRes, { providerType: this.type });
            } else if (errRes.groupErrorType == 'SESSION_ERROR') {
                error = new SessionError(errRes);
            }
        }
        return error || new ApiError(errRes, { providerType: this.type });
    }

    serviceRequest(context, inputReq) {
        return new Promise((resolve, reject) => {
            let requestInput = this.createRequest(context, inputReq);
            //logger.info("API request is initiated", requestInput.uri);
            logger.info(context.loggerPrefix, ' - API: (' + inputReq.url + ') api-request is initiated.');
            request(requestInput, (error, httpResponse, body) => {
                if (appConfig.get('apiDebug') === true) {
                    logger.debug(context.loggerPrefix, '- ApiDebug: (' + inputReq.url + ') API Request', requestInput);
                    logger.debug(context.loggerPrefix, '- ApiDebug: (' + inputReq.url + ') API Header Response', httpResponse);
                    // logger.debug('- ApiDebug: (' + inputReq.url + ') API Success Response', body);
                    logger.debug(context.loggerPrefix, '- ApiDebug: (' + inputReq.url + ')API Error Response', error);
                }

                if (httpResponse && httpResponse.timings) {
                    logger.debug(context.loggerPrefix, ' - API: (' + inputReq.url + ') Begin request: ' + new Date(httpResponse.timingStart));
                    logger.info(context.loggerPrefix, ' - API: (' + inputReq.url + ') Connection: ' + (httpResponse.timings.connect));
                    logger.debug(context.loggerPrefix, ' - API: (' + inputReq.url + ') Socket Initialization: ' + (httpResponse.timingPhases.wait));
                    logger.debug(context.loggerPrefix, ' - API: (' + inputReq.url + ') DNS lookup : ' + (httpResponse.timingPhases.dns));
                    logger.debug(context.loggerPrefix, ' - API: (' + inputReq.url + ') TCP Connection: ' + (httpResponse.timingPhases.tcp));
                    logger.info(context.loggerPrefix, ' - API: (' + inputReq.url + ') Got HTTP response: ' + (httpResponse.timingPhases.firstByte));
                    logger.debug(context.loggerPrefix, ' - API: (' + inputReq.url + ') Download: + ' + (httpResponse.timingPhases.download));
                    logger.info(context.loggerPrefix, ' - API: (' + inputReq.url + ') Request total time: ' + (httpResponse.timingPhases.total))
                    logger.debug(context.loggerPrefix, ' - API: (' + inputReq.url + ') End request: ' + httpResponse.timings.end);
                }

                if (error) {
                    logger.info(context.loggerPrefix, "API Request is failed", requestInput.uri);
                    logger.error(context.loggerPrefix, ' - API: (' + inputReq.url + ') Request is failed.', error);
                    //logger.error('Server Error Response', error);
                    reject(this.createErrorResponse({ errorType : error.code, groupErrorType : 'SERVER_ERROR'}));
                } else {
                   // logger.info("API Request is completed", requestInput.uri, httpResponse.statusCode);
                    if (httpResponse.statusCode >= 200 && httpResponse.statusCode < 300 ) {
                        //logger.debug('Request Success Response', body)
                        if (httpResponse.statusCode == 204) {
                            body = body || '{}';
                        }
                        logger.info(context.loggerPrefix, ' - API: (' + inputReq.url + ') Request status - success.');
                        let _apiRes = { data: body, headers: httpResponse.headers };
                        apiCache.set(context, inputReq, _apiRes);
                        resolve(_apiRes);
                    } else {
                        //logger.debug('Request Failed Response', body)
                        logger.error(context.loggerPrefix, ' - API: (' + inputReq.url + ') Request status - error.', body, httpResponse.statusCode);
                        reject(this.createErrorResponse(this.parseErrorResponse(body)));
                    }
                }
            });
        });

    }

    stubServiceRequest(context, inputReq) {

        return new Promise((resolve, reject) => {
            let requestInput = this.createRequest(context, inputReq);
            var serviceFile = (inputReq.method || 'POST') + '_' + inputReq.url.replace(/[\?=,]/g, '_').replace(/[\.\/]/g, '');
            var hash = crypto.createHash('md5').update(serviceFile + JSON.stringify(inputReq.data || {})).digest("hex")
            var contextualStubPath = path.join(this.stubFolderPath, this.type, 'hash', hash + '.json');
            var contextualExists = fs.existsSync(contextualStubPath);
            var dataPath;
            if (contextualExists) {
                dataPath = contextualStubPath;
            } else {
                logger.info(context.loggerPrefix, 'contextual Stub File doen\'t exist', contextualStubPath);
                let stubFilePath = path.join(this.stubFolderPath, this.type, serviceFile + '.json');
                if (fs.existsSync(stubFilePath)) {
                    dataPath = stubFilePath
                } else {
                    logger.error(context.loggerPrefix, 'STUB File doen\'t exist', stubFilePath);
                }
            }
            if (dataPath) {
                logger.info(context.loggerPrefix, 'Reading stub data from file', dataPath);
                let stubContent = fs.readFileSync(dataPath).toString();
                if( inputReq.url == '/v1.0/authenticator/cobrandDetails' ) {
                    var cobAppInfo = context.get('req').attr.cobAppInfo;
                    var cobrandInfo = {};
                    cobrandInfo.cobrandId = context.get('req').query.brandId || cobAppInfo.brandId;
                    cobrandInfo.applicationId = cobAppInfo.applicationId;
                    cobrandInfo.channelId = cobAppInfo.channelId;
                    stubContent = JSON.stringify(cobrandInfo);
                }
                resolve({ data: stubContent, headers: { 'content-type': 'application/json' } });
            } else {
                reject(new ApiError({ message: "Stub not found" }, { providerType: this.type } ));
            }
        });
    }

    cacheServiceRequst(context, inputReq) {

        return new Promise((resolve, reject) => {
            let cacheContent = apiCache.get(context, inputReq);
            if( cacheContent ) {
                resolve(cacheContent);
            } else {
                reject();
            }
        });
    }

    getInteceptors() {
        return [];
    }

    generateUniqueTrackId(context) {

        var uniqueTrackingId = '';
    
        if (appConfig.get('uniqueTrackingIdEnabled') === true) {
    
            if (!_.isUndefined(this.ipAddressLastThreeDigit)) {
                let uniqueIPAddress = global.uniqueIPAddress;
                this.ipAddressLastThreeDigit = uniqueIPAddress.substring(uniqueIPAddress.lastIndexOf(".") + 1, uniqueIPAddress.length);
            }
    
    
            var getRandomChar = function () {
                var text = "";
                var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
                return possible.charAt(Math.floor(Math.random() * possible.length));;
            }
    
            var nsession = context.get('req').query._s;
    
            var tparams = [];
            tparams.push('');
            tparams.push(getRandomChar());
            tparams.push((new Date()).getTime());
            tparams.push(getRandomChar());
            tparams.push(appConfig.get('nodeInstance'));
            tparams.push(getRandomChar());
            tparams.push(this.ipAddressLastThreeDigit);
            tparams.push(getRandomChar());
            tparams.push(context.get('app'));
            tparams.push(getRandomChar());
            tparams.push("N");
            tparams.push(getRandomChar());
            if (nsession && !_.isEmpty(nsession)) {
                tparams.push(":");
                tparams.push(yutils.createHash(nsession));
            }
            uniqueTrackingId = tparams.join('');
            logger.info(context.loggerPrefix, "UniqueTrackingId: ", uniqueTrackingId);
        }
        return uniqueTrackingId;
    }
}

module.exports = AbstractProvider;