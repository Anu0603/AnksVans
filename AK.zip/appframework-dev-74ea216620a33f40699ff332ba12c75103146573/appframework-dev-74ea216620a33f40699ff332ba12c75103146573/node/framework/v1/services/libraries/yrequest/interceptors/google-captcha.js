module.paths = module.parent.paths;

const AbstactInterceptor = require('./abstract');

const _ = require('underscore');
const path = require('path');

const { TechError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));
const internalProviderService = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/internal-provider'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

class GoogleCaptchaInteceptor extends AbstactInterceptor {

	preHandle(context, reqData) {

		return super.preHandle(context, reqData)
			.then(parseReqData => {
				let siteId = ( reqData.method == 'GET' ) ?  reqData.url.substr(reqData.url.lastIndexOf('/')+1) : parseReqData.providerId;
				return _verifyRequestByAbusiveService(context, siteId)
					.then(abusiveRes => {
						return { parseReqData, abusiveRes };
					})
			})
			.then(data => {
				let validateCaptcha = data.abusiveRes.captchaValidation;
				// captcha validation is not required for getProvider call
				if( validateCaptcha === true && data.parseReqData.method != 'GET' ) {
					if( _.isEmpty(data.parseReqData.captchaData) ) {
						return _getCaptchaAPIDetails(context, parseReqData.captchaData)
							.then(() => {
								return data.parseReqData;
							});
					} else {
						throw new TechDiff({"errorCode" : "CAPTCHA_ERROR"})
					}
				} else {
					data.parseReqData.captcha = validateCaptcha;
					return data.parseReqData;
				}
			});
	}

	postHandle(context, resData) {
		return super.postHandle(context, resData)
			.then(parsedResData => {
				if( parsedResData.reqData.method == 'GET' ) {
					let data = JSON.parse(parsedResData.data);
					data.captcha = parsedResData.reqData.captcha === true;
					parsedResData.data = JSON.stringify(data);
				}
				return parsedResData;
			});
	}
}

var _verifyRequestByAbusiveService = (context, siteId) => {

	var abuseServiceUrl = appConfig.get('abuseServiceDetectionURL');
	
	if( _.isEmpty(abuseServiceUrl) ) {
		logger.info(context.loggerPrefix, 'abuseServiceDetectionURL is empty', abuseServiceUrl);
		return Promise.resolve({ captchaValidation : false });
	}

	var jsonData = {
			"name" : "ADD_ACCOUNT",
			"payload" : {
				"cobrandId" : context.get('brandId'),
				"userId" : context.getUserContext().userId,
		  		"siteId" : siteId
		  	},
		  	"source" : {
		  		"component" : "NODE",
		  		 "ip" : global.uniqueIPAddress
		  	}
		}

	var _absuiveReq = {
		url : abuseServiceUrl,
		method :'GET',
		timeout : appConfig.get('abuseServiceTimeout'),
		data : { filter : JSON.stringify(jsonData) },
		proxy : false
	};

	logger.info(context.loggerPrefix, 'URL Details of Abuse details ', _absuiveReq);
	return internalProviderService.vendorCall(context, _absuiveReq)
            .then(_httpResponse => {
				logger.info(context.loggerPrefix, 'response.statusCod : ', _httpResponse.statusCode);
				logger.info(context.loggerPrefix, 'Abuse Service response :',  _httpResponse.data);
				let statusResponse = JSON.parse(_httpResponse.data);
				if( statusResponse.allowed === false ) {
					logger.error(context.loggerPrefix, "Site is blocked");
					statusResponse.errorCode = "SITE_BLOCKED";
					throw new TechError(statusResponse);
				} else if(statusResponse.action=="CHALLENGE_CAPTCHA") {
					return { captchaValidation : true };
				} else {
					logger.info(context.loggerPrefix, "Abuse service is validated successfully. Continue to add account.");
					return { captchaValidation : false };
				}
			})
			.catch(e => {
				if( !e.details || e.details.errorCode != "SITE_BLOCKED" ) {
					return { captchaValidation : true }
				} else {
					throw e;
				}
			});
};

var _getCaptchaAPIDetails = (context, captchaData) => {
	logger.info(context.loggerPrefix, 'Fetching captcha details');

	var _captchaAPIReq = {
		url : 'https://www.google.com/recaptcha/api/siteverify',
		method :'POST',
		form: { secret: context.getParam('FlgCaptchaSecretKey'), response : captchaData },
		isFormData : true
	};

	return internalProviderService.vendorCall(context, _captchaAPIReq)
            .then(_httpResponse => {
					var statusResponse = JSON.parse(_httpResponse.data).success;
					if(statusResponse){
						logger.info(context.loggerPrefix, "Captcha is validated successfully. Continue add account.");
						return {};
					} else {
						logger.error(context.loggerPrefix, "Captcha validated failed. Retrurn to login form.");
						throw new TechDiff({
						   "errorOccurred" : true,
						   "exceptionType" : "CaptchaNotVerifiedException",
						   "message" : "Captcha verification is failed"
					   });
					}
			})
			.catch(e => {
				logger.error(context.loggerPrefix, 'Captcha API error::::::', error);
				throw new TechDiff({
					"exceptionType" : "CaptchaNotVerifiedException",
					"message" : "Captcha verification is failed"
				});
			});
}

module.exports = GoogleCaptchaInteceptor;