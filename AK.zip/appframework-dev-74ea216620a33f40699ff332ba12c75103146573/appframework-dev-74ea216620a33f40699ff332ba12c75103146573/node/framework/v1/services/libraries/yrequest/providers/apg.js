module.paths = module.parent.paths;

const YslProvider = require('./ysl');

const appConfig = require(global.paths.APP_CONFIG_PATH);

class ApgProvider extends YslProvider {

    constructor(providerType) {
        super(providerType);
    }

    createRequest(context, inputReq) {
        logger.debug(context.loggerPrefix, "Constructing apg-request input for url", inputReq.url);

        var _request = super.createRequest(context, inputReq);
        _request.proxy = appConfig.get('httpProxyUrl');
        return _request;
    }

}

module.exports = ApgProvider;