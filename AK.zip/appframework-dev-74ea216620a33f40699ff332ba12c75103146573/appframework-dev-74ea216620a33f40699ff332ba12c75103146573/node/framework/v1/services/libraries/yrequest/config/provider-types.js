module.paths = module.parent.paths;

module.exports = {
    REST : "REST",
    YSL : "YSL",
    ESS : "ESS",
    VENDOR : "VENDOR",
    APG : "APG"
}