module.paths = module.parent.paths;

const _ = require('underscore');
const path = require('path');

const AbstactProvider = require('./abstract');
const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));
const errorCodeConfig = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/error-code-config'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

const VERSION_PATTERN = /\d+[.\d+]*/g;
const YSL_BASE_URL_INFO_CACHE = {};

class YslProvider extends AbstactProvider {

    constructor(providerType) {
        super(providerType);
    }

    service(context, inputReq) {
        //logger.info('YSL Call is invoked');
        return super.service(context, inputReq)
            .then(_httpResponse => {
                //logger.info('Response', _httpResponse);
                return _httpResponse;
            })
    }

    createRequest(context, inputReq) {
        logger.debug(context.loggerPrefix, "Constructing ysl-request input for url", inputReq.url);

        var _request = super.createRequest(context, inputReq);
        _request.headers['com.yodlee.ops.loggin.trackerId'] = this.generateUniqueTrackId(context);

        var userSession = context.getUserAuthToken();

        var yslBaseUrlInfo = YSL_BASE_URL_INFO_CACHE[inputReq.baseUrl];
        if (!yslBaseUrlInfo) {
            yslBaseUrlInfo = {};

            let _yslUrlArray = inputReq.baseUrl.split('/ysl/');
            yslBaseUrlInfo.baseUrl = _yslUrlArray[0] + '/ysl';
            yslBaseUrlInfo.cobrandName = _yslUrlArray[1];
            YSL_BASE_URL_INFO_CACHE[inputReq.baseUrl] = yslBaseUrlInfo;
        }

        var apiVersion = inputReq.url.match(VERSION_PATTERN)[0];
        _request.headers['Api-Version'] = apiVersion;
        _request.headers['Cobrand-Name'] = yslBaseUrlInfo.cobrandName;

        _request.uri = yslBaseUrlInfo.baseUrl + '' + inputReq.url.split(apiVersion)[1]

        if (!_.isEmpty(userSession)) {
            _request.headers['Authorization'] = '{cobSession=token:' + yutils.getYslNodeHeader(userSession) + ',userSession=' + userSession + '}';
        }

        return _request;
    }

    parseErrorResponse(errorData) {
        let _errorResponse = JSON.parse(errorData);
        let errorType = errorCodeConfig.getMappingErrorType(_errorResponse.errorCode);
        if( errorType ) {
            logger.info("YSL Error Type ", errorType);
            _errorResponse.errorType = errorType;
            if (errorType == 'YSL_SESSION_ERROR' || errorType == 'INVALID_TOKEN' | errorType == 'STALE_SESSION') {
                _errorResponse.groupErrorType = 'SESSION_ERROR'
            }
        }
        return _errorResponse;
    }

    getInteceptors(context, reqData) {
        var inteceptors = [];
        if (reqData.url.indexOf('/user/preferences') != -1 && reqData.method == 'POST') {
            inteceptors.push("mem-pref");
        }

        if( context.getParam('siteloginFormCaptchaEnabled') ) {
            if (reqData.url.indexOf('/providerAccounts') != -1 && reqData.method.toUpperCase() == 'POST' ) {
                inteceptors.push('google-captcha');
            } else if (reqData.url.indexOf('/providers/') != -1 ) {
                inteceptors.push('google-captcha');
            }
        }
        return inteceptors;
    }
}

module.exports = YslProvider;