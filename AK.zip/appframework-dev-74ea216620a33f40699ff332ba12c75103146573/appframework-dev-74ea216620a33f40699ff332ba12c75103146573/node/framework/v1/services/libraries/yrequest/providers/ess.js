module.paths = module.parent.paths;

const AbstactProvider = require('./abstract');

class EssProvider extends AbstactProvider {

    constructor(providerType) {
        super(providerType);
        this.isFormInputProvider = true;
    }

    service(context, inputReq) {
        //logger.info('YSL Call is invoked');
        return super.service(context, inputReq)
            .then(_httpResponse => {
                //logger.info('Response', _httpResponse);
                return _httpResponse;
            })
    }

    parseErrorResponse(data) {
        return data;
    }
}

module.exports = EssProvider;