module.paths = module.parent.paths;

const crypto = require('crypto');
const path = require('path');
const fs = require('fs');

const appConfig = require(global.paths.APP_CONFIG_PATH);
const apiPaths = require('./api-paths.js');
const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));

const apiCacheFolderPath = path.join(global.paths.RESOURCE_CACHE_PATH, 'static');

var set = (context, inputReq, apiRes) => {
    if( appConfig.get('apiCacheEnabled') === true && inputReq.apiCacheKey ) {
        let cachePath = _getApiCachePath(inputReq.apiCacheKey);
        let cacheRes = {};
        cacheRes.expiredId = yutils.getDateByIntervalType(appConfig.get("apiCacheIntervalType"));
        cacheRes.response = apiRes;
        cacheRes.url = inputReq.url;
        yutils.createFolder(_getApiCacheRootPath());
        fs.writeFileSync(cachePath, JSON.stringify(cacheRes));
        logger.info(context.loggerPrefix, "Cached response for api", inputReq.url, cachePath);
    }
}

var get = (context, inputReq) => {
    let apiResponse;
    if( _isEnabled(inputReq.url, inputReq.method || 'POST') ) {
        inputReq.apiCacheKey = _getApiCacheKey(inputReq);
        let cachePath = _getApiCachePath(inputReq.apiCacheKey);
        if(fs.existsSync(cachePath)) {
            let cacheExpired = false;
            logger.info(context.loggerPrefix, "Fetching api response from cache file", inputReq.apiCacheKey, inputReq.url);
            let cacheContent = require(cachePath);
            let currentExpiredId = yutils.getDateByIntervalType(appConfig.get("apiCacheIntervalType"));
            
            if( cacheContent.expiredId != currentExpiredId ) {
                _remove(cachePath);
                if( cacheContent.expiredId != currentExpiredId ) {
                    cacheExpired = true;
                }
            }
            if( !cacheExpired ) {
                logger.info(context.loggerPrefix, "Found api resopnse in cache", inputReq.apiCacheKey, inputReq.url);
                apiResponse = JSON.parse(JSON.stringify(cacheContent.response));
            } else {
                logger.info(context.loggerPrefix, "API-Cache is expired so re-calling API", inputReq.url, cacheContent.expiredId, currentExpiredId);
            }
        } else {
            logger.info(context.loggerPrefix, "Cache doen't exist for api ", inputReq.url);
        }
    } else {
        logger.info(context.loggerPrefix, "Cache is not enabled for api ", inputReq.url);
    }
    return apiResponse;
}

var _isEnabled = (apiPath, method) => {
    var isEnabled = false;
    if( apiPaths[apiPath] && method == "GET" ) {
        isEnabled = true;
    }
    return isEnabled;
}

var _getApiCacheKey = (inputReq) => {
    var urlData = (inputReq.method || 'POST') + '_' + inputReq.baseUrl + '_' + inputReq.url;
    return crypto.createHash('md5').update(urlData + JSON.stringify(inputReq.data || {})).digest("hex");
}

var _getApiCachePath = (fileName) => {
    return path.join(_getApiCacheRootPath(), fileName + '.json');
}

var _getApiCacheRootPath = () => {
    return path.join(apiCacheFolderPath, appConfig.get('resourceCacheFolder'), 'api');
}

var _remove = ( cacheFilePath ) => {
	try {
		delete require.cache[cacheFilePath];
		logger.debug('Deleted api-cache for path', cacheFilePath);
	} catch(e) {
		logger.debug('require-clear api-cache error', e);
	}
}

module.exports = {
    set,
    get
}