module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const yrequest = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest'));
const { TechError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));
const ProviderTypes = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest/config/provider-types'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

var restCall = (context, inputData) => {

	logger.debug(context.loggerPrefix, 'Initiate Rest Call', inputData.url);
	inputData.serviceType = ProviderTypes.REST;
	inputData.baseUrl = context.get('resturl');

	return yrequest(context, inputData);
}

var yslCall = (context, inputData) => {

	logger.debug(context.loggerPrefix, 'Initiate Ysl Call', inputData.url);
	inputData.serviceType = ProviderTypes.YSL;
	inputData.baseUrl = context.get('yslurl');

	return yrequest(context, inputData);
}

var apgCall = (context, inputData) => {

	logger.debug(context.loggerPrefix, 'Initiate Ess Call', inputData.url);
	inputData.serviceType = ProviderTypes.APG;
	inputData.baseUrl = context.get('apgurl');

	return yrequest(context, inputData);
}

var essCall = (context, inputData) => {

	logger.debug(context.loggerPrefix, 'Initiate Ess Call', inputData.url);
	inputData.serviceType = ProviderTypes.ESS;
	inputData.baseUrl = appConfig.get("esLoggingEndPoint");

	return yrequest(context, inputData);
}

var vendorCall = (context, inputData) => {

	logger.debug(context.loggerPrefix, 'Initiate Cdn Call', inputData.url);
	inputData.serviceType = ProviderTypes.VENDOR;
	inputData.baseUrl = '';

	return yrequest(context, inputData);
}

var makeCall = (context, inputData) => {
	logger.debug('request data', inputData);
	if (ProviderTypes[inputData.serviceType.toUpperCase()]) {
		return eval(inputData.serviceType.toLowerCase() + 'Call')(context, inputData);
	} else {
		logger.error(context.loggerPrefix, "Invalid service type", inputData.serviceType);
		throw "INVALID_SERVICE_TYPE"
	}
}

var graphCall = (context, graphInputData) => {
	console.log(this);
	if (_.isArray(graphInputData.graphData)) {
		let promises = [];
		graphInputData.graphData.map(inputData => {
			let apiCall = makeCall(context, inputData)
				.then(response => { response.identifier = inputData.identifier; return response })
				.catch(e => { let errData = { errorType : e.errorType, errorOccurred : true, details : e.details };
						return { data: JSON.stringify(errData), identifier: inputData.identifier, error: true } });
			promises.push(apiCall);
		});

		return Promise.all(promises)
			.then(graphOutput => {
				let finalResponse = { headers: {} };
				let outputArray = [], error = false;
				graphOutput.map(outputData => {
					outputArray.push("\"" + outputData.identifier + "\":" + outputData.data);
					finalResponse[outputData.headers] = outputData.headers;
					error = error || outputData.error;
				});
				finalResponse.data = "{" + outputArray.join(",") + "}";
				if (error === true) {
					logger.error(context.loggerPrefix, 'Graph call is failed')
					throw new TechError({ data: JSON.parse(finalResponse.data), serviceType: 'graph' });
				} else {
					return finalResponse;
				}
			});
	} else {
		logger.error(context.loggerPrefix, 'graph data is empty or not an array.')
		throw "INVALID_INPUT";
	}
}

module.exports = {
	restCall,
	yslCall,
	apgCall,
	essCall,
	vendorCall,
	makeCall,
	graphCall
}