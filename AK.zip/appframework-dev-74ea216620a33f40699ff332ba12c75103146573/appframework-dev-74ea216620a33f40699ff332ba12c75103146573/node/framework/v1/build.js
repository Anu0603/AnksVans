module.paths = module.parent.paths

const path = require('path')
const fs = require('fs')
const _ = require('underscore')

const appConfig = require(global.paths.APP_CONFIG_PATH)

const clusterMessaging = require(path.join(
	__dirname,
	'libraries/cluster-message'
))
const yutils = require(path.join(
	global.paths.FRAMEWORK_VERSION_PATH,
	'libraries/yutils'
))

const CBDK_VAR_PREFIX = '____global____'
const CBDK_VAR_PREFIX_REGEX = new RegExp(CBDK_VAR_PREFIX, 'g')

var buildTime = new Date().getTime()

var _deleteCacheFiles = () => {
	return new Promise((resolve) => {
		logger.info('Cleaning cache-files task initiated.')
		yutils.removeAllFiles(
			path.join(global.paths.FRAMEWORK_VERSION_PATH, 'resource-cache'),
			false
		)
		logger.info('Cleaning cache-files task completed.')
		resolve()
	})
}

var _buildApp = (buildMode) => {
	logger.info('Build Mode is ', buildMode)
	var isValidBundle = false
	return new Promise((resolve, reject) => {
		module.paths.push(
			(global.paths.BLOCKS_NODE_MODULES_PATH = path.resolve(
				'../blocks/node_modules'
			))
		)
		logger.info('Building application is initiated.')
		const webpack = require('webpack')
		const webpackConfig = require(path.join(
			global.paths.BASE_PATH,
			'..',
			'webpack.config'
		))
		const cbdkData = fs
			.readFileSync(
				path.join(
					global.paths.FRAMEWORK_VERSION_PATH,
					'brand-default/css/scss/global_cbdk.scss'
				)
			)
			.toString()
		const variables = cbdkData.match(/\$[a-zA-Z0-9\-\s:]+/g)
		const cbdkVariables = []
		variables.map((variable) => {
			variable = variable.replace(':', '').trim()
			let mVariable =
				variable.trim() +
				':' +
				variable.replace('$', CBDK_VAR_PREFIX) +
				';'
			if (cbdkVariables.indexOf(mVariable) == -1) {
				cbdkVariables.push(mVariable)
			}
		})
		logger.debug('Modifed Cbdk Variables', cbdkVariables)
		const webpackConfigData = webpackConfig({
			envType: buildMode,
			cbdkVariables: cbdkVariables.join('\n')
		})
		const compiler = webpack(webpackConfigData)

		if (appConfig.get('buildWatch') === true) {
			logger.info('Build watch is enabled in %s mode', buildMode)
			const watching = compiler.watch(
				{
					ignored: /node_modules/,
					aggregateTimeout: 300,
					poll: undefined
				},
				(err, stats) => {
					if (err || stats.hasErrors()) {
						logger.error(
							stats.toString({ minimal: true, colors: true })
						)
					} else {
						logger.info(stats.toString())
						logger.info('Building compilation is success.')
						clusterMessaging.triggerMessage(
							{
								cmd: 'RELOAD_BRAND',
								args: {
									cobAppKey: 'ALL',
									serverStartupTime:
										new Date().getTime() + '',
									resourceCacheFolder: appConfig.get(
										'resourceCacheFolder'
									)
								}
							},
							'WORKERS'
						)
					}
					_postBuildProcess(webpackConfigData)
						.then(() => {
							logger.info('Building application is completed.')
							if (!isValidBundle) {
								isValidBundle = true
								resolve()
							}
						})
						.catch((e) => {
							logger.error(
								'Building application is failed due errors of Post build process.'
							)
							reject(e)
						})
				}
			)
		} else {
			logger.info('Build watch is disabled in %s mode', buildMode)
			compiler.run((err, stats) => {
				logger.info(stats.toString())

				if (err || stats.hasErrors()) {
					logger.info('Building application is failed.')
					reject(err || new Error('FAILED'))
				} else {
					_postBuildProcess(webpackConfigData)
						.then(() => {
							logger.info('Building application is completed.')
							resolve()
						})
						.catch((e) => {
							logger.error(
								'Building application is failed due errors of Post build process.'
							)
							reject(e)
						})
				}
			})
		}
	})
}

var _postBuildProcess = (webpackConfigData) => {
	return new Promise((resolve) => {
		let cssBlockAppPath = path.join(global.paths.BLOCK_APP_PATH, 'css')
		let scssBlockAppPath = path.join(global.paths.BLOCK_APP_PATH, 'scss')
		yutils.createFolder(scssBlockAppPath)
		let cssFiles = fs.readdirSync(cssBlockAppPath)
		cssFiles.map((fileName) => {
			let scssFilePath = path.join(
				scssBlockAppPath,
				fileName.replace('.css', '.scss')
			)
			try {
				let cssFilePath = path.join(cssBlockAppPath, fileName)
				let fstat = fs.statSync(cssFilePath)
				if (buildTime < new Date(fstat.mtime).getTime()) {
					logger.debug(
						'Replacing ' +
							CBDK_VAR_PREFIX +
							' with $ for css module',
						cssFilePath
					)
					fs.writeFileSync(
						scssFilePath,
						fs
							.readFileSync(cssFilePath)
							.toString()
							.replace(CBDK_VAR_PREFIX_REGEX, '$')
					)
					//fs.unlink(cssFilePath);
				}
			} catch (e) {
				logger.error('sass file creation is failed', scssFilePath)
			}
		})

		let mainBundlePath = path.join(
			global.paths.BLOCK_APP_PATH,
			'js/bundle.js'
		)

		if (buildTime < new Date(fs.statSync(mainBundlePath).mtime).getTime()) {
			let mainBundleData = fs.readFileSync(mainBundlePath).toString()
			fs.writeFileSync(
				mainBundlePath,
				mainBundleData.replace(
					'"' + webpackConfigData.output.publicPath + '"',
					'"' +
						webpackConfigData.output.publicPath +
						'" + PARAM.brandResourcePath +"/"'
				)
			)
		}
		buildTime = new Date().getTime()
		resolve()
	})
}
var _initialize = () => {
	return _deleteCacheFiles().then(() => {
		if (appConfig.get('ignoreBuild') === true) {
			return {}
		} else if (
			appConfig.get('developmentMode') === true ||
			appConfig.get('buildMode') === true
		) {
			return _buildApp(
				appConfig.get('developmentMode') === true
					? 'development'
					: 'production'
			)
		} else {
			return {}
		}
	})
}

exports.initialize = _initialize
