module.exports = {
    "block.common": {
        ssoRedirectUrlConfig: {
            //Will redirect incase of Authentication issues
            login_url: "",
            //Will redirect incase one of the user session is invalidate
            stale_session_url: "",
            //redirect user to calback url sent as part of request.
            logout_url: "",
            //If URL configured, will call else will not call
            keepalive_url: "",
            //SSO: will redirect user on session timeout
            session_timeout_url: "",
            //Any tech issues redirect to this url
            techdiff_url: "",
            //Default url to redirect if none of the above is configured
            fallback_url: "",
            default_domain: ""
        },
        ssoErrorHandleEnabled: false,
        ssoRedirectPostMessageEnabled: false,
        supportedApps: ["fastlink"],
        supported_currency: [
            "AUD",
            "BRL",
            "GBP",
            "CAD",
            "CNY",
            "EUR",
            "HKD",
            "INR",
            "IDR",
            "JPY",
            "MXN",
            "NZD",
            "RUR",
            "SGD",
            "ZAR",
            "CHF",
            "USD",
            "VND"
        ],
        overrideQueryParamsKeys: {
            product_type: {
                alias: "product",
                values: ["AGGR", "VERIFICATION", "VERIFICATIONPLUSAGGR"]
            }
        },
        postQueryParams: []
        //segmentBrandType : 'NAME', // possible values are ID or NAME
        //cssOverrideDisabled : true
        //siteLogoImageCacheEnabled : true
    },
    "block.fastlink": {
        popular_providers_count: 10,
        popular_providers_count_mobile: 10,

        providers_search_count: 40,
        providers_search_count_mobile: 40,

        enable_real_estate: true,
        enable_manual_account: true,

        show_landing_screen_footer: true,
        show_privacy_policy: true,
        show_security_policy: true,

        show_providers_already_added_icon: true,

        show_providers_base_url: true,
        show_providers_favicon: true,

        show_popular_site_name: false,

        //Login
        login_tnc_type: "external",
        login_tnc_version: 1,
        login_onetime_show_tnc: false,
        login_show_tnc_always: true,
        login_allow_copy_paste: false,
        login_show_tnc_checkbox: false,
        login_external_tnc_url: "http://yodlee.com",
        product_type: "AGGR", // Valid product type - "AGGR"|"VERIFICATION"|"VERIFICATIONPLUSAGGR"

        // VERIFICATION MODULE
        verification_eligble_containers: ["bank"], // Add the eligible containers in the array

        // SUCCESS SCREEN - IAV keys
        success_account_selection_type: "MULTI_ACCOUNT", // Valid selection Types - "MULTI_ACCOUNT"|"SINGLE_ACCOUNT"
        disable_link_more_btn_for_verification: true,
        enable_verification_ms_flow: false,

        // SUCCESS SCREEN
        disable_trash_icon: false, //Option to remove Delete trash icon
        container_list: [
            "bank",
            "creditCard",
            "investment",
            "loan",
            "mortgage",
            "insurance",
            "bill",
            "reward"
        ], //List of Containers- order as well to display only listed containers
        disable_bottom_text: false, //Key to disable 'Any future text'
        disable_popup_on_delete: false, //Disable pop up while clicking on delete button
        disable_popup_on_cancel: false, //Disable pop up while clicking on cancel button
        polling_interval: 0, //Time for Polling period interval on success
        disable_link_more_for_add: false, //Disabling link more accounts for ADD
        disable_link_more_for_edit: false, //Disabling link more accounts for edit
        disable_link_more_for_refresh: false, //Disabling link more accounts for refresh
        disable_link_more_for_standard: false, //Disabling link more accounts for standard flow

        /* Erro  module
         * TA = Try Again
         * EC = Edit credentials
         * RC = Recover credentials
         * UA = Unlock account
         * VFY = Verify
         * DA = Delete account
         * UN = Update now
         * AMA = Add manual account
         * AMRA = Add Manually Real Estate Address
         * MAA = Manually Add Account
         * LAA = Link another account
         * UC = Update credentials
         * CL = Change language
         * TAA = Take appropriate action
         * VA = Verify account
         * UI = Update info
         * SL = Log in to Site
         * UAN = Update account now
         * CP = Change password
         * RV = Re-verify
         * VS = Visit
         * SCS = Select the correct site
         * SDS = Select Different Site
         * GTS = GO TO Site
         * RF = REFRESH
         * TO = Timed Out
         * NXT = Next
         * CANCEL = Cancel
         * OK = OK
         * LAA = Link Another Site // this is deprecated. Instead use LAA
         * EM = Enter Manually
         */

        //ERROR DISCREPTION WITH TOOLTIP
        error_discription_tooltip: ["INCORRECT_CREDENTIALS"],

        // VERIFICATION MODULE
        disable_verification_success_page: false, // Option to disable Success Page in verification module
        provider_account_polling_interval: 300, // Polling interval time in milliseconds,
        success_page_stay_time: 1500, // Time period for which user to stay on Success Screen
        error_account_locked_buttons: "GTS,LAA", // error_407
        // error_incorrect_credentials_buttons: "SDS",
        error_invalid_addl_info_provided_buttons: "TA,LAA", // MFA time out
        error_addl_authentication_required_buttons: "TA,LAA", // MFA time out
        error_mfa_info_not_provided_in_real_time_by_user_via_app_buttons:
            "TA,LAA",
        error_user_action_needed_at_site_buttons: "GTS,LAA", //
        error_credentials_update_needed_buttons: "GTS,LAA", // error_406 - NOT WORKING
        error_site_session_invalidated_buttons: "TA",

        error_unexpected_site_error_buttons: "TA,LAA",
        error_tech_error_buttons: "TA,LAA",
        error_data_retrieval_failed_buttons: "TA,LAA",
        error_request_time_out_buttons: "TA,LAA",
        error_dataset_not_supported_buttons: "TA,LAA",
        error_enrollment_required_for_dataset_buttons: "TA,LAA",
        error_generic_buttons: "TA,LAA",

        error_site_unavailable_buttons: "TA,LAA",
        error_site_blocking_error_buttons: "GTS,LAA",
        error_site_not_supported_buttons: "MAA,LAA",
        error_site_not_supported_manual_account_disabled_buttons: "LAA",
        error_data_not_available_buttons: "LAA,VS",
        error_new_authentication_required_buttons: "EC",
        error_beta_site_dev_in_progress_buttons: "LAA",
        // hardcoded in  Matching service.
        error_verification_failed_buttons: "LMA,CANCEL",
        error_update_not_allowed_buttons: "CLOSE",
        error_refresh_too_soon_buttons: "CLOSE",
        error_refresh_already_in_process_buttons: "CLOSE",

        // IAV+AGG no verification_eligible_container type account is available
        error_no_accounts_for_verification_buttons: "LAA",

        error_deeplink_tech_diff_buttons: "TECH_DIFF_CLOSE",
        error_tech_diff_buttons: "TECH_DIFF_CLOSE",

        // ERROR CDV OPTIONS
        cdv_pre_verification_invoke_enabled_errors: [
            "INCORRECT_CREDENTIALS",
            "ACCOUNT_LOCKED",
            "BETA_SITE_DEV_IN_PROGRESS",
            "SITE_BLOCKING_ERROR",
            "UNEXPECTED_SITE_ERROR",
            "SITE_UNAVAILABLE",
            "TECH_ERROR",
            "GENERIC",
            "DATASET_NOT_SUPPORTED",
            "VERIFICATION_FAILED"
        ],
        cdv_post_verification_invoke_enabled_errors: [],

        // CDV MODULE
        enable_cdv: false,
        show_cdv_on_search: false,
        show_cdv_on_login: false,
        cdv_initiate_accountType_selection: "CHECKING",
        error_cdv_invalid_flow_buttons: "CLOSE",
        error_cdv_initiate_verification_already_initiated_buttons: "CLOSE",
        error_cdv_initiate_verification_already_completed_buttons: "CLOSE",
        error_cdv_initiate_verification_unknown_buttons: "CLOSE",
        error_cdv_complete_already_success_buttons: "CLOSE",
        error_cdv_complete_already_failed_buttons: "CLOSE",
        error_cdv_complete_failed_buttons: "CLOSE",

        //Real estate
        disable_realestate_manual: false,
        disable_realestate_system: false,
        disable_realestate_edit: false,

        //Callback
        client_callback_domains: "", //Ex: money.yodlee.com
        client_callback_url_validation: false,

        // Tech Diff Page
        enable_techdiff_page: true
    }
};
