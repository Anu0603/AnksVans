module.exports = {
    "block.common": {
        error_title_default: "Technical Difficulties",
        error_description_default:
            "We are unable to process your request at this time, please try again later.",
        currency_aud: "Australian Dollar (AUD)",
        currency_brl: "Brazillian Real (BRL)",
        currency_gbp: "British Pound (GBP)",
        currency_cad: "Canadian Dollar (CAD)",
        currency_cny: "Chinese Renminbi (CNY)",
        currency_eur: "Euro (EUR)",
        currency_hkd: "Hong Kong Dollar (HKD)",
        currency_inr: "Indian Rupees (INR)",
        currency_idr: "Indonesian Rupiah (IDR)",
        currency_jpy: "Japenese Yen (JPY)",
        currency_mxn: "Mexican Peso (MXN)",
        currency_nzd: "New Zealand Dollar (NZD)",
        currency_rur: "Russian Ruble (RUR)",
        currency_sgd: "Singalore Dollar (SGD)",
        currency_zar: "South African Rand (ZAR)",
        currency_chf: "Swiss Frac (CHF)",
        currency_usd: "United States Dollar (USD)",
        currency_vnd: "Vietnamese Dong (VND)",
        popup_cancel_button: "Cancel",
        popup_continue_button: "Continue",
        next_button_text: "Next",
        delete_button_text: "Delete",
        CobrandName: "Yodlee",
        error_required_field: "This is a required field",
        fastlink_title: "Fastlink"
    },
    "block.fastlink": {
        cobrand_name: "Yodlee",
        fl_module_name: "fastlink",
        error_tech_diff_title: "Technical Difficulties",
        error_tech_diff_desc:
            "We are unable to process your request at this time, please try again later.",
        site_sort_order: "Sorted by Most Popular",
        security_policy: "Security Policy",
        privacy_policy: "Privacy Policy",
        no_search_result_line_one: "We didn't find any results for ",
        no_search_result_line_two: "You may need to",
        search_different_fi: "search for a different financial institution.",
        search: "Search",
        real_estate: "Real Estate",
        manual: "Manual Accounts",
        login_tnc_prefix: "By clicking submit you have accepted the ",
        login_tnc: "Terms and Conditions.",
        login_reset: "Redirect to Reset Password",
        login_submit_button_text: "Submit",
        login_update_button_text: "Update",
        login_edit_credentials_label: "Edit your credentials",
        mfa_qa_label: "Security Question Answer",
        mfa_token_label: "Passcode",
        mfa_info_text: "Your bank requires another form of authentication.",
        mfa_timer_msg: "Time Remaining:",
        mfa_captcha_placeholder: "Type the characters above",
        login_optional_text: "(optional)",
        login_choose_one: "Choose One",
        field_inline_error_message: "",
        popup_account_not_link: "Your Accounts will not be saved.",
        popup_exit_confirmation: "Are you sure you want to exit?",
        popup_continue: "Continue Linking Accounts",
        popup_exit: "Exit",
        account_number_mask_character: "x-",

        // VERIFICATION MODULE
        verification_login_stepper_text: "Securely Verifying Your Login...",
        verification_data_stepper_text: "Retrieving Data...",
        verification_success_text: "SUCCESS",

        //SUCCESS SCREEN
        accounts_summary_title_text:
            "The account(s) below will be added to your profile.",
        account_summary_all_accounts_deleted_text:
            "All accounts have been deleted.",
        account_summary_linking_more_accounts_loading_text:
            "More accounts are still being linked...",
        account_summary_link_more_accounts_button_text: "Link More Accounts",
        account_summary_save_and_finish_button_text: "Save & Finish",
        cdv_complete_success_button_deeplink_text: "Close",
        account_summary_save_and_link_more_accounts_button_text:
            "Save & Link More Accounts",
        account_summary_cancel_button_text: "Cancel",
        account_summary_close_button_text: "Close",
        account_summary_bottom_text_start: "Any future accounts opened with ",
        account_summary_bottom_text_end:
            " will be added to your profile automatically.",
        account_summary_delete_popup_confirmation_text:
            "Are you sure you want to delete this account?",
        account_summary_cancel_popup_confirmation_text_1:
            "Your accounts will not be saved.",
        account_summary_cancel_popup_confirmation_text_2:
            "Are you sure you want to exit?",
        account_summary_delete_popup_keep_account_button_text: "Keep Account",
        account_summary_delete_popup_delete_account_button_text:
            "Delete Account",
        account_summary_cancel_popup_continue_linking_accounts_button_text:
            "Continue Linking Accounts",
        account_summary_delete_popup_exit_button_text: "Exit",
        account_summary_title_container_bank: "Cash",
        account_summary_title_container_insurance: "Insurance",
        account_summary_title_container_loan: "Loan",
        account_summary_title_container_investment: "Investment",
        account_summary_title_container_creditcard: "Cards",
        account_summary_title_container_reward: "Rewards",
        account_summary_title_container_bill: "Bills",
        account_summary_selection_message:
            "Select the accounts that you would like to enable.",
        account_summary_single_account_selection_message:
            "Select the account that you would like to enable.",
        accounts_summary_single_account_message_text:
            "The account below will be verified.",
        account_summary_enbale_all_text: "ENABLE ALL ACCOUNTS",
        account_summary_selection_message_modal_text:
            "Enabling your accounts will allow them to be used for money movement such as bill payment and transfers.",
        account_summary_aggregation_message_modal_text:
            "Adding accounts to your profile allows you to view all of your financial accounts in one location to easily monitor your net worth.",

        //ACTION BUTTON TEXT
        try_again_button_text: "Try Again",
        edit_credentials_button_text: "Edit Credentials",
        cancel_button_text: "Cancel",
        // ERROR SCREEN BUTTONS
        error_lma_button_text: "Link More Accounts",
        error_maa_button_text: "Manually Add Account",
        error_ta_button_text: "Try Again",
        error_gts_button_text: "Go to Site",
        error_vs_button_text: "Visit Site",
        error_laa_button_text: "Link Another Account",
        error_close_button_text: "Close",
        error_sds_button_text: "Select Different Site",
        error_ec_button_text: "Edit Credentials",
        error_cancel_button_text: "Cancel",
        error_tech_diff_close_button_text: "Close",

        // ERROR TITLES, DESCRIPTIONS and TOOLTIP CONTENT
        error_account_locked_title: "Your Account is Locked",
        error_account_locked_desc:
            "You're locked out of your account. Please visit _SITE_NAME_ to fix.",
        error_incorrect_credentials_title: "Incorrect Credentials",
        error_incorrect_credentials_desc:
            "The credentials you've entered are incorrect or you've selected the wrong site.",
        error_incorrect_credentials_tooltip_content:
            "<div>The credentials entered don't match the financial institution chosen.</div><div><p>Common reasons are:</p><ul><li>Some FIs have similar names, like Fidelity Brokerage and Fidelity Net Benefits. Please search and choose the correct FI subsidiary where there are several to choose from.</li><li>You've made a typo entering your credentials.</li><li>Your credentials have changed from the details you entered.</li></ul></div>",
        error_addl_authentication_required_title:
            "Additional Information Required",
        error_addl_authentication_required_desc:
            "Your security authentication timed out or a new security authentication is required. Please try again.",
        error_invalid_addl_info_provided_title: "Invalid Security Info",
        error_invalid_addl_info_provided_desc:
            "The information you provided is incorrect. Please try again or visit _SITE_NAME_ to verify your details.",

        /* "error_action_required_at_site_title" and "error_action_required_at_site_desc"
           *  The above mentioned title and description strings are common for the below mentioned ERROR_CODE
              1. USER_ACTION_NEEDED_AT_SITE
              2. CREDENTIALS_UPDATE_NEEDED
          */
        error_action_required_at_site_title: "Action Required at _SITE_NAME_",
        error_action_required_at_site_desc:
            "Please visit _SITE_NAME_ to update your account information or password.",

        error_property_value_not_available_title:
            "Property Value is Unavailable",
        error_property_value_not_available_desc:
            "Please ensure the property information is correct or enter it manually",
        error_site_session_invalidated_title: "Session Ended",
        error_site_session_invalidated_desc:
            "The session has ended due to security reasons or you are already logged in. Please make sure you're logged out on other devices and try again. ",

        /* "error_site_unavailable_title" and "error_site_unavailable_desc"
          *  The above mentioned title and description strings are common for the below mentioned ERROR_CODE
              1. UNEXPECTED_SITE_ERROR
              2. TECH_ERROR
              3. DATA_RETRIEVAL_FAILED
              4. REQUEST_TIME_OUT
              5. DATASET_NOT_SUPPORTED
              6. ENROLLMENT_REQUIRED_FOR_DATASET
              7. GENERIC - which is a fallback ERROR_CODE.
          */
        error_technical_error_title: "Technical Error",
        error_technical_error_desc:
            "We're unable to link your account at this time. Please try again later and contact _COBRANDNAME_ support team if the issue persists.",

        error_site_unavailable_title: "Site is Down",
        error_site_unavailable_desc:
            "We're unable to link your account at this time. Please try again in 4-24 hours.",

        error_site_blocking_error_title: "Site is Blocked",
        error_site_blocking_error_desc:
            "We're unable to add your account because this site is blocked. Please contact _SITE_NAME_'s customer support to fix.",

        error_site_not_supported_title: "Site Not Supported",
        error_site_not_supported_desc:
            "We're unable to support this site, but you can add your account details manually.",
        /**
         * 'site_not_supported_manual_account_disabled' this error status is a dereived error status
         * from "site_not_supported". This status is dereived to handle the use case of showing the different
         * error message when the "manual accounts" are disabled in the application.
         *
         * Further changes in the "site_not_supported" site Error status will have impact on the
         * "site_not_supported_manual_account_disabled" status. Consider this in the implementation.
         */
        error_site_not_supported_manual_account_disabled_title:
            "Site Not Supported",
        error_site_not_supported_manual_account_disabled_desc:
            "We're unable to support this site.",

        error_data_not_available_title: "Data is Unavailable",
        error_data_not_available_desc:
            "We're unable to find the requested account type for this site or you have closed the account.",

        error_new_authentication_required_title: "New Authentication Required",
        error_new_authentication_required_desc:
            "This site's method of authentication has changed. Please follow the new sign-on process. ",

        error_beta_site_dev_in_progress_title: "Site Support in Process",
        error_beta_site_dev_in_progress_desc:
            "We're still in the process of building support for this site. Please try again later. ",

        error_mfa_info_not_provided_in_real_time_by_user_via_app_title:
            "Your Request Timed Out",
        error_mfa_info_not_provided_in_real_time_by_user_via_app_desc:
            "Security info was not received in the time period required. Please try again.",

        error_verification_failed_title: "Account Verification Failed",
        error_verification_failed_desc:
            "We couldn’t verify your account at this time. Please try again later.",

        error_no_accounts_for_verification_title: "Account Verification Failed",
        error_no_accounts_for_verification_desc:
            "You do not have accounts eligible for verification with this site.",
        error_update_not_allowed_title: "Unable to Refresh Account",
        error_update_not_allowed_desc:
            "We're unable to refresh your account at this time. Please try again later.",
        error_refresh_too_soon_title: "Refresh Too Soon",
        error_refresh_too_soon_desc:
            "Not enough time has passed since your last refresh. Please try again later.",
        error_refresh_already_in_process_title: "Refresh Already in Process",
        error_refresh_already_in_process_desc:
            "We’re currently working on refreshing your account. Please check back later.",

        // REAL ESTATE ERRORS
        error_real_estate_address_not_found_title:
            "Property Value is Unavailable",
        error_real_estate_address_not_found_desc:
            "Please ensure the property information is correct or enter manually.",
        error_real_estate_value_already_added_title:
            "Real Estate Property value already exists",
        error_real_estate_value_already_added_desc:
            "Real Estate Property value already exists",
        error_real_estate_unable_to_delete_title:
            "Unable to Delete your Account",
        error_real_estate_unable_to_delete_desc:
            "We're unable to delete your account at this time. Please try again later.",

        // MANUAL ACCOUNT ERRORS
        error_manual_account_unable_to_delete_title:
            "Unable to Delete your Account",
        error_manual_account_unable_to_delete_desc:
            "We're unable to delete your account at this time. Please try again later.",

        // DEEPLINK ERRORS
        error_deeplink_tech_diff_title: "Technical Error",
        error_deeplink_tech_diff_desc:
            "We’re facing a technical issue. Please contact _COBRANDNAME_ support team or try again later.",

        // CDV MODULE
        cdv_error_account_type_not_selected: "Account type not selected",
        cdv_error_routing_number_not_valid: "Routing Number Not Valid",
        cdv_error_routing_number_not_found: "Routing Number Not Found",
        cdv_error_account_number_not_valid: "Account Number Not Valid",
        cdv_error_amount_not_valid: "Amount Not Valid",
        cdv_invoke_verification_info_text:
            "A small deposit and withdrawal, all less than one dollar, will be made to your account in the next 2-4 days. When you see these transactions, you can complete the verification.",
        cdv_invoke_pre_verification_demarcation_text: "OR",
        cdv_invoke_pre_verification_title: "Manual Verification",
        cdv_invoke_pre_verification_text_1:
            "Use your bank's routing and account number.",
        cdv_invoke_pre_verification_text_2: "Process takes 2-4 business days.",
        cdv_invoke_pre_verification_button_text: "Enter Account Information",
        cdv_invoke_post_verification_demarcation_text: "OR",
        cdv_invoke_post_verification_title: "Don't see your account?",
        cdv_invoke_post_verification_text:
            "If you have an account with your institution that is not shown above, you can add it manually by using your bank's routing and account number.",
        cdv_invoke_post_verification_button_text: "Manually Add Account",
        cdv_initiate_verification_info_title: "Enter Account Details",
        cdv_initiate_verification_form_account_type_text: "Account Type",
        cdv_initiate_verification_form_account_type_checking_text: "Checking",
        cdv_initiate_verification_form_account_type_savings_text: "Savings",
        cdv_initiate_verification_form_routing_number_text: "Routing Number",
        cdv_initiate_verification_form_account_number_text: "Account Number",
        cdv_initiate_verification_form_help_text:
            "Having trouble with your Account or Routing Number?",
        cdv_initiate_verification_form_detail_info_text:
            "A small deposit and withdrawal, all less than one dollar, will be made to your account in the next 2-4 days. When you see these transactions, you can complete the verification.",
        cdv_initiate_verification_form_submit_button_text: "Start Verification",
        cdv_initiate_verification_form_help_popup_title_text:
            "Routing & Account Number Location",
        cdv_initiate_verification_success_title: "Verification Started",
        cdv_initiate_verification_success_text:
            "A small deposit and withdrawal, all less than one dollar, will be made to your account in the next 2-4 days. When you see these transactions, you can complete the verification.",
        cdv_initiate_verification_success_button_text: "Close",
        cdv_initiate_verification_inprogress_title: "Verification in Progress",
        cdv_initiate_verification_inprogress_text:
            "The verification for your account is currently in progress. Please try again later.",
        cdv_initiate_verification_inprogress_button_text: "Close",
        cdv_complete_verification_info_title: "Complete Verification",
        cdv_complete_verification_info_text:
            "Please enter the amount of the deposits and the withdrawals we made to your account.",
        cdv_complete_verification_account_info_account_number_text:
            "Account Number",
        cdv_complete_verification_account_info_routing_number_text:
            "Routing Number",
        cdv_complete_verification_account_info_account_type_text:
            "Account Type",
        cdv_complete_verification_form_deposit_1_text: "Deposit Amount 1",
        cdv_complete_verification_form_deposit_2_text: "Deposit Amount 2",
        cdv_complete_verification_form_withdrawal_text: "Withdrawal Amount",
        cdv_complete_verification_form_submit_button_text: "Submit",
        cdv_complete_success_title: "SUCCESS",
        cdv_complete_success_button_text: "Save & Finish",
        error_cdv_invalid_flow_title: "Incorrect Information",
        error_cdv_invalid_flow_desc:
            "We're sorry, it appears to be an invalid flow in the challenge deposit verification process.",
        error_cdv_initiate_verification_already_completed_title:
            "Verification Status",
        error_cdv_initiate_verification_already_completed_desc:
            "This account has already completed the verification process.",
        error_cdv_initiate_verification_unknown_title: "Verification Status",
        error_cdv_initiate_verification_unknown_desc:
            "We're unable to verify your account at this time. Please try again later.",
        error_cdv_complete_already_success_title:
            "Verification Already Completed",
        error_cdv_complete_already_success_desc:
            "You have already verified this account.",
        error_cdv_complete_failed_title: "Account Verification Failed",
        error_cdv_complete_failed_desc:
            "We couldn’t verify your account because you entered the incorrect amount too many times.",
        error_cdv_complete_incorrect_amount_title:
            "Amounts Entered Incorrectly",
        error_cdv_complete_already_failed_title: "Account Verification Failed",
        error_cdv_complete_already_failed_desc:
            "We couldn’t verify your account because you entered the incorrect amount too many times.",

        // Manual Account
        manual_account_add_account_title: "Add Manual Account",
        manual_account_view_account_title: "View Accounts",
        manual_account_edit_account_title: "Edit Manual Account",
        manual_account_delete_account_popup_header: "Delete Account",
        manual_account_delete_confirm_text:
            "Are you sure you want to delete this account?",
        manual_account_delete_account_warning_text:
            "Warning: All account-related data will be deleted permanently. This action cannot be undone.",
        manual_account_delete_account_button_text: "Delete Account",

        //Real Estate
        real_estate_add_account_title: "Add Real Estate Account",
        real_estate_submit_button_text: "Submit",
        real_estate_edit_account_title: "Edit Real Estate Account",
        real_estate_include_net_worth_label: "Include In Net worth",
        real_estate_estimated_value_label: "Estimated Value",
        currency_label: "Currency",
        real_estate_real_estate_name: "Real Estate Name",
        real_estate_street_address_label: "Street Address",
        real_estate_city_state_zip_label: "City and State or ZIP",
        real_estate_city_label: "City",
        real_estate_state_label: "State",
        real_estate_zip_label: "Zip",
        real_estate_calculate_auto: "Calculate Automatically",
        real_estate_calculate_auto_desc: "We will calculate using SmartZip*",
        real_estate_enter_manually: "Enter Value",
        real_estate_enter_manually_desc: "Enter home value manually",
        real_estate_delete_confirm_text: "Are you sure you want to delete ?",
        real_estate_delete_account_popup_header: "Delete Account",
        real_estate_footer_text: "*Home Values provided by",
        real_estate_smartzip_footer_text: "SmartZip Analytics, Inc.",
        real_estate_view_account_title: "View Real Estate Account",
        real_estate_main_home_text: "Main Home",
        real_estate_see_more_details_text: "See more details on",
        real_estate_smartzip: " Smart Zip*",
        real_estate_save_finish_button_label: "Save & Finish",
        real_estate_save_and_link_more_button_label:
            "Save & Link More Accounts",
        real_estate_error_invalid_value: "Please enter a valid property value",
        real_estate_error_no_special_char: "No special characters allowed",
        error_real_estate_error_search_again_desc:
            "Multiple matches found for the address provided. Please make sure that you have entered the full street address (including street number) and zip code.",
        error_real_estate_error_multiple_matches_found_desc:
            "Multiple matches found for the address provided. Please choose the correct match for your property.",
        real_estate_delete_account_warning_text:
            "Warning: All account-related data will be deleted permanently. This action cannot be undone.",
        real_estate_delete_account_button_text: "Delete Account",
        real_estate_spinner_message_text: " Verifying Address...",
        smartzip_popup_heading: "You are entering a third party's website",
        smartzip_popup_text_line1:
            "By selecting Continue you will be taken to a third party website that may have a different privacy policy and level of security from _COBRAND_NAME_. _COBRAND_NAME_ is not responsible for and does not endorse or monitor content, products, services, or anything else offered or expressed on other websites.",
        smartzip_popup_text_line2:
            "You can select Cancel button to return to the previous page.",
        smartzip_popup_header: "Important Notice",

        //MAPING of Country code with the country name to be shown in the search result
        iso_country_name_af: "Afghanistan",
        iso_country_name_ax: "Aland islands",
        iso_country_name_al: "Albania",
        iso_country_name_dz: "Algeria",
        iso_country_name_as: "American Samoa",
        iso_country_name_ad: "Andorra",
        iso_country_name_ao: "Angola",
        iso_country_name_ai: "Anguilla",
        iso_country_name_aq: "Antarctica",
        iso_country_name_ag: "Antigua",
        iso_country_name_ar: "Argentina",
        iso_country_name_am: "Armenia",
        iso_country_name_aw: "Aruba",
        iso_country_name_au: "Australia",
        iso_country_name_at: "Austria",
        iso_country_name_az: "Azerbaijan",
        iso_country_name_bs: "Bahamas",
        iso_country_name_bh: "Bahrain",
        iso_country_name_bd: "Bangladesh",
        iso_country_name_bb: "Barbados",
        iso_country_name_by: "Belarus",
        iso_country_name_be: "Belgium",
        iso_country_name_bz: "Belice",
        iso_country_name_bj: "Benin",
        iso_country_name_bm: "Bermuda",
        iso_country_name_bt: "Bhutan",
        iso_country_name_bo: "Bolivia",
        iso_country_name_ba: "Bosnia",
        iso_country_name_bw: "Botswana",
        iso_country_name_bv: "Bouvet island",
        iso_country_name_br: "Brazil",
        iso_country_name_io: "British indian Ocean Territory",
        iso_country_name_bn: "Brunei",
        iso_country_name_bg: "Bulgaria",
        iso_country_name_bf: "Burkina",
        iso_country_name_bi: "Burundi",
        iso_country_name_kh: "Cambodia",
        iso_country_name_cm: "Cameroon",
        iso_country_name_ca: "Canada",
        iso_country_name_cv: "Cape Verde",
        iso_country_name_ky: "Cayman",
        iso_country_name_cf: "CAR",
        iso_country_name_td: "Chad",
        iso_country_name_cl: "Chile",
        iso_country_name_cn: "China",
        iso_country_name_cx: "Christmas Island",
        iso_country_name_cc: "Cocos Island",
        iso_country_name_co: "Colombia",
        iso_country_name_km: "Comoros",
        iso_country_name_cg: "Congo",
        iso_country_name_cd: "Dr Congo",
        iso_country_name_ck: "Cook Islands",
        iso_country_name_cr: "Costa Rica",
        iso_country_name_ci: "Ivory Coast",
        iso_country_name_hr: "Croatia",
        iso_country_name_cu: "Cuba",
        iso_country_name_cy: "Cyprus",
        iso_country_name_cz: "Czech",
        iso_country_name_dk: "Denmark",
        iso_country_name_dj: "Djibouti",
        iso_country_name_dm: "Dominica",
        iso_country_name_do: "Dominican",
        iso_country_name_ec: "Ecuador",
        iso_country_name_eg: "Egypt",
        iso_country_name_sv: "El Salvador",
        iso_country_name_gq: "Equatorial Guinea",
        iso_country_name_er: "Eritrea",
        iso_country_name_ee: "Estonia",
        iso_country_name_et: "Ethiopia",
        iso_country_name_fk: "Falkland",
        iso_country_name_fo: "Faroe Islands",
        iso_country_name_fj: "Fiji",
        iso_country_name_fi: "Finland",
        iso_country_name_fr: "France",
        iso_country_name_gf: "Guiana",
        iso_country_name_pf: "Polynesia",
        iso_country_name_tf: "French Southern Territories",
        iso_country_name_ga: "Gabon",
        iso_country_name_gm: "Gambia",
        iso_country_name_ge: "Georgia",
        iso_country_name_de: "Germany",
        iso_country_name_gh: "Ghana",
        iso_country_name_gi: "Gibraltar",
        iso_country_name_gr: "Grecia",
        iso_country_name_gl: "Greenland",
        iso_country_name_gd: "Grenada",
        iso_country_name_gp: "Guadeloupe",
        iso_country_name_gu: "Guam",
        iso_country_name_gt: "Guatemala",
        iso_country_name_gg: "Guerney",
        iso_country_name_gn: "Guinea",
        iso_country_name_gw: "Guinea-Bissau",
        iso_country_name_gy: "Guyana",
        iso_country_name_ht: "Haiti",
        iso_country_name_hm: "Heard island & Mcdonald islands",
        iso_country_name_va: "Holy See",
        iso_country_name_hn: "Honduras",
        iso_country_name_hk: "Hong Kong",
        iso_country_name_hu: "Hungary",
        iso_country_name_is: "Iceland",
        iso_country_name_in: "India",
        iso_country_name_id: "Indonesia",
        iso_country_name_ir: "Iran, islamic Republic Of",
        iso_country_name_iq: "Iraq",
        iso_country_name_ie: "Ireland",
        iso_country_name_im: "Isle Of Man",
        iso_country_name_il: "Israel",
        iso_country_name_it: "Italy",
        iso_country_name_jm: "Jamaica",
        iso_country_name_jp: "Japan",
        iso_country_name_je: "Jersey",
        iso_country_name_jo: "Jordan",
        iso_country_name_kz: "Kazakhstan",
        iso_country_name_ke: "Kenya",
        iso_country_name_ki: "Kiribati",
        iso_country_name_kr: "South Korea",
        iso_country_name_kw: "Kuwait",
        iso_country_name_kg: "Kyrgyzstan",
        iso_country_name_la: "Laos",
        iso_country_name_lv: "Latvia",
        iso_country_name_lb: "LÃ­bano",
        iso_country_name_ls: "Lesotho",
        iso_country_name_ls: "Liberia",
        iso_country_name_ly: "Libya",
        iso_country_name_li: "Liechtenstein",
        iso_country_name_lt: "Lithuania",
        iso_country_name_lu: "Luxembourg",
        iso_country_name_mo: "Macao",
        iso_country_name_mk: "Macedonia",
        iso_country_name_mg: "Madagascar",
        iso_country_name_mw: "Malawi",
        iso_country_name_my: "Malaysia",
        iso_country_name_mv: "Maldives",
        iso_country_name_ml: "Mali",
        iso_country_name_mt: "Malta",
        iso_country_name_mh: "Marshall islands",
        iso_country_name_mq: "Martinique",
        iso_country_name_mr: "Mauritania",
        iso_country_name_mu: "Mauritius",
        iso_country_name_yt: "Mayotte",
        iso_country_name_mx: "Mexico",
        iso_country_name_fm: "Micronesia",
        iso_country_name_md: "Moldova",
        iso_country_name_mc: "Monaco",
        iso_country_name_mn: "Mongolia",
        iso_country_name_me: "Montenegro",
        iso_country_name_ms: "Montserrat",
        iso_country_name_ma: "Morocco",
        iso_country_name_mz: "Mozambique",
        iso_country_name_mm: "Myanmar",
        iso_country_name_na: "Namibia",
        iso_country_name_nr: "Nauru",
        iso_country_name_np: "Nepal",
        iso_country_name_nl: "Netherlands",
        iso_country_name_an: "Netherlands",
        iso_country_name_nc: "New Caledonia",
        iso_country_name_nz: "New Zealand",
        iso_country_name_ni: "Nicaragua",
        iso_country_name_ne: "Niger",
        iso_country_name_ng: "Nigeria",
        iso_country_name_nu: "Niue",
        iso_country_name_nf: "Norfolk island",
        iso_country_name_mp: "CNMI",
        iso_country_name_no: "Norway",
        iso_country_name_om: "Oman",
        iso_country_name_pk: "Pakistan",
        iso_country_name_pw: "Palau",
        iso_country_name_ps: "Palestinian",
        iso_country_name_pa: "Panama",
        iso_country_name_pg: "Papua",
        iso_country_name_py: "Paraguay",
        iso_country_name_pe: "Peru",
        iso_country_name_ph: "Philippines",
        iso_country_name_pn: "Pitcairn Island",
        iso_country_name_pl: "Poland",
        iso_country_name_pt: "Portugal",
        iso_country_name_pr: "Puerto Rico",
        iso_country_name_qa: "Qatar",
        iso_country_name_re: "Reunion",
        iso_country_name_ro: "Romania",
        iso_country_name_ru: "Russian Federation",
        iso_country_name_rw: "Rwanda",
        iso_country_name_bl: "Saint Barthelemy",
        iso_country_name_sh: "St. Helena",
        iso_country_name_kn: "St. Kitts & Nevis",
        iso_country_name_lc: "St. Lucia",
        iso_country_name_mf: "Saint Martin",
        iso_country_name_pm: "St. Pierre & Miquelon",
        iso_country_name_vc: "St. Vincent & Grenadines",
        iso_country_name_ws: "Samoa",
        iso_country_name_sm: "San Marino",
        iso_country_name_st: "Sao Tome & Principe",
        iso_country_name_sa: "Saudi Arabia",
        iso_country_name_sn: "Senegal",
        iso_country_name_rs: "Serbia",
        iso_country_name_sc: "Seychelles",
        iso_country_name_sl: "Sierra Leone",
        iso_country_name_sg: "Singapore",
        iso_country_name_sk: "Slovakia",
        iso_country_name_si: "Slovenia",
        iso_country_name_sb: "Solomon Islands",
        iso_country_name_so: "Somalia",
        iso_country_name_za: "South Africa",
        iso_country_name_gs: "South Georgia And Sandwich isl.",
        iso_country_name_es: "Spain",
        iso_country_name_lk: "Srilanka",
        iso_country_name_sd: "Sudan",
        iso_country_name_sr: "Suriname",
        iso_country_name_sj: "Svalbard & Janmayen",
        iso_country_name_sz: "Swaziland",
        iso_country_name_se: "Sweden",
        iso_country_name_ch: "Switzerland",
        iso_country_name_sy: "Syrian",
        iso_country_name_tw: "Taiwan",
        iso_country_name_tj: "Tajikistan",
        iso_country_name_tz: "Tanzania",
        iso_country_name_th: "Thailand",
        iso_country_name_tl: "East Timor",
        iso_country_name_tg: "Togo",
        iso_country_name_tk: "Tokelau",
        iso_country_name_to: "Tonga",
        iso_country_name_tt: "Trinidad & Tobago",
        iso_country_name_tn: "Tunisia",
        iso_country_name_tr: "Turkey",
        iso_country_name_tm: "Turkmenistan",
        iso_country_name_tc: "TCI",
        iso_country_name_tv: "Tuvalu",
        iso_country_name_tg: "Uganda",
        iso_country_name_ua: "Ukraine",
        iso_country_name_ae: "UAE",
        iso_country_name_gb: "UK",
        iso_country_name_us: "US",
        iso_country_name_um: "United States Outlying islands",
        iso_country_name_uy: "Uruguay",
        iso_country_name_uz: "Uzbekistan",
        iso_country_name_vu: "Vanuatu",
        iso_country_name_ve: "Venezuela",
        iso_country_name_vn: "Viet Nam",
        iso_country_name_vg: "BVI",
        iso_country_name_vi: "USVI",
        iso_country_name_wf: "Wallis & Futuna",
        iso_country_name_eh: "Sahara",
        iso_country_name_ye: "Yemen",
        iso_country_name_zm: "Zambia",
        iso_country_name_zw: "Zimbabwe"
    }
};
