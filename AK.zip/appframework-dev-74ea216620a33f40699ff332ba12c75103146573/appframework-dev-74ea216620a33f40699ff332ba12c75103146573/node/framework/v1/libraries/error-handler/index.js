module.paths = module.parent.paths;

const path = require('path');
const qs = require('querystring');
const _ = require('underscore');

const errorCodeConfig = require("./error-code-config");
const cookieHelper = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'common/cookie-helper'));
const { YError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

var handleError = (_err, req, res) => {

    let errorInfo = _getErrorDetails(_err, req);
    if (req.attr.view === true) {
        _redirectErrorView(errorInfo, req, res);
    } else {
        res.setHeader('Content-Type', 'application/json');
        res.status(500).end(JSON.stringify(errorInfo));
    }
}

var _getErrorDetails = (_err, req) => {
    var errorInfo = {};
    if (_err instanceof YError) {
        if (!_err.code) {
            errorInfo = errorCodeConfig.getErrorInfo(_err.errorType, _err.args);
        } else {
            errorInfo.code = _err.code;
            errorInfo.message = _err.message;
        }
        errorInfo.errorType = _err.errorType;
        errorInfo.details = _err.details;
    } else {
        let techDiffError = errorCodeConfig.getErrorInfo('TECH_ERROR');
        errorInfo = { code: techDiffError.code, name: _err.name, message: _err.message };
        errorInfo.errorType = 'TECH_ERROR';
    }
    errorInfo.refId = Math.random().toString(36).substring(2, 15);
    errorInfo.errorOccurred = true;
    logger.error(req.attr.loggerPrefix, "[Error-" + errorInfo.refId + "]", _err.stack || _err);
    return errorInfo;
}

var _redirectErrorView = (errorDetails, req, res) => {
    logger.info('Error Details', errorDetails);
    var redirectUrl;
    cookieHelper.clearAllCookies(req, res);
    redirectUrl = '/apperror/' + (req.attr.cobAppInfo ? req.attr.cobAppInfo.cobAppName : 'default') + '/';
    let parameters = {};
    parameters.app = req.attr.app || req.query.app;
    if (errorDetails.code) {
        parameters['code'] = errorDetails.code;
    }
    if (errorDetails.refId) {
        parameters['refId'] = errorDetails.refId;
    }

    if (req.query.postSource) {
        parameters['postSource'] = req.query.postSource;
    }
    if (req.query.ssoDomain) {
        parameters['ssoDomain'] = req.query.ssoDomain;
    }

    if (appConfig.get('authTestingEnabled') === true) {
        let message = errorDetails.message;
        if (!_.isEmpty(errorDetails.details)) {
            message = errorDetails.details.description;
        }
        parameters['details'] = encodeURIComponent(message);
    }
    redirectUrl += '?' + qs.stringify(parameters);
    logger.info('Error Redirect url :', redirectUrl);
    res.redirect(redirectUrl);
}

var getSSORedirectUrlConfig = (context) => {
    var ssoGroup = context.getParam('ssoGroup') || '';
    var postSource = context.get('req').query.postSource || '';
    var redirectUrlConfigKey = 'ssoRedirectUrlConfig'

    return context.getParam(redirectUrlConfigKey + '_' + postSource + '_' + ssoGroup)
        || context.getParam(redirectUrlConfigKey + '_' + postSource)
        || context.getParam(redirectUrlConfigKey + '_' + ssoGroup)
        || context.getParam(redirectUrlConfigKey);

};

var getSSORedirectUrl = (context, errorCode) => {
    var ssoConfig = getSSORedirectUrlConfig(context);
    var urlRedirectKey = errorCodeConfig.getRedirectUrlKey(errorCode);
    var redirectUrl = ssoConfig[urlRedirectKey] || ssoConfig['fallback_url'];

    if (!_.isEmpty(redirectUrl)) {
        redirectUrl = (context.get('req').query.ssoDomain || ssoConfig['default_domain']) + redirectUrl;
        redirectUrl += ((redirectUrl.indexOf('?') != -1) ? '&' : '?') + 'errorCode='+errorCode;
    }

    return redirectUrl;
}

module.exports = {
    handleError,
    getSSORedirectUrl,
    getSSORedirectUrlConfig
}