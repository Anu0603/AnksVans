module.paths = module.parent.paths;

const _ = require('underscore');

const errorCodesInfo = {

    "TECH_ERROR" : { "code": "N100",  "message" : "Internal Server Error." },
    "INVALID_COBAPP": { "code": "N101", "message": "Invalid cobAppName '{cobAppName}'." },
    "MISMATCH_COBAPP": { "code": "N102", "message": "'{cobAppName}' cobApp's data is invalid." },
    "INVALID_ACCESS" : { "code": "N103", "message": "Invalid Access."},
    "COOKIE_DISABLED" : { "code": "N104", "message": "Cookie is disabled by the user or not supported in the user's browser."},
    "MEM_PREF_KEY_TAMPERED" : { "code": "N105", "message": "Mem pref key is tampered."},
    "INVALID_APP_ACCESS" : { "code": "N106", "message": "Invalid app - {appName}."},

    "LOGIN_ERROR" : { "code" : "N400", "message" : "{loginType} Authentication is failed."},
    "EMPTY_TOKEN" : { "code": "N401", "message": "{loginType} Token is mandatory." },
    "INVALID_BEARER_TOKEN" :  { "code": "N402", "message": "Invalid '{loginType}' token format."},
    "INVALID_TOKEN" :  { "code": "N403", "message": "Invalid token in the authorization header."},
    "EMPTY_SAML_ISSUER" : { "code" : "N404", "message" : "Saml Issuer Id is mandatory."},
    "EMPTY_SAML_RESPONSE" : { "code" : "N405", "message" : "Saml Response is mandatory."},
    "EMPTY_SAML_SOURCE" : { "code" : "N406", "message" : "Saml Source is mandatory."},
    "EMPTY_CREDENTAILS" : { "code": "N490", "message": "{loginType} credentials are mandatory."},
    "INVALID_USER_CREDENTIALS" : { "code": "N491", "message": "PWD Credentails are mandatory."},


    "SESSION_ERROR" : { "code" : "N500", "message" : "Session is invalid."},
    "STALE_SESSION" : { "code" : "N501", "message" : "Stale session is found."},
    "SESSION_MISMATCH" : { "code": "N502", "message": "Token is mismatched."},
    "USER_SESSION_TIMED_OUT" : { "code": "N503", "message": "User session is timed out."},
    "YSL_SESSION_ERROR": { "code": "N504", "message" : "Invalid cobrand/user session."},
    "USER_LOGOUT" : { "code": "N505", "message": "User is logged out."},

    "API_ERROR" : { "code" : "N600", "message" : "{providerType} api-service is failed." },

    "SERVER_ERROR": { "code": "N700", "message" : "{providerType} Server is not reachable."},
    "ECONNREFUSED": { "code": "N701", "message" : "{providerType} Server is inactiive."},
    "ECONNRESET": { "code": "N702", "message" : "{providerType} Server Connection is closed due to timeout or reboot."},
    "ENOTFOUND": { "code": "N703", "message" : "{providerType} Server is not found."},
    "ETIMEDOUT": { "code": "N704", "message" : "{providerType} Server Connection is timedout."},
    "ESOCKETTIMEDOUT": { "code": "N705", "message" : "{providerType} Server Connection is failed."},
    "YSL_SERVER_ERROR": { "code": "N706", "message" : "{providerType} Server Connection is unavailable due to DB errors"}
}

const errorCodeMapping = {
    "Y903": "YSL_SERVER_ERROR",
    "Y008": "STALE_SESSION",
    "Y010": "YSL_SESSION_ERROR",
    "Y015": "INVALID_TOKEN",
    "Y017": "INVALID_TOKEN",
    "Y018": "INVALID_TOKEN",
    "Y020": "INVALID_TOKEN",
    "Y021": "INVALID_TOKEN",
    "Y022": "INVALID_TOKEN",
    "Y023": "INVALID_TOKEN"
}

const redirectUrlKeyMap = {
    "N1XX" : "techdiff_url",
    "N4XX" : "login_url",
    "N5XX" : "stale_session_url",
    "N7XX" : "techdiff_url",
    "N503" : "session_timeout_url",
    "N505" : "logout_url"
}

var _constructErrorMessage = ( message, msgArgs ) => {
    logger.debug("Construct Error Message", message, msgArgs);
    if( !_.isEmpty(msgArgs) ) {
        var regexp = RegExp ('\{\\b(' + Object.keys (msgArgs).join ('|') + ')\\b\}', 'g');
        message = message.replace(regexp, function(_, word) {
            return msgArgs[word];
        });
    }
    return message;
}

exports.getErrorInfo = (type, msgArgs) => {

    let errorInfo = errorCodesInfo[type] || {};
    if (!_.isEmpty(errorInfo)) {
        errorInfo = JSON.parse(JSON.stringify(errorInfo));
        errorInfo.message = _constructErrorMessage( errorInfo.message, msgArgs );
    }
    return errorInfo;
}

exports.getRedirectUrlKey = ( code ) => {
    logger.debug("Fetching Redirect url key for ErrorCode : ", code);
    let redirectUrlKey = redirectUrlKeyMap[code];
    if( _.isEmpty(redirectUrlKey) ) {
        let ncode = code.substr(0,2) + "XX";
        redirectUrlKey = redirectUrlKeyMap[ncode];
    }
    return redirectUrlKey;
}

exports.getMappingErrorType = ( errorType ) => {
    return errorCodeMapping[errorType];
}