module.paths = module.parent.paths;

const _ = require('underscore');

const errorCodeConfig = require("./error-code-config");
class YError extends Error {
    constructor(errorType, causedError, args) {
        super();
        logger.info("YError construction for error Type", errorType, causedError, args);
        this.errorType = errorType;
        this.args = args;
        if( _.isString(causedError) ) {
            logger.debug("causedError is String", causedError, args);
            let errorInfo = errorCodeConfig.getErrorInfo(causedError, args);
            this.code = errorInfo.code;
            this.message = errorInfo.message;
        } else if( causedError ) {
            if( causedError.details ) {
                logger.debug("causedError is Object", causedError);
                this.details = causedError.details;
                if( causedError.code ) {
                    this.code = causedError.code;
                    this.message = causedError.message;
                }
            } else if( causedError.errorType ) {
                logger.debug("causedError details not found so construction using errorType", causedError, args);
                let errorInfo = errorCodeConfig.getErrorInfo(causedError.errorType, args);
                this.code = errorInfo.code;
                this.message = errorInfo.message;
                if( causedError.errorMessage ) {
                    this.details = {}
                    this.details.description = causedError.errorMessage;
                    this.details.errorCode = causedError.errorCode;
                }
            } else {
                // nested errors
                this.details = causedError;
            }
        }
    }
}

class TechError extends YError {
    constructor(arg1, args) {
        super('TECH_ERROR', arg1, args);
    }
}

class ApiError extends YError {
    constructor(arg1, args) {
        super('API_ERROR', arg1, { providerType : args.providerType });
    }
}

class LoginError extends YError {
    constructor(arg1, args) {
        super('LOGIN_ERROR', arg1, args);
    }
}

class SessionError extends YError {
    constructor(arg1, args) {
        super('SESSION_ERROR', arg1, args);
    }
}

class ServerError extends YError {
    constructor(arg1, args) {
        super('SERVER_ERROR', arg1, args);
    }
}

module.exports = {
    YError,
    TechError,
    ApiError,
    LoginError,
    SessionError,
    ServerError
}