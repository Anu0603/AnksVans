module.paths = module.parent.paths;

const path = require('path');
const fs = require('fs');
const cluster = require('cluster');
const _ = require('underscore');

const clusterMessaging = require(path.join(__dirname, 'cluster-message'));
const yutils = require(path.join(__dirname, 'yutils'));

const appConfig = require(global.paths.APP_CONFIG_PATH);

var COBRAND_BRAND_KEYS = {}, CHANNEL_BRAND_KEYS = [], _devopsBrandKeys = [];

var initialize = () => {

    if (cluster.isWorker === true) {
        logger.error('copyAllLabels is not accessable by worker');
        return;
    }

    if (appConfig.get('devOpsEnabled') === true) {
        let cobLabelNames = _initCobAppLabels();
        if( !_.isEmpty(cobLabelNames) ) {
            _copyCobrandLabelsToBrands(cobLabelNames, () => {
                _watchDevOpsBrand();
            });
        } else {
            logger.error('Skipping brands watch as CobAppConfig is empty.');
        }
    }
}

var _initCobAppLabels = () => {
    let cobApps = appConfig.getAllCobApps(), cobLabelNames = [];

    logger.info("CobApps for brand-watch", cobApps);    
    _.each(cobApps, cobAppInfo => {
        let labelFileName = cobAppInfo.brandId + '-' + cobAppInfo.applicationId;
        if (cobAppInfo.labelIdentifier) {
            labelFileName = labelFileName + '-' + cobAppInfo.labelIdentifier;
        }
        COBRAND_BRAND_KEYS[labelFileName] = cobAppInfo;
        if( cobAppInfo.isChannel === true ) {
            CHANNEL_BRAND_KEYS.push(labelFileName);
        }
        cobLabelNames.push(labelFileName);
    });

    return cobLabelNames;
}

var _copyCobrandLabelsToBrands = (cobLabelNames, callback) => {
    let cobAppKeys = [];
    if (!_.isEmpty(cobLabelNames)) {
        cobLabelNames.map(cobLabelName => {
            let copied = false, cobAppInfo = COBRAND_BRAND_KEYS[cobLabelName];
            if( cobAppInfo ) {
                copied = true;
                let input = {labelName : cobLabelName};
                input.labelIdentifier = cobAppInfo.labelIdentifier;
                _copyLabelToBrand(input, cobAppKeys);
                if( cobAppInfo.isChannel === true ) {
                    let devOpsLabels = fs.readdirSync(global.paths.DEVOPS_BRANDS_PATH);
                    input.touchFile = true;
                    devOpsLabels.map(labelName => {
                        if(_isSubbrandLabel(labelName, cobLabelName)) {
                            input.labelName = labelName;
                            _copyLabelToBrand(input, cobAppKeys);
                        }
                    });
                }
            } else {
                CHANNEL_BRAND_KEYS.map(channelLabelName => {
                    let input = {};
                    input.labelIdentifier = COBRAND_BRAND_KEYS[channelLabelName].labelIdentifier;
                    if(_isSubbrandLabel(cobLabelName, channelLabelName)) {
                        copied = true;
                        input.labelName = cobLabelName;
                        _copyLabelToBrand(input, cobAppKeys);
                    }
                })
            }
            if( !copied ) {
                logger.debug('Invalid label', cobLabelName);
            }
        });
    } else {
        logger.error('CobAppKeys are empty to copy labels', cobLabelNames)
    }
    if( callback ) {
        callback(null, cobAppKeys);
    }
}

var _isSubbrandLabel = (cobrandLabelName, channelLabelName) => {
    let idx = cobrandLabelName.indexOf(channelLabelName);
    let fidx = cobrandLabelName.length - channelLabelName.length;
    logger.debug('Is Sub-brand label', idx, fidx, cobrandLabelName, channelLabelName);
    return (idx > 0 && idx == fidx);
}

var _copyLabelToBrand = (input, cobAppKeys) => {
    var labelFileName = input.labelName;
    var sourceFolderPath = path.join(global.paths.DEVOPS_BRANDS_PATH, labelFileName);
    if (fs.existsSync(sourceFolderPath)) {
        let cobAppKey = labelFileName;
        if( !_.isEmpty(input.labelIdentifier) ) {
            cobAppKey = labelFileName.substr(0, labelFileName.indexOf(input.labelIdentifier)-1);
        }
        let distFolderPath = path.join(global.paths.BRANDS_PATH, cobAppKey);
        let writeLabel = true;
        if (fs.existsSync(distFolderPath)) {
            if( input.touchFile === true ) {
                writeLabel = false;
            } else {
                logger.info('Deleting existing label ', distFolderPath);
                yutils.removeAllFiles(distFolderPath, true);
            }
        }
        if( writeLabel ) {
            fs.mkdirSync(distFolderPath);
            logger.info('Copying Label is started for cob-app', labelFileName);
            logger.info('Source and Dist Brands Folder Path', sourceFolderPath, distFolderPath);
            yutils.copyFolder(sourceFolderPath, distFolderPath, true);
            let cacheId = new Date(fs.statSync(distFolderPath).mtime).getTime();
            fs.writeFileSync(path.join(distFolderPath, 'cache-key.txt'), cacheId);

            logger.info('Copying Label is completed for cob-app', labelFileName);
        } else {
            logger.info('Folder is upto date.', labelFileName)
        }
        cobAppKeys.push(cobAppKey);
    } else {
        logger.info('Label doen\'t exist for cob-app', sourceFolderPath);
    }
};

var _rebuildDevOpsCobrandLabelsByFolderWatch = _.debounce(function() {
	let cobAppKeys = [], nodeCache = false;
	while(_devopsBrandKeys.length) {
		let cobAppKey = _devopsBrandKeys.pop();
		if( cobAppKeys.indexOf(cobAppKey) == -1 ) {
            if( cobAppKey == 'node-cache' ) {
                nodeCache = true;
            } else {
                cobAppKeys.push(cobAppKey);
            }
		}
    }
    logger.debug('Verifying cobAppKeys for copying labels', cobAppKeys);

    if( nodeCache ) {
        appConfig.set('node-cache : resourceCacheFolder', new Date().getTime()+"");
        logger.info('node-cache : Setting resourceCacheFolder ', appConfig.get('resourceCacheFolder'));

        var serverStartupTime = new Date().getTime();
        appConfig.set('serverStartupTime', serverStartupTime+"");
        logger.info('Setting serverStartupTime ', appConfig.get('serverStartupTime'));


        clusterMessaging.triggerMessage({
            cmd: 'RELOAD_BRAND',
            args : { cobAppKey : 'ALL', serverStartupTime : serverStartupTime, 
                        resourceCacheFolder : appConfig.get('resourceCacheFolder') },
        }, 'WORKERS');

        _clearExpiredResourceCacheFiles();

    } else {
        _copyCobrandLabelsToBrands(cobAppKeys, function(_err, _result) {
            if( !_.isEmpty(_result) ) {

                appConfig.set('node-cache : resourceCacheFolder', new Date().getTime()+"");
                logger.info('node-cache : Setting resourceCacheFolder ', appConfig.get('resourceCacheFolder'));

                logger.info('list of cobrands for rebulding resources: ', _result);
                _result.map( cobAppKey => {
                    logger.info('Brand Refresh Trigger initiated ', cobAppKey);
                    clusterMessaging.triggerMessage({
                        cmd: 'RELOAD_BRAND',
                        args : { cobAppKey : cobAppKey, resourceCacheFolder : appConfig.get('resourceCacheFolder') },
                    }, 'WORKERS');
                    logger.info('Brand Refersh Trigger completed ', cobAppKey);
                });

                _clearExpiredResourceCacheFiles();
            }
            if(_err) {
                logger.error('Coping labels is failed', _err);
            }
        });
    }
}, 5000);

var _clearExpiredResourceCacheFiles = _.debounce(function() {
    logger.info('cleaning expired resource-cache folders are triggered to reload all');
    var staticCacheRootPath  = path.join(global.paths.RESOURCE_CACHE_PATH, 'static');
    
    if( fs.existsSync(staticCacheRootPath) ) {
        fs.readdirSync(staticCacheRootPath).map( fileName => {
            if( fileName != 'common' && fileName != appConfig.get('resourceCacheFolder') ) {
                let cacheFilePath = path.join(staticCacheRootPath, fileName);
                yutils.removeAllFiles(path.join(staticCacheRootPath, fileName), true);
                logger.info("Deleted expired static cache file", cacheFilePath);
            }
        });
    }
}, 1*60*1000);

var _watchDevOpsBrand = () => {
    logger.info('brand-watch initiated for devopsFolder');
    let filePath = path.join(global.paths.DEVOPS_BRANDS_PATH);
    fs.watch(filePath, function(eventType, fileName) {
        logger.debug('FS.Watch: EventType and filePath : %s : %s', eventType, fileName);
        _devopsBrandKeys.push(fileName);
        _rebuildDevOpsCobrandLabelsByFolderWatch();
    });
    _clearExpiredResourceCacheFiles();
}

module.exports = {
    initialize
}

