module.paths = module.parent.paths;

const _ = require('underscore');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const appConfig = require(global.paths.APP_CONFIG_PATH);

var encryptDataAES128ECB = (input, privateKey) => {
    var encrypted = '';
    if (!_.isEmpty(input) && !_.isEmpty(privateKey)) {
        var cipher = crypto.createCipher('aes-128-ecb', privateKey)
        encrypted = cipher.update(input, 'utf-8', 'hex');
        encrypted += cipher.final('hex');
    }
    return encrypted;

};

var encryptDataSHA256 = (input, privateKey, applyHash) => {
    var encrypted = '';
    if (!_.isEmpty(input) && !_.isEmpty(privateKey)) {
        encrypted = crypto.createHmac("sha256", privateKey)
            .update(input)
            .digest("hex");

        if (applyHash === true) {
            encrypted = createHash(encrypted);
        }
    }
    return encrypted;
}

var createHash = (data, algo) => {
    return crypto.createHash(algo || 'md5').update(data).digest("hex");
}

var createFolder = (dirPath) => {
    try {
        fs.mkdirSync(dirPath);
    } catch (error) {
        if (error && error.code != 'EEXIST') {
            //When it fail in this way, do the custom steps
            if (error && (error.code == 'ENOENT' || error.errno === 34 || error.errno == -2)) {
                //Create all the parents recursively
                createFolder(path.dirname(dirPath));
                //And then the directory
                createFolder(dirPath);
            } else {
                logger.error('Error while creating directory ' + dirPath, error);
            }
        }
    }
};

var removeAllFiles = (dirPath, removeSelf) => {
    if (removeSelf === undefined) {
        removeSelf = false;
    }
    try {
        var files = fs.readdirSync(dirPath);
        if (files.length > 0) {
            for (let i = 0; i < files.length; i++) {
                let filePath = path.join(dirPath, files[i]);
                if (fs.statSync(filePath).isFile()) {
                    if (files[i] != 'default.json') {
                        fs.unlinkSync(filePath);
                    }
                } else {
                    removeAllFiles(filePath, removeSelf);
                }
            }
        }
        if (removeSelf) {
            try {
                fs.rmdirSync(dirPath);
            } catch (e) {
                if (e.code != 'ENOTEMPTY') {
                    logger.error(e);
                }
            }
        }
    } catch (e) {
        logger.error('Error : ', e);
        return;
    }
}

var copyFolder = ( source, target, ignoreRootFolder ) => {
    var files = [];

    //check if folder needs to be created or integrated
    var targetFolder;
    if( !ignoreRootFolder ) {
        targetFolder = path.join( target, path.basename( source ) );
        if ( !fs.existsSync( targetFolder ) ) {
            fs.mkdirSync( targetFolder );
        }
    } else {
        targetFolder = target;
    }

    //copy
    files = fs.readdirSync( source );
    files.forEach( function ( file ) {
        let srcFile = path.join( source, file );
        if ( fs.lstatSync( srcFile ).isDirectory() ) {
            copyFolder( srcFile, targetFolder );
        } else {
            let targetFile = path.join( targetFolder, file );
            fs.writeFileSync(targetFile, fs.readFileSync(srcFile));
        }
    });
}

var getYslNodeHeader = (privateKey) => {
    return encryptDataAES128ECB(appConfig.get('nodeInstance'), appConfig.get('publicKey') + ( privateKey || '' ) )
}

var getBrowser = ( req ) => {

    if( _.isEmpty(req) ) {
        logger.info("Req is null", req)
        return '';
    }
    var userAgent = req.headers['user-agent'];

    if( _.isEmpty(userAgent) ) {
        logger.info("User Agent is empty", userAgent)
        return '';
    }

    if (/Chrome[\/\s](\d+\.\d+)/.test(userAgent)) {
        return 'gc'
    } else if (/Firefox[\/\s](\d+\.\d+)/.test(userAgent)) {
        return 'ff'
    } else if(/Edge\/\d./i.test(userAgent)){
        return 'ie Edge'
    } else if(/Trident\/7.0/.test(userAgent)){
        return 'ie ie11'
    } else if (/MSIE (\d+\.\d+);/.test(userAgent)) {
        return 'ie ie' + new Number(RegExp.$1)
    } else if (/Safari[\/\s](\d+\.\d+)/.test(userAgent)) {
        return 'safari'
    } else if(/Android[\/\s](\d+\.\d+)/.test(userAgent)) {
        return 'android'
    }
    
    if(/touch[\/\s](\d+\.\d+)/.test(userAgent.toLowerCase())) {//windows touch based adds this
        return 'touch'
    }
};

var getDateByIntervalType = ( intervalType ) => {
    let cacheDate = new Date();
    let cacheExpiredId = cacheDate.getMonth()+""+cacheDate.getDate();
    if( intervalType == "HOUR" ) {
        cacheExpiredId = cacheExpiredId+""+cacheDate.getHours();
    } else if( intervalType == "MINUTE" ) {
        cacheExpiredId = cacheExpiredId+""+cacheDate.getHours()+""+cacheDate.getMinutes();
    }
    return cacheExpiredId;
}

module.exports = {
    removeAllFiles,
    copyFolder,
    createHash,
    encryptDataSHA256,
    createFolder,
    encryptDataAES128ECB,
    getBrowser,
    getYslNodeHeader,
    getDateByIntervalType
}

