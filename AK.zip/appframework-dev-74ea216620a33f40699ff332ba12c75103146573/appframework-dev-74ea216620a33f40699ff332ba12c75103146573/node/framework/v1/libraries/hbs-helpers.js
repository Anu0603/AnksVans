module.paths = module.parent.paths;

const hbs = require('hbs');

hbs.registerHelper("app-title", function() {
    var title = this.context.getString(this.context.get('app') + "_title") || this.context.get('app');
    return new hbs.handlebars.SafeString(title);
});

hbs.registerHelper('app-resource', function( resourcePath, hasQuery ) {

    var resourceQueryPath = resourcePath;

    if( hasQuery === true ) {
        resourceQueryPath += '?cjs=1'
        if( resourcePath == 'js/app-framework.js' ) {
            if(this.viewData.browser && this.viewData.browser.indexOf('ie11') != -1 ) {
                resourceQueryPath += '&polyfill=1'
            }
        } else if( resourcePath == 'brand/config' ) {
            resourceQueryPath += "&app=" + this.context.get('app') + "&isParent=1";
        }
    }

    return '/resource/' + _getBrandResourcePath(this.context) + '/' + resourceQueryPath;
});

hbs.registerHelper('brand-resource-path', function() {
    return _getBrandResourcePath(this.context);
});

var _getBrandResourcePath = (context) => {
    return context.get('cobAppName') + '/' + context.getBrandContext().getBrandAppResourceKey();
}