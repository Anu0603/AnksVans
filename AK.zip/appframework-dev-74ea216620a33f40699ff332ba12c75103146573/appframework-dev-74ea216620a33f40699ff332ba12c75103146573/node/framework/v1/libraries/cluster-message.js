module.paths = module.parent.paths;

const cluster = require('cluster');
const path = require('path');
const _ = require('underscore');

const logger = global.logger;

function ClusterMessage() {

    var _initialize = false;

    var _init = function () {
        if (_initialize) {
            logger.info('Cluster events is already initialized');
            return;
        } else {
            logger.info('Cluster events is initializing... ');
            _initialize = true;
        }

        if (cluster.isWorker) {

            logger.info('Cluster-Workers message-event is initializing...', process.pid);

            // Receive messages from the master process.
            process.on('message', function (msg) {
                if (!_.isEmpty(msg) && !_.isEmpty(msg.cmd)) {
                    logger.info('Worker ' + process.pid + ' received message from master.', msg);
                    _excuteTask(msg);
                }
            });

            logger.info('Cluster-Workers message-event is completed', process.pid);
        }

        if (cluster.isMaster) {

            logger.info('Cluster-Master message-event is initializing...', process.pid);

            // Fork workers.
            for (let workerId in cluster.workers) {

                // Receive messages from this worker and handle them in the master process.
                cluster.workers[workerId].on('message', function (msg) {
                    if (!_.isEmpty(msg) && !_.isEmpty(msg.cmd)) {
                        logger.info('Master ' + process.pid + ' received message from worker ' + workerId + '.', msg);
                        _excuteTask(msg);
                    }
                });
            }

            logger.info('Cluster-Master message-event is completed', process.pid);
        }
    }


    var _triggerMessage = function (msg, sendTo) {
        if (_.isEmpty(msg) || _.isEmpty(msg.cmd) || _.isEmpty(sendTo)) {
            logger.error("Invalid inputs ", msg, sendTo);
            return;
        }
        if (cluster.isMaster && sendTo == 'WORKERS') {
            logger.info('Triggered message from master to workers');
            try {
                for (let workerId in cluster.workers) {
                    if (cluster.workers[workerId].process.pid) {
                        logger.info('Triggering message from master to wroker ', cluster.workers[workerId].process.pid, msg);
                        cluster.workers[workerId].send(msg);
                    }
                }
            } catch (e) {
                logger.error('Error while triggering reload cobapp event', e);
            }
        } else if (cluster.isWorker && sendTo == 'MASTER') {
            logger.info('Triggered message from worker to master', process.pid, msg);
            process.send(msg);
        } else {
            logger.error("Invalid trigger ", msg);
        }
    }

    var _excuteTask = function (msg) {
        if (cluster.isWorker) {
            if (msg.cmd == 'RELOAD_BRAND') {
                require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'build-modules/brand-info')).triggerBrandRefresh(msg.args);
            }
        }
    }

    return {
        triggerMessage: _triggerMessage,
        initialize: _init
    }
}

module.exports = new ClusterMessage();