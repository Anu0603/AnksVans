/**
 * $Change$
 * $Revision$
 * $DateTime$
 */
module.paths = module.parent.paths;

const path = require('path');
const _ = require('underscore');

const yutils = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/yutils'));
const cookieHelper = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'common/cookie-helper'));
const BrandInfo = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'build-modules/brand-info'));
const { TechError } = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/error-handler/errors'));
const internalProviderService = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/internal-provider'));
const ProviderTypes = require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'services/libraries/yrequest/config/provider-types'));

const appConfig = require(global.paths.APP_CONFIG_PATH);
const DEFAULT_USER_PREFS = '{ "prefs" : { "dateFormat": "MM/DD/YYYY", "currencyCode": "USD", "currencyNotation": "SYMBOL", "currencySymbol": "$", "decimalSeparator": ".", "groupingSeparator": ",", "groupPattern": "###,##0.##", "groupSize": "3", "locale": "en_US" }, "segmentInfo" : {}}';

class YContext {
    constructor(req, res) {
        this._data = {
            ...req.attr.cobAppInfo,
            req: req,
            res: res,
            app: req.params.app || req.query.app,
        }
        this.loggerPrefix = req.attr.loggerPrefix;
        if( req.params.brandKey && req.params.brandKey != 'static' ) {
            let brandKeys = decodeURIComponent(req.params.brandKey).split(':');
            this._data.resourceCacheId = brandKeys[0];
            if( brandKeys[1] ) {
                if( appConfig.get('stub') === true ) {
                    this._data.brandId = req.attr.cobAppInfo.brandId = brandKeys[1];
                } else {
                    this.segmentBrandName = decodeURIComponent(brandKeys[1]);
                }
            }
        }
    }

    get(key) {
        return this._data[key]
    }

    generateSessionToken(userId, app) {
        var secretKey = appConfig.get('publicKey') + '' + cookieHelper.getCookie(this._data.req, 'rsession');
        var tokenContent = '' +
            ( app || this._data.app ) +
            this._data.brandId +
            this._data.applicationId +
            this._data.cobAppName +
            userId;

        logger.debug(this.loggerPrefix, 'generated tokenContent parameters : ', tokenContent);
        var token = yutils.encryptDataSHA256(tokenContent, secretKey, true);
        logger.debug(this.loggerPrefix, 'generated tokenContent : ', token, secretKey);
        return token;
    }

    getBrandContext() {
        if (!this._data.brandInfo) {
            let args = { brandId: this._data.brandId, applicationId: this._data.applicationId };
            let ucontext = this.getUserContext();
            args.locale = ucontext.prefs.locale;
            args.segmentBrandName = ucontext.segmentInfo.segmentBrandName || this.segmentBrandName;
            if( this._data.channelId > 0 ) {
                args.channelId = this._data.channelId;
            }
            logger.debug(this.loggerPrefix, "Input args for fetching brand-context...", args);
            this._data.brandInfo = BrandInfo.getInstance(args);
        }
        return this._data.brandInfo;
    }

    getUserContext() {
        if (!this._data.user) {
            var userData = this._data.req.attr.userData;
            if (!userData) {
                userData = cookieHelper.getCookie(this._data.req, 'udata');
                try {
                    userData = JSON.parse(userData);
                } catch (e) {
                    logger.error(this.loggerPrefix, "user Data is null so setting default preferences")
                }
            }
            if (!userData) {
                userData = JSON.parse(DEFAULT_USER_PREFS);
                userData.prefs.locale = this._data.req.query.locale;
            }
            this._data.user = userData;
            logger.debug(this.loggerPrefix, 'User Data is ', this._data.user);
        }
        return this._data.user;
    }

    getUserAuthToken() {
        return cookieHelper.getCookie(this._data.req, 'rsession');
    }

    getParam(key) {
        return this.getBrandContext().getAppContext().getParam(key, this._data.app);
    }

    getString(key) {
        return this.getBrandContext().getAppContext().getLocaleString(key, this._data.app);
    }
}

var createContext = (req, res) => {

    return new Promise(function (resolve, reject) {
        if (!_.isUndefined(req.params.cobAppName)) {
            if (req.query.channelAppName) {
                req.params.cobAppName = req.query.channelAppName + ":" + req.params.cobAppName;
            }
            let cobAppInfo = appConfig.getCobAppInfo(req.params.cobAppName);
            if (_.isEmpty(cobAppInfo)) {
                logger.error(req.attr.loggerPrefix, "Invalid CobAppName", req.params.cobAppName);
                throw new TechError("INVALID_COBAPP", { cobAppName: req.params.cobAppName });
            }

            if (cobAppInfo.isValid === true) {
                req.attr.cobAppInfo = cobAppInfo;
                resolve(new YContext(req, res));
            } else {
                logger.info(req.attr.loggerPrefix, 'Checking whether cobAppInfo Data is valid or not', cobAppInfo.cobAppName);
                if (_isValidCobAppInfo(cobAppInfo)) {
                    req.attr.cobAppInfo = cobAppInfo;
                    let yContext = new YContext(req, res)
                    return verifyCobrandDetails(yContext)
                        .then(status => {
                            resolve(new YContext(req, res));
                        })
                        .catch(_err => {
                            req.attr.cobAppInfo = null;
                            reject(_err);
                        })
                } else {
                    logger.error(req.attr.loggerPrefix, "Insufficient data in cobAppConfig for cobAppName", req.params.cobAppName);
                    throw new TechError("INVALID_COBAPP", { cobAppName: req.params.cobAppName });
                }
            }
        } else {
            resolve(new YContext(req, res));
        }
    });
}

var verifyCobrandDetails = (context) => {

    var cobAppInfo = context.get('req').attr.cobAppInfo;

    logger.info(context.loggerPrefix, 'Fetching Cobrand/Sub-brand Details', cobAppInfo.cobAppName);

    var inputReq;
    if( !appConfig.get('yslAuth') ) {
        inputReq = { url: '/v1.0/authenticator/cobrandDetails', data: { cobSessionToken: '12345' }, isFormData : true, serviceType : ProviderTypes.REST  };
    } else {
        inputReq = { url: '/1.1/client',  method : 'GET', headers : {}, serviceType : ProviderTypes.YSL };
        inputReq.headers['x-request-source'] = yutils.getYslNodeHeader();
    }

    return internalProviderService.makeCall(context, inputReq)
        .then(response => {
            let _err;
            try {
                logger.info(context.loggerPrefix, 'Cobrand/Sub-brand Details Response is', response.data);
                let parsedResponse = JSON.parse(response.data);
                if (cobAppInfo.isSubbrand == true) {
                    if (cobAppInfo.channelId == parsedResponse.channelId + '') {
                        cobAppInfo.brandId = parsedResponse.cobrandId + '';
                    } else {
                        logger.error(context.loggerPrefix, 'Channel Ids are mismatched', cobAppInfo.channelId, parsedResponse.channelId);
                    }
                }
                if (cobAppInfo.brandId == parsedResponse.cobrandId + ''
                    && cobAppInfo.applicationId == parsedResponse.applicationId) {
                    appConfig.setCobAppInfo(cobAppInfo);
                } else {
                    logger.error(context.loggerPrefix, 'Channel/cobrand/app Ids are not matching', cobAppInfo, parsedResponse);
                    _err = new TechError('MISMATCH_COBAPP', { cobAppName: cobAppInfo.cobAppName });
                }
            } catch (_err) {
                logger.error(context.loggerPrefix, 'Error occurred while parsing Cobrand/Sub-brand details', _err);
                _err = new TechError('UNCAUGHT_ERROR');
            }

            if (_err) {
                throw _err;
            }
        })
        .catch(e => {
            logger.error(context.loggerPrefix, 'Error occurred while validating Cobrand/Sub-brand details.');
            throw e;
        });
}

var _isValidCobAppInfo = (cobAppInfo) => {
    var valid = true;
    if (_.isEmpty(cobAppInfo.resturl) || _.isEmpty(cobAppInfo.yslurl)
        || _.isEmpty(cobAppInfo.brandId) || _.isEmpty(cobAppInfo.applicationId)) {
        valid = false;
    }
    return valid;
}

exports.createContext = createContext;
