module.paths = module.parent.paths;

const path = require('path');
const fs = require('fs');

const AbstractProcess = require('./abstract-process');
const appConfig = require(global.paths.APP_CONFIG_PATH);

class WorkerProcess extends AbstractProcess {
    constructor() {
        super();
    }

    initialize() {
        super.initialize();
        //newrelic should be initialized first before start worker.
        if( appConfig.get('enableNewRelic') === true ) {
            this._loadNewRelicModule();
        }
        process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';
    }

    startServer() {
        if (global.pid) {
            logger.error('Server is already started for workder', global.pid);
            return;
        } else {
            logger.info('Starting server for worker');
        }

        global.pid = process.pid;
        this.initialize();

            var app = require('../express-app').initialize();

            if (appConfig.get('protocol') == 'http') {
                require('http').createServer(app);
            } else {
                let privateKey = ''
                let certificate = ''

                try {
                    privateKey = fs.readFileSync(path.join(global.paths.BASE_PATH, 'ssl/localhost/server.key')).toString();
                    certificate = fs.readFileSync(path.join(global.paths.BASE_PATH, 'ssl/localhost/server.crt')).toString();
                } catch (e) {
                    logger.error('Failed to load private key/certificate.', e)
                }

                app = require('https').createServer({
                    key: privateKey,
                    cert: certificate
                }, app);
            }

            require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/cluster-message')).initialize();
            app.listen(appConfig.get('port'), function (a) {
                logger.info("Server is listening at port:", appConfig.get('port'));
            });
    }

    _loadNewRelicModule() {
        if( process.env.NEW_RELIC_PROXY_HOST && process.env.NEW_RELIC_PROXY_PORT ) {
            process.env.NEW_RELIC_PROXY_URL = 'http://' +  process.env.NEW_RELIC_PROXY_HOST + ':' + process.env.NEW_RELIC_PROXY_PORT + '/';
        }    
        logger.info('newrelic proxy url is ', process.env.NEW_RELIC_PROXY_URL);
        require('newrelic');
    }
}
  
module.exports = WorkerProcess;