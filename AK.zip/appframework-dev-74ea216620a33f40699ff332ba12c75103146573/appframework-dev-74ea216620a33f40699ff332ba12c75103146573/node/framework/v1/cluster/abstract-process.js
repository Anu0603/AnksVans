module.paths = module.parent.paths;

const cluster = require('cluster');

class AbstractProcess {

    static getProcessor() {
        let Processor;
        if( cluster.isMaster ) {
            Processor = require("./master-process");
        } else {
            Processor = require("./worker-process");
        }
        return new Processor();
    }

    constructor() {}

    initialize() {}
}

module.exports = AbstractProcess;