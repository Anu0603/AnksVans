module.paths = module.parent.paths;

const cluster = require('cluster');
const path = require('path');

const AbstractProcess = require('./abstract-process');
const appConfig = require(global.paths.APP_CONFIG_PATH);

class MasterProcess extends AbstractProcess {
    constructor() {
        super();
    }

    initialize() {
        super.initialize();
    }

    startServer() {
        if (global.pid) {
            logger.error('Already initialized');
            return;
        }

        let workers = 0;
        this.initialize();
        global.pid = process.pid

        let numCPUs = appConfig.get('numCpus') || require('os').cpus().length;

        let new_worker_env = {};
        new_worker_env.serverStartupTime = new Date().getTime();
        new_worker_env.resourceCacheFolder = new Date().getTime();

        appConfig.set('serverStartupTime', new_worker_env.serverStartupTime+"");
        appConfig.set('resourceCacheFolder', new_worker_env.resourceCacheFolder+"");

        cluster.on('online', function (worker) {
            logger.info('Worker ' + worker.process.pid + ' is online');
        });

        cluster.on('listening', function (worker) {
            workers++;
            if (workers == numCPUs) {
                require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/cluster-message')).initialize();
                require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'libraries/brand-watch')).initialize();
                logger.info('******* Node Server is started with ' + workers + ' workers in ' + appConfig.get('protocol') + ' mode *******');
            }
        });

        cluster.on('exit', function (deadWorker) {
            if (workers >= numCPUs) {
                // Restart the worker
                var worker = cluster.fork();

                // // Note the process IDs
                var newPID = worker.process.pid;
                var oldPID = deadWorker.process.pid;

                // Log the event
                logger.info('worker ' + oldPID + ' died.');
                logger.info('worker ' + newPID + ' born.');
            }
        });

        var _initializeWorkers = () => {
            logger.info('Intializing %s workers', numCPUs);
            for (let i = 0; i < numCPUs; i++) {
                cluster.fork(new_worker_env);
            }
        }

        require(path.join(global.paths.FRAMEWORK_VERSION_PATH, 'build')).initialize()
            .then(_initializeWorkers)
            .catch(err => {
                logger.error("Startup is failed", err);
                logger.error("Shutdown Node Server due to startup errors");
                setTimeout(function () {
                    process.exit(1);
                }, 5000);
            });

    }
}

module.exports = MasterProcess;