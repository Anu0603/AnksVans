
const path = require('path');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const MiniCssExtractPlugin = require('mini-css-extract-plugin')

module.exports = function (_options) {

    return {
        mode: _options.envType,
        entry: path.resolve(__dirname, './../src/' + _options.entryFile),
        output: {
            path: path.resolve(__dirname, './../dist'),
            filename: 'bundle.js',
            // publicPath: '/assets/'
        },
        module: {
            rules: [{
                test: /\.js$/,
                exclude: /node_modules/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['@babel/preset-react']
                    }
                }
            }, {
                test: /\.(css)$/,
                use: [MiniCssExtractPlugin.loader, "css-loader"],
            }, {
                test: /\.(scss|sass)$/,
                use: [MiniCssExtractPlugin.loader, "css-loader", "sass-loader"],
            }, {
                test: /\.(png|jpg|gif)$/,
                exclude: /node_modules/,
                use: [
                    {
                        loader: 'file-loader'
                    }
                ]
            }, {
                test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,

                use: [
                    {
                        loader: 'url-loader',
                        options: {
                            limit: 1000,
                            mimetype: 'application/font-woff'
                        }
                    }

                ]
            }, {
                test: /\.(ttf|eot|svg)(\?v=[0-9]\.[0-9]\.[0-9])?$/,

                loader: 'file-loader'
            }]
        },
        devServer: {
            contentBase: path.resolve(__dirname, './../dist'),
            port: 9000
        },
        plugins: [
            new MiniCssExtractPlugin({
                filename: '[name].css',
                chunkFilename: '[id].css',
                allChunks: true,
                ignoreOrder: true, // Enable to remove warnings about conflicting order
            }),
            new HtmlWebpackPlugin({
                template: "src/index.html" //source html
            })
        ]
    }
}