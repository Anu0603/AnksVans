import React from 'react';
import Label from './../src/framework/react/components/Label';

export default {
    title: 'Label',
};

export const LabelDefault = () => (
    <Label label="This is a sample label" htmlFor="username" />
);

export const LabelHtmlFor = () => (
    <Label label="This is a sample label for HtmlFor" htmlFor="username" />
);

export const LabelRequired = () => (
    <Label label="Label_test_required" htmlFor="username" required={true} />
);
