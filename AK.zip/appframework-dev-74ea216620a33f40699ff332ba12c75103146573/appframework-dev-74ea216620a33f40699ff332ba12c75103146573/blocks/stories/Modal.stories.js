import React from 'react';
import { Modal } from './../src/framework/react/components/Modal';

export default {
    title: 'Modal',
};

const modalRoot = global.document.createElement('div');
modalRoot.setAttribute('id', 'modal-root');
const body = global.document.querySelector('body');
body.appendChild(modalRoot);

export const Default = () => (
    <Modal show={true} />
);

export const WithChildren = () => (
    <Modal show={true} children="This is sample modal content" />
);

export const WithCrossIcon = () => (
    <Modal show={true} crossIconEnabled={true} children="This is sample modal content" />
);

export const SmallModal = () => (
    <Modal show={true} className="small" children="This is sample modal content" />

);


