import React from 'react';
import { CheckBox } from './../src/framework/react/components/CheckBox';

export default {
    title: 'CheckBox',
};

export const CheckBoxDefault = () => (
    <CheckBox />
);

export const CheckBoxLabel = () => (
    <CheckBox label="This is a sample label" />
);

export const CheckBoxChecked = () => (
    <CheckBox checked={true} />
);

export const CheckBoxReversed = () => (
    <CheckBox reversed={true} />
);

export const CheckBoxOnChange = () => (
    <CheckBox onChange={(e, val) => onChange(e, val)} />
);

export const CheckBoxHexcode1 = () => (
    <CheckBox hexCode1='#007bff' />
);

export const CheckBoxHexcode2 = () => (
    <CheckBox checked={true} hexCode2='#8CE172' />
);

export const CheckBoxDisabled = () => (
    <CheckBox disabled={true} />
);

const onChange = (e, val) => console.log(e);