import React from 'react';
import { Radio } from './../src/framework/react/components/RadioButton';

export default {
  title: 'Radio',
};

export const RadioDefault = () => (
  <Radio />
);

export const RadioLabel = () => (
  <Radio label="Radio_Label" hexCode2='#8CE172' />
);

export const RadioName = () => (
  <Radio name="Radio_Name" />
);

export const RadioValue = () => (
  <Radio value="Radio_value" />
);

export const RadioOnChange = () => (
  <Radio onChange={e => onChange(e)} />
);

export const RadioSecondaryLabel = () => (
  <Radio secondaryLabel="Secondary_Label" />
);

export const RadioChecked = () => (
  <Radio checked={true} hexCode2='#8CE172' />
);

export const RadioDisabled = () => (
  <Radio disabled={true} />
);

const onChange = (e, val) => console.log(e);