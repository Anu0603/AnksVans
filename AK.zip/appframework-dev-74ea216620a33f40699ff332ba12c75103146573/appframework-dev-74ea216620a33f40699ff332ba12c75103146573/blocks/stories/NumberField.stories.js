import React from 'react';
import { NumberField } from './../src/framework/react/components/InputField';

export default {
    title: 'NumberField',
};

export const NumberFieldDefault = () => (
    <NumberField id="123" />
);

export const NumberFieldLarge = () => (
    <NumberField large={true} />
);

export const NumberFieldValue = () => (
    <NumberField value={'100'} />
);

export const NumberFieldClear = () => (
    <NumberField showClearField={true} />
);

export const NumberFieldLabel = () => (
    <NumberField label="This is a sample label" />
);

export const NumberFieldPlaceholder = () => (
    <NumberField placeholder="Enter Username" />
);

export const NumberFieldErrorMessage = () => (
    <NumberField error={true} errorMessage="Error! Something went wrong" />
);

export const NumberFieldWarningMessage = () => (
    <NumberField warning={true} warningMessage="Some warning" />
);

export const NumberFieldOnChange = () => (
    <NumberField onChange={(e, val) => onChange(e, val)} />
);

export const NumberFieldDisabled = () => (
    <NumberField disabled={true} />
);

const onChange = (e, val) => console.log(e);