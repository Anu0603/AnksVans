import React from "react";
import Dropdown from "./../src/framework/react/components/Dropdown";

const options = [
  {
    optionValue: 1,
    displayText: "Hello",
    descriptionText: "This is a description of the item.",
    selected: false,
    group: "North America"
  },
  {
    optionValue: 2,
    displayText: "Goodbye",
    descriptionText: "This is a description of the item......................",
    selected: false,
    group: "Asia"
  },
  {
    optionValue: 2,
    displayText: "Goodbye",
    descriptionText: "This is a descr",
    selected: false,
    group: "North America"
  }
];

export default {
  title: "Dropdown"
};

export const empty = () => {
  return <Dropdown />;
};

export const withoutLabel = () => {
  return <Dropdown options={options} htmlId="dropdown"></Dropdown>;
};

export const withLabel = () => {
  return (
    <Dropdown
      options={options}
      placeholder="This has a placeholder"
      labelText="Label"
      htmlId="dropdown"
    ></Dropdown>
  );
};

export const withWarning = () => {
  return (
    <Dropdown
      options={options}
      warning={true}
      warningMessage="This is a warning message."
      defaultValue="Default value set"
      htmlId="dropdown"
    ></Dropdown>
  );
};

export const withError = () => {
  return (
    <Dropdown
      options={options}
      error={true}
      errorMessage="This is an error message."
      htmlId="dropdown"
    ></Dropdown>
  );
};

export const withGroups = () => {
  return (
    <Dropdown options={options} showGroups={true} htmlId="dropdown"></Dropdown>
  );
};

export const withOnchange = () => {
  return (
    <Dropdown
      options={options}
      htmlId="dropdown"
      onChange={() => console.log("changed")}
    ></Dropdown>
  );
};

export const noBorder = () => {
  return (
    <Dropdown options={options} htmlId="dropdown" border={false}></Dropdown>
  );
};

export const customPlaceholder = () => {
  return (
    <Dropdown
      options={options}
      htmlId="dropdown"
      placeholder="Custom placeholder!"
    />
  );
};
