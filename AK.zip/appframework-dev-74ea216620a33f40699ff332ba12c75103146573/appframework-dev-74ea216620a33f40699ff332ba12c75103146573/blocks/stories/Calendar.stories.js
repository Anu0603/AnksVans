import React from "react";
import { Calendar } from "../src/framework/react/components/Calendar";

export default {
  title: "Calendar"
};

export const calendar = () => {
  return <Calendar />;
};

export const calendarDefaultDate = () => {
  return <Calendar value="4-12-2021" />;
};
