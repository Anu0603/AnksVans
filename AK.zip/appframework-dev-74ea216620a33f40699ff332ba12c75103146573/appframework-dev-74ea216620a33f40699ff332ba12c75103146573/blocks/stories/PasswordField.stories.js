import React from 'react';
import { PasswordField } from './../src/framework/react/components/InputField';

export default {
    title: 'PasswordField',
};

export const Default = () => (
    <PasswordField placeholder="Enter Password" />
);

export const WithLargeEnabled = () => (
    <PasswordField large={true} />
);

export const WithValue = () => (
    <PasswordField value={'100'} />
);

export const WithLabel = () => (
    <PasswordField label="This is a sample label" />
);

export const WithPlaceholder = () => (
    <PasswordField placeholder="Enter Password" />
);

export const WithShowPassword = () => (
    <PasswordField showPassword={true} />
);

export const WithErrorMessage = () => (
    <PasswordField error={true} errorMessage="Error! Something went wrong" />
);

export const WithWarningMessage = () => (
    <PasswordField warning={true} warningMessage="Some warning" />
);

export const WithOnChange = () => (
    <PasswordField onChange={(e, val) => onChange(e, val)} />
);

export const WithDisabled = () => (
    <PasswordField disabled={true} />
);

const onChange = (e, val) => console.log(e);