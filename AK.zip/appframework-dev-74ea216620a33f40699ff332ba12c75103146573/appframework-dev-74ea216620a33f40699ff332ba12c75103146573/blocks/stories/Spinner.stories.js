import React from 'react';
import {Spinner} from './../src/framework/react/components/Spinner';

export default {
  title: 'Spinner',
};

export const spinnerDefault = () => (
  <Spinner id='regularSpinner' name="someButtonName" classes="aaa"/>
);

export const spinnerCustom = () => (
  <Spinner id='regularSpinner' color="red" circleColor="green" name="someButtonName" classes="aaa"/>
);

export const spinnerSmall = () => (
  <Spinner id='smallSpinner' name="someButtonName" classes="aaa" size="sm" />
);

export const spinnerLarge = () => (
  <Spinner id='largeSpinner' name="someButtonName" classes="aaa" size="lg"/>
);

const onClick = () => console.log('onClick');