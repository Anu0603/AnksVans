import React from "react";
import DatePicker from "../src/framework/react/components/DatePicker";
import moment from "moment";

export default {
  title: "DatePicker"
};

export const withDefaultDate = () => {
  return <DatePicker defaultDate="4-2-2020" />;
};

export const withMinDate = () => {
  return <DatePicker minDate="2-15-2020" />;
};

export const withMaxDate = () => {
  return <DatePicker maxDate="2-15-2020" />;
};

export const withMinMaxDates = () => {
  return <DatePicker minDate="1-2-2020" maxDate="2-2-2020" />;
};

export const differentFormat = () => {
  return <DatePicker dateFormat="DD-MM-YYYY" />;
};

export const withOnchangeEvent = () => {
  let useDate = date => moment(date).format("ll");

  return <DatePicker onChange={d => console.log(useDate(d))} />;
};
