import React from 'react';
import { Toggle } from './../src/framework/react/components/ToggleButton';

export default {
    title: 'Toggle',
};

export const ToggleDefault = () => (
    <Toggle id="abc" />
);

export const ToggleLabel = () => (
    <Toggle label="This is a sample label" id="abc" />
);

export const ToggleName = () => (
    <Toggle name="Toggle_Name" id="abc" />
);

export const ToggleValue = () => (
    <Toggle value="Toggle_value" id="abc" />
);

export const ToggleOnChange = () => (
    <Toggle id="abc" value="test" onChange={e => onChange(e)} />
);

export const ToggleDefaultChecked = () => (
    <Toggle id='abc' defaultChecked={true} />
);

export const ToggleDisabled = () => (
    <Toggle id='abc' disabled={true} />
);

const onChange = (e, val) => console.log(e);