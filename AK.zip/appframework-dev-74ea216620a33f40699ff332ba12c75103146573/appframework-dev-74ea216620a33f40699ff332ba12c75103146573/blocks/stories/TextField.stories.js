import React from 'react';
import { TextField } from './../src/framework/react/components/InputField';

export default {
    title: 'TextField',
};

export const TextFieldDefault = () => (
    <TextField id="123" />
);

export const TextFieldLarge = () => (
    <TextField large={true} />
);

export const TextFieldValue = () => (
    <TextField value={'100'} />
);

export const TextFieldLabel = () => (
    <TextField label="This is a sample label" />
);

export const TextFieldPlaceholder = () => (
    <TextField placeholder="Enter Username" />
);

export const TextFieldErrorMessage = () => (
    <TextField error={true} errorMessage="Error! Something went wrong" />
);

export const TextFieldWarningMessage = () => (
    <TextField warning={true} warningMessage="Some warning" />
);

export const TextFieldDisableCopyPaste = () => (
    <TextField allowCopyPaste={false} />
);

export const TextFieldOnChange = () => (
    <TextField onChange={(e, val) => onChange(e, val)} />
);

export const TextFieldDisabled = () => (
    <TextField disabled={true} />
);

const onChange = (e, val) => console.log(e);