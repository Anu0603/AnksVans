import React, { useEffect, useState } from 'react';
import { Button } from './../src/framework/react/components/Button'

export default {
  title: 'Button',
};

export const button = () => (
  <Button id='someButton' tabIndex="0" name="someButtonName" label="Button" onClick={onClick} />
);

export const buttonSmall = () => (
  <Button id='someButton' name="someButtonName" size="sm"
    label="Button" onClick={onClick} />
);

export const buttonLarge = () => (
  <Button id='someButton' name="someButtonName" size="lg"
    label="Button" onClick={onClick} />
);


export const buttonSecondary = () => (
  <Button id='someButton' name="someButtonName" variant="secondary"
    label="Button" onClick={onClick} />
);

export const buttonSmallSecondary = () => (
  <Button id='someButton' name="someButtonName" variant="secondary" size="sm"
    label="Button" onClick={onClick} />
);

export const buttonLargeSecondary = () => (
  <Button id='someButton' name="someButtonName" variant="secondary" size="lg"
    label="Button" onClick={onClick} />
);


export const buttonTertiary = () => (
  <Button id='someButton' name="someButtonName" variant="tertiary"
    label="Button" onClick={onClick} />
);

export const buttonSmallTertiary = () => (
  <Button id='someButton' name="someButtonName" variant="tertiary" size="sm"
    label="Button" onClick={onClick} />
);

export const buttonLargeTertiary = () => (
  <Button id='someButton' name="someButtonName" variant="tertiary" size="lg"
    label="Button" onClick={onClick} />
);


export const buttonDanger = () => (
  <Button id='someButton' name="someButtonName" variant="danger"
    label="Button" onClick={onClick} />
);

export const buttonSmallDanger = () => (
  <Button id='someButton' name="someButtonName" variant="danger" size="sm"
    label="Button" onClick={onClick} />
);

export const buttonLargeDanger = () => (
  <Button id='someButton' name="someButtonName" variant="danger" size="lg"
    label="Button" onClick={onClick} />
);


export const buttonWarning = () => (
  <Button id='someButton' name="someButtonName" variant="warning"
    label="Button" onClick={onClick} />
);

export const buttonSmallWarning = () => (
  <Button id='someButton' name="someButtonName" variant="warning" size="sm"
    label="Button" onClick={onClick} />
);

export const buttonLargeWarning = () => (
  <Button id='someButton' name="someButtonName" variant="warning" size="lg"
    label="Button" onClick={onClick} />
);

/**
 * Reversed Buttons
 */
export const buttonReversed = () => (
  <Button id='someButton' name="someButtonName" reversed={true} label="Button" onClick={onClick} />
);

export const buttonSmallReversed = () => (
  <Button id='someButton' name="someButtonName" reversed={true} size="sm"
    label="Button" onClick={onClick} />
);

export const buttonLargeReversed = () => (
  <Button id='someButton' name="someButtonName" reversed={true} size="lg"
    label="Button" onClick={onClick} />
);

export const buttonSecondaryReversed = () => (
  <div className="containerDark">
    <Button id='someButton' name="someButtonName" variant="secondary" reversed={true} 
  label="Button" onClick={onClick} />
  </div>  
);

export const buttonSmallSecondaryReversed = () => (
  <div className="containerDark">
  <Button id='someButton' name="someButtonName" variant="secondary" reversed={true} size="sm"
    label="Button" onClick={onClick} />
  </div>
);

export const buttonLargeSecondaryReversed = () => (
  <div className="containerDark">
    <Button id='someButton' name="someButtonName" variant="secondary" reversed={true} size="lg"
    label="Button" onClick={onClick} />
  </div>
  
);


export const buttonTertiaryReversed = () => (
  <Button id='someButton' name="someButtonName" variant="tertiary" reversed={true} 
    label="Button" onClick={onClick} />
);

export const buttonSmallTertiaryReversed = () => (
  <Button id='someButton' name="someButtonName" variant="tertiary" reversed={true} size="sm"
    label="Button" onClick={onClick} />
);

export const buttonLargeTertiaryReversed = () => (
  <Button id='someButton' name="someButtonName" variant="tertiary" reversed={true} size="lg"
    label="Button" onClick={onClick} />
);


export const buttonDangerReversed = () => (
  <Button id='someButton' name="someButtonName" variant="danger" reversed={true} 
    label="Button" onClick={onClick} />
);

export const buttonSmallDangerReversed = () => (
  <Button id='someButton' name="someButtonName" variant="danger" reversed={true} size="sm"
    label="Button" onClick={onClick} />
);

export const buttonLargeDangerReversed = () => (
  <Button id='someButton' name="someButtonName" variant="danger" reversed={true} size="lg"
    label="Button" onClick={onClick} />
);


export const buttonWarningReversed = () => (
  <Button id='someButton' name="someButtonName" variant="warning" reversed={true} 
    label="Button" onClick={onClick} />
);

export const buttonSmallWarningReversed = () => (
  <Button id='someButton' name="someButtonName" variant="warning" reversed={true}  size="sm"
    label="Button" onClick={onClick} />
);

export const buttonLargeWarningReversed = () => (
  <Button id='someButton' name="someButtonName" variant="warning" reversed={true}  size="lg"
    label="Button" onClick={onClick} />
);

/**
 * Button type
 */
export const buttonTypeButton = () => (
  <Button id='someButton' name="someButtonName" label="Button" onClick={onClick} />
);

export const buttonTypeSubmit = () => (
  <Button id='someButton' name="someButtonName" label="Button" onClick={onClick} buttonType="submit"/>
);

export const buttonTypeReset = () => (
  <Button id='someButton' name="someButtonName" label="Button" onClick={onClick}  buttonType="reset"/>
);

/**
 * Button Disabled
 */
export const buttonDisabled = () => (
  <Button id='someButton' name="someButtonName" disabled={true} label="Button" onClick={onClick} />
);

/**
 * Button Full Width
 */
export const buttonFullWidth = () => (
  <Button id='someButton' name="someButtonName" fullWidth={true} label="Button" onClick={onClick} />
);

/**
 * Button Always Loading
 */
export const buttonAlwaysLoading = () => (
  <div class="container">
    <Button id='someButton' name="someButtonName" isLoading={true} label="Button" onClick={onClick} />
  </div>  
);

/**
 * Button Loading
 */
export const buttonLoading = () => {
  const [isLoading, setLoading] = useState(false);

  useEffect(() => {
    if (isLoading) {
      simulateNetworkRequest().then(() => {
        setLoading(false);
      });
    }
  }, [isLoading]);

  const handleClick = () => setLoading(true);

  return (
    <div class="container">
      <Button id='loadBtn' isLoading={isLoading} label="Load" onClick={handleClick} />
    </div>    
  )
}

function simulateNetworkRequest() {
  return new Promise(resolve => setTimeout(resolve, 2000));
}

const onClick = (e) => console.log('onClick' + e);

