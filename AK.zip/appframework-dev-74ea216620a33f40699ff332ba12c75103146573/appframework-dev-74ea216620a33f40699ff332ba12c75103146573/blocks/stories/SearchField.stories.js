import React from 'react';
import { SearchField } from './../src/framework/react/components/InputField';

export default {
    title: 'SearchField',
};

export const Default = () => (
    <SearchField placeholder="Search.." />
);

export const WithLargeEnabled = () => (
    <SearchField large={true} />
);

export const WithValue = () => (
    <SearchField value={'100'} />
);

export const WithLabel = () => (
    <SearchField label="This is a sample label" />
);

export const WithPlaceholder = () => (
    <SearchField placeholder="Search.." />
);

export const WithShowSearchIcon = () => (
    <SearchField showSearchIcon={true} />
);

export const WithShowClearField = () => (
    <SearchField showClearField={true} value="abc" />
);

export const WithErrorMessage = () => (
    <SearchField error={true} errorMessage="Error! Something went wrong" />
);

export const WithWarningMessage = () => (
    <SearchField warning={true} warningMessage="Some warning" />
);

export const WithOnChange = () => (
    <SearchField onChange={(e, val) => onChange(e, val)} />
);

export const WithDisabled = () => (
    <SearchField disabled={true} />
);

const onChange = (e, val) => console.log(e);