let jest = require('jest')

jest.run()