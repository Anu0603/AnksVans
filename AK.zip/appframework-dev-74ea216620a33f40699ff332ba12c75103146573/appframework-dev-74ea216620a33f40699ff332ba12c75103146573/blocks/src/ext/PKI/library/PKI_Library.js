/* PKI Encryption JS Module
** Exposes PKI object with 2 methods - encrypt(), setKey()
*/
import pidCrypt from "./pidcrypt";
import "./asn1";
import "./rsa";


(function() {
  function formatString(str)
  {
    var tmp='';
    for(var i=0;i<str.length;i+=80)
      tmp += '   ' + str.substr(i,80) +'\n';
    return tmp;
  }

  function showData(tree) {
    var data = '';
    var val = '';
    if(tree.value)
     val = tree.value;
    data += tree.type + ':' +  val.substr(0,48) + '...\n';
    if(tree.sub)
      for(var i=0;i<tree.sub.length;i++)
        data += showData(tree.sub[i]);
    return data;
  }

  function certParser(cert){
    var lines = cert.split('\n');
    var read = false;
    var b64 = false;
    var end = false;
    var flag = '';
    var retObj = {};
    retObj.info = '';
    retObj.salt = '';
    retObj.iv;
    retObj.b64 = '';
    retObj.aes = false;
    retObj.mode = '';
    retObj.bits = 0;
    for(var i=0; i< lines.length; i++){
      flag = lines[i].substr(0,9);
      if(i==1 && flag != 'Proc-Type' && flag.indexOf('M') == 0)//unencrypted cert?
        b64 = true;
      switch(flag){
        case '-----BEGI':
          read = true;
          break;
        case 'Proc-Type':
          if(read)
            retObj.info = lines[i];
          break;
        case 'DEK-Info:':
          if(read){
            var tmp = lines[i].split(',');
            var dek = tmp[0].split(': ');
            var aes = dek[1].split('-');
            retObj.aes = (aes[0] == 'AES')?true:false;
            retObj.mode = aes[2];
            retObj.bits = parseInt(aes[1]);
            retObj.salt = tmp[1].substr(0,16);
            retObj.iv = tmp[1];
          }
          break;
        case '':
          if(read)
            b64 = true;
          break;
        case '-----END ':
          if(read){
            b64 = false;
            read = false;
          }
        break;
        default:
          if(read && b64)
            retObj.b64 += pidCryptUtil.stripLineFeeds(lines[i]);
      }
    }
    return retObj;
  }

  //publicly available
  window.PKI = {
    encrypt: function(data) {
     
      var params = {};
      let crypted = null;
      if(typeof _public_key_2048 !== 'undefined' && _public_key_2048.length > 0) {
        params = certParser(_public_key_2048);
      } else {
        Logger.info('Could not find public key for encryption');
        return;
      }
      if(params.b64){
          var key = pidCryptUtil.decodeBase64(params.b64);
          //new RSA instance
          var rsa = new pidCrypt.RSA();
          //RSA encryption
          //ASN1 parsing
          var asn = pidCrypt.ASN1.decode(pidCryptUtil.toByteArray(key));
          var tree = asn.toHexTree();
          //setting the public key for encryption
          rsa.setPublicKeyFromASN(tree);
          crypted = rsa.encryptRaw(data);
          //var encypted_data = pidCryptUtil.fragment(pidCryptUtil.convertFromHex(crypted)),64);
          //pidCryptUtil.fragment(pidCryptUtil.encodeBase64(pidCryptUtil.convertFromHex(crypted)),64);
          var encypted_data = crypted;
          return _keyAlias + ":" + encypted_data;
          //theForm.input.value = '';
       } else {
            Logger.info('Could not find public key for encryption');
            return 0;
       }
     },
     setKey: function(responseObj) {
        //the server response has to have the properties that is being looked for
        if(typeof responseObj === 'object' && responseObj["keyAsPemString"] && responseObj["keyAlias"]) {
          _public_key_2048 = responseObj["keyAsPemString"];
          _keyAlias = responseObj["keyAlias"];
        } else {
          Logger.info('Could not find public key for encryption. Server response is not returning public key in correct format');
          return;
        }
     },
     isKeyAvailable: function() {
        //make a fake encryption call
        if(typeof _public_key_2048 !== 'undefined' && _public_key_2048.length > 0) {
          var testCall = this.encrypt("test"); //will return valid value if key is available and correct
        }
        return !!testCall;
     }
  };

  //private vars
  var _public_key_2048  = '',
      _keyAlias = '';

})();