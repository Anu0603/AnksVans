import React from 'react'

const FastLink = React.lazy(() => import('./../../bricks/fastlink'))
// const Enrich = React.lazy(() => import('./../../bricks/enrich'))

const Navigator = ({ routeName, ...props }) => {
	let _routes = {
		fastlink: FastLink
		// enrich: Enrich
	}

	let Route = _routes[routeName]

	if (Route) {
		return <Route {...props} />
	} else {
		return <div className={'product-not-found'}>Product Not Found</div>
	}
}

export default Navigator
