import React from 'react'
import { Provider } from 'react-redux'
import renderer from 'react-test-renderer'
import configureStore from 'redux-mock-store'
import StoreProvider from '../store'

const mockStore = configureStore([])

const thunk = ({ dispatch, getState }) => next => action => {
	if (typeof action === 'function') {
		return action(dispatch, getState)
	}

	return next(action)
}

const create = () => {
	const store = {
		getState: jest.fn(() => ({})),
		dispatch: jest.fn()
	}
	const next = jest.fn()

	const invoke = action => thunk(store)(next)(action)

	return { store, next, invoke }
}

describe('Redux Store', () => {
	let store = null,
		container = null

	beforeEach(() => {
		store = mockStore({
			myState: 'sample text'
		})
		store.dispatch = jest.fn()
		container = renderer.create(
			<Provider store={store}>
				<StoreProvider>
					<button onClick={store.dispatch}>Test</button>
				</StoreProvider>
			</Provider>
		)
	})
	it('Check if it renders with given state from Redux store', () => {
		expect(container.toJSON()).toMatchSnapshot()
	})

	it('Check if action is dispatched on button click', () => {
		renderer.act(() => {
			container.root.findByType('button').props.onClick()
		})
		// expect(store.dispatch).toHaveBeenCalledTimes(1);
		expect(store.dispatch.mock.calls.length).toBe(1)
	})

	it('passes through non-function action', () => {
		const { next, invoke } = create()
		const action = { type: 'TEST' }
		invoke(action)
		expect(next).toHaveBeenCalledWith(action)
	})

	it('calls the function', () => {
		const { invoke } = create()
		const fn = jest.fn()
		invoke(fn)
		expect(fn).toHaveBeenCalled()
	})

	it('passes dispatch and getState', () => {
		const { store, invoke } = create()
		invoke((dispatch, getState) => {
			dispatch('TEST DISPATCH')
			getState()
		})
		expect(store.dispatch).toHaveBeenCalledWith('TEST DISPATCH')
		expect(store.getState).toHaveBeenCalled()
	})
})
