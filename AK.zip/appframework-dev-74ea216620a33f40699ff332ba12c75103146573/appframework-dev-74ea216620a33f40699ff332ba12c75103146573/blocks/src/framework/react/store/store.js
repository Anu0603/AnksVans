import React from 'react'
import { createStore, combineReducers, applyMiddleware, compose } from 'redux'

import { Provider } from 'react-redux'

import siteSelectionReducer from '../../../bricks/fastlink/store/reducers/siteSelection'
import loginReducer from '../../../bricks/fastlink/store/reducers/login'
import refreshReducer from '../../../bricks/fastlink/store/reducers/refresh'
import accountsReducer from '../../../bricks/fastlink/store/reducers/accounts'
import providerInfo from '../../../bricks/fastlink/store/reducers/providerInfo'
import cdvReducer from '../../../bricks/fastlink/store/reducers/cdv'
import realEstateReducer from '../../../bricks/fastlink/store/reducers/realEstate'
import manualAccountReducer from '../../../bricks/fastlink/store/reducers/manualAccount'
import userAddedAccountData from '@fastlinkRoot/store/reducers/userAddedAccountData'
import deeplinkReducer from '@fastlinkRoot/store/reducers/deeplink'

import FastlinkReducer from '@fastlinkRoot/store/reducers'

const rootReducer = combineReducers({
	fastlink: FastlinkReducer,
	siteSelection: siteSelectionReducer,
	login: loginReducer,
	refresh: refreshReducer,
	accounts: accountsReducer,
	currentProvider: providerInfo,
	cdv: cdvReducer,
	realEstate: realEstateReducer,
	manualAccount: manualAccountReducer,
	userAddedAccountData: userAddedAccountData,
	deeplink: deeplinkReducer
})

//TODO : use this below sort of Middlewares for logs, performance ,Amplitude and New relic
const middleware = store => {
	return next => {
		return action => {
			//console.log(" Dispatching Action", action);
			const result = next(action)
			//console.log("Next state", store.getState());
			return result
		}
	}
}
const composeEnhancers = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose

export const store = createStore(
	rootReducer,
	composeEnhancers(applyMiddleware(middleware))
)

const StoreProvider = props => (
	<Provider store={store}>{props.children}</Provider>
)

export default StoreProvider
