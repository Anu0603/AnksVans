import React from 'react'
import Link from '../Link'

describe('Link Component', () => {
    let container = null

    beforeEach(() => {
        container = null
    })

    it('Check if Link Component is rendered', () => {
        act(() => {
            container = mount(<Link label="test_label" />);
        })
        expect(container.find('a')).toHaveLength(1)
    });

    it('Check if onClick prop is called', () => {
        const onClickMock = jest.fn();
        act(() => {
            container = mount(<Link onClick={onClickMock} />);
        })
        container.find('a').simulate('click');
        expect(onClickMock.mock.calls.length).toBe(1);
    });

    // onclick mock function event
    // check for label
});