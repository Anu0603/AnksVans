import React from 'react'
import PfileModal from '../PfileModal'

import PfileService from './../../../../../bricks/fastlink/services/resource/pfileService'
jest.mock('./../../../../../bricks/fastlink/services/resource/pfileService')

describe('Modal Component', () => {
	let container = null
	let dummyData = '<p><h3>Dummy Heading</h3></p>'

	const modalRoot = global.document.createElement('div')
	modalRoot.setAttribute('id', 'modal-root')
	const body = global.document.querySelector('body')
	body.appendChild(modalRoot)

	beforeEach(() => {
		container = null
		PfileService.getPfileContent.mockImplementation(
			(_options, _callback) => {
				_callback(null, dummyData)
			}
		)
		// PfileService.getPfileContent.mockImplementation((_options, _callback) => _callback('Some Error', null))
	})

	afterEach(() => {
		container.unmount()
	})

	it('Check if PfileModal Component is rendered', () => {
		act(() => {
			container = mount(<PfileModal show={true} />)
		})
		expect(container.find('.modal-inner-container')).toHaveLength(1)
		expect(container).toMatchSnapshot()
	})

	it('Check if PfileService throws error and PfileModal Component is not rendered', () => {
		PfileService.getPfileContent.mockImplementation((_options, _callback) =>
			_callback('Some Error', null)
		)
		act(() => {
			container = mount(<PfileModal show={false} />)
		})
		expect(container.find('.modal-inner-container')).not.toHaveLength(1)
		// expect(container).toMatchSnapshot();
	})
})
