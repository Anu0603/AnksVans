import React, { useState, Component } from 'react'
import classNames from 'classnames'

import './Icon.scss'
class Icon extends Component {
	constructor(props) {
		super(props)
	}

	render() {
		let {
			type = 'fal',
			iconClass,
			classes,
			iconRef,
			...propss
		} = this.props
		let iconClasss = classNames(type, iconClass, classes)

		return <i ref={iconRef} className={iconClasss} {...propss} />
	}
}

export default Icon
