import React, { useState } from "react";
import classNames from "classnames";
import PropTypes from "prop-types";

import TextField from "./TextField";

import "./TextField.scss";

const propTypes = {
  /**
   * Specifies input element id
   */
  id: PropTypes.string,
  /**
   * Specifies input element's value
   */
  value: PropTypes.string,
  /**
   * Specifies input element's default value
   */
  // defaultValue: PropTypes.string,
  /**
   * Specifies placeholder string
   */
  placeholder: PropTypes.string,
  /**
   * Specifies label of the textfield
   */
  label: PropTypes.string,
  /**
   * Specifies custom class to be applied on the label
   */
  labelClass: PropTypes.string,
  /**
   * Specifies custom classes to be applied on the component's container
   */
  containerClass: PropTypes.string,
  /**
   * Specifies custom classes to be applied on the input
   */
  inputclass: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
  /**
   * Specifies boolean property to render large textfield
   *  @default (false)
   */
  large: PropTypes.bool,
  /**
   * Specifies boolean property to disable/enable the textfield
   * @default (false)
   */
  disabled: PropTypes.bool,
  /**
   * Specifies boolean property yo show eye icon on the textfield
   * @default (false)
   */
  showPassword: PropTypes.bool,
  /**
   * Specifies boolean property to show and hide the search icon on the left side of the text-field.
   * @default (true)
   */
  showSearchIcon: PropTypes.bool,
  /**
   * Specifies boolean property to show and hide the X on the right side of the text-field, which is used to clear the text-field values.
   * @default (true)
   */
  showClearField: PropTypes.bool,
  /**
   * Specifies boolean property yo show error on the textfield
   * @default (false)
   */
  error: PropTypes.bool,
  /**
   * Specifies the error message to be displayed
   */
  errorMessage: PropTypes.string,
  /**
   * Specifies boolean property yo show warning on the textfield
   * @default (false)
   */
  warning: PropTypes.bool,
  /**
   * Specifies warning message to be displayed
   */
  warningMessage: PropTypes.string,
  /**
   * Specifies warning message to be displayed
   */
  onChange: PropTypes.func
};

const defaultProps = {
  id: "",
  value: "",
  // defaultValue: '',
  placeholder: "",
  label: "",
  labelClass: "",
  containerClass: "",
  inputclass: "",
  large: false,
  disabled: false,
  showPassword: false,
  showClearField: true,
  showSearchIcon: true,
  error: false,
  errorMessage: "",
  warning: false,
  warningMessage: "",
  onChange: () => {}
};

const SearchField = ({
  value,
  onChange,
  showSearchIcon,
  showClearField,
  ...props
}) => {

  const clearField = e => {
    onChange(e);
  };
  
  const updateSearchField = e => {
    onChange(e);
  };

  let predecorator = showSearchIcon && {
    icon: "fa-search",
    isThin: true
  };

  let postdecorator = showClearField && {
    icon: "fa-times",
    isThin: true,
    action: clearField.bind(this)
  };

  return (
   
    <div>
      <TextField
        value={value}
        onChange={updateSearchField.bind(this)}
        {...props}
        predecorator={predecorator}
        postdecorator={value.length > 0  ? postdecorator : {}}
      />
    </div>
  );
};

SearchField.propTypes = propTypes;
SearchField.defaultProps = defaultProps;

export default SearchField;
