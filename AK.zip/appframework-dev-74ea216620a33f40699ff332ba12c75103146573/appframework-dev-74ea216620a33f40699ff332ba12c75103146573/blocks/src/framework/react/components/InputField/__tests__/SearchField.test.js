import React from 'react'
import SearchField from '../SearchField'

describe('Search Component', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check if search component is rendered', () => {
		act(() => {
			container = mount(<SearchField type="text" />)
		})
		expect(container.find('.tfield-container')).toHaveLength(1)
	})

	it('Check if Pre Decorator component and Icon is rendered', () => {
		act(() => {
			container = mount(<SearchField type="text" />)
		})
		expect(container.find('.pre-decorator')).toHaveLength(1)
		expect(container.find('.fa-search')).toHaveLength(1)
	})

	it('Check if Post Decorator, ClearField and Icon is rendered', () => {
		let props = {
			type: 'text',
			postdecorator: { icon: 'fa-search', action: () => {} },
			value: 'test'
		}
		act(() => {
			container = mount(<SearchField {...props} />)
		})
		expect(container.find('.post-decorator')).toHaveLength(1)
		container.find('.post-decorator i').simulate('click')
		expect(container.find('.post-decorator .fa-times')).toHaveLength(1)
	})

	it('Check if search value is being changed', () => {
		act(() => {
			container = mount(<SearchField value="test search" />)
		})
		container
			.find('input')
			.simulate('change', { target: { value: 'test search' } })
		const input = container.find('input')
		expect(input.prop('defaultValue')).toBe('test search')
	})
})
