import React from "react";
import ReactDOM from "react-dom";
import ModalPortal from "./ModalPortal";

class Modal extends React.Component {
  constructor(props) {
    super(props);
    let newElement = document.createElement("div");
    newElement.setAttribute("class", "modal-outer-container");
    this.connectChild = newElement;
    this.modalRoot = document.getElementById("modal-root");
  }

  componentDidMount() {
    this.modalRoot.appendChild(this.connectChild);
  }

  componentWillUnmount() {
    this.modalRoot.removeChild(this.connectChild);
  }

  render() {
    if (!this.props.show) return null;
    return ReactDOM.createPortal(
      <ModalPortal {...this.props} />,
      this.connectChild
    );
  }
}

export default Modal;
