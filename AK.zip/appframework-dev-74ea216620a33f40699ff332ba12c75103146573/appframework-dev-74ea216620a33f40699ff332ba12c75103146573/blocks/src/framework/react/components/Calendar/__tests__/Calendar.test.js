import React from "react";

import Calendar from "./../Calendar";
import Dropdown from "./../../Dropdown";

describe("<Calendar> Component", () => {
  let container = null;

  beforeEach(() => {
    container = null;
  });

  it("Renders days of week headers and calendar body by default", () => {
    act(() => {
      container = shallow(<Calendar />);
    });

    expect(container.find(".calendar_body_week")).toHaveLength(1);
    expect(container.find(".calendar_body_days")).toHaveLength(1);
    // expect(container).toMatchSnapshot()
  });

  it("Renders month, year, and days of value prop", () => {
    act(() => {
      container = mount(<Calendar value="5-12-2021" />);
    });

    let monthOptions = container
      .find(Dropdown)
      .at(0)
      .props().options;
    let selectedMonth = monthOptions.filter(o => o.selected);
    let yearOptions = container
      .find(Dropdown)
      .at(1)
      .props().options;
    let selectedYear = yearOptions.filter(o => o.selected);

    expect(selectedMonth[0].displayText).toBe("May");
    expect(selectedYear[0].displayText).toBe("2021");

    container.update();
    expect(container.find(".filled").length).toBe(31);
  });

  it('Check if Previous Month Button onClick prop is called', () => {
    const onClickMock = jest.fn();
    act(() => {
      container = mount(<Calendar value="1-12-2021" />);
    })
    container.find('.calendar_header_left_arrow').simulate('click');
    // expect(onClickMock.mock.calls.length).toBe(1);
  });

  it('Check if Next Month Button onClick prop is called', () => {
    const onClickMock = jest.fn();
    act(() => {
      container = mount(<Calendar value="12-12-2021" />);
    })
    container.find('.calendar_header_right_arrow').simulate('click');
    // expect(onClickMock.mock.calls.length).toBe(1);
  });

  it('Check if year is out of range', () => {
    act(() => {
      container = mount(<Calendar value="12-12-5021" />);
    })
    // expect(onClickMock.mock.calls.length).toBe(1);
  });

  it('Check if <td> onClick prop is called', () => {
    act(() => {
      container = mount(<Calendar value="5-12-2021" />);
    })
    let monthOptions = container.find(Dropdown).at(0).props().options;
    let selectedMonth = monthOptions.filter(o => o.selected);
    let yearOptions = container.find(Dropdown).at(1).props().options;
    let selectedYear = yearOptions.filter(o => o.selected);

    expect(selectedMonth[0].displayText).toBe("May");
    expect(selectedYear[0].displayText).toBe("2021");

    container.update();
    container.find(".filled").at(0).simulate('click');
  });
});
