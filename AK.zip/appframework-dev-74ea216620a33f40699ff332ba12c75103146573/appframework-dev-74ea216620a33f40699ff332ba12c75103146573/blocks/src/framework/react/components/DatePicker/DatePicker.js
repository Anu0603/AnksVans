import React, { useState, useEffect, useRef, useCallback } from 'react'
import PropTypes from 'prop-types'
import moment from 'moment'
import TextField from '../InputField/TextField'
import { Calendar } from '../Calendar'
import { keyCodes } from '../utils'
import IconNameMap from '../Icon/IconNameMap'
import './DatePicker.scss'

const propTypes = {
	// defaultDate: (props, propName, componentName) => {
	//   let date = moment(new Date(props[propName])).format("MM/DD/YYY");
	//   if (!date.isValid()) {
	//     return new Error(
	//       "Invalid prop `" +
	//         propName +
	//         "` supplied to `" +
	//         componentName +
	//         "`. Validation failed."
	//     );
	//   }
	// },
	onChange: PropTypes.func
}

const defaultProps = {
	error: false,
	errorMessage: 'Invalid date',
	onChange: () => {},
	dateFormat: 'MM/DD/YYYY',
	minDate: null,
	maxDate: null
}

const Datepicker = props => {
	const defaultDate = props.defaultDate
		? moment(new Date(props.defaultDate)).format(props.dateFormat)
		: ''
	const [isVisible, setIsVisible] = useState(false)
	const [mainDate, setMainDate] = useState(defaultDate)
	const [plainDate, setPlainDate] = useState()
	const [formattedDate, setFormattedDate] = useState()
	const [isValidDate, setIsValidDate] = useState(true)
	const [warning, setWarning] = useState(false)
	const [warningMessage, setWarningMessage] = useState('')
	const dateFormat = props.dateFormat

	const firstUpdate = useRef(true)
	const datepickerRef = useRef()

	// const checkValidity = d => {
	//   if (!d) return undefined;

	//   let valid = moment(d).isValid();

	//   return valid;
	// };

	const checkInRange = d => {
		let date = moment(new Date(d)).format()
		let min = moment(d, 'day').isSameOrAfter(props.minDate, 'day')
		let max = moment(d, 'day').isSameOrBefore(props.maxDate, 'day')

		// if (min) {
		// 	setWarningMessage(
		// 		'Date precedes ' +
		// 			`${moment(new Date(props.minDate)).format(dateFormat)}` +
		// 			'.'
		// 	)
		// }

		// if (max) {
		// 	setWarningMessage(
		// 		'Date exceeds ' +
		// 			`${moment(new Date(props.maxDate)).format(dateFormat)}` +
		// 			'.'
		// 	)
		// }

		if (props.minDate !== null && !min) {
			return false
		}

		if (props.maxDate !== null && !max) {
			return false
		}

		return true
	}

	const resetStates = () => {
		setIsValidDate(true)
		setWarning(false)
	}

	const updateDate = useCallback(date => {
		const isInRange = checkInRange(date)

		if (isInRange) {
			return setMainDate(moment(new Date(date), dateFormat))
		}
	}, [])

	// useEffect(() => {
	//   if (datepickerRef.current) {
	//     document.addEventListener("click", handleOutsideClick, false);
	//   }

	//   return () => {
	//     document.removeEventListener("click", handleOutsideClick, false);
	//   };
	// }, [isVisible]);

	useEffect(() => {
		resetStates()

		let tempDate = mainDate

		if (!tempDate) return undefined

		let valid = moment(new Date(tempDate)).isValid()
		let checkRange = props.minDate || props.maxDate

		valid
			? [
					setFormattedDate(
						moment(new Date(tempDate)).format(dateFormat)
					),
					setPlainDate(moment(new Date(tempDate))),
					undefined
			  ]
			: [setIsValidDate(false), undefined]

		checkRange
			? checkInRange(tempDate)
				? undefined
				: [setPlainDate(), setFormattedDate(), setWarning(true)]
			: undefined

		props.onChange(tempDate)
	}, [mainDate])

	useEffect(() => {
		if (firstUpdate.current) {
			firstUpdate.current = false
			return
		}
	}, [])

	// function handleOutsideClick(event) {
	//   if (!datepickerRef.current.contains(event.target)) {
	//     isVisible ? setIsVisible(false) : undefined;
	//     resetStates();
	//   }
	// }

	function handleKeyDown(event) {
		if (event.keyCode === keyCodes.backspace) {
			setFormattedDate()
		}
		if (event.keyCode === keyCodes.enter) {
			setMainDate(moment(new Date(event.target.value), dateFormat))
			setIsVisible(prevState => !prevState)
		}
	}

	return (
		<div
			className="datepicker"
			ref={datepickerRef}
			style={{ width: props.width }}
		>
			<TextField
				key={Math.random()}
				placeholder={props.placeholder}
				value={formattedDate}
				// onClick={() => setIsVisible(true)}
				onKeyDown={e => handleKeyDown(e)}
				onBlur={e => {
					e.target.value
						? setMainDate(
								e,
								moment(new Date(e.target.value), dateFormat)
						  )
						: undefined
				}}
				error={props.error}
				errorMessage={props.errorMessage}
				warning={warning}
				warningMessage={warningMessage}
				postdecorator={{
					icon: IconNameMap['calendar'],
					action: () => setIsVisible(prevState => !prevState)
				}}
				disabled={true}
			/>
			<div className={isVisible ? 'show' : 'hide'}>
				<Calendar
					isValidDate={isValidDate}
					setDate={updateDate}
					minDate={props.minDate}
					maxDate={props.maxDate}
					value={plainDate || props.defaultDate}
					width={props.width}
					yearStart={props.yearStart}
					yearEnd={props.yearEnd}
					onChange={() => setIsVisible(false)}
				></Calendar>
			</div>
		</div>
	)
}

Datepicker.propTypes = propTypes
Datepicker.defaultProps = defaultProps

export default Datepicker
