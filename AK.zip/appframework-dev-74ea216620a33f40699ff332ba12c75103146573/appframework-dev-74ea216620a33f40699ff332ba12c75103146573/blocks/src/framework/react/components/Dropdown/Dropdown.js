//Refer the following React-Select component
//https://react-select.com/home

import React, { useState, useEffect, useRef } from 'react'
import './Dropdown.scss'
import PropTypes from 'prop-types'
import classNames from 'classnames'
import { Icon, IconNameMap } from './../Icon'
import { TextField } from './../InputField'
import Label from './../Label'
import { keyCodes } from './../utils'

const propTypes = {
	htmlId: PropTypes.string,
	labelText: PropTypes.string,
	listType: PropTypes.oneOf(['default']).isRequired,
	options: PropTypes.arrayOf(
		PropTypes.shape({
			optionValue: PropTypes.any.isRequired,
			displayText: PropTypes.string.isRequired,
			descriptionText: PropTypes.string,
			selected: PropTypes.bool
		})
	),
	showSelectedMark: PropTypes.bool,
	showDescription: PropTypes.bool,
	showGroups: PropTypes.bool,
	onChange: PropTypes.func,
	border: PropTypes.bool,
	value: PropTypes.string,
	placeholder: PropTypes.string,
	hexCode1: PropTypes.string,
	hexCode2: PropTypes.string
}

const defaultProps = {
	htmlId: 'id-' + Math.random(),
	textFieldKey: 'dropdown',
	labelText: '',
	listType: 'default',
	showSelectedMark: false,
	showDescription: false,
	showGroups: false,
	onChange: () => {},
	border: true,
	placeholder: 'Select one...',
	hexCode1: '',
	hexCode2: ''
}

const Dropdown = props => {
	if (!props.options) return null

	const [isHidden, setIsHidden] = useState(true)
	// const [ selectedValues, setSelectedValues ] = useState(props.options.filter(o => o.selected))
	const [localOptions, setLocalOptions] = useState(props.options)
	const [selectedDisplayText, setSelectedDisplayText] = useState(
		props.options
			.filter(o => o.selected)
			.map(o => o.displayText)
			.join(' ')
	)

	let fontColor = {
		color: props.hexCode1
	}

	const [startingItem, setStartingItem] = useState(0)
	// const [width, setWidth] = useState();
	const listRef = useRef()
	const itemRef = useRef()
	const firstUpdate = useRef(true)

	// Need to remove, added for time being
	const dataId = props['data-id']

	useEffect(() => {
		if (!isHidden) {
			listRef.current.focus()
			document.addEventListener('click', handleOutsideClick, false)
		}

		return () => {
			document.removeEventListener('click', handleOutsideClick, false)
		}
	}, [isHidden])

	useEffect(() => {
		if (!firstUpdate.current && startingItem > -1) {
			singleSelect(startingItem)
			props.onChange(null, {
				'data-id': dataId,
				value: localOptions[startingItem]
			})
		}
	}, [startingItem])

	useEffect(() => {
		let index = props.options.findIndex(o => o.selected) || 0
		setStartingItem(index)
		firstUpdate.current = false

		let option = localOptions.filter(o => o.selected)
		if (option.length) {
			setSelectedDisplayText(option[0].displayText)
		}
	})

	function handleOutsideClick(event) {
		if (!isHidden && !listRef.current.contains(event.target)) {
			setIsHidden(true)
		}
	}

	function handleDisplayList(event) {
		switch (event.keyCode) {
			case keyCodes.enter:
			case keyCodes.up:
			case keyCodes.down:
				toggleListDisplay()
				break
		}
	}

	function toggleListDisplay() {
		setIsHidden(prevState => !prevState)
	}

	function singleSelect(i) {
		if (props.options.length > 0 && i > -1) {
			let setToFalse = props.options.map(item => {
				item.selected = false
				return item
			})
			setToFalse[i].selected = true

			// setStartingItem(i);
			setLocalOptions(setToFalse)
		}
	}

	function checkKeyPress(event) {
		switch (event.keyCode) {
			case keyCodes.up:
				setStartingItem(prevState => Math.max(prevState - 1, 0))
				break
			case keyCodes.down:
				setStartingItem(prevState =>
					prevState + 1 < props.options.length
						? prevState + 1
						: prevState
				)
				break
			case keyCodes.enter:
				toggleListDisplay()
		}
	}

	return (
		<div className="dropdown-component">
			{props.labelText && (
				<Label
					classes="dd-label"
					htmlFor={props.htmlId}
					label={props.labelText}
					required={false}
					onClick={() => toggleListDisplay()}
				></Label>
			)}
			<TextField
				id={props.htmlId}
				key={props.textFieldKey + '-' + Math.random()}
				placeholder={props.placeholder}
				value={selectedDisplayText}
				onFocus={props.onFocus}
				onBlur={props.onBlur}
				onClick={() => toggleListDisplay()}
				onKeyDown={event => handleDisplayList(event)}
				inputclass="hidden-text dropdown-base"
				postdecorator={{
					icon: IconNameMap['angle-down'],
					action: () => toggleListDisplay()
				}}
				style={{ border: props.border ? undefined : 'none' }}
			></TextField>
			<div
				className={classNames('listDisplay__results', {
					hidden: isHidden
				})}
				onKeyDown={event => checkKeyPress(event)}
				ref={listRef}
				role="listbox"
				tabIndex={-1}
			>
				{localOptions
					.sort((a, b) =>
						a.group > b.group ? 1 : b.group > a.group ? -1 : 0
					)
					.map((option, index) => {
						let id = index

						//Inform parent about default selection
						// if (option.selected) {
						//   props.onChange(null, {
						//     "data-id": dataId,
						//     value: option,
						//   });
						// }

						return (
							<div key={option.optionValue + '-' + id++}>
								{props.showGroups && <h3>{option.group}</h3>}
								<div
									id={'option-' + id++}
									key={
										props.textFieldKey + '-' + Math.random()
									}
									className={classNames(
										'listDisplay__result',
										{
											selected: option.selected
										}
									)}
									onClick={e => {
										singleSelect(index)
										toggleListDisplay()
									}}
									onKeyPress={event => {
										checkKeyPress(event)
									}}
									tabIndex={0}
									role="option"
									ref={itemRef}
									value={option.optionValue}
									// aria-activedescendant={() => option.selected ? singleSelect(index) : undefined}
								>
									{props.showSelectedMark &&
										option.selected && (
											<Icon
												iconClass={IconNameMap.check}
											></Icon>
										)}
									<div
										className="listDisplay__item"
										style={fontColor}
									>
										{option.displayText}
									</div>
									{props.showDescription && (
										<div className="listDisplay__description">
											{option.descriptionText}
										</div>
									)}
								</div>
							</div>
						)
					})}
			</div>
		</div>
	)
}

Dropdown.propTypes = propTypes
Dropdown.defaultProps = defaultProps

export default Dropdown
