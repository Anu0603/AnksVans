import React from 'react'
import CheckBox from '../CheckBox'

describe('CheckBox Component', () => {

    let container = null

    beforeEach(() => {
        container = null
    })

    it('Check if CheckBox component is rendered', () => {
        act(() => {
            container = mount(<CheckBox checked={true} label="test" />);
        })
        expect(container.find('button')).toHaveLength(1)
        expect(container.find('label')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    });

    it('Check if CheckBox is checked and checked icon is rendered', () => {
        act(() => {
            container = mount(<CheckBox checked={true} />);
        })
        expect(container.prop('checked')).toBe(true);
        expect(container.find('.checkbox-checked')).toHaveLength(1);
        expect(container.find('.tick-yes')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    });

    it('Check if Icon is rendered and check if reversed prop is true', () => {
        act(() => {
            container = mount(<CheckBox checked={true} reversed={true} />);
        })
        expect(container.find('.checkbox-reversed')).toHaveLength(1);
        expect(container.find('i')).toHaveLength(1);
    });

    it('Simulating CheckBox component to be false', () => {
        act(() => {
            container = mount(<CheckBox checked={true} />);
        })
        container.find('button').simulate('change', { target: { value: false } });
        expect(container.prop('value')).not.toBe(true);
    });

    it('Check for highLightColor when CheckBox is checked', () => {
        let props = { checked: true, hexCode2: '#8CE172' }
        act(() => {
            container = mount(<CheckBox {...props} />);
        })
        const input = container.find('button');
        expect(input.prop('style')).toHaveProperty('backgroundColor', '#8CE172');
    });

    it('Check if onClick prop is called', () => {
        const onClickMock = jest.fn();
        act(() => {
            container = mount(<CheckBox onChange={onClickMock} />);
        })
        container.find('button').simulate('click');
        expect(onClickMock.mock.calls.length).toBe(1);
    });
});