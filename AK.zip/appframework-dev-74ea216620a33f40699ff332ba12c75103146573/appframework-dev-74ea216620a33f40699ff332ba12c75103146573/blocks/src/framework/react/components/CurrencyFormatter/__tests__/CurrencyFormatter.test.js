import React from 'react'
import CurrencyFormatter from '../CurrencyFormatter'

describe('CurrencyFormatter Component', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check if CurrencyFormatter component is rendered', () => {
		let props = { quantity: 100, negative: false }
		act(() => {
			container = mount(<CurrencyFormatter {...props} />)
		})
		expect(container.find('.currency')).toHaveLength(1)
		expect(container).toMatchSnapshot()
	})

	it('Check if CurrencyFormatter curreny type is changed', () => {
		let props = { quantity: 100, negative: false, currency: 'INR' }
		let _text = '₹100.00'
		act(() => {
			container = mount(<CurrencyFormatter {...props} />)
		})
		expect(container.find('.currency div')).toHaveLength(1)
		expect(container.find('.currency div').text()).toEqual(_text)
		expect(container).toMatchSnapshot()
	})

	it('Check for negative currency values', () => {
		let props = { quantity: 100, negative: true, currency: 'INR' }
		let _text = '-₹100.00'
		act(() => {
			container = mount(<CurrencyFormatter {...props} />)
		})
		expect(container.find('.currency div').text()).toEqual(_text)
		expect(container).toMatchSnapshot()
	})

	it('Check if currency is invalid and amount is NaN', () => {
		const originalError = console.error
		console.error = jest.fn()
		let props = { quantity: 'abc', negative: false, currency: 'INRR' }
		let _text = ' INRR'
		act(() => {
			container = mount(<CurrencyFormatter {...props} />)
		})
		expect(container.find('.currency div').text()).toEqual(_text)
		expect(container).toMatchSnapshot()
		console.error = originalError
	})

	// check for negative values
})
