export const keyCodes = {
	esc: 27,
	space: 32,
	enter: 13,
	backspace: 8,
	tab: 9,
	up: 38,
	down: 40,
	home: 36,
	end: 35,
	n: 78,
	p: 80,
}
