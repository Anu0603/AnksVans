import React, { useState } from "react";
import classNames from "classnames";
import PropTypes from "prop-types";
import "./checkbox.scss";
import { Icon } from "./../Icon";

const propTypes = {
  /**
   * Specifies Custom CSS classes to be applied on top of component CSS
   */
  classes: PropTypes.string,

  /**
   * Specifies as true if checkbox needs to be checked
   * @default (false)
   */
  checked: PropTypes.bool,

  /**
   * Specifies as true if dark contrast is needed
   * @default (false)
   */
  reversed: PropTypes.bool,

  /**
   * Specifies if checkbox is disabled
   * @default (false)
   */
  disabled: PropTypes.bool,

  /**
   * Specifies onChange Handler, with paramterized checked as true or false
   */
  onChange: PropTypes.func,
  /**
   * Specifies the hexCode1 of the radio button
   */
  hexCode1: PropTypes.string,
  /**
   * Specifies the hexCode2 of the radio button
   */
  hexCode2: PropTypes.string
};

const defaultProps = {
  disabled: false,
  reversed: false
};

const checkboxClassprefix = "checkbox";

const CheckBox = props => {
  const [checked, setChecked] = useState(props.checked ? props.checked : false);

  let { label, reversed, classes, disabled, onChange, ...attributes } = props;

  const classList = classNames(
    classes,
    `${checkboxClassprefix}-base`,
    checked && `${checkboxClassprefix}-checked`,
    reversed && `${checkboxClassprefix}-reversed`
  );

  let highLightColor = null;
  if (props.hexCode2 && checked) {
    highLightColor = { backgroundColor: props.hexCode2 };
  }

  return (
    <React.Fragment>
      <button
        onClick={() => {
          setChecked(!checked);
          onChange(!checked);
        }}
        type="button"
        disabled={disabled}
        style={highLightColor}
        className={classList}
      >
        {checked ? <i className="fa fa-check tick-yes"></i> : null}
      </button>
      {props.label ? (
        <label className="checkbox-label">{props.label}</label>
      ) : null}
    </React.Fragment>
  );
};

CheckBox.propTypes = propTypes;
CheckBox.defaultProps = defaultProps;

export default CheckBox;
