import React from "react";

import Dropdown from "./../Dropdown";

describe("<Dropdown> Component", () => {
  let container = null;
  let testOptions = [
    {
      group: "Test Group 1",
      optionValue: 0,
      displayText: "Test One",
      descriptionText: "Test Description",
    },
    {
      group: "Test Group 2",
      optionValue: 1,
      displayText: "Test Two",
      descriptionText: "Test Description",
    },
    {
      group: "Test Group 3",
      optionValue: 2,
      displayText: "Test Three",
      descriptionText: "Test Description",
    },
  ];

  beforeEach(() => {
    container = null;
  });

  it("Does not render without options", () => {
    act(() => {
      container = shallow(<Dropdown />);
    });
    expect(container.find(".dropdown-component")).toHaveLength(0);
    // expect(container).toMatchSnapshot()
  });

  it("Renders with options", () => {
    act(() => {
      container = mount(<Dropdown options={testOptions} />);
    });

    expect(container.prop("options")).toBeTruthy();
    expect(container.find(".dropdown-component")).toHaveLength(1);
    // expect(container).toMatchSnapshot()
  });

  it("Renders with menu options not visible", () => {
    act(() => {
      container = mount(<Dropdown options={testOptions} />);
    });

    expect(container.find(".listDisplay__results").hasClass("hidden")).toBe(
      true
    );
  });

  it("Shows menu options when clicked", () => {
    act(() => {
      container = mount(<Dropdown options={testOptions} />);
    });
    container.find(".dropdown-base").simulate("click");
    expect(container.find(".listDisplay__results").hasClass("hidden")).toBe(
      false
    );
  });

  it("Returns correct value on change", () => {
    act(() => {
      container = mount(<Dropdown options={testOptions} />);
    });
    const input = container.find("input");
    input.simulate("change", { target: { value: "Test Two" } });

    // expect(container.find("input").props().defaultValue).toEqual("Test Two");
  });

  it("Check if groupHeading is rendered when showGroups is true", () => {
    let props = { showGroups: true, options: testOptions };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    expect(
      container
        .find("h3")
        .at(0)
        .text()
    ).toEqual("Test Group 1");
  });

  it("Check if labelText is rendered", () => {
    let props = {
      labelText: "test_label",
      htmlId: "test-dropdown",
      options: testOptions,
    };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    expect(container.find("Label").props().label).toEqual("test_label");
  });

  it("Check if List Description is rendered", () => {
    let props = {
      labelText: "test_label",
      htmlId: "test-dropdown",
      showDescription: true,
      options: testOptions,
    };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    expect(container.find(".listDisplay__description").at(0)).toHaveLength(1);
  });

  it("Check if DropDown Label onClick prop is called", () => {
    const onClickMock = jest.fn();
    let props = {
      labelText: "test_label",
      htmlId: "test-dropdown",
      options: testOptions,
    };
    act(() => {
      container = mount(
        <Dropdown {...props} toggleListDisplay={onClickMock} />
      );
    });
    container
      .find(".listDisplay__result")
      .at(0)
      .simulate("click");
  });

  it("Check if label onKeyPress prop is called", () => {
    let props = {
      labelText: "test_label",
      htmlId: "test-dropdown",
      options: testOptions,
    };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    container
      .find(".listDisplay__result")
      .at(0)
      .simulate("keypress", { keyCode: 38 });
    container
      .find(".listDisplay__result")
      .at(0)
      .simulate("keypress", { keyCode: 13 });
  });

  it("Check if Div onKeyDown prop is called", () => {
    let props = {
      labelText: "test_label",
      htmlId: "test-dropdown",
      options: testOptions,
    };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    container
      .find(".listDisplay__result")
      .at(0)
      .simulate("keyDown", { keyCode: 40 });
  });

  it("Check if Input onKeyDown prop for ENTER, UP & DOWN key is triggered", () => {
    let props = {
      labelText: "test_label",
      htmlId: "test-dropdown",
      options: testOptions,
    };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    container.find("input").simulate("keyDown", { keyCode: 40 });
    container.find("input").simulate("keyDown", { keyCode: 13 });
    container.find("input").simulate("keyDown", { keyCode: 38 });
  });

  it("Check if TextField onClick prop is called", () => {
    let props = {
      labelText: "test_label",
      placeholder: "test_placeholder",
      htmlId: "test-dropdown",
      showSelectedMark: true,
      options: testOptions,
    };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    container.find("input").simulate("click");
  });

  it("Check if TextField onBlur prop is called", () => {
    let props = {
      labelText: "test_label",
      htmlId: "test-dropdown",
      showSelectedMark: true,
      options: testOptions,
    };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    container.find("input").simulate("blur");
  });

  it("Check if TextField Postdecorator is rendered", () => {
    global.Math.random = () => 0.5;
    let props = {
      labelText: "test_label",
      htmlId: "test-dropdown",
      options: testOptions,
      postdecorator: { icon: "fa-times", action: () => {} },
    };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    debugger;
    expect(container.find(".post-decorator")).toHaveLength(1);
    expect(container.find(".fa-angle-down")).toHaveLength(1);
    expect(container).toMatchSnapshot();
    //snapshot
  });

  it("Check if PostDecorator onClick prop is called", () => {
    let props = {
      labelText: "test_label",
      htmlId: "test-dropdown",
      options: testOptions,
      postdecorator: { icon: "fa-times", action: () => {} },
    };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    container.find(".post-decorator a").simulate("click");
  });

  it("Check if label onClick prop is called", () => {
    let props = {
      labelText: "test_label",
      htmlId: "test-dropdown",
      options: testOptions,
    };
    act(() => {
      container = mount(<Dropdown {...props} />);
    });
    container.find("Label").simulate("click");
  });
});
