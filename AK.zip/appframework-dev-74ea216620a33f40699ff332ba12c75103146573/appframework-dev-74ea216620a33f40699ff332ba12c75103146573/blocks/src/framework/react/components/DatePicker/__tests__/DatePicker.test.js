import React from "react";

import DatePicker from "./../DatePicker";
import { Calendar } from "./../../Calendar";
import Dropdown from "./../../Dropdown";
import { TextField } from "./../../InputField";
import moment from "moment";

describe("<DatePicker> Component", () => {
  let container = null;

  beforeEach(() => {
    container = null;
  });

  it('Check if DatePicker component is rendered', () => {
    act(() => {
      container = mount(<DatePicker />);
    })
    expect(container.find('.datepicker')).toHaveLength(1)
    // expect(container).toMatchSnapshot()
  });

  it("Renders component and has default date set for Calendar", () => {
    act(() => {
      container = mount(<DatePicker />);
    });

    container.update();

    let currentMonth = moment().format("MMMM");
    let monthOptions = container
      .find(Calendar)
      .find(Dropdown)
      .at(0)
      .prop("options");
    let visibleMonth = monthOptions.filter(o => o.selected);

    expect(container.find(Calendar)).toHaveLength(1);
    expect(visibleMonth[0].displayText).toBe(currentMonth);
  });

  it("Has correct month set for Calendar when default date is passed", () => {
    act(() => {
      container = mount(<DatePicker defaultDate="8-20-2015" />);
    });

    container.update();

    let monthOptions = container
      .find(Calendar)
      .find(Dropdown)
      .at(0)
      .prop("options");
    let visibleMonth = monthOptions.filter(o => o.selected);

    expect(visibleMonth[0].displayText).toBe("August");
  });

  it('Check if Input is rendered', () => {
    act(() => {
      container = mount(<DatePicker />);
    })
    expect(container.find('input').at(0)).toHaveLength(1)
  });

  it('Check if Input onKeyDown prop for DOWN, BACKSPACE & ENTER is called', () => {
    act(() => {
      container = mount(<DatePicker />);
    })
    container.find('input').at(0).simulate('keyDown', { keyCode: 40 })
    container.find('input').at(0).simulate('keyDown', { keyCode: 8 })
    container.find('input').at(0).simulate('keyDown', { keyCode: 13 })
  });


  it('Check if Input onClick prop is called', () => {
    act(() => {
      container = mount(<DatePicker defaultDate="8-20-2015" />)
    })
    container.find('input').at(0).simulate('click')
  });

  it('Check if Input onBlur prop is called', () => {
    act(() => {
      container = mount(<DatePicker defaultDate="8-20-2015" />)
    })
    container.find('input').at(0).simulate('blur')
  });

  it('Check if Input onBlur prop is undefined', () => {
    act(() => {
      container = mount(<DatePicker />)
    })
    container.find('input').at(0).simulate('blur')
  });

  it('Check if Input Postdecorator is rendered', () => {
    act(() => {
      container = mount(<DatePicker defaultDate="8-20-2015" />)
    })
    expect(container.find('.post-decorator').at(0)).toHaveLength(1)
    expect(container.find('.fa-angle-down').at(0)).toHaveLength(1)
    // expect(container).toMatchSnapshot()
    //snapshot
  });

  it('Check if PostDecorator onClick prop is called', () => {
    act(() => {
      container = mount(<DatePicker />)
    })
    container.find('.post-decorator a').at(0).simulate('click')
    container.find('.post-decorator a').at(1).simulate('click')
  });


  it('Check if date is inrange', () => {
    let props = { defaultDate: "8-20-2015", minDate: "1-01-1950", maxDate: "3-31-2020" }
    act(() => {
      container = mount(<DatePicker {...props} />)
    })
    container.update();
    let monthOptions = container.find(Calendar).find(Dropdown).at(0).prop("options");
    let visibleMonth = monthOptions.filter(o => o.selected);
    expect(visibleMonth[0].displayText).toBe("August");
  });

  it('Check if date is less than minRange', () => {
    let props = { defaultDate: "8-20-1949", minDate: "1-01-1950" }
    act(() => {
      container = mount(<DatePicker {...props} />)
    })
    container.update();
    let monthOptions = container.find(Calendar).find(Dropdown).at(0).prop("options");
    let visibleMonth = monthOptions.filter(o => o.selected);
    expect(visibleMonth[0].displayText).toBe("August");
  });

  it('Check if date is more than minRange', () => {
    let props = { defaultDate: "8-20-2021", minDate: "", maxDate: "3-31-2020" }
    act(() => {
      container = mount(<DatePicker {...props} />)
    })
    container.update();
    let monthOptions = container.find(Calendar).find(Dropdown).at(0).prop("options");
    let visibleMonth = monthOptions.filter(o => o.selected);
    expect(visibleMonth[0].displayText).toBe("August");
  });

  it('Check if date is invalid', () => {
    let props = { defaultDate: "18-20-2021", minDate: "", maxDate: "20-20-2020" }
    act(() => {
      container = mount(<DatePicker {...props} />)
    })
  });

});
