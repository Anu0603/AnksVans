import React, { Component } from 'react';
import classNames from 'classnames';
import PropTypes from 'prop-types';

import './Toggle.scss';
/*
Toggle Switch Component
Note: id is required for ToggleSwitch component to function. Name, currentValue, defaultChecked, Small and onChange're optional.
Usage: <ToggleSwitch id="id" onChange={function (e) { console.log("Checkbox Current State: " + e.target.checked); }} />
*/

class ToggleSwitch extends Component {
  state = {
    checked: this.props.checked
    // switchIcon: this.props.checked ? "fa-check" : "fa-times"
  };
  onChange = e => {
    this.setState({
      checked: e.target.checked,
      switchIcon: e.target.checked ? 'fa-check ' : 'fa-times'
    });

    if (typeof this.props.onChange === 'function') {
      this.props.onChange(e);
    }
  };

  render() {
    let switchClassName = classNames(
      'fa',
      this.props.checked ? 'fa-check' : 'fa-times'
    );

    let labelClassName = classNames(
      'toggle-switch-label-text',
      this.props.disabled ? 'toggle-switch-disabled' : null
    );

    return (
      <div className='toggle-switch-cnr'>
        {this.props.label ? (
          <label
            htmlFor={this.props.id}
            aria-hidden={true}
            className={labelClassName}
          >
            {this.props.label}
          </label>
        ) : null}
        <div className='toggle-switch'>
          <input
            type='checkbox'
            name={this.props.Name}
            className='toggle-switch-checkbox'
            id={this.props.id}
            checked={this.props.checked}
            // defaultChecked={this.props.defaultChecked}
            onChange={this.onChange}
            disabled={this.props.disabled}
          />
          {this.props.id ? (
            <label className='toggle-switch-label' htmlFor={this.props.id}>
              <span
                className={
                  this.props.disabled
                    ? 'toggle-switch-handle toggle-switch-disabled'
                    : 'toggle-switch-handle'
                }
              >
                <span className={switchClassName}></span>
              </span>
              <span
                className={
                  this.props.disabled
                    ? 'toggle-switch-inner toggle-switch-disabled'
                    : 'toggle-switch-inner'
                }
              />
            </label>
          ) : null}
        </div>
      </div>
    );
  }
}

ToggleSwitch.propTypes = {
  id: PropTypes.string.isRequired,
  Name: PropTypes.string,
  onChange: PropTypes.func,
  checked: PropTypes.bool,
  //   defaultChecked: PropTypes.bool,
  currentValue: PropTypes.bool,
  disabled: PropTypes.bool
};

export default ToggleSwitch;
