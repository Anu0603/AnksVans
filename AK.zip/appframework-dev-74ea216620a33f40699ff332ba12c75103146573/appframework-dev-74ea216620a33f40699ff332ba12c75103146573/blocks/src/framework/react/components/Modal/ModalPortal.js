import React from 'react'
import { Icon } from '../Icon'
import './Modal.scss'
import classNames from 'classnames'

const ModalPortal = props => {
	let CrossIcon = null
	let _classNames = classNames('backDrop', {
		greyBackDrop: props.backDropEnabled
	})

	if (props.crossIconEnabled) {
		CrossIcon = (
			<div className="modal-header">
				<div className="title"></div>
				<div
					id={'header-close-btn-container'}
					onClick={props.onCrossIconClick}
				>
					<div className="modalCrossIcon">
						<Icon
							iconClass="fa-times"
							type="fal"
							style={{ color: '#B8B8B8' }}
						/>
					</div>
				</div>
			</div>
		)
	}

	let modalClassName =
		'modal ' + (props.className != undefined ? props.className : '')

	return (
		<div className="modal-inner-container">
			<div className={_classNames} onClick={props.onBackDropClick}></div>
			<div className={modalClassName}>
				{CrossIcon}
				<div className="modal-content">{props.children}</div>
			</div>
		</div>
	)
}

export default ModalPortal
