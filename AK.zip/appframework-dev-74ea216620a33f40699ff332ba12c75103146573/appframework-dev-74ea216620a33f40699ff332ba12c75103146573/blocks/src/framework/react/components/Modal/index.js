import Modal from './Modal'
import PfileModal from './PfileModal'

export {
    Modal,
    PfileModal
}