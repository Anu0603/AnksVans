import React from 'react'
import Spinner from '../Spinner'

describe('Spinner Component', () => {

    let container = null

    beforeEach(() => {
        container = null
    })

    it('Check if Spinner component is rendered', () => {
        act(() => {
            container = mount(<Spinner />);
        })
        expect(container.find('.spinner-wrapper')).toHaveLength(1)
        expect(container).toMatchSnapshot()
        //take the snapshot
    });

    it('Check if Spinner child component is rendered', () => {
        act(() => {
            container = mount(<Spinner />);
        })
        expect(container.find('.spinner')).toHaveLength(1)
    });

    it('Check if size, color and circleColor of spinner are updated', () => {
        let props = { size: "lg", color: "#4195E1", circleColor: "#CCCCCC" }
        act(() => {
            container = mount(<Spinner {...props} />);
        })
        expect(container.prop('size')).toBe("lg");
        expect(container.prop('color')).toBe("#4195E1");
        expect(container.prop('circleColor')).toBe("#CCCCCC");
        expect(container).toMatchSnapshot()
    });



    // props - sm -- check whether small class is there
    //         md 
    //         lg
    //         snapshot

    // pass - color 
    //         access the dom - style
    //             check whether color is matching
    //         snapshot


});