import React from 'react'
import ToggleSwitch from '../Toggle'

describe('ToggleSwitch Component', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check if ToggleSwitch component is rendered', () => {
		act(() => {
			container = mount(<ToggleSwitch id="abc" />)
		})
		expect(container.find('.toggle-switch-cnr')).toHaveLength(1)
		expect(container).toMatchSnapshot()
	})

	it('Check if ToggleSwitch label renders text and Check for null id', () => {
		act(() => {
			container = mount(<ToggleSwitch label="test" id="" />)
		})
		expect(container.find('.toggle-switch-label-text')).toHaveLength(1)
		expect(container.find('.toggle-switch-label-text').text()).toEqual(
			'test'
		)
		expect(container).toMatchSnapshot()
	})

	it('Check if onChange prop is called', () => {
		const onChangeMock = jest.fn()
		const event = {
			preventDefault() {},
			target: { value: 'test', checked: true }
		}
		act(() => {
			container = mount(<ToggleSwitch id="abc" onChange={onChangeMock} />)
		})
		container.find('input').simulate('change', event)
		expect(onChangeMock.mock.calls.length).toBe(1)
	})

	it('Simulating ToggleSwitch component to be false', () => {
		act(() => {
			container = mount(<ToggleSwitch id="abc" />)
		})
		container.find('input').simulate('change', { target: { value: false } })
		const input = container.find('input')
		expect(input.prop('value')).not.toBe(true)
	})

	it('Check if inner label is rendered when id is passed', () => {
		let props = { id: 'abc', checked: true }
		act(() => {
			container = mount(<ToggleSwitch {...props} />)
		})
		expect(container.find('.toggle-switch-label')).toHaveLength(1)
	})

	it('Check if check icon is rendered when defaultcheck and checked is true', () => {
		let props = { id: 'abc', checked: true, defaultChecked: true }
		act(() => {
			container = mount(<ToggleSwitch {...props} />)
		})
		expect(
			container.find(
				'.toggle-switch-label .toggle-switch-handle .fa-check'
			)
		).toHaveLength(1)
	})

	it('Check for Toggle disabled prop', () => {
		let props = { id: 'abc', disabled: true }
		act(() => {
			container = mount(<ToggleSwitch {...props} />)
		})
		expect(container.find('.toggle-switch-disabled')).toHaveLength(2)
	})
})
