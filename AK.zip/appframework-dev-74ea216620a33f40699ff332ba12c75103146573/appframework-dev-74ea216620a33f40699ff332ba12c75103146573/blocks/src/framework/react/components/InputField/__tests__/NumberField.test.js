import React from 'react'
import NumberField from '../NumberField'

describe('<NumberField> Component', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check if NumberField component is rendered', () => {
		act(() => {
			container = mount(<NumberField value={'100'} />)
		})
		expect(container.find('.tfield-container')).toHaveLength(1)
		expect(container).toMatchSnapshot()
		//snapshot
	})

	it('Check if NumberField placeholder is rendered', () => {
		act(() => {
			container = mount(<NumberField placeholder={'Enter Number'} />)
		})
		expect(container.prop('placeholder')).toBe('Enter Number')
	})

	it('Check if error Icon and error message is rendered', () => {
		let _errorMessage = 'Some error occurred'
		act(() => {
			container = mount(
				<NumberField error={true} errorMessage={_errorMessage} />
			)
		})
		expect(container.find('.message-cnr')).toHaveLength(1)
		expect(container.find('.message-cnr span').text()).toEqual(
			_errorMessage
		)
		expect(
			container.find('.error-decorator .fa-exclamation-circle')
		).toHaveLength(1)
		expect(container).toMatchSnapshot()
	})

	it('Check if warning message is rendered', () => {
		let _warningMessage = 'Some warning'
		act(() => {
			container = mount(
				<NumberField warning={true} warningMessage={_warningMessage} />
			)
		})
		expect(container.find('.message-cnr')).toHaveLength(1)
		expect(container.find('.message-cnr span').text()).toEqual(
			_warningMessage
		)
		expect(container).toMatchSnapshot()
	})

	it('NumberField component should display new value on the user input', () => {
		act(() => {
			container = mount(<NumberField value={'200'} />)
		})
		container.find('input').simulate('change', { target: { value: '200' } })
		const input = container.find('input')
		expect(input.prop('defaultValue')).toBe('200')
	})
})
