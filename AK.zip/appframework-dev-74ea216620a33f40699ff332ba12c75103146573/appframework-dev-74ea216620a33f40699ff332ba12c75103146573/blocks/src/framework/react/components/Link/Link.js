import React, { useState } from 'react'
import classNames from 'classnames'

import "./Link.scss";

const Link = (props) => {
    return (
        <a className={props.classes} onClick={props.onClick} onFocus={props.onFocus} onBlur={props.onBlur}>
            {props.lable}
        </a>
    )
}

export default Link;