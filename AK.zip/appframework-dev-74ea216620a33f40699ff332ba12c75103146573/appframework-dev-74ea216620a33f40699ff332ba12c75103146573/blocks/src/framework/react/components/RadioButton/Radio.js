import React, { ReactFragment } from 'react'
import classNames from 'classnames'
import PropTypes from 'prop-types'

import './Radio.scss'

const propTypes = {
	/**
	 * Specifies input element id
	 */
	id: PropTypes.string,
	/**
	 * Specifies the class of the container element
	 */
	containerClass: PropTypes.string,
	/**
	 * Specifies the value of the radio button
	 */
	value: PropTypes.string,
	/**
	 * Specifies the name of the group the radio button belongs
	 */
	name: PropTypes.string,
	/**
	 * Specifies the label of the radio button
	 */
	label: PropTypes.string,
	/**
	 * Specifies the label of the radio button
	 */
	secondaryLabel: PropTypes.string,
	/**
	 * Specifies the boolean value to disable/enable the radio button
	 */
	disabled: PropTypes.bool,
	/**
	 * Specifies the boolean value to check/uncheck by default the radio button
	 */
	checked: PropTypes.bool,
	/**
	 * Specifies the change event handler of the radio button
	 */
	onChange: PropTypes.func,
	/**
	 * Specifies the hexCode1 of the radio button
	 */
	hexCode1: PropTypes.string,
	/**
	 * Specifies the hexCode2 of the radio button
	 */
	hexCode2: PropTypes.string
}

const defaultProps = {
	id: '',
	containerClass: '',
	value: '',
	name: '',
	label: '',
	secondaryLabel: '',
	disabled: false,
	// checked: false,
	onChange: () => {}
}

const Radio = ({
	id,
	containerClass,
	value,
	name,
	label,
	secondaryLabel,
	disabled,
	checked,
	onChange,
	hexCode1,
	hexCode2,
	...props
}) => {
	let cnrClass = classNames(
		containerClass,
		disabled && 'disabled',
		'input-radio-cnr'
	)
	let highLightColor = null
	if (hexCode2 && checked) {
		highLightColor = { backgroundColor: hexCode2 }
	}
	React.useEffect(() => {
		setMyValues(checked)
	})
	const [myValues, setMyValues] = React.useState(props.checked)
	return (
		<React.Fragment>
			<div className={cnrClass}>
				<label htmlFor={id} className="input-radio">
					<input
						type="radio"
						id={id}
						name={name}
						value={value}
						onChange={e => onChange(e, value)}
						disabled={disabled}
						defaultChecked={myValues}
						{...props}
					/>
					<p className="input-radio-indicator-cnr">
						<span
							className="input-radio-indicator"
							style={highLightColor}
						></span>
					</p>
					{label ? (
						<p className="input-radio-label">{label}</p>
					) : null}
					{secondaryLabel ? (
						<p className="input-radio-secondary-label">
							{secondaryLabel}
						</p>
					) : null}
				</label>
			</div>
		</React.Fragment>
	)
}

Radio.propTypes = propTypes
Radio.defaultProps = defaultProps

export default Radio
