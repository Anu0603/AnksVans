import React, { useState, useEffect } from 'react'
import classNames from 'classnames'
import PropTypes from 'prop-types'

import { Icon } from '../Icon/'

import './TextField.scss'

const propTypes = {
	/**
	 * Specifies input element id
	 */
	id: PropTypes.string,
	/**
	 * Specifies input element's value
	 */
	value: PropTypes.string,
	/**
	 * Specifies input element's default value
	 */
	// defaultValue: PropTypes.string,
	/**
	 * Specifies placeholder string
	 */
	placeholder: PropTypes.string,
	/**
	 * Specifies label of the textfield
	 */
	label: PropTypes.string,
	/**
	 * Specifies custom class to be applied on the label
	 */
	labelClass: PropTypes.string,
	/**
	 * Specifies custom classes to be applied on the component's container
	 */
	containerClass: PropTypes.string,
	/**
	 * Specifies custom classes to be applied on the input
	 */
	inputclass: PropTypes.oneOfType([PropTypes.string, PropTypes.array]),
	/**
	 * Specifies boolean property to render large textfield
	 *  @default (false)
	 */
	large: PropTypes.bool,
	/**
	 * Specifies boolean property to disable/enable the textfield
	 * @default (false)
	 */
	disabled: PropTypes.bool,
	/**
	 * Specifies boolean property to allow the copy/paste in the textfield
	 * @default (true)
	 */
	allowCopyPaste: PropTypes.bool,
	/**
	 * Specifies boolean property yo show error on the textfield
	 * @default (false)
	 */
	error: PropTypes.bool,
	/**
	 * Specifies the error message to be displayed
	 */
	errorMessage: PropTypes.string,
	/**
	 * Specifies boolean property yo show warning on the textfield
	 * @default (false)
	 */
	warning: PropTypes.bool,
	/**
	 * Specifies warning message to be displayed
	 */
	warningMessage: PropTypes.string,
	/**
	 * Specifies warning message to be displayed
	 */
	onChange: PropTypes.func,
	/**
	 * Specifies the configuration object for the icons to be displayed on the left side of input-text field
	 * Predecorators does not support the action handler or and event binding.
	 * @type (
	 *           {
	 *               icon : '',
	 *           }
	 *       )
	 */
	predecorator: PropTypes.object,
	/**
	 * Specifies the configuration object for the icons to be displayed on the right side of input-text field
	 * @type (
	 *           {
	 *               icon : '',
	 *               action : ()=>{}
	 *           }
	 *       )
	 */
	postdecorator: PropTypes.object,
	/**
	 * Specifies boolean value to show the X to show the clear field.
	 */
	showClearField: PropTypes.bool
}

const defaultProps = {
	id: '',
	value: '',
	// defaultValue: '',
	placeholder: '',
	label: '',
	labelClass: '',
	containerClass: '',
	inputclass: '',
	large: false,
	disabled: false,
	allowCopyPaste: true,
	error: false,
	errorMessage: '',
	warning: false,
	warningMessage: '',
	onChange: () => {}
}

const TextField = ({
	label,
	labelClass,
	inputclass,
	containerClass,
	value,
	// defaultValue,
	type,
	large,
	showPassword,
	showClearField,
	error,
	errorMessage,
	warning,
	warningMessage,
	predecorator,
	postdecorator,
	onChange,
	...props
}) => {
	let _cnrClass = classNames(
		'tfield-container',
		containerClass,
		large && 'tlarge',
		error && 'error',
		!error && warning && 'warning'
	)

	let _inputClass = classNames(
		'tfield-input',
		typeof inputclass === 'string' ? inputclass : inputclass.join(' ')
	)

	let _labelClass = classNames('tfield-label', labelClass)

	let message
	if (error) {
		message = errorMessage
	} else if (warning) {
		message = warningMessage
	} else {
		message = ''
	}

	const updateTextField = e => {
		onChange(e)
	}

	const restrictPasswordCopyPaste = function(e) {
		e.preventDefault()
	}

	const { allowCopyPaste, ...restProps } = props
	let copyPasteProps = null
	if (!allowCopyPaste) {
		copyPasteProps = {
			onCut: restrictPasswordCopyPaste.bind(this),
			onCopy: restrictPasswordCopyPaste.bind(this),
			onPaste: restrictPasswordCopyPaste.bind(this)
		}
	}

	return (
		<div className={_cnrClass}>
			{label && <div className={_labelClass}>{label}</div>}
			<div className="input-field-cnr">
				{predecorator && predecorator.icon && (
					<span className="pre-decorator">
						<Icon iconClass={predecorator.icon} type="fal" />
					</span>
				)}
				{props.placeholder.length > 43 && (
					<div className="tfield-label white">
						{props.placeholder}
					</div>
				)}
				<input
					className={_inputClass}
					type={type ? type : 'text'}
					//  value={valueState.value ? valueState.value : value}
					defaultValue={value}
					onChange={updateTextField.bind(this)}
					{...restProps}
					{...copyPasteProps}
					autoComplete="off"
				/>
				{postdecorator && postdecorator.icon && (
					<span className="post-decorator">
						<a onClick={postdecorator.action} tabIndex={0} href="#">
							<Icon iconClass={postdecorator.icon} type="fal" />
						</a>
					</span>
				)}
				{error && (
					<span className="error-decorator">
						<Icon iconClass="fa-exclamation-circle" type="fas" />
					</span>
				)}
			</div>
			{message && (
				<p className="message-cnr">
					<span>{message}</span>
				</p>
			)}
		</div>
	)
}

TextField.propTypes = propTypes
TextField.defaultProps = defaultProps

export default TextField
