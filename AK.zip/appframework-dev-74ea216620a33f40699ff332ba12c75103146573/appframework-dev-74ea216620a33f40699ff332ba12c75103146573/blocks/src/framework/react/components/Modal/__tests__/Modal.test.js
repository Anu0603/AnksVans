import React from 'react'
import Modal from '../Modal'

describe('Modal Component', () => {
    let container = null

    const modalRoot = global.document.createElement('div');
    modalRoot.setAttribute('id', 'modal-root');
    const body = global.document.querySelector('body');
    body.appendChild(modalRoot);

    beforeEach(() => {
        container = null
    })

    afterEach(() => {
        container.unmount();
    });

    it('Check if Modal Component is rendered', () => {
        act(() => {
            container = mount(<Modal show={true} />);
        })
        expect(container.find('.modal-inner-container')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    });

    it('Check if modal content is rendered', () => {
        let props = { show: true, children: "<p>Test modal content</p>" }
        act(() => {
            container = mount(<Modal {...props} />);
        })
        expect(container.find('.modal-inner-container')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    });

    it('Check if modal close icon is rendered', () => {
        let props = { show: true, crossIconEnabled: true, className: "small" }
        act(() => {
            container = mount(<Modal {...props} />);
        })
        expect(container.find('#header-close-btn-container')).toHaveLength(1)
    });

    it('Check if modal onCrossIconClick is called', () => {
        let props = { show: true, crossIconEnabled: true, className: "small" }
        const onClickMock = jest.fn();
        act(() => {
            container = mount(<Modal {...props} onCrossIconClick={onClickMock} />);
        })
        container.find('#header-close-btn-container').simulate('click');
        expect(onClickMock.mock.calls.length).toBe(1);
    });

    it('Check if onClick prop is called', () => {
        const onClickMock = jest.fn();
        act(() => {
            container = mount(<Modal show={true} onBackDropClick={onClickMock} />);
        })
        container.find('.backDrop').simulate('click');
        expect(onClickMock.mock.calls.length).toBe(1);
    });

    it('Check if Modal Component is null', () => {
        act(() => {
            container = mount(<Modal />);
        })
        expect(container.find('.modal-inner-container')).not.toHaveLength(1)
    });
});