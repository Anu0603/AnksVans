import React from 'react'
import { configure, shallow, mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { act } from 'react-dom/test-utils'

configure({ adapter: new Adapter() });

import Icon from './../Icon'
import IconNameMap from './../IconNameMap'

describe('<Icon> Component', () => {

    let container = null

    beforeEach(() => {
        container = null
    })


    it('Icon class', () => {
        act(() => {
            container = shallow(<Icon iconClass={IconNameMap.close} />)
        })
        // expect(container.find('.myclass')).toHaveLength(1)
    })
})