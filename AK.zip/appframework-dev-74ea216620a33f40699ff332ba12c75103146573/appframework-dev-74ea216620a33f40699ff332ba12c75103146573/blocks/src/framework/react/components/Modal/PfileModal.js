import React, { useEffect, useState, Component } from "react";
import Modal from "./Modal";
import PfileService from "../../../../bricks/fastlink/services/resource/pfileService";

class PfileModal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      content: null,
      show: props.show
    };
  }

  componentDidMount() {
    PfileService.getPfileContent(
      {
        fileName: this.props.fileName
      },
      (_error, _response) => {
        if (_error) {
          console.log("Could not fetch PopulatSite Data");
        } else {
          this.setState({
            content: _response
          });
        }
      }
    );
  }

  render() {
    const { show, ...remainingProps } = this.props;
    return (
      <Modal show={this.state.show} {...remainingProps} className='medium'>
        <div
          className='pfile-modal'
          dangerouslySetInnerHTML={{ __html: this.state.content }}
        ></div>
      </Modal>
    );
  }
}

export default PfileModal;
