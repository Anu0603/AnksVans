export { default } from './Label'
