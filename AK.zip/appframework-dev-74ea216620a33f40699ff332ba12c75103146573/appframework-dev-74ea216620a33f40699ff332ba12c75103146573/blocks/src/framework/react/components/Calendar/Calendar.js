import React, { useState, useEffect, useRef } from 'react'
import PropTypes from 'prop-types'
import moment from 'moment'
import Dropdown from '../Dropdown'
import './Calendar.scss'
import { Icon, IconNameMap } from '../Icon'

const propTypes = {
	setDate: PropTypes.func,
	yearStart: PropTypes.number,
	yearEnd: PropTypes.number
}

const defaultProps = {
	yearStart: 10,
	yearEnd: 10,
	onChange: () => {}
}

const Calendar = props => {
	const calendarSlots = 35
	// const new Date(props.value) = props.new Date(props.value)
	//   ? new Date(props.new Date(props.value))
	//   : new Date();
	const init = moment()
	const defaultDate = props.value ? props.value : init

	/* Date/time variables */
	const [currentDateTime, setCurrentDateTime] = useState(
		moment(new Date(defaultDate))
	)
	const [currentMonth, setCurrentMonth] = useState(
		moment(new Date(defaultDate)).format('MMMM')
	)
	const [currentYear, setCurrentYear] = useState(
		moment(new Date(defaultDate)).format('YYYY')
	)

	/* Calendar variables */
	const [calendar, setCalendar] = useState()
	const firstDay = moment(new Date(currentMonth + ' 1, ' + currentYear))
		.startOf('month')
		.format('d')
	const lastDay = moment(
		new Date(currentMonth + ' 1, ' + currentYear)
	).daysInMonth()
	const lastDayOfLastMonth = moment(
		new Date(currentMonth + ' 1, ' + currentYear)
	)
		.subtract(1, 'month')
		.daysInMonth()
	const weekdaysShort = moment.weekdaysShort().map((d, i) => {
		return <th key={'calendar-th-' + i}>{d.substr(0, 1)}</th>
	})
	const months = moment.months()
	const years = () => {
		const yearArr = []
		const dateStart = moment().subtract(props.yearStart, 'y')
		const dateEnd = moment().add(props.yearEnd, 'y')

		while (dateEnd.diff(dateStart, 'years') >= 0) {
			yearArr.push(dateStart.format('YYYY'))
			dateStart.add(1, 'year')
		}

		return yearArr
	}

	const [monthOptions, setMonthOptions] = useState(
		months.map(month => {
			return {
				optionValue: month,
				displayText: month,
				selected: month === currentMonth ? true : false
			}
		})
	)
	const [yearsOptions, setYearOptions] = useState(
		years().map(year => {
			return {
				optionValue: year,
				displayText: year,
				selected: year === currentYear ? true : false
			}
		})
	)

	useEffect(() => {
		let year = moment(new Date(defaultDate)).format('YYYY')
		let yearList = years()
		let yearInRange =
			year >= yearList[0] && year <= yearList[yearList.length - 1]
				? true
				: false

		if (yearInRange) {
			setCurrentYear(moment(new Date(defaultDate)).format('YYYY'))
		}

		setCurrentMonth(moment(new Date(defaultDate)).format('MMMM'))
	}, [props.value])

	useEffect(() => {
		setCalendar(calculateCalendar())
	}, [currentDateTime])

	useEffect(() => {
		setMonthOptions(prevState => {
			return prevState.map(item => {
				item.displayText === currentMonth
					? (item.selected = true)
					: (item.selected = false)
				return item
			})
		})
		setCalendar(calculateCalendar())
	}, [currentMonth])

	useEffect(() => {
		setYearOptions(prevState => {
			return prevState.map(item => {
				item.displayText === currentYear
					? (item.selected = true)
					: (item.selected = false)
				return item
			})
		})
		setCalendar(calculateCalendar())
	}, [currentYear])

	function handleSetDate(date) {
		let formattedDate = moment(new Date(date))
		setCurrentDateTime(formattedDate)
		props.setDate ? props.setDate(formattedDate) : undefined
	}

	function calculateCalendar() {
		let blanksBefore = []
		for (var i = 0, c = lastDayOfLastMonth; i < firstDay; i++, c--) {
			blanksBefore.push(
				<td key={'calendar-td-last-month-' + c} className="blank"></td>
			)
		}
		blanksBefore.reverse()
		let daysInMonth = []
		for (var d = 1; d <= lastDay; d++) {
			daysInMonth.push(
				<td
					className="filled"
					key={'calendar-td-current-month-' + currentMonth + ' ' + d}
					onClick={e => {
						e.currentTarget.getAttribute('disabled') == false
							? undefined
							: [
									handleSetDate(
										currentMonth +
											' ' +
											e.currentTarget.innerHTML +
											', ' +
											currentYear
									),
									props.onChange()
							  ]
					}}
					value={moment(
						new Date(currentMonth + ' ' + currentYear + '-' + d)
					).format()}
				>
					{d}
				</td>
			)
		}
		let blanksAfter = []
		for (var m = calendarSlots, b = 1; m >= lastDay - 1; m--, b++) {
			blanksAfter.push(
				<td key={'calendar-td-next-month-' + b} className="blank"></td>
			)
		}
		let totalSlots = [...blanksBefore, ...daysInMonth, ...blanksAfter]
		let rows = []
		let cells = []
		totalSlots.forEach((row, i) => {
			if (i % 7 !== 0 && rows.length <= 6) {
				cells.push(row) // if index not equal 7 that means not go to next week
			} else if (rows.length <= 6) {
				rows.push(cells) // when reach next week we contain all td in last week to rows
				cells = [] // empty container
				cells.push(row) // in current loop we still push current row to new container
			}
			if (i === totalSlots.length - 1 && rows.length <= 6) {
				// when end loop we add remain date
				rows.push(cells)
			}
		})
		let newMappedRows = rows.map((d, i) => {
			return <tr key={'calendar-tr-' + i}>{d}</tr>
		})
		return newMappedRows
	}

	function previousMonth() {
		if (currentMonth === 'January') {
			setCurrentYear(
				moment(new Date('January 1, ' + currentYear))
					.subtract(1, 'year')
					.format('YYYY')
			)
		}

		setCurrentMonth(prevState =>
			moment(new Date(prevState + ' 1, ' + currentYear))
				.subtract(1, 'month')
				.format('MMMM')
		)
	}

	function nextMonth() {
		if (currentMonth === 'December') {
			setCurrentYear(
				moment(new Date('January 1, ' + currentYear))
					.add(1, 'year')
					.format('YYYY')
			)
		}

		setCurrentMonth(prevState =>
			moment(new Date(prevState + ' 1, ' + currentYear))
				.add(1, 'month')
				.format('MMMM')
		)
	}

	return (
		<div
			className="calendar"
			style={{ width: props.width }}
			onChange={props.onChange}
		>
			<div className="calendar_header">
				<button
					className="calendar_header_left_arrow"
					onClick={() => previousMonth()}
				>
					<Icon iconClass={IconNameMap['arrow-left']} />
				</button>
				<Dropdown
					options={monthOptions}
					border={false}
					htmlId="calendar-month"
					onChange={(e, data) => {
						if (data.value) {
							setCurrentMonth(
								moment(
									new Date(
										data.value.displayText +
											' 1, ' +
											currentYear
									)
								).format('MMMM')
							)
						}
					}}
				/>
				<Dropdown
					options={yearsOptions}
					border={false}
					htmlId="calendar-year"
					onChange={(e, data) => {
						if (data.value) {
							setCurrentYear(
								moment(
									new Date(
										currentMonth +
											' 1, ' +
											data.value.displayText
									)
								).format('YYYY')
							)
						}
					}}
				/>
				<button
					className="calendar_header_right_arrow"
					onClick={() => nextMonth()}
				>
					<Icon iconClass={IconNameMap['arrow-right']} />
				</button>
			</div>
			<table className="calendar_body">
				<thead className="calendar_body_week">
					<tr>{weekdaysShort}</tr>
				</thead>
				<tbody className="calendar_body_days">{calendar}</tbody>
			</table>
		</div>
	)
}

Calendar.propTypes = propTypes
Calendar.defaultProps = defaultProps

export default Calendar
