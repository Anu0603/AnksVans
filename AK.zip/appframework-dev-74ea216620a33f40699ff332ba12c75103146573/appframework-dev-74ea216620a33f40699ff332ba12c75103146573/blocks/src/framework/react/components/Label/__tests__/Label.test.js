import React from 'react'
import Label from '../Label'

describe('Label Component', () => {
    let container = null

    beforeEach(() => {
        container = null
    })

    it('Check if Label is rendered', () => {
        let props = { htmlFor: 'test_id', label: 'test_label' }
        act(() => {
            container = mount(<Label {...props} />);
        })
        expect(container.find('label')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    });

    it('Check for Required prop', () => {
        let props = { htmlFor: 'test_id', label: 'test_label', required: true }
        act(() => {
            container = mount(<Label {...props} />);
        })
        expect(container.find('label span')).toHaveLength(1)
        expect(container.find('label span').text()).toEqual(' *')
        expect(container).toMatchSnapshot()
    });
});