import Icon from './Icon'
import IconNameMap from './IconNameMap'

export { Icon, IconNameMap }

