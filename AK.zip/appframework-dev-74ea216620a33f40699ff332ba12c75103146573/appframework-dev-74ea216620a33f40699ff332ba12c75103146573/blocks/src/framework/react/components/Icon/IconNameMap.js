const IconNameMap = {
  "angle-down": "fa-angle-down",
  "arrow-left": "fa-arrow-left",
  "arrow-right": "fa-arrow-right",
  calendar: "fa-calendar-alt",
  "add-circle": "fa-plus-circle",
  "angle-down": "fa-angle-down",
  check: "fa-check",
  "chevron-left": "fa-chevron-left",
  close: "fa-times",
  "edit-icon": "fa-edit",
  "info-circle": "fa-info-circle"
};

export default IconNameMap;
