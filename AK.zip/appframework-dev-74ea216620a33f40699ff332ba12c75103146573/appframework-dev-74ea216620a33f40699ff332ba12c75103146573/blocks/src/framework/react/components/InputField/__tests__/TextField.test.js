import React from 'react'
import TextField from '../TextField'
import { getParam } from '../../../../../bricks/fastlink/conf'
jest.mock('../../../../../bricks/fastlink/conf')

describe('<Text> Component', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check if text component is rendered', () => {
		act(() => {
			container = shallow(<TextField value={'100'} />)
		})
		expect(container.find('.tfield-container')).toHaveLength(1)
		expect(container).toMatchSnapshot()
		//snapshot
	})

	it('Check if Predecorator is rendered', () => {
		let props = { predecorator: { icon: 'fa-times' } }
		act(() => {
			container = mount(<TextField {...props} />)
		})
		expect(container.find('.pre-decorator')).toHaveLength(1)
		expect(container.find('Icon')).toHaveLength(1)
		expect(container).toMatchSnapshot()
		//snapshot
	})

	it('Check if Postdecorator is rendered', () => {
		let classes = ['tfield', 'tlarge']
		let props = {
			inputclass: classes,
			postdecorator: { icon: 'fa-times', action: () => {} }
		}
		act(() => {
			container = mount(<TextField {...props} />)
		})
		expect(container.find('.post-decorator')).toHaveLength(1)
		expect(container.find('Icon')).toHaveLength(1)
		expect(container).toMatchSnapshot()
		//snapshot
	})

	it('Check if error Icon and error message is rendered', () => {
		let _errorMessage = 'Some error occurred'
		act(() => {
			container = mount(
				<TextField error={true} errorMessage={_errorMessage} />
			)
		})
		expect(container.find('.message-cnr')).toHaveLength(1)
		expect(container.find('.message-cnr span').text()).toEqual(
			_errorMessage
		)
		expect(
			container.find('.error-decorator .fa-exclamation-circle')
		).toHaveLength(1)
		expect(container).toMatchSnapshot()
		//check for the strin .text
		//snapshot
	})

	it('Check if warning message is rendered', () => {
		let _warningMessage = 'Some warning'
		act(() => {
			container = mount(
				<TextField warning={true} warningMessage={_warningMessage} />
			)
		})
		expect(container.find('.message-cnr')).toHaveLength(1)
		expect(container.find('.message-cnr span').text()).toEqual(
			_warningMessage
		)
		expect(container).toMatchSnapshot()
	})

	it('Text component should display new value on the user input', () => {
		act(() => {
			container = mount(<TextField value="200" />)
		})
		container.find('input').simulate('change', { target: { value: '200' } })
		const input = container.find('input')
		expect(input.prop('defaultValue')).toBe('200')
	})

	it('Check if Text component is large and label is rendered', () => {
		act(() => {
			container = mount(<TextField large={true} label="Test Label" />)
		})
		expect(container.find('.tlarge')).toHaveLength(1)
		expect(container.find('.tfield-label')).toHaveLength(1)
	})

	it('Check if placeholder is displayed as label if its length is above 43 characters', () => {
		act(() => {
			container = mount(
				<TextField
					large={true}
					placeholder="last 4 digits of your home phone number (optional)"
				/>
			)
		})
		expect(container.find('.tfield-label')).toHaveLength(1)
	})

	it('Check if Text component copy paste is restricted', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'login_allow_copy_paste') {
					return true
				}
			})
			container = mount(<TextField allowCopyPaste={false} />)
		})
	})
})
