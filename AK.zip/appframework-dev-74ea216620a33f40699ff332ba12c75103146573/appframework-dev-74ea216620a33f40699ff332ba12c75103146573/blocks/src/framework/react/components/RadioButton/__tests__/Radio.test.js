import React from 'react'
import Radio from '../Radio'

describe('Radio Component', () => {
    let container = null

    beforeEach(() => {
        container = null
    })

    it('Check if Radio component and indicator is rendered', () => {
        act(() => {
            container = mount(<Radio />);
        })
        expect(container.find('div')).toHaveLength(1)
        expect(container.find('.input-radio-indicator')).toHaveLength(1);
        expect(container).toMatchSnapshot()
    });

    it('Check if Radio label component renders text', () => {
        act(() => {
            container = mount(<Radio label="test" />);
        })
        expect(container.find('.input-radio-label')).toHaveLength(1);
        expect(container.find('label').text()).toEqual('test')
        expect(container).toMatchSnapshot()
        //snapshot
    });

    it('Check if onChange prop is called', () => {
        const onChangeMock = jest.fn();
        const event = { preventDefault() { }, target: { value: 'test' } };
        act(() => {
            container = mount(<Radio onChange={onChangeMock} />);
        })
        container.find('input').simulate('change', event);
        expect(onChangeMock.mock.calls.length).toBe(1);
    });

    it('Simulating Radio component to be false', () => {
        act(() => {
            container = mount(<Radio />);
        })
        container.find('input').simulate('change', { target: { value: false } });
        const input = container.find('input');
        expect(input.prop('value')).not.toBe(true);
    });

    it('Check if name prop of Radio is updated with new value', () => {
        let props = { name: "test_radio" }
        act(() => {
            container = mount(<Radio {...props} />);
        })
        const input = container.find('input');
        expect(input.prop('name')).toBe("test_radio");
    });

    it('Check for highLightColor when Radio is checked', () => {
        let props = { checked: true, hexCode2: '#8CE172' }
        act(() => {
            container = mount(<Radio {...props} />);
        })
        const input = container.find('.input-radio-indicator-cnr .input-radio-indicator');
        expect(input.prop('style')).toHaveProperty('backgroundColor', '#8CE172');
    });

    it('Check if Radio is disabled', () => {
        let props = { disabled: true }
        act(() => {
            container = mount(<Radio {...props} />);
        })
        expect(container.find('.disabled')).toHaveLength(1);
        const input = container.find('input');
        expect(input.prop('disabled')).toBe(true);
    });

    //snapshot of the radio

    //create the jest mock function
    // pass to the onChange
    // simulate the onchange event - check wther the mock function called 1 time

    // pass the color - check the stylr - 
    //snapshot

});