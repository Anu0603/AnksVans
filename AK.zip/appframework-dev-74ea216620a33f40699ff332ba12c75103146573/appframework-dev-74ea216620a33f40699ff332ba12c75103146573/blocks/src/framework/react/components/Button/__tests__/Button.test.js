import React from 'react'

import Button from './../Button'

describe('<Button> Component', () => {

    let container = null

    beforeEach(() => {
        container = null
    })


    it('Check whether Primary button rendered', () => {
        act(() => {
            container = shallow(<Button variant="primary" />)
        })
        expect(container.find('.btn-primary')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    })


    it('Check whether secondary button rendered', () => {
        act(() => {
            container = shallow(<Button variant="secondary" />)
        })
        expect(container.find('.btn-secondary')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    })


    it('Check whether tertiary button rendered', () => {
        act(() => {
            container = shallow(<Button variant="tertiary" />)
        })
        expect(container.find('.btn-tertiary')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    })


    it('Check whether danger button rendered', () => {
        act(() => {
            container = shallow(<Button variant={'danger'} />)
        })
        expect(container.find('.btn-danger')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    })


    it('Check whether warning button rendered', () => {
        act(() => {
            container = shallow(<Button variant="warning" />)
        })
        expect(container.find('.btn-warning')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    })


    it('Check whether button has Spinner', () => {
        act(() => {
            container = mount(<Button variant="primary" isLoading={true} />)
        })
        expect(container.find('.btn-base .spinner')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    })

    it('Check whether reverse style button rendered', () => {
        act(() => {
            container = shallow(<Button variant="primary" reversed={true} />)
        })
        expect(container.find('.btn-primary-reversed')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    })

    it('Check whether danger reverse style button rendered', () => {
        act(() => {
            container = shallow(<Button variant="danger" reversed={true} />)
        })
        expect(container.find('.btn-danger-reversed')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    })

    it('Check whether full width button rendered', () => {
        act(() => {
            container = shallow(<Button variant="primary" fullWidth={true} />)
        })
        expect(container.find('.btn-full')).toHaveLength(1)
        expect(container).toMatchSnapshot()
    })
})