import React from "react";
import classNames from "classnames";
import PropTypes from "prop-types";

import "./currency-formatter.scss";
import symbols from "./symbols";

const propTypes = {
  quantity: PropTypes.number.isRequired,
  currency: PropTypes.string,
  negative: PropTypes.bool
};
const defaultProps = {
  currency: "USD"
};

const CurrencyFormatter = props => {
  const { quantity, currency, negative, style, classes } = props;

  const classList = classNames(classes, negative && "negative", "currency");
  const formattedNumber = isNaN(quantity)
    ? quantity
    : parseFloat(quantity).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, "$&,");

  // TODO: Number superator should be dynamic not hardcoded comma
  return (
    <div className={classList} style={style}>
      {symbols[currency] ? (
        <div>
          {negative ? "-" : ""}
          {symbols[currency]}
          {formattedNumber.toString().replace(/-/, "")}
        </div>
      ) : (
          <div>
            {formattedNumber.slice(0, -3)}
            {" " + currency}
          </div>
        )}
    </div>
  );
};
CurrencyFormatter.propTypes = propTypes;
CurrencyFormatter.defaultProps = defaultProps;

export default CurrencyFormatter;
