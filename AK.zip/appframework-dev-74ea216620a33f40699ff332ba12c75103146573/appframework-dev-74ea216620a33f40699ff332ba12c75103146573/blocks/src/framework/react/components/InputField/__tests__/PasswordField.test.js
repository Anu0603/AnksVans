import React from 'react'
import PasswordField from '../PasswordField'

describe('Password Component', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check if password component is rendered', () => {
		act(() => {
			container = mount(
				<PasswordField type="password" showPassword={true} />
			)
		})
		expect(container.find('.tfield-container')).toHaveLength(1)
	})

	it('Check if onChange prop is called', () => {
		const onChangeMock = jest.fn()
		const event = { preventDefault() {}, target: { value: 'test' } }
		act(() => {
			container = mount(
				<PasswordField
					type="password"
					showPassword={true}
					onChange={onChangeMock}
				/>
			)
		})
		container.find('input').simulate('change', event)
		expect(onChangeMock.mock.calls.length).toBe(1)
	})

	it('Check if Post Decorator component and Icon is rendered', () => {
		act(() => {
			container = mount(
				<PasswordField type="password" showPassword={true} />
			)
		})
		expect(container.find('.post-decorator')).toHaveLength(1)
		expect(container.find('.fa-eye')).toHaveLength(1)
		expect(container).toMatchSnapshot()
	})

	it('Check if Post Decorator component is not displayed', () => {
		act(() => {
			container = mount(
				<PasswordField type="password" showPassword={false} />
			)
		})
		expect(container.find('.post-decorator')).not.toHaveLength(1)
		expect(container).toMatchSnapshot()
	})

	it('Password component should accept new value', () => {
		act(() => {
			container = mount(
				<PasswordField
					type="password"
					showPassword={true}
					value="1234567890"
				/>
			)
		})
		container
			.find('input')
			.simulate('change', { target: { value: '1234567890' } })
		const pass = container.find('input')
		expect(pass.prop('defaultValue')).toBe('1234567890')
		expect(container).toMatchSnapshot()
	})

	it('Check if postdecorator icons are toggled', () => {
		act(() => {
			container = mount(
				<PasswordField type="password" showPassword={true} />
			)
		})
		container.find('.post-decorator i').simulate('click')
		expect(container.find('.post-decorator .fa-eye-slash')).toHaveLength(1)
		container.find('.post-decorator i').simulate('click')
		expect(container.find('.post-decorator .fa-eye')).toHaveLength(1)
		expect(container).toMatchSnapshot()
	})

	//show password - false - check post decorator not displayed
	//snapshot
	//show password - true - check it displayed
	//snapshot
	//click on the eye icon - showing eye-slash displayed
	//snapshot
	//pass some value
	//check whether displayed
	//snapshot
})
