import React from 'react'
import App from './../App'

jest.mock('./../Navigator', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="navigator"></div>
		}
	}
})

describe('App Container', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check whether App container rendered', () => {
		act(() => {
			container = mount(<App />)
		})
		expect(container.find('div.navigator')).toHaveLength(1)
	})
})
