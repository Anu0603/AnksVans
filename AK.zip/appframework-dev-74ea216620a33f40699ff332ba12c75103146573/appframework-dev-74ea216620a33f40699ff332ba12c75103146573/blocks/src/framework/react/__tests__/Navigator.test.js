import React, { Suspense } from 'react'
import Navigator from './../Navigator'

jest.mock('./../../../bricks/fastlink', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="fastlink"></div>
		}
	}
})

describe('Product Navigator', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	//FIXME: There is a issue in using the React Lazy....need to check this
	it('Check whether route is rendered', () => {
		act(() => {
			container = mount(
				<Suspense fallback={<div>Sample Suspense wrapper</div>}>
					<Navigator routeName={'fastlink'} />
				</Suspense>
			)
		})
		expect(container.find('div')).toHaveLength(1)
	})

	it('Check whether default error section rendered when wrong route name passed', () => {
		act(() => {
			container = mount(
				<Suspense fallback={<div>Sample Suspense wrapper</div>}>
					<Navigator routeName={'test'} />
				</Suspense>
			)
		})

		expect(container.find('div.product-not-found')).toHaveLength(1)
	})
})
