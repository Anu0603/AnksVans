import React, { Suspense } from 'react'
import StoreProvider from './store/store'
import Navigator from './Navigator'

import './../app/styles/App.scss'

const App = props => {
	return (
		<StoreProvider>
			<Suspense fallback={<div>...</div>}>
				<Navigator routeName={'fastlink'} />
			</Suspense>
		</StoreProvider>
	)
}

export default App
