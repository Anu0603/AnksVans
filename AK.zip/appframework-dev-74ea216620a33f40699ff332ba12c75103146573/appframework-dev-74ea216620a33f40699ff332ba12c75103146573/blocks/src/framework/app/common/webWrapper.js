import Wrapper from './wrapper'

export class WebWrapper extends Wrapper {
	iframeResizeRequired = null
	iframeHeight = 0
	constructor() {
		super()
	}

	appInitialize() {
		/* istanbul ignore else */
		if (this.isIframeResizeEnabled()) {
			this.resizeInterval = setInterval(() => {
				this.resizeIframeWindow()
			}, 500)
		}
	}

	isIframeResizeEnabled() {
		/* istanbul ignore else */
		if (this.iframeResizeRequired == null) {
			/* istanbul ignore else */
			if (
				BrandUtils.getRequestParameter('locationurl') &&
				BrandUtils.getRequestParameter('iframeResize') == 'true'
			) {
				this.iframeResizeRequired = true
				document.body.classList.add('iframe-resize')
			}
		}
		return this.iframeResizeRequired
	}

	sendPostMessage(data) {
		/* istanbul ignore else */
		if (BrandUtils.getRequestParameter('locationurl')) {
			window.parent.postMessage(
				data,
				encodeURI(BrandUtils.getRequestParameter('locationurl'))
			)
		}
	}

	resizeIframeWindow() {
		var iframeHeight = document.getElementById('fastlink-container')
			.offsetHeight

		/* istanbul ignore else */
		if (this.iframeHeight != iframeHeight) {
			var diff = this.iframeHeight - iframeHeight
			/* istanbul ignore else */
			if (diff > 5 || diff < -5) {
				this.sendPostMessage({
					fnToCall: 'resizeIframeWindow',
					finappId: '10003600',
					height: iframeHeight
				})
			}
		}
	}
}

export default WebWrapper
