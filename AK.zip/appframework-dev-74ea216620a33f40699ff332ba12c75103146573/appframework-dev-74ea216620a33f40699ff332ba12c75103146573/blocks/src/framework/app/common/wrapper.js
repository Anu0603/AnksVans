export default class Wrapper {
	queryParams = {}

	constructor() {}

	getRequestParameter(paramName, isRemove) {
		return BrandUtils.getRequestParameter(paramName, isRemove)
	}

	isIframeResizeEnabled() {
		return false
	}

	closeAplication(parameters) {
		/* istanbul ignore else */
		if (this.resizeInterval) {
			clearInterval(this.resizeInterval)
		}

		let callBackUrl = this.getRequestParameter('callback', null)
		let locationUrl = this.getRequestParameter('locationurl', null)

		let validateUrl = BrandUtils.getParam(
			'client_callback_url_validation',
			'fastlink'
		)
		let clientMessageURL = callBackUrl || locationUrl

		let cbLocation = this.getRequestParameter('callbackLocation', null)

		let isValidUrl = Application.Utilities.isValidDomainCallbackUrl(
			clientMessageURL
		)

		/* istanbul ignore else */
		if (clientMessageURL && (!validateUrl || isValidUrl)) {
			/* istanbul ignore else */
			if (locationUrl) {
				this.sendPostMessage(parameters.postMessageData)
			}

			/* istanbul ignore else */
			if (callBackUrl) {
				this.redirectionCallbackUrl(
					clientMessageURL,
					parameters.callbackData,
					cbLocation
				)
			}
		}
	}

	redirectionCallbackUrl(callBack, parameters, cbLocation) {
		let lochref
		if (Application.Utilities.isEmpty(parameters)) {
			lochref = callBack
		} else {
			if (callBack.indexOf('?') == -1) {
				lochref = callBack + '?' + parameters
			} else {
				if (
					callBack.indexOf('?', callBack.length - 1) ==
					callBack.length - 1
				) {
					lochref = callBack + parameters
				} else {
					lochref = callBack + '&' + parameters
				}
			}
		}

		if (cbLocation == 'top') {
			top.location.href = lochref
		} else {
			location.href = lochref
		}
	}
}
