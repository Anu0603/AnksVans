import React from 'react'
import Utilities from '../Utilities'

describe('Utilities Testing', () => {
	it('Check for getAppMakeServiceURL service', () => {
		let makeCallURL = Utilities.getAppMakeServiceURL()
		expect(makeCallURL).toContain('/services/test/internal-provider/ysl')
	})

	it('Check for getAppGraphServiceURL service', () => {
		let makeCallURL = Utilities.getAppGraphServiceURL()
		expect(makeCallURL).toContain('/services/test/internal-provider/graph')
	})

	it('Check for getPfileResourceServiceURL service', () => {
		let makeCallURL = Utilities.getPfileResourceServiceURL()
		expect(makeCallURL).toContain('/resource/daflqa/static/pfile/')
	})

	it('Check for getFavIconResourceServiceURL service with png file', () => {
		let params = { url: 'test.png', siteId: 123 }
		let makeCallURL = Utilities.getFavIconResourceServiceURL(params)
		expect(makeCallURL).toContain('/resource/daflqa/static/site-image/')
	})

	it('Check for getFavIconResourceServiceURL service with svg file', () => {
		let params = { url: '/img/test.svg', siteId: 123 }
		let makeCallURL = Utilities.getFavIconResourceServiceURL(params)
		expect(makeCallURL).toContain('/img/test.svg')
	})

	it.skip('Check for getSiteLogoResourceServiceURL service', () => {
		let params = { url: 'test.png', siteId: 123 }
		let makeCallURL = Utilities.getSiteLogoResourceServiceURL(params)
		expect(makeCallURL).toMatch(
			'/resource/daflqa/static/site-image/123?cdnImageUrl=test.png&contentType=png'
		)
	})

	it.skip('Check for getSiteLogoResourceServiceURL service with svg extension', () => {
		let params = { url: 'test.svg', siteId: 123 }
		let makeCallURL = Utilities.getSiteLogoResourceServiceURL(params)
		expect(makeCallURL).toMatch(
			'/resource/daflqa/static/site-image/123?cdnImageUrl=test.svg&contentType=svg%2Bxml'
		)
	})

	it('Check for getImageResourceServiceURL service', () => {
		let makeCallURL = Utilities.getImageResourceServiceURL('test.png')
		expect(makeCallURL).toMatch('/resource/daflqa/static/img/test.png')
	})

	it('Check for getErrorRedirectUrl service', () => {
		let makeCallURL = Utilities.getErrorRedirectUrl(123)
		expect(makeCallURL).toContain('/apperror/test/?code=123&someBaseParams')
	})

	it('Check for isValidDomainCallbackUrl service', () => {
		let makeCallURL = Utilities.isValidDomainCallbackUrl(
			'https://www.test.com/'
		)
		expect(makeCallURL).toBe(true)
	})

	it('Check for isValidDomainCallbackUrl service for invalid URL', () => {
		let makeCallURL = Utilities.isValidDomainCallbackUrl('www.test.com')
		expect(makeCallURL).toBe(false)
	})

	it('Check for isEmpty service', () => {
		let makeCallURL = Utilities.isEmpty('')
		expect(makeCallURL).toBe(true)
	})
})
