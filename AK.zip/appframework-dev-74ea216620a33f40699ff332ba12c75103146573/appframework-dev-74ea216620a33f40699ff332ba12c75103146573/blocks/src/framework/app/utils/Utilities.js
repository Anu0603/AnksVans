let Utilities = function() {
	var getAppMakeServiceURL = () => {
		return (
			'/services/' +
			BrandUtils.get('cobAppName') +
			'/internal-provider/ysl?' +
			PARAM.apiParams +
			'&' +
			PARAM.baseParams
		)
	}

	var getAppGraphServiceURL = () => {
		return (
			'/services/' +
			BrandUtils.get('cobAppName') +
			'/internal-provider/graph?' +
			PARAM.apiParams +
			'&' +
			PARAM.baseParams
		)
	}

	var getPfileResourceServiceURL = pfileName => {
		return (
			'/resource/' +
			PARAM.brandResourcePath +
			'/pfile/' +
			pfileName +
			'?locale=' +
			PARAM.userInfo.prefs.locale
		)
	}

	var getFavIconResourceServiceURL = options => {
		let contentType
		let imageExt = options.url.split('.').reverse()[0]
		if (imageExt.toLowerCase() !== 'svg') {
			contentType = encodeURIComponent('x-icon')
			return (
				'/resource/' +
				PARAM.brandResourcePath +
				'/site-image/' +
				options.siteId +
				'?cdnImageUrl=' +
				options.url +
				'&contentType=' +
				contentType
			)
		} else {
			return options.url
		}
	}

	var getSiteLogoResourceServiceURL = options => {
		if (BrandUtils.getParam('siteLogoImageCacheEnabled') === true) {
			let imageExt = options.url
				.split('.')
				.reverse()[0]
				.toLowerCase()
			let contentType = encodeURIComponent(
				imageExt == 'svg' ? 'svg+xml' : imageExt
			)
			return (
				'/resource/' +
				PARAM.brandResourcePath +
				'/site-image/' +
				options.siteId +
				'?cdnImageUrl=' +
				options.url +
				'&contentType=' +
				contentType +
				'&cache=1'
			)
		} else {
			return options.url
		}
	}

	var getImageResourceServiceURL = imageName => {
		return '/resource/' + PARAM.brandResourcePath + '/img/' + imageName
	}

	var getErrorRedirectUrl = code => {
		return (
			'/apperror/' +
			BrandUtils.get('cobAppName') +
			'/?code=' +
			code +
			'&' +
			PARAM.baseParams
		)
	}

	var isValidDomainCallbackUrl = url => {
		var valid = false
		if (!isEmpty(url)) {
			if (
				/^(http|https|ftp):\/\/[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/i.test(
					url
				)
			) {
				var clientDomains = BrandUtils.getParam(
					'client_callback_domains',
					'fastlink'
				)
				if (!isEmpty(clientDomains)) {
					var urlParts = url
						.replace('http://', '')
						.replace('https://', '')
						.split(/[/?#]/)
					var domain = urlParts[0]
					if (clientDomains.split(',').indexOf(domain) != -1) {
						valid = true
					}
				} else {
					valid = true
				}
			}
		}
		return valid
	}

	var isEmpty = str => {
		return (
			str == null ||
			(typeof str == 'object' && Object.keys(str) == 0) ||
			typeof str == 'undefined' ||
			str.trim() == ''
		)
	}

	return {
		getAppMakeServiceURL,
		getAppGraphServiceURL,
		getPfileResourceServiceURL,
		getFavIconResourceServiceURL,
		getSiteLogoResourceServiceURL,
		getImageResourceServiceURL,
		getErrorRedirectUrl,
		isValidDomainCallbackUrl,
		isEmpty
	}
}

export default Utilities()
