import WebWrapper from './common/webWrapper'
import BaseService from './services/BaseService'
import Utilities from './utils/Utilities'

document.addEventListener('DOMContentLoaded', function() {
	//TODO : There will be conditional check which sayd Mobile wrapper or Web Wrapper to get picked
	const wrapper = new WebWrapper()
	wrapper.appInitialize()
	//TODo : Need to use memoisation technique here to make sure that global object is not polluted. Checkin so that team is not blocked.
	// window.Application = wrapper;

	window.Application = {
		Wrapper: wrapper,
		BaseService: BaseService,
		Utilities: Utilities
	}
})
