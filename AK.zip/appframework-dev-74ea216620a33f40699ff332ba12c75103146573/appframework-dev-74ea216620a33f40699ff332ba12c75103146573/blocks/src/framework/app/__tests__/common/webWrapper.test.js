import WebWrapper from './../../common/webWrapper'

describe('Wrapper', () => {
	const webWrapperInstance = new WebWrapper()
	const locationurl = 'https://www.yodlee.com'

	jest.useFakeTimers()

	beforeEach(() => {
		Object.defineProperty(window.document, 'URL', {
			writable: true,
			value: 'someurl'
		})

		document.getElementById = jest.fn(selector => {
			switch (selector) {
				case 'fastlink-container':
					return {
						offsetHeight: 100
					}
			}
		})

		BrandUtils.getRequestParameter = jest.fn(keyName => {
			switch (keyName) {
				case 'locationurl':
					return locationurl

				case 'iframeResize':
					return 'true'
			}
		})
	})

	it('Check whether appInitialize method gets called', () => {
		webWrapperInstance.appInitialize()
		jest.runOnlyPendingTimers()
		expect(
			BrandUtils.getRequestParameter.mock.calls.length
		).toBeGreaterThan(1)
	})

	it('Check whether sendPostMessage calls the parent application postmessage', () => {
		parent.postMessage = jest.fn()

		webWrapperInstance.sendPostMessage('sample data')
		expect(parent.postMessage.mock.calls.length).toBe(1)
	})
})
