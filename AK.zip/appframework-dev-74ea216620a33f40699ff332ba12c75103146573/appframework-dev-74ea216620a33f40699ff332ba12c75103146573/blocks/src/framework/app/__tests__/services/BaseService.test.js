import BaseService from './../../services/BaseService'
import axios from 'axios'

jest.mock('axios', () => {
	return {
		__esModule: true,
		default: {
			defaults: {
				headers: {
					common: {}
				}
			},
			create: jest.fn(function() {
				return this
			}),
			CancelToken: () => {}
		}
	}
})

describe('BaseService', () => {
	it('Chech whether makecall returns the data', done => {
		const users = [{ name: 'Bob' }]
		const resp = { data: users }

		axios.request = jest.fn(() =>
			Promise.resolve(
				new Promise(function(resolve, reject) {
					resolve(resp)
				})
			)
		)

		BaseService.makecall({
			method: 'GET',
			data: {}
		}).then(data => {
			expect(data).toBe(resp.data)
			done()
		})
	})

	it('Check whether the makecall returns the error', done => {
		const error = {
			code: 'N501',
			message: 'Stale session is found.',
			errorType: 'SESSION_ERROR',
			details: {
				description: 'Invalid token in authorization header',
				errorCode: 'Y008'
			},
			refId: 'xvu9iszkw7i',
			errorOccurred: true
		}
		const resp = { data: error }

		axios.request = jest.fn(() =>
			Promise.resolve(
				new Promise(function(resolve, reject) {
					reject({ response: resp })
				})
			)
		)

		BaseService.makecall({
			method: 'GET',
			data: {}
		}).catch(_error => {
			expect(error).toBe(_error)
			done()
		})
	})

	it('Check whether Authorization Header is constructed when cookie is disabled', done => {
		const users = [{ name: 'Bob' }]
		const resp = { data: users }

		PARAM.cookieDisabled = true

		axios.request = jest.fn((url, args) => {
			return Promise.resolve(
				new Promise(function(resolve, reject) {
					resolve(resp)
				})
			)
		})

		BaseService.makecall({
			method: 'GET',
			data: {}
		}).then(data => {
			expect(axios.defaults.headers.common).toHaveProperty(
				'Authorization'
			)
			done()
		})
	})

	it('Check whether getPfileResourceCall method returns the pfile data', done => {
		const resp = { data: { pfile: 'Sample  pfile data' } }

		Application.Utilities.getPfileResourceServiceURL = jest.fn(
			fileName => '/pfile/' + fileName
		)

		axios.request = jest.fn((url, args) => {
			return Promise.resolve(
				new Promise(function(resolve, reject) {
					resolve(resp)
				})
			)
		})

		BaseService.getPfileResourceCall({
			fileName: 'termAndCondition'
		}).then(data => {
			expect(data).toBe(resp.data)
			done()
		})
	})
})
