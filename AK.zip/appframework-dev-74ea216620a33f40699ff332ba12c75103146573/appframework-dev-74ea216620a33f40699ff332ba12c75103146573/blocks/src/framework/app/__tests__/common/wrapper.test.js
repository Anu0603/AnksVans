import Wrapper from './../../common/wrapper'

describe('Wrapper', () => {
	const wrapperInstance = new Wrapper()
	const callabckURL = 'https://www.yodlee.com'
	const locationurl = 'https://www.yodlee.com'
	const callbackparams = 'key1=value1&key2=value2'

	afterEach(() => {
		jest.restoreAllMocks()
		jest.clearAllMocks()
	})

	it('Check whether getRequestParameter returns the value', () => {
		BrandUtils.getRequestParameter = jest.fn(keyName => {
			switch (keyName) {
				case 'callback':
					return callabckURL

				case 'locationurl':
					return locationurl
			}
		})

		let _value = wrapperInstance.getRequestParameter('callback')

		expect(_value).toBe(callabckURL)
	})

	it('Check whether isIframeResizeEnabled return by default false in wrapper', () => {
		BrandUtils.getRequestParameter = jest.fn(keyName => {
			switch (keyName) {
				case 'callback':
					return callabckURL

				case 'locationurl':
					return locationurl
			}
		})

		let _value = wrapperInstance.isIframeResizeEnabled()

		expect(_value).toBe(false)
	})

	it('Check whether postmessage is called when locationurl is configured when calling closeAplication', () => {
		BrandUtils.getRequestParameter = jest.fn(keyName => {
			switch (keyName) {
				case 'callback':
					return ''

				case 'locationurl':
					return locationurl
			}
		})

		wrapperInstance.sendPostMessage = jest.fn()

		Application.Utilities.isValidDomainCallbackUrl = jest.fn(() => true)

		wrapperInstance.closeAplication({
			postMessageData: 'sample poast message data',
			callbackData: 'sample callback data'
		})

		expect(wrapperInstance.sendPostMessage.mock.calls.length).toBe(1)
	})

	it('Check whether callbackURL is called when callback is configured when calling closeAplication', () => {
		BrandUtils.getRequestParameter = jest.fn(keyName => {
			switch (keyName) {
				case 'callback':
					return callabckURL

				case 'locationurl':
					return ''

				case 'client_callback_url_validation':
					return true
			}
		})

		BrandUtils.getParam = jest.fn(key => {
			switch (key) {
				case 'client_callback_url_validation':
					return true
			}
		})

		Object.defineProperty(window, 'location', {
			value: {
				href: 'sample-url'
			}
		})

		Application.Utilities.isEmpty = jest.fn(() => true)

		wrapperInstance.resizeInterval = true

		Application.Utilities.isValidDomainCallbackUrl = jest.fn(() => true)

		wrapperInstance.closeAplication({
			postMessageData: 'sample poast message data',
			callbackData: 'some callback data'
		})

		expect(location.href).toBe(callabckURL)
	})

	// it('Check whether redirectionCallbackUrl method adds the data to location.href', () => {
	// 	Object.defineProperty(window, 'location', {
	// 		value: {
	// 			href: 'sample-url'
	// 		}
	// 	})

	// 	Application.Utilities.isEmpty = jest.fn(() => true)

	// 	wrapperInstance.redirectionCallbackUrl(callabckURL)

	// 	expect(location.href).toBe(callabckURL)
	// })

	it('Check whether redirectionCallbackUrl method adds the data to location.href', () => {
		Object.defineProperty(window, 'location', {
			value: {
				href: 'sample-url'
			}
		})

		Application.Utilities.isEmpty = jest.fn(() => false)

		wrapperInstance.redirectionCallbackUrl(callabckURL, callbackparams)

		expect(location.href).toBe(callabckURL + '?' + callbackparams)
	})
})
