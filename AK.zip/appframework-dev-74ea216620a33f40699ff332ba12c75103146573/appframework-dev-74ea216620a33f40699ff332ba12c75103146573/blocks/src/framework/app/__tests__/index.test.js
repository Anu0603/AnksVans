import './../index'

describe('App Framework', () => {
	window.document.dispatchEvent(
		new Event('DOMContentLoaded', {
			bubbles: true,
			cancelable: true
		})
	)

	it('Check whether App Framework has been initialized', () => {
		expect(typeof window.Application).toBe('object')
		expect(typeof window.Application.Wrapper).toBe('object')
		expect(typeof window.Application.BaseService).toBe('object')
		expect(typeof window.Application.Utilities).toBe('object')
	})
})
