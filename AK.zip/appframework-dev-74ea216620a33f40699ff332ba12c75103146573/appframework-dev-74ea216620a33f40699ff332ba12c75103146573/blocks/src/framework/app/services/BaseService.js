import axios from 'axios'
const instance = axios.create({
	timeout: 60000
})

let cancel, authrizationHeader

const BaseService = () => {
	let makecall = _options => {
		try {
			let _requestOptions = {
				method: _options.method || 'POST',
				data: _options.data
			}

			_options.headers = {
				'Content-Type': 'application/json'
			}

			if (PARAM.cookieDisabled) {
				_options.headers[
					'Authorization'
				] = _consturctAuthorizationHeader()
			}

			if (_options.headers) {
				Object.assign(
					instance.defaults.headers.common,
					_options.headers
				)
			}

			if (!_options.nodeserviceUrl) {
				_options.nodeserviceUrl = Application.Utilities.getAppMakeServiceURL()
			}
			_requestOptions.cancelToken = new axios.CancelToken(
				function executor(c) {
					cancel = c
				}
			)

			return instance
				.request(_options.nodeserviceUrl, _requestOptions)
				.then(function(response) {
					//FIXME: Callback is deprecated. callback related code will be removed soon hence skipping code coverage
					/* istanbul ignore if */
					if (_options.callback) {
						console.warn('Callback is deprecated, use promise')
						_options.callback(null, response.data)
						return
					}

					_renewClientSession();
					return response.data
				})
				.catch(function(error) {
					//FIXME: Callback is deprecated. callback related code will be removed soon hence skipping code coverage
					/* istanbul ignore if */
					if (_options.callback) {
						console.warn('Callback is deprecated, use promise')
						_options.callback(
							error,
							error.response ? error.response.data : null
						)
						return
					}

					let apiErrorResponse = error.response.data
					if (apiErrorResponse) {
						if (!_handleError(apiErrorResponse)) {
							_renewClientSession();
							if (
								apiErrorResponse.details.serviceType == 'graph'
							) {
								let graphResponse = {}
								Object.keys(apiErrorResponse.details.data).map(
									graphKey => {
										let errorRes =
											apiErrorResponse.details.data[
												graphKey
											]
										if (
											errorRes &&
											!_handleError(errorRes)
										) {
											if (
												errorRes.errorOccurred === true
											) {
												graphResponse[graphKey] =
													errorRes.details || {}
												graphResponse[
													graphKey
												].errorOccurred = true
											} else {
												graphResponse[
													graphKey
												] = errorRes
											}
										}
									}
								)
								apiErrorResponse = graphResponse
							}
						}
					} else {
						console.log('Invalid Error Response', apiErrorResponse)
					}
					return Promise.reject(apiErrorResponse)
				})
		} catch (e) {
			console.log(e)
		}
	}

	let _handleError = errorData => {
		let isValid = false
		if (
			errorData.errorType == 'SESSION_ERROR' ||
			errorData.errorType == 'SERVER_ERROR'
		) {
			window.location = Application.Utilities.getErrorRedirectUrl(
				errorData.code
			)
		} else {
			console.log('Error Type', errorData.errorType)
		}
		return isValid
	}

	let _renewClientSession = () => {
		if( document.getElementById('yokeepAlive') ) {
			if( !window.clientKeepAliveUrl ) {
				window.clientKeepAliveUrl = document.getElementById('yokeepAlive').src;
			}
			document.getElementById('yokeepAlive').src = window.clientKeepAliveUrl + '?nocache=' + (new Date()).getTime();
		}
	}

	let _consturctAuthorizationHeader = () => {
		if (!authrizationHeader) {
			//rsession and prefs going as part of request header for mobile bundle and cookie disabled
			let authHeaders = []
			authHeaders.push('rsession=' + sessionStorage.getItem('rdata'))
			if (PARAM.userInfo) {
				authHeaders.push(
					'udata=' +
						encodeURIComponent(JSON.stringify(PARAM.userInfo))
				)
			}
			if (PARAM.nsession) {
				authHeaders.push(
					'nsession=' +
						encodeURIComponent(JSON.stringify(PARAM.nsession))
				)
			}
			authrizationHeader = authHeaders.join(';')
		}
		return authrizationHeader
	}

	let graphCall = _options => {
		_options.nodeserviceUrl = Application.Utilities.getAppGraphServiceURL()
		return makecall(_options)
	}

	/**
	 *
	 * @description This is a service Wrapper for invoking the pFile content for the specific type like privacy policy, Terms and Conditions, etc
	 */
	let getPfileResourceCall = _options => {
		_options.nodeserviceUrl = Application.Utilities.getPfileResourceServiceURL(
			_options.fileName
		)
		_options.method = 'GET'
		return makecall(_options)
	}

	let cancelLastRequest = () => {
		cancel('REQUEST_CANCEL')
	}

	return {
		makecall,
		graphCall,
		getPfileResourceCall,
		cancelLastRequest
	}
}

export default BaseService()
