export default {
	parsePopularSitesData: response => {
		if (response && response.provider) {
			return response.provider.map(element => {
				return {
					id: element.id,
					logo: element.logo,
					name: element.name,
				}
			})
		} else {
			return []
		}
	},
	parseSearchedSitesData: response => {
		if (response && response.provider) {
			return response.provider.map(element => {
				return {
					id: element.id,
					favicon: element.favicon,
					baseUrl: element.baseUrl,
					name: element.name,
					isAddedByUser: element.isAddedByUser,
					countryISOCode: element.countryISOCode,
				}
			})
		} else {
			return []
		}
	},
}
