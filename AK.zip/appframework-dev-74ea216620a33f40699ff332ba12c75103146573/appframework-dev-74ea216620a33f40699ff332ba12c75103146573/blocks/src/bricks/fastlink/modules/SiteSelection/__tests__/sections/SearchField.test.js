import React from 'react'

import SearchFieldSection from '../../sections/SearchField'

import { getString } from '../../../../conf'
jest.mock('../../../../conf')

describe('Search Field Section', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check whether search field section rendered', () => {
		act(() => {
			container = shallow(<SearchFieldSection />)
		})
		expect(container.find('.search-bar-cnr')).toHaveLength(1)
	})

	it('Check whether search info section shown', () => {
		let _text = 'Sorted by Most Popular'
		act(() => {
			getString.mockImplementation(_key => {
				if (_key == 'site_sort_order') {
					return _text
				}
				return ''
			})

			container = shallow(
				<SearchFieldSection
					isSearchMode={true}
					haveSearchResult={true}
				/>
			)
		})
		expect(container.find('.search-info .text').text()).toEqual(_text)
	})
})
