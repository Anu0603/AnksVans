import React, { Component } from 'react'
import { AppStrings, getString, AutoIds } from '../../../../../conf'
import { Button } from '../../../../../../../framework/react/components/Button'
import {
	Icon,
	IconNameMap
} from '../../../../../../../framework/react/components/Icon'
import { Link } from '../../../../../../../framework/react/components/Link'
import AppConstants from '../../../../../conf/constants/AppConstants'

class CDVInitiateSuccessView extends Component {
	constructor(props) {
		super(props)

		if (props.status == AppConstants.CDV_INITIATE_STATUS_INPROGRESS) {
			this.title = getString(
				AppStrings.CDV_INITIATE_VERIFICATION_INPROGRESS_TITLE
			)
			this.description = getString(
				AppStrings.CDV_INITIATE_VERIFICATION_INPROGRESS_TEXT
			)
			this.buttonText = getString(
				AppStrings.CDV_INITIATE_VERIFICATION_INPROGRESS_BUTTON_TEXT
			)
		} else {
			this.title = getString(
				AppStrings.CDV_INITIATE_VERIFICATION_SUCCESS_TITLE
			)
			this.description = getString(
				AppStrings.CDV_INITIATE_VERIFICATION_SUCCESS_TEXT
			)
			this.buttonText = getString(
				AppStrings.CDV_INITIATE_VERIFICATION_SUCCESS_BUTTON_TEXT
			)
		}
	}

	render() {
		return (
			<div className="message-wrapper" autoid={AutoIds.CDV_COMMON_AUTOID}>
				<Link
					classes="close-icon"
					onClick={this.props.onClose}
					lable={<Icon type="fal" iconClass={IconNameMap.close} />}
				></Link>
				<div className="msg-container">
					<Icon
						id="initiate-success-icon"
						classes="success-icon"
						iconClass="fas fa-tasks"
					/>
					<div id="initiate-success-title" className="msg-title">
						{this.title}
					</div>
					<div id="initiate-success-text" className="text">
						{this.description}
					</div>
					<Button
						classes="initiate-success-btn"
						size="md"
						variant="secondary"
						label={this.buttonText}
						onClick={this.props.onClose}
					></Button>
				</div>
			</div>
		)
	}
}
export default CDVInitiateSuccessView
