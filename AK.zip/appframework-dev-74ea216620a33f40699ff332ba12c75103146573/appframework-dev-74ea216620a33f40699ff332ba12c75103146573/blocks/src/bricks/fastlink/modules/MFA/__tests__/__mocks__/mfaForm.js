const mfaLoginForm = {
	mfaTimeout: 125000,
	formType: 'token',
	row: [
		{
			id: 'token_row',
			label: 'Security Key',
			fieldRowChoice: '0001',
			form: '0001',
			field: [
				{
					id: 'token',
					name: 'tokenValue',
					isOptional: false,
					value: '',
					valueEditable: 'true',
					maxLength: 10,
					minLength: 0,
					type: 'text'
				}
			]
		}
	]
}

export default mfaLoginForm
