import React from 'react'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../conf'
import { Spinner } from './../../../../../framework/react/components/Spinner'
const SpinnerMsg = props => {
	return (
		<React.Fragment>
			{props.isLoading && (
				<Spinner
					id="spinner"
					name="spinner"
					size="md"
					color={props.secondaryColor}
					children={
						<div
							id="data-refresh-label"
							className="data-refresh-label"
							autoid={
								AutoIds.ACCOUNT_SUMMARY_LABEL_MOREACCOUNTSTEXT
							}
						>
							{getString(
								AppStrings.ACCOUNT_SUMMARY_LINKING_MORE_ACCOUNTS_LOADING_TEXT
							)}
						</div>
					}
				/>
			)}
		</React.Fragment>
	)
}
export default SpinnerMsg
