import React from 'react'
import { Provider } from 'react-redux'

import MFAModule from './../index'

import configureStore from 'redux-mock-store'
const mockStore = configureStore([])

jest.mock('./../views/mfa', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="mfa-view"></div>
		}
	}
})

describe('Landing Module', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	let renderComponent = () => {
		let store = mockStore({
			search: {
				providers: []
			}
		})

		container = mount(
			// <Provider store={store}>
			<MFAModule />
			// </Provider>
		)
	}

	it('Check whether landing module rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('div.mfa-view')).toHaveLength(1)
	})
})
