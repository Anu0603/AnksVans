export default {
	providerMap: {
		NORMAL: {
			name: 'Ally Bank',
			id: 9565,
			hexCode1: '#3E0046',
			hexCode2: '#40B8BD'
		},
		SITE_NOT_ASSOCIATED: {
			name: 'MILLYARD BANK',
			hexCode1: '#747474',
			hexCode2: '#0096D6'
		},
		RTN_NOT_FOUND: {}
	}
}
