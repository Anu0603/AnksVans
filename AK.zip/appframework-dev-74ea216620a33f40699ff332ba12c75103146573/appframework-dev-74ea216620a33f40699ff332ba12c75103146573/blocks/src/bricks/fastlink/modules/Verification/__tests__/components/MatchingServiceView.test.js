import React from 'react'
import MatchingServiceView from '../../components/MatchingServiceView'
import ProviderData from './../__mocks__/provider'
import VerificationData from './../__mocks__/verification'
import MatchingService from './../../../../services/provider/VerificationService'

jest.mock('./../../../../services/provider/VerificationService')

describe('Matching Service View Section', () => {
	let container = null
	beforeEach(() => {
		container = null

		MatchingService.mockImplementation(() => {
			return {
				matchingVerification: (_options, _callback) => {
					return Promise.resolve(VerificationData.verification)
				}
			}
		})
	})

	it('Check if Matching Service View is rendered', () => {
		act(() => {
			container = shallow(
				<MatchingServiceView currentProvider={ProviderData.provider} />
			)
		})
		expect(container.find('.data-message-wrapper')).toHaveLength(1)
	})

	it('Check if Matching Verification sets status as MATCHING_COMPLETED', () => {
		act(() => {
			container = shallow(
				<MatchingServiceView currentProvider={ProviderData.provider} />
			)
		})
		expect(container.find('.data-message-wrapper')).toHaveLength(1)
	})

	it('Check if Matching Verification sets status as MATCHING_FAILED', () => {
		act(() => {
			container = shallow(
				<MatchingServiceView currentProvider={ProviderData.provider} />
			)
		})
		expect(container.find('.data-message-wrapper')).toHaveLength(1)
	})
})
