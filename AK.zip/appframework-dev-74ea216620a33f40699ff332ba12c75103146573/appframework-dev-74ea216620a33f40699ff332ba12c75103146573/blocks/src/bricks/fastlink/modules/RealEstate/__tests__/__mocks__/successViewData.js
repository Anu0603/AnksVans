const manualAccountData = {
	showSpinner: false,
	currency: 'USD',
	amount: '123',
	accountName: 'Test',
	valuationType: 'MANUAL',
}

const automaticAccountData = {
	showSpinner: false,
	currency: 'USD',
	amount: '123',
	accountName: 'Test',
	valuationType: 'SYSTEM',
}
export default { manualAccountData, automaticAccountData }
