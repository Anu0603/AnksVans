import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Button } from '../../../../../framework/react/components/Button'
import { Spinner } from '../../../../../framework/react/components/Spinner'
import { AppStrings, getString } from '../../../../fastlink/conf'
import CONSTANTS from './../../../router/Constant'
import AccountsService from '../../../services/account/AccountsService'
import ManualAccountService from '../../../services/account/ManualAccountService'
import DeleteModal from '../sections/DeleteModal'
import ErrorBanner from './../../../components/Error/ErrorBanner'
import ErrorContent from './../../../components/Error/ErrorContent'
import { CurrencyFormatter } from './../../../../../framework/react/components/CurrencyFormatter'
import {
	Icon,
	IconNameMap
} from '../../../../../framework/react/components/Icon'

export class SuccessView extends Component {
	constructor(props) {
		super(props)
		this.state = {
			errorStatus: false,
			showDeleteModal: false,
			showSpinner: true,
			accountName: '',
			nickname: '',
			accountType: '',
			amountDueInt: 0,
			balanceInt: 0,
			currency: ''
		}
		this.manualAccountService = new ManualAccountService()
		this.accountsService = new AccountsService()
		this.manualAccountDataResp
	}

	componentDidMount() {
		const id = this.props.data.id
		const container = this.props.data.container

		this.manualAccountService
			.getManualAccount({ id, container })
			.then(resp => {
				let acct = resp.account[0]

				this.manualAccountDataResp = resp.account
				this.props.onAdd(resp)
				this.setState({
					accountName: acct.accountName,
					nickname: acct.nickname,
					accountType: acct.accountType,
					balanceInt: acct.balance.amount,
					currency: acct.balance.currency,
					showSpinner: false
				})
			})
			.catch(error => console.log(error))
	}

	handleDelete() {
		const accountId = this.props.data.id
		this.accountsService.deleteAccount({ accountId }).then(
			() => {
				this.setState({ showDeleteModal: false })
				this.props.onDelete(this.accountId)
				this.props.navigate(CONSTANTS.ROUTE_LANDING_MODULE)
			},
			error => {
				console.log('error occured while deleting', error)
				this.setState({
					showDeleteModal: false,
					errorReason: 'MANUAL_ACCOUNT_UNABLE_TO_DELETE',
					errorStatus: 'MANUAL_ACCOUNT_UNABLE_TO_DELETE',
					showErrorBanner: true
				})
			}
		)
	}

	handleEdit() {
		this.props.showNextView('MA_LANDING_VIEW', {
			isEdit: true,
			editAccount: this.manualAccountDataResp,
			currency: this.state.currency,
			originalAcctNumber: this.props.data.originalAcctNumber,
			prevFieldValues: this.props.data.prevFieldValues
		})
	}

	render() {
		return (
			<div className="section-container">
				<div className="section-header">
					<div className="title">
						{getString(
							AppStrings.MANUAL_ACCOUNT_VIEW_ACCOUNT_TITLE
						)}
					</div>
				</div>
				{this.state.errorStatus && (
					<React.Fragment>
						<ErrorBanner errorCode={this.state.errorReason} />
						<ErrorContent errorCode={this.state.errorReason} />
					</React.Fragment>
				)}
				{this.state.showDeleteModal && (
					<DeleteModal
						showHidePopUp={flag => {
							this.setState({ showDeleteModal: flag })
						}}
						handleDelete={this.handleDelete.bind(this)}
						accountName={this.state.accountName}
					/>
				)}
				{this.state.showSpinner ? (
					<Spinner id="largeSpinner" size="lg" />
				) : (
					<div className="form-content">
						<div className="sub-section pad-tb-2x sub-edit">
							<div className="title">
								{this.state.accountName}
							</div>
							<div className="info-txt text-capitalize">
								{this.state.accountType === 'CD'
									? 'CD'
									: this.state.accountType.toLowerCase()}
							</div>
							<CurrencyFormatter
								quantity={this.state.balanceInt}
								currency={this.state.currency}
								classes="list-second-sub-title"
							/>
							<Icon
								type="fal"
								iconClass={IconNameMap['edit-icon']}
								onClick={this.handleEdit.bind(this)}
							/>
						</div>
						<div className="btn-wrapper pad-tb-2x">
							<Button
								className="save-and-finish-btn"
								variant="primary"
								label="Save & Finish"
								fullWidth
								onClick={() => {
									Application.Wrapper.close()
								}}
							/>
							<Button
								className="save-and-link-btn"
								variant="secondary"
								label="Save & Link More Accounts"
								fullWidth
								onClick={() =>
									this.props.navigate(
										CONSTANTS.ROUTE_LANDING_MODULE
									)
								}
							/>

							<Button
								className="cancel-btn"
								variant="tertiary"
								label="Cancel"
								fullWidth
								onClick={() =>
									this.setState({ showDeleteModal: true })
								}
							/>
						</div>
					</div>
				)}
			</div>
		)
	}
}

const mapStateToProps = state => {
	return {}
}

const mapDispatchToProps = dispatch => {
	return {
		// onFetchProvider: () => dispatch(actionCreators.fetchProviders())
		onAdd: manualAccountDetails =>
			dispatch({
				type: 'ADD_MANUAL_ACCOUNT',
				payload: { manualAccount: manualAccountDetails.account[0] }
			}),
		onDelete: accountID =>
			dispatch({
				type: 'REMOVE_REAL_ESTATE_ACCOUNT',
				payload: { accountID }
			})
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(SuccessView)
