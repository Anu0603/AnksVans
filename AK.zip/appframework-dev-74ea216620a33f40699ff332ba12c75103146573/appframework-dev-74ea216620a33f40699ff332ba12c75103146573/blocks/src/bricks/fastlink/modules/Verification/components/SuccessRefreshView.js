import React, { Component } from "react";
import { connect } from "react-redux";
import { AppStrings, getString, AutoIds } from "../../../conf";
import { Icon } from "./../../../../../framework/react/components/Icon";

class SuccessRefreshView extends Component {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.onSuccessrefreshViewLoad();
  }

  render() {
    return (
      <div
        className="success-message-wrapper flex-center"
        autoid={AutoIds.VERIFICATION_SUCCESS_CONTAINER}
      >
        <div id="success-refresh-label" className="text">
          {getString(AppStrings.VERIFICATION_SUCCESS_TEXT)}
        </div>
        <Icon
          type="fas"
          id="success-refresh-icon"
          classes="success-refresh-icon"
          iconClass="fa-shield-check"
        />
      </div>
    );
  }
}

const mapDispatchToProps = dispatch => {
  return {
    //  onFetchProvider: () => dispatch(actionCreators.fetchProviders())
    onSuccessrefreshViewLoad: () =>
      dispatch({
        type: "SUCCESS_REFRESH_VIEW",
        payload: { successRefreshView: true }
      })
  };
};

export default connect(null, mapDispatchToProps)(SuccessRefreshView);
