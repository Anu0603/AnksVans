import React from 'react'
import PostVerificationView from './../../../components/invoke/postVerificationView'
import ProviderData from './../../__mocks__/provider'

describe('CDV Invoke View - Post Verification', () => {
	let container = null
	beforeEach(() => {
		container = null
	})

	it('Check whether post verification section is rendered without provider', () => {
		act(() => {
			container = shallow(<PostVerificationView />)
		})
		expect(container.find('div.cdv-invoke-post-ver-content')).toHaveLength(
			1
		)
	})

	it('Check whether post verification section is rendered with provider', () => {
		act(() => {
			container = shallow(
				<PostVerificationView provider={ProviderData.provider} />
			)
		})
		expect(container.find('div.cdv-invoke-post-ver-content')).toHaveLength(
			1
		)
	})

	it('Check whether demarcate section is rendered ', () => {
		act(() => {
			container = shallow(
				<PostVerificationView provider={ProviderData.provider} />
			)
		})
		expect(
			container.find('div.cdv-invoke-post-ver-content .demarcate')
		).toHaveLength(1)
	})

	it('Check whether text content is rendered ', () => {
		act(() => {
			container = shallow(
				<PostVerificationView provider={ProviderData.provider} />
			)
		})
		expect(
			container.find('div.cdv-invoke-post-ver-content .text-content')
		).toHaveLength(1)
	})

	it('Check whether button is rendered ', () => {
		act(() => {
			container = shallow(
				<PostVerificationView provider={ProviderData.provider} />
			)
		})
		expect(
			container.find('div.cdv-invoke-post-ver-content .btn-wrapper')
		).toHaveLength(1)
	})

	it('Check whether button label is of primary color', () => {
		act(() => {
			container = shallow(
				<PostVerificationView provider={ProviderData.provider} />
			)
		})
		expect(
			container
				.find('.btn-wrapper')
				.children(0)
				.prop('style')['backgroundColor']
		).toEqual('#3E0046')
	})

	it('Check whether class passed to component is attached to the compnent base element', () => {
		act(() => {
			container = shallow(
				<PostVerificationView
					classes="abc"
					provider={ProviderData.provider}
				/>
			)
		})
		expect(
			container.find('div.cdv-invoke-post-ver-content').prop('className')
		).toMatch(/abc/)
	})

	it('Check whether info icon is clickable', () => {
		act(() => {
			container = shallow(
				<PostVerificationView provider={ProviderData.provider} />
			)
		})
		expect(container.state().showInfoPopup).toEqual(false)
		container
			.find('.text-content')
			.children('.text')
			.last()
			.children('.tooltip-spacer')
			.children()
			.simulate('click')
		expect(container.state().showInfoPopup).toEqual(true)
		container
			.find('.text-content')
			.children('.text')
			.last()
			.children('.tooltip-spacer')
			.children()
			.simulate('click')
		expect(container.state().showInfoPopup).toEqual(false)
	})
})
