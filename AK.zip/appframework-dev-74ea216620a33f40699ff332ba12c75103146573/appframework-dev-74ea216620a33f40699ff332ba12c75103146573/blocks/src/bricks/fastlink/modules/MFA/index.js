import React, { Component } from 'react'

import Mfa from '../../modules/MFA/views/mfa'

class MFAModule extends Component {
	constructor(props) {
		super(props)
	}

	static propTypes = {}

	static defaultProps = {}

	componentDidMount() {}

	render() {
		return <Mfa {...this.props} />
	}
}

export default MFAModule
