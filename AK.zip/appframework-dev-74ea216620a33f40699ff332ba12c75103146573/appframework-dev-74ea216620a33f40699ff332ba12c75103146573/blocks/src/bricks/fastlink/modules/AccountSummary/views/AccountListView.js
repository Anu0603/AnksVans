import React, { Component } from 'react'
import ReactDOM from 'react-dom'
import { connect } from 'react-redux'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../conf'
import AppConstants from '../../../conf/constants/AppConstants'
import Constants from '../../../router/Constant'
import ProviderAccountPolling from './../../../concept/api/polling/ProviderAccountPolling'
import AccountsPolling from '../../../concept/api/polling/AccountsPolling'
import ActSummaryButtons from '../sections/ActSummaryButtons'
import ActSummaryHelpText from './../sections/ActSummaryHelpText'
import SpinnerMsg from './../sections/SpinnerMsg'
import ContainerList from './../sections/accounts'
import CDVModule from './../../CDV'
import Postmessage from './../../../components/ExternalNotification'
import DeeplinkConstants from '@fastlinkRoot/filters/deeplink/DeeplinkConstants'

class AccountListView extends Component {
	constructor(props) {
		super(props)

		this.data = this.props
		this.status = this.props.status
		this.additionalStatus = this.props.additionalStatus
		this.institutionName = this.props.currentProvider.name
		this.state = {
			isLoading: true,
			selectedAccounts: {}
		}

		/* Description: The below code is used to set the app-flow in the account-summary
		 * module, when then PRODUCT_TYPE is a combined flow. i.e. either the IAV+AGG or AGG+IAV
		 */
		if (
			this.isProductTypeVerificationThenAggregation() ||
			this.isProductTypeAggregationThenVerification()
		) {
			this.state['flow'] = this.getAppFlow()
		}

		this.providerAccountPollingService = new ProviderAccountPolling(
			this.data.providerId,
			this.data.providerAccountId,
			this.data.requestId
		)
		this.allDeleted = false
		this.accountsPollingService = new AccountsPolling(
			this.data.providerAccountId,
			'ACTIVE'
		)

		this.anAccountDeleted = false
		this.containerAccountList = this.props.accountsResponse
			? Object.assign({}, this.props.accountsResponse)
			: []
		// PRAMS for this view component
		this.containerforSortList = getParam(AppParams.CONTAINER_LIST)
		this.disableBottomText = getParam(AppParams.DISABLE_BOTTOM_TEXT)
		this.pollingInterval = getParam(AppParams.POLLING_INTERVAL)
		this.accountsContainerList = []
		this.setAccountsContainer()
		//this.postMessage = new Postmessage();
		this.addPostMessage({
			status: this.data.status,
			additionalStatus: this.data.additionalStatus,
			providerAccountId: this.data.providerAccountId
		})
		this.isDeeplink = props.deeplinkData.isDeeplink
		this.deeplinkType = props.deeplinkData.deeplinkType
	}

	addPostMessage(data) {
		Postmessage.addUpdateProviderAccountsData(data)
	}

	showBackIcon() {
		this.backIcon.removeAttribute('style')
		this.backIcon.addEventListener(
			'click',
			this.reloadVerificationFromAggrgation.bind(this)
		)
	}

	hideBackIcon() {
		this.backIcon.setAttribute('style', 'display:none')
	}

	handleBackIconVisiblity() {
		if (
			this.isProductTypeAggregation() ||
			this.isProductTypeVerification() ||
			(this.isProductTypeVerificationThenAggregation() &&
				AppConstants.APP_FLOW_VERIFICATION == this.state.flow)
		) {
			this.hideBackIcon()
		}
	}

	isProductTypeAggregation() {
		return (
			getParam(AppParams.PRODUCT_TYPE) ==
			AppConstants.AGGREGATION_FLOW_NAME
		)
	}

	isProductTypeVerification() {
		return (
			getParam(AppParams.PRODUCT_TYPE) ==
			AppConstants.VERIFICATION_FLOW_NAME
		)
	}

	isProductTypeVerificationThenAggregation() {
		return (
			getParam(AppParams.PRODUCT_TYPE) ===
			AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME
		)
	}

	isProductTypeAggregationThenVerification() {
		return (
			getParam(AppParams.PRODUCT_TYPE) ===
			AppConstants.AGGREGATION_THEN_VERIFICATION_FLOW_NAME
		)
	}

	/* Description: getAppFlow() determines and set initial app-flow for the combined PRODUCT_TYPE, i.e. whether it is
	 * IAV+AGG or AGG+IAV, it determines the initial app-flow based on the PRODUCT_TYPE.
	 */
	getAppFlow() {
		if (this.isProductTypeVerificationThenAggregation()) {
			return AppConstants.APP_FLOW_VERIFICATION
		} else if (this.isProductTypeAggregationThenVerification()) {
			return AppConstants.APP_FLOW_AGGREGATION
		} else {
			return undefined
		}
	}

	/* Description: updateFlowAndRerender() set the app-flow for the combined PRODUCT_TYPE when the application is rerendered,
	 * i.e. whether it is IAV+AGG or AGG+IAV, it updates the app-flow based on the PRODUCT_TYPE.
	 */
	updateFlowAndRerender() {
		let flow
		if (this.isProductTypeVerificationThenAggregation()) {
			flow = AppConstants.APP_FLOW_AGGREGATION
			this.showBackIcon()
		} else if (this.isProductTypeAggregationThenVerification()) {
			flow = AppConstants.APP_FLOW_VERIFICATION
		}
		this.setState({
			flow: flow
		})
	}

	reloadVerificationFromAggrgation() {
		let flow = this.getAppFlow()
		this.setState({
			flow: flow
		})
	}

	componentDidMount() {
		this.providerAccountPollingService.startPolling(this.props.dispatch)
		this.accountsPollingService.startPolling(this.props.dispatch)
		console.log('Accounts service initiated..')

		if (this.data.backIcon) {
			this.backIcon = ReactDOM.findDOMNode(this.data.backIcon.current)
		}
		this.handleBackIconVisiblity()
	}

	componentWillUnmount() {
		this.stopPolling()
	}

	stopPolling() {
		console.log('Stop polling.')
		this.providerAccountPollingService.endPolling()
		this.accountsPollingService.endPolling()
	}

	deleteCallback = function deleteCallback(deletedAccountId) {
		if (deletedAccountId) {
			this.anAccountDeleted = true
			this.accountsPollingService.startPolling(this.props.dispatch)
			console.log('Deleted account id:', deletedAccountId)
		} else {
			console.log('Error deleting an account')
		}
	}

	// Update the state upon the props change.
	static getDerivedStateFromProps(nextProps, prevState) {
		console.log('getDerivedStateFromProps')
		if (
			nextProps.status !== 'IN_PROGRESS' &&
			nextProps.additionalStatus !== 'ACCT_SUMMARY_RECEIVED'
		) {
			return { isLoading: false }
		}
		return null
	}

	shouldComponentUpdate(newProps, newState) {
		if (
			this.anAccountDeleted &&
			!newState.isLoading &&
			!this.allDeleted &&
			newProps.accountsResponse &&
			Object.keys(newProps.accountsResponse).length == 0
		) {
			this.allDeleted = true
		}

		this.addPostMessage({
			status: newProps.status,
			requestId: newProps.requestId,
			additionalStatus: newProps.additionalStatus,
			providerAccountId: newProps.providerAccountId,
			selectedAccounts: newState.selectedAccounts
		})

		if (newProps.accountsResponse) {
			this.setAccountsContainer()
			this.containerAccountList = Object.assign(
				{},
				newProps.accountsResponse
			)
			for (let container in this.containerAccountList) {
				let lists = this.containerAccountList[container]
				for (let listIndex in lists) {
					lists[listIndex].checked = false
					if (newState.selectedAccounts[lists[listIndex].id]) {
						lists[listIndex].checked = true
					}
				}
			}
		}
		return true
	}

	setAccountsContainer() {
		if (this.containerforSortList && this.containerforSortList.length > 0) {
			this.accountsContainerList = this.containerforSortList
		} else {
			this.accountsContainerList = this.props.accountsResponse
				? Object.keys(this.props.accountsResponse)
				: []
		}
	}

	componentDidUpdate(prevProps, prevState, snapshot) {
		if (this.state.isLoading) {
			this.accountsPollingService.startPolling(this.props.dispatch)
		} else {
			this.providerAccountPollingService.endPolling()
			this.accountsPollingService.endPolling()
		}
		this.handleBackIconVisiblity()
	}

	selectionOnChange(selectedItem) {
		console.log(selectedItem)
		let temp = Object.assign({}, this.state.selectedAccounts)
		delete temp[selectedItem.id]
		if (selectedItem.clearList) {
			temp = {}
		}
		if (selectedItem.checked) {
			temp[selectedItem.id] = selectedItem.checked
		}
		this.setState({ selectedAccounts: temp })
	}

	allSelectionOnChange(selectedItem) {
		if (selectedItem.checked) {
			let selectedList = {}

			/* Description: This the all selected check is done only on the VERIFICATION_ELIGIBLE_CONTAINERS
			 */
			let verficationEligibleContainers = getParam(
				AppParams.VERIFICATION_ELIGBLE_CONTAINERS
			)

			verficationEligibleContainers.forEach(container => {
				let lists = this.containerAccountList[container]
				for (let listIndex in lists) {
					selectedList[lists[listIndex].id] = true
				}
			})

			this.setState({ selectedAccounts: selectedList })
		} else {
			this.setState({ selectedAccounts: {} })
		}
	}

	render() {
		return (
			<div className="account-list-summary">
				<div className="accuount-summary-details">
					{this.allDeleted ? (
						<div className="delete-msg-wrapper text">
							<i className="fa fa-engine-warning"></i>
							{getString(
								AppStrings.ACCOUNT_SUMMARY_ALL_ACCOUNTS_DELETED_TEXT
							)}
						</div>
					) : (
						<ContainerList
							containerList={this.accountsContainerList}
							selectedAccounts={this.state.selectedAccounts}
							verifiedAccounts={this.data.verifiedAccounts}
							handleCloseAppHandler={
								this.props.handleCloseAppHandler
							}
							currentProvider={this.props.currentProvider}
							containerAccountList={this.containerAccountList}
							selectionOnChange={this.selectionOnChange.bind(
								this
							)}
							allSelectionOnChange={this.allSelectionOnChange.bind(
								this
							)}
							deleteCallback={this.deleteCallback.bind(this)}
							appflow={this.state.flow}
							deeplinkData={this.props.deeplinkData}
						></ContainerList>
					)}

					<SpinnerMsg
						isLoading={this.state.isLoading}
						primaryColor={this.props.currentProvider.hexCode1}
						secondaryColor={this.props.currentProvider.hexCode2}
					/>

					<ActSummaryButtons
						navigate={this.props.navigate}
						currentProvider={this.props.currentProvider}
						selectedAccounts={this.state.selectedAccounts}
						handleCloseAppHandler={this.props.handleCloseAppHandler}
						stopPolling={this.stopPolling.bind(this)}
						containerList={this.accountsContainerList}
						providerAccountId={this.data.providerAccountId}
						allDeleted={this.allDeleted}
						requestId={this.props.requestId}
						nextButtonCallback={this.updateFlowAndRerender.bind(
							this
						)}
						appflow={this.state.flow}
						deeplinkData={this.props.deeplinkData}
					/>

					{!(
						this.isDeeplink &&
						(this.deeplinkType ==
							DeeplinkConstants.FLOW_TYPES['REFRESH'] ||
							this.deeplinkType ==
								DeeplinkConstants.FLOW_TYPES[
									'EDIT_CREDENTIALS'
								])
					) && (
						<ActSummaryHelpText
							disableBottomText={this.disableBottomText}
							institutionName={this.institutionName}
							containerList={this.accountsContainerList}
							primaryColor={this.props.currentProvider.hexCode1}
							appflow={this.state.flow}
						/>
					)}

					{getParam(AppParams.ENABLE_CDV) ? (
						<div className="cdv-account-summary-container">
							<CDVModule
								navigate={this.props.navigate}
								provider={this.props.currentProvider}
								path={AppConstants.CDV_PATH_INVOKE}
								subPath={
									AppConstants.CDV_SUB_PATH_INVOKE_POST_VERIFICATION
								}
							/>
						</div>
					) : null}
				</div>
			</div>
		)
	}
}

const mapStateToProps = state => {
	return {
		status: state.refresh.status,
		additionalStatus: state.refresh.additionalStatus,
		accountsResponse: state.accounts.response,
		deeplinkData: state.deeplink
	}
}
export default connect(mapStateToProps, null)(AccountListView)
