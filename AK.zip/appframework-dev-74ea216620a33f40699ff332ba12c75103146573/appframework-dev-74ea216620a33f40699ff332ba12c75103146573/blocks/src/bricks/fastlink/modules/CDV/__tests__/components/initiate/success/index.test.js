import React from 'react'
import CDVInitiateSuccessView from './../../../../components/initiate/success'
import { AppStrings, getString } from './../../../../../../conf'
import AppConstants from '../../../../../../conf/constants/AppConstants'

jest.mock('./../../../../../../conf')

describe('CDV Initiate View - Success View', () => {
	let container = null
	beforeEach(() => {
		container = null

		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.CDV_INITIATE_VERIFICATION_SUCCESS_TITLE:
					return 'Verification Started'
					break
				case AppStrings.CDV_INITIATE_VERIFICATION_SUCCESS_TEXT:
					return 'Small deposits and withdrawals, all less than one dollar will be made to your account in the next 2-4 days. When you see these transactions, you can complete the verfication.'
					break
				case AppStrings.CDV_INITIATE_VERIFICATION_SUCCESS_BUTTON_TEXT:
					return 'Close'
					break
				case AppStrings.CDV_INITIATE_VERIFICATION_INPROGRESS_TITLE:
					return 'Verification in Progress'
					break
				case AppStrings.CDV_INITIATE_VERIFICATION_INPROGRESS_TEXT:
					return 'The verification for your account is currently in progress. Please try again later.'
					break
				case AppStrings.CDV_INITIATE_VERIFICATION_INPROGRESS_BUTTON_TEXT:
					return 'Close'
					break
				default:
					break
			}
		})
	})

	it('Check whether success section is rendered in case of default status being passed', () => {
		act(() => {
			container = mount(<CDVInitiateSuccessView />)
		})
		expect(container.find('div.message-wrapper')).toHaveLength(1)
		expect(
			container.find('div.msg-container .initiate-success-btn')
		).toHaveLength(1)
		expect(container.find('div.msg-container .success-icon')).toHaveLength(
			1
		)
		expect(
			container.find('div.msg-container #initiate-success-text')
		).toHaveLength(1)
		expect(
			container.find('div.msg-container #initiate-success-title')
		).toHaveLength(1)

		expect(
			container.find('div.msg-container .initiate-success-btn').text()
		).toEqual('Close')
		expect(
			container.find('div.msg-container #initiate-success-text').text()
		).toEqual(
			'Small deposits and withdrawals, all less than one dollar will be made to your account in the next 2-4 days. When you see these transactions, you can complete the verfication.'
		)
		expect(
			container.find('div.msg-container #initiate-success-title').text()
		).toEqual('Verification Started')
	})

	it('Check whether success section is rendered in case of INPROGRESS status being passed', () => {
		act(() => {
			container = mount(
				<CDVInitiateSuccessView
					status={AppConstants.CDV_INITIATE_STATUS_INPROGRESS}
				/>
			)
		})
		expect(container.find('div.message-wrapper')).toHaveLength(1)
		expect(
			container.find('div.msg-container .initiate-success-btn')
		).toHaveLength(1)
		expect(container.find('div.msg-container .success-icon')).toHaveLength(
			1
		)
		expect(
			container.find('div.msg-container #initiate-success-text')
		).toHaveLength(1)
		expect(
			container.find('div.msg-container #initiate-success-title')
		).toHaveLength(1)

		expect(
			container.find('div.msg-container .initiate-success-btn').text()
		).toEqual('Close')
		expect(
			container.find('div.msg-container #initiate-success-text').text()
		).toEqual(
			'The verification for your account is currently in progress. Please try again later.'
		)
		expect(
			container.find('div.msg-container #initiate-success-title').text()
		).toEqual('Verification in Progress')
	})

	it('Check whether success section is rendered in case of SUCCESS status being passed', () => {
		act(() => {
			container = mount(
				<CDVInitiateSuccessView
					status={AppConstants.CDV_INITIATE_STATUS_SUCCESS}
				/>
			)
		})
		expect(container.find('div.message-wrapper')).toHaveLength(1)
		expect(
			container.find('div.msg-container .initiate-success-btn')
		).toHaveLength(1)
		expect(container.find('div.msg-container .success-icon')).toHaveLength(
			1
		)
		expect(
			container.find('div.msg-container #initiate-success-text')
		).toHaveLength(1)
		expect(
			container.find('div.msg-container #initiate-success-title')
		).toHaveLength(1)

		expect(
			container.find('div.msg-container .initiate-success-btn').text()
		).toEqual('Close')
		expect(
			container.find('div.msg-container #initiate-success-text').text()
		).toEqual(
			'Small deposits and withdrawals, all less than one dollar will be made to your account in the next 2-4 days. When you see these transactions, you can complete the verfication.'
		)
		expect(
			container.find('div.msg-container #initiate-success-title').text()
		).toEqual('Verification Started')
	})

	it('Check whether onClose CallBack is being called on clicking Close Button', () => {
		let onCloseCalled = false
		act(() => {
			container = mount(
				<CDVInitiateSuccessView
					onClose={function() {
						onCloseCalled = true
					}}
				/>
			)
		})
		expect(onCloseCalled).toEqual(false)
		container
			.find('div.msg-container .initiate-success-btn')
			.simulate('click')
		expect(onCloseCalled).toEqual(true)
	})
})
