import React, { Component } from 'react'
import { AppStrings, getString } from '../../../../fastlink/conf'
import { Modal } from '../../../../../framework/react/components/Modal'
import { Button } from '../../../../../framework/react/components/Button'
export default class SmartzipModal extends Component {
	constructor(props) {
		super(props)
		this.coBrandName = getString('CobrandName')
	}
	render() {
		return (
			<Modal
				backDropEnabled={true}
				onBackDropClick={() => this.props.showHideSmartzipPopup(false)}
				crossIconEnabled={true}
				show={true}
				className="small"
				onCrossIconClick={() => this.props.showHideSmartzipPopup(false)}
			>
				<h4 className="help-title" id="smartzip-modal-title">
					{getString(AppStrings.SMARTZIP_POPUP_HEADING)}
				</h4>
				<p className="help-text" id="smartzip-text-1">
					{getString(AppStrings.SMARTZIP_POPUP_TEXT_LINE1).replace(
						/_COBRAND_NAME_/g,
						this.coBrandName
					)}
				</p>
				<div className="modal-button-wrapper">
					<Button
						id="continue-smartzip"
						name="continue-smartzip"
						label={getString(AppStrings.POPUP_CONTINUE_BUTTON)}
						onClick={() => {
							window.open('http://smartzip.com/avm.cfm', '_blank')
							this.props.showHideSmartzipPopup(false)
						}}
						// autoid={AutoIds.ACCOUNT_SUMMARY_BUTTON_LINK_MORE_ACCOUNTS}
					/>
					<Button
						id="exit"
						name="exit"
						variant="danger"
						reversed={true}
						label={getString(AppStrings.POPUP_CANCEL_BUTTON)}
						onClick={() => {
							this.props.showHideSmartzipPopup(false)
						}}
						// autoid={AutoIds.ACCOUNT_SUMMARY_BUTTON_LINK_MORE_ACCOUNTS}
					/>
				</div>
			</Modal>
		)
	}
}
