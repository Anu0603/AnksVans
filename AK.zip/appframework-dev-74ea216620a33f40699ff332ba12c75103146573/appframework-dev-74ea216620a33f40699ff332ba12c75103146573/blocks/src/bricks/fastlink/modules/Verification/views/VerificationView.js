import React, { Component } from 'react'
import { connect } from 'react-redux'
import LoginRefreshView from './../components/LoginRefreshView'
import DataRefreshView from './../components/DataRefreshView'
import SuccessRefreshView from './../components/SuccessRefreshView'
import ProviderAccountPolling from './../../../concept/api/polling/ProviderAccountPolling'
import Constants from '../../../router/Constant'
import { AppParams, getParam } from './../../../conf'
import MatchingServiceView from './../components/MatchingServiceView'
import AccountsService from './../../../services/account/AccountsService'
import Postmessage from './../../../components/ExternalNotification'
import ProviderAccountService from '@fastlinkRoot/services/provider/ProviderAccountService'
import ProviderDetailsServices from '@fastlinkRoot/services/provider/ProviderDetailsServices'
import TechErrorConstants from '../../../components/Error/TechnicalError/TechErrorConstants'

class VerificationView extends Component {
	constructor(props) {
		super(props)
		let requestParams = this.props

		this.state = {
			providerId: requestParams.providerId
				? requestParams.providerId
				: requestParams.currentProvider
				? requestParams.currentProvider.id
				: null,
			status: requestParams.status,
			navigationStatus: requestParams.status,
			additionalStatus: requestParams.additionalStatus,
			providerAccountId: requestParams.providerAccountId,
			requestId: requestParams.requestId,

			verifiedAccounts: []
		}

		this.isSuccessCalled = false
		this.currentStatus = requestParams.status
		this.accountsService = new AccountsService()
		this.providerAccountService = new ProviderAccountService()
		this.providerDetailsServices = new ProviderDetailsServices()
		this.redirectionAddStatusList = this.getRedirectionStatusList()
		this.disableSuccessPage = getParam(
			AppParams.DISABLE_VERIFICATION_SUCCESS_PAGE
		)
		this.isMSFlow = FLUtil.isMSFlowEnabled()
		this.updateCurrentStatus(this.state)

		this.isVerificationFlow = true
		this.isAggregationFlow = false
		if (
			getParam(AppParams.PRODUCT_TYPE) ==
			AppConstants.AGGREGATION_FLOW_NAME
		) {
			this.isVerificationFlow = false
			this.isAggregationFlow = true
		}
	}

	getRedirectionStatusList() {
		let redirectionAddStatusList = [
			'AVAILABLE_DATA_RETRIEVED',
			'ACCT_SUMMARY_RECEIVED'
		]

		if (
			AppConstants.VERIFICATION_FLOW_NAME == FLUtil.getFlowName() ||
			AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME ===
				FLUtil.getFlowName()
		) {
			redirectionAddStatusList.pop()
		}
		return redirectionAddStatusList
	}

	componentDidMount() {
		if (this.state.providerId) {
			this.startPolling()
		} else {
			this.getProviderAccountDetails()
		}
	}

	getProviderAccountDetails() {
		this.providerAccountService
			.getProviderAccountDetails({
				providerAccountId: this.state.providerAccountId
			})
			.then(
				this.getProviderDetails.bind(this),
				this.providerAccountDetailsErrorHandler.bind(this)
			)
	}

	providerAccountDetailsErrorHandler(_response) {
		if (_response.details && _response.details.errorCode == 'Y825') {
			let errordata = {
				errorOccured: true,
				errorCode: AppConstants.UPDATE_NOT_ALLOWED,
				providerAccountId: this.state.providerAccountId,
				currentProvider: this.props.currentProvider
			}

			if (
				_response.details.errorMessage &&
				_response.details.errorMessage
					.toUpperCase()
					.includes(AppConstants.REFRESHED_RECENTLY_API_TAG)
			) {
				errordata.errorCode = AppConstants.REFRESH_TOO_SOON
			} else if (
				_response.details.errorMessage &&
				_response.details.errorMessage
					.toUpperCase()
					.includes(AppConstants.DATA_RETRIEVAL_API_TAG)
			) {
				errordata.errorCode = AppConstants.REFRESH_ALREADY_IN_PROCESS
			}
			this.props.navigate(Constants.ROUTE_ERROR_MODULE, errordata)
		} else {
			this.props.handleTechDiff(
				TechErrorConstants.getAPIError(
					_response.details,
					TechErrorConstants.API_TYPE.PROVIDER_ACCOUNT_DETAILS
				)
			)
		}
	}

	getProviderDetails(_response) {
		this.setState({
			providerId: _response.providerId,
			requestId: _response.requestId,
			status: _response.status,
			navigationStatus: _response.status,
			additionalStatus: _response.additionalStatus
		})

		// TODO
		this.requestId = _response.requestId

		this.providerDetailsServices
			.getProvidersDetails({
				providerId: _response.providerId
			})
			.then(
				this.setProviderDetails.bind(this),
				this.providerDetailsErrorHandler.bind(this)
			)
	}

	setProviderDetails(_response) {
		this.props.dispatch({
			type: 'SELECTED_PROVIDER_DATA',
			payload: _response
		})
		this.startPolling()
	}

	providerDetailsErrorHandler(response) {
		this.props.handleTechDiff(TechErrorConstants.GENERIC_API_ERROR)
	}

	componentWillUnmount() {
		this.stopPolling()
	}

	startPolling() {
		this.providerAccountPollingService = new ProviderAccountPolling(
			this.state.providerId,
			this.state.providerAccountId,
			this.state.requestId ? this.state.requestId : this.requestId
		)
		this.providerAccountPollingService.startPolling(this.props.dispatch)
	}

	stopPolling() {
		if (this.providerAccountPollingService) {
			this.providerAccountPollingService.endPolling()
		}
	}

	getAccountDetails(dispatch) {
		this.accountsService.getAccounts(
			{
				providerAccountId: this.state.providerAccountId,
				status: 'ACTIVE'
			},
			this.setAccounts.bind(this, dispatch)
		)
	}

	setAccounts(dispatch, _error, _response) {
		if (this.isVerificationFlow) {
			let verficationEligibleContainers = getParam(
				AppParams.VERIFICATION_ELIGBLE_CONTAINERS
			)
			let accountsCount = 0
			let response = _response
			verficationEligibleContainers.forEach(container => {
				accountsCount =
					accountsCount +
					(response[container] && response[container].length
						? response[container].length
						: 0)
			})

			if (accountsCount) {
				this.currentStatus = 'SUCCESS_PAGE'
			} else {
				this.stopPolling()
				let errordata = {
					errorCode: AppConstants.NO_ACCOUNTS_FOR_VERIFICATION,
					providerAccountId: this.state.providerAccountId,
					loginUrl: this.props.currentProvider.loginUrl,
					currentProvider: this.props.currentProvider
				}
				this.props.navigate(Constants.ROUTE_ERROR_MODULE, errordata)
			}
			this.isVerificationFlow = false
		}

		this.props.dispatch({
			type: 'FETCH_ACCOUNTS',
			payload: {
				response: _response
			}
		})
	}

	isSuccessOrMatchingStarted(state) {
		return !(
			state.currentStatus == 'SUCCESS_PAGE' ||
			state.currentStatus == 'INITIATE_MATCHING'
		)
	}

	isRediectORInitiateMatchingService(state) {
		return (
			(state.navigationStatus == 'IN_PROGRESS' &&
				this.redirectionAddStatusList.indexOf(state.additionalStatus) !=
					-1) ||
			state.navigationStatus == 'SUCCESS' ||
			state.navigationStatus == 'PARTIAL_SUCCESS'
		)
	}

	setNavigationStatus(nextNavigationStatusDetails) {
		this.setState(nextNavigationStatusDetails)
	}

	onRefreshSuccess(nextProps) {
		let tempProps = Object.assign({}, nextProps)
		tempProps.verifiedAccounts = this.state.verifiedAccounts
		this.props.navigate(Constants.ROUTE_ACCOUNT_SUMMARY_MODULE, tempProps)
	}

	onRefreshFailure(nextState) {
		let errordata = {
			errorOccured: true,
			errorCode: nextState.additionalStatus,
			providerAccountId: nextState.providerAccountId,
			loginUrl: this.props.currentProvider.loginUrl,
			currentProvider: this.props.currentProvider
		}

		let routingModule = Constants.ROUTE_ERROR_MODULE

		if (nextState.additionalStatus == 'INCORRECT_CREDENTIALS') {
			routingModule = Constants.ROUTE_LOGIN_MODULE
			errordata.siteInfo = this.props.currentProvider
		}

		this.props.navigate(routingModule, errordata)
	}

	updateCurrentStatus(state) {
		let status = null
		switch (state.navigationStatus) {
			case 'SUCCESS':
			case 'PARTIAL_SUCCESS':
			case 'IN_PROGRESS':
				if (
					this.isRediectORInitiateMatchingService(state) &&
					this.isSuccessOrMatchingStarted(state)
				) {
					if (this.isVerificationFlow) {
						status = 'VERIFICATION_FLOW_SUCCESS_PAGE'
					} else {
						status = 'SUCCESS_PAGE'
					}
					if (this.isMSFlow) {
						status = 'INITIATE_MATCHING'
					}
				} else if (
					state.navigationStatus == 'IN_PROGRESS' &&
					this.redirectionAddStatusList.indexOf(
						state.additionalStatus
					) <= -1
				) {
					status = state.navigationStatus
				}
				break

			case 'MATCHING_COMPLETED':
				status = 'SUCCESS_PAGE'
				break

			case 'ACCOUNT_SUMMARY':
			case 'USER_INPUT_REQUIRED':
			case 'FAILED':
				status = state.navigationStatus
				break

			case 'MATCHING_FAILED':
				status = 'FAILED'
				break
		}

		if (status) {
			this.currentStatus = status
			if (this.disableSuccessPage && status == 'SUCCESS_PAGE') {
				this.currentStatus = 'ACCOUNT_SUMMARY'
			}
		}
	}

	static getDerivedStateFromProps(nextProps, prevState) {
		Postmessage.addUpdateProviderAccountsData({
			status: nextProps.status,
			requestId: nextProps.requestId,
			additionalStatus: nextProps.additionalStatus,
			providerAccountId: nextProps.providerAccountId
		})

		let nextStateUpdate = {
			status: nextProps.status,
			navigationStatus: nextProps.status,
			requestId: nextProps.requestId,
			additionalStatus: nextProps.additionalStatus
		}
		// Don't update state  if navigation status got changed through manually
		if (
			prevState.navigationStatus == 'MATCHING_COMPLETED' ||
			prevState.navigationStatus == 'MATCHING_FAILED' ||
			prevState.navigationStatus == 'ACCOUNT_SUMMARY'
		) {
			return null
		}

		//console.log("nextStateUpdate" + JSON.stringify(nextStateUpdate));
		return nextStateUpdate
	}

	shouldComponentUpdate(nextProps, nextState) {
		//console.log("nextState" + JSON.stringify(nextState));
		this.updateCurrentStatus(nextState)
		if (nextProps.requestId) {
			this.providerAccountPollingService.requestId = nextProps.requestId
		}
		//console.log("nextState" + JSON.stringify(this.currentStatus));
		let shoulUpdate = true
		switch (this.currentStatus) {
			case 'ACCOUNT_SUMMARY':
				this.stopPolling()
				this.onRefreshSuccess(this.props)
				shoulUpdate = false
				break

			case 'FAILED':
				this.stopPolling()
				this.onRefreshFailure(nextState)
				shoulUpdate = false
				break

			case 'USER_INPUT_REQUIRED':
				this.stopPolling()
				this.props.navigate(Constants.ROUTE_MFA_MODULE, {
					mfaLoginForm: nextProps.mfaLoginForm[0],
					providerAccountId: this.state.providerAccountId,
					requestId: this.state.requestId
				})
				shoulUpdate = false
				break

			case 'VERIFICATION_FLOW_SUCCESS_PAGE':
				if (this.isVerificationFlow) {
					this.getAccountDetails()
				}
				break

			case 'SUCCESS_PAGE':
				if (!this.isSuccessCalled) {
					this.stopPolling()
					if (this.isAggregationFlow) {
						this.getAccountDetails()
					}
					setTimeout(
						() =>
							this.setNavigationStatus({
								navigationStatus: 'ACCOUNT_SUMMARY'
							}),
						getParam(AppParams.SUCCESS_PAGE_STAY_TIME)
					)
				}
				this.isSuccessCalled = true
				break

			case 'INITIATE_MATCHING':
				this.stopPolling()
				break
		}
		return shoulUpdate
	}

	renderRefreshView() {
		let _refreshView = null
		let _status = this.currentStatus
		switch (_status) {
			case 'LOGIN_IN_PROGRESS':
				_refreshView = <LoginRefreshView {...this.props} />
				break

			case 'VERIFICATION_FLOW_SUCCESS_PAGE':
			case 'IN_PROGRESS':
				_refreshView = <DataRefreshView {...this.props} />
				break

			case 'SUCCESS_PAGE':
				_refreshView = <SuccessRefreshView {...this.props} />
				break

			case 'ACCOUNT_SUMMARY':
				_refreshView = <SuccessRefreshView {...this.props} />
				break

			case 'INITIATE_MATCHING':
				_refreshView = (
					<MatchingServiceView
						{...this.props}
						disableSuccessPage={this.disableSuccessPage}
						setNavigationStatus={this.setNavigationStatus.bind(
							this
						)}
					/>
				)
				break

			default:
				_refreshView = <LoginRefreshView {...this.props} />
				break
		}
		return _refreshView
	}

	render() {
		return <React.Fragment>{this.renderRefreshView()}</React.Fragment>
	}
}

const mapStateToProps = state => {
	return {
		status: state.refresh.status,
		additionalStatus: state.refresh.additionalStatus,
		mfaLoginForm: state.refresh.mfaLoginForm,
		currentProvider: state.currentProvider
	}
}

export default connect(mapStateToProps, null)(VerificationView)
