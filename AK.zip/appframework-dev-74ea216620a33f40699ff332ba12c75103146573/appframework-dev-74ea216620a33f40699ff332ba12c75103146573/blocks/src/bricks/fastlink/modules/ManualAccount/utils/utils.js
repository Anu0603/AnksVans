import {
	AppStrings,
	getString,
	AppParams,
	getParam
} from '../../../../fastlink/conf'

const getCurrencyDropdownOptions = currencyOptionsParams => {
	if (currencyOptionsParams) {
		return currencyOptionsParams.map(option => {
			return {
				displayText: getString('currency_' + option.toLowerCase()),
				optionValue: option
			}
		})
	}
}

const getAccountTypeOptions = c => {
	const options = accountTypes.map(acct => {
		if (acct.name === c) {
			return {
				displayText: acct.name,
				optionValue: acct.value,
				selected: true
			}
		} else {
			return {
				displayText: acct.name,
				optionValue: acct.value,
				selected: false
			}
		}
	})

	return options
}

const getAccountTypeContainer = c => {
	return accountTypes
		.filter(acct => acct.value === c)
		.map(item => item.container)
}

const getFrequencyOptions = () => {
	const freq = [
		'one time',
		'daily',
		'weekly',
		'every 2 weeks',
		'twice every month',
		'monthly every 2 months',
		'every 3 months',
		'half yearly',
		'yearly'
	]

	const options = freq.map(f => {
		return {
			displayText: f,
			optionValue: f
		}
	})

	return options
}

const accountTypes = [
	{
		name: 'Savings',
		value: 'SAVINGS',
		container: 'bank',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'balance',
			'currency',
			'includeInNetWorth',
			'memo'
		],
		requiredFields: ['accountType', 'accountName']
	},
	{
		name: 'Checking',
		value: 'CHECKING',
		container: 'bank',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'balance',
			'currency',
			'includeInNetWorth',
			'memo'
		],
		requiredFields: ['accountType', 'accountName']
	},
	{
		name: 'CD',
		value: 'CD',
		container: 'bank',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'balance',
			'currency',
			'includeInNetWorth',
			'memo'
		],
		requiredFields: ['accountType', 'accountName']
	},
	{
		name: 'Prepaid',
		value: 'PREPAID',
		container: 'bank',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'balance',
			'currency',
			'includeInNetWorth',
			'memo'
		],
		requiredFields: ['accountType', 'accountName']
	},
	{
		name: 'Bills',
		value: 'BILLS',
		container: 'bill',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'amountDue',
			'balance',
			'currency',
			'dueDate',
			'memo'
		],
		requiredFields: ['accountType', 'accountName', 'dueDate']
	},
	{
		name: 'Credit',
		value: 'CREDIT',
		container: 'creditCard',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'amountDue',
			'balance',
			'currency',
			'includeInNetWorth',
			'dueDate',
			'memo'
		],
		requiredFields: ['accountType', 'accountName', 'dueDate']
	},
	{
		name: 'Insurance',
		value: 'INSURANCE',
		container: 'insurance',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'amountDue',
			'balance',
			'currency',
			'includeInNetWorth',
			'dueDate',
			'memo'
		],
		requiredFields: ['accountType', 'accountName', 'dueDate']
	},
	{
		name: 'Brokerage Cash',
		value: 'BROKERAGE_CASH',
		container: 'investment',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'balance',
			'currency',
			'includeInNetWorth',
			'memo'
		],
		requiredFields: ['accountType', 'accountName']
	},
	{
		name: 'Annuity',
		value: 'ANNUITY',
		container: 'investment',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'balance',
			'currency',
			'includeInNetWorth',
			'memo'
		],
		requiredFields: ['accountType', 'accountName']
	},
	{
		name: 'Personal Loan',
		value: 'PERSONAL_LOAN',
		container: 'loan',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'amountDue',
			'balance',
			'currency',
			'includeInNetWorth',
			'dueDate',
			'memo'
		],
		requiredFields: ['accountType', 'accountName', 'dueDate']
	},
	{
		name: 'Home Loan',
		value: 'HOME_LOAN',
		container: 'loan',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'amountDue',
			'balance',
			'currency',
			'includeInNetWorth',
			'dueDate',
			'memo'
		],
		requiredFields: ['accountType', 'accountName', 'dueDate']
	},
	{
		name: 'Other Assets',
		value: 'OTHER_ASSETS',
		container: 'otherAssets',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'balance',
			'currency',
			'includeInNetWorth',
			'memo'
		],
		requiredFields: ['accountType', 'accountName', 'balance']
	},
	{
		name: 'Other Liabilities',
		value: 'OTHER_LIABILITIES',
		container: 'otherLiabilities',
		displayFields: [
			'accountType',
			'accountName',
			'nickname',
			'accountNumber',
			'balance',
			'currency',
			'includeInNetWorth',
			'memo'
		],
		requiredFields: ['accountType', 'accountName', 'balance']
	}
]

const fields = [
	{
		id: 'account-name',
		name: 'accountName',
		type: 'text',
		properties: {
			value: '',
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Account Name',
			default: '',
			maxLength: 50
		}
	},
	{
		id: 'account-number',
		name: 'accountNumber',
		type: 'text',
		properties: {
			value: '',
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Account Number',
			default: ''
		}
	},
	{
		id: 'amount-due',
		name: 'amountDue',
		type: 'text',
		properties: {
			value: '',
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Amount Due',
			default: ''
		}
	},
	// {
	//   name: "assetVsLiability",
	//   type: "radio",
	//   properties: {
	//     value: "asset",
	//     options: [
	//       {
	//         id: "option-asset",
	//         name: "asset-vs-liability",
	//         value: "asset",
	//         label: "Asset",
	//         checked: true
	//       },
	//       {
	//         id: "option-liability",
	//         name: "asset-vs-liability",
	//         value: "liability",
	//         label: "Liability",
	//         checked: false
	//       }
	//     ]
	//   }
	// },
	{
		id: 'balance',
		name: 'balance',
		type: 'text',
		properties: {
			value: '',
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Balance',
			default: ''
		}
	},
	{
		id: 'currency',
		name: 'currency',
		type: 'dropdown',
		properties: {
			value: '',
			options: getCurrencyDropdownOptions(),
			default: 'USD',
			placeholder: 'Currency'
		}
	},
	// {
	//   name: "frequency",
	//   type: "dropdown",
	//   properties: {
	//     value: "",
	//     options: getFrequencyOptions(),
	//     default: ""
	//   }
	// },
	{
		id: 'include-in-net-worth',
		name: 'includeInNetWorth',
		type: 'toggle',
		properties: {
			value: false,
			options: [
				{
					id: 'option-asset',
					name: 'include-in-net-worth',
					value: true,
					checked: true
				},
				{
					id: 'option-liability',
					name: 'include-in-net-worth',
					value: false,
					checked: false
				}
			]
		}
	},
	{
		id: 'memo',
		name: 'memo',
		type: 'text',
		properties: {
			value: '',
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Memo',
			default: ''
		}
	},
	{
		id: 'due-date',
		name: 'dueDate',
		type: 'datepicker',
		properties: {
			value: '',
			placeholder: 'Next Due Date (MM/DD/YYYY)',
			minDate: new Date()
		}
	},
	{
		id: 'nickname',
		name: 'nickname',
		type: 'text',
		properties: {
			value: '',
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Nickname',
			default: '',
			maxLength: 50
		}
	}
]

const getFields = c => {
	let selectedAccountType = accountTypes.filter(obj => obj.value === c)
	let displayFields = fields
		.filter(f => {
			return selectedAccountType[0].displayFields.includes(f.name)
		})
		.sort((a, b) => {
			return (
				selectedAccountType[0].displayFields.indexOf(a.name) -
				selectedAccountType[0].displayFields.indexOf(b.name)
			)
		})
	let requiredFields = fields.filter(f => {
		return selectedAccountType[0].requiredFields.includes(f.name)
	})

	let setAllFields = () => {
		displayFields.map(obj => {
			obj.properties.required = false

			if (obj.type === 'text') {
				let hasOptional = obj.properties.placeholder.includes(
					'(optional)'
				)
				let removeOptional = hasOptional
					? obj.properties.placeholder.split(' (optional)', 1)[0]
					: obj.properties.placeholder

				/* Resets field values */
				obj.properties.value = ''

				/* Sets required/non-required fields and placeholders */
				if (requiredFields.indexOf(obj) > -1) {
					obj.properties.placeholder = removeOptional
				} else {
					obj.properties.placeholder = removeOptional + ' (optional)'
				}
			}

			return obj
		})

		let rq = displayFields
			.filter(f => requiredFields.includes(f))
			.map(obj => {
				obj.properties.required = true
				return obj
			})

		if (rq.length) {
			return Object.assign(rq, displayFields)
		} else {
			return displayFields
		}
	}

	return setAllFields()
}

const getResponse = accountDetails => {
	accountDetails.currency = accountDetails.homeValue.currency
	accountDetails.currencyOptions = this.state.currencyOptions.map(item => {
		item.selected =
			item.optionValue === accountDetails.homeValue.currency
				? true
				: false
		return item
	})
}

export default {
	getCurrencyDropdownOptions,
	getAccountTypeOptions,
	getAccountTypeContainer,
	getFrequencyOptions,
	getFields,
	getResponse
}
