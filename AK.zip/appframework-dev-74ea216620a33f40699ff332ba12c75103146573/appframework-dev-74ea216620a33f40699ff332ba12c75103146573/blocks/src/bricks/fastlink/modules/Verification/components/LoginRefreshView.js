import React, { Component } from "react";
import { AppStrings, getString, AutoIds } from "../../../conf";
import { Spinner } from "./../../../../../framework/react/components/Spinner";

class LoginRefreshView extends Component {
    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div className="login-message-wrapper flex-center" autoid={AutoIds.VERIFICATION_LOGIN_STEPPER_CONTAINER}>
                <Spinner
                    id="login-spinner"
                    size="lg"
                    color={this.props.currentProvider.hexCode2}
                    circleColor='#ffffff'
                    class="login-spinner"
                    children={
                        <div id="login-refresh-label" className="login-refresh-label">
                            {getString(AppStrings.VERIFICATION_LOGIN_STEPPER_TEXT)}
                        </div>
                    }
                />
            </div>
        );
    }

}

export default LoginRefreshView;