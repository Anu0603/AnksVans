import { CheckBox } from './../../../../../../framework/react/components/CheckBox'
import React, { Component } from 'react'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../conf'

const EnableAllAccounts = props => {
	let accountSelectionHandler = checked => {
		props.allSelectionOnChange({ checked: checked })
	}

	let checkBoxProps = {
		checked: props.checked,
		hexCode1: props.currentProvider.hexCode1,
		hexCode2: props.currentProvider.hexCode2,
		onChange: accountSelectionHandler.bind(this)
	}
	let key = 'check-all'
	if (props.checked) {
		key = key + ' checked'
	}
	const inlineStyle = {
		color: props.currentProvider.hexCode1
	}
	return (
		<div
			className="enable-all-wrapper"
			autoid="iav-all-enable-accounts"
			style={inlineStyle}
		>
			{getString('account_summary_enbale_all_text')}
			<CheckBox key={key} {...checkBoxProps} />
		</div>
	)
}

export default EnableAllAccounts
