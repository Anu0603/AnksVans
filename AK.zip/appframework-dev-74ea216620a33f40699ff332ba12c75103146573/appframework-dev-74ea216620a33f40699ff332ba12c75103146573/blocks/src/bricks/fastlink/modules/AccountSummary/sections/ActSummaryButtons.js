import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../conf'
import React, { useState } from 'react'
import ProviderAccountService from '../../../services/provider/ProviderAccountService'
import { Button } from '../../../../../framework/react/components/Button'
import { Modal } from '../../../../../framework/react/components/Modal'
import Constants from '../../../router/Constant'
import AppConstants from '../../../conf/constants/AppConstants'
import Postmessage from './../../../components/ExternalNotification'
import DeeplinkConstants from '@fastlinkRoot/filters/deeplink/DeeplinkConstants'

const ActSummaryButtons = props => {
	const containerLength =
		props.containerList && Object.keys(props.containerList).length
	let eventCapture = null

	if ((containerLength == 0 || !containerLength) && !props.allDeleted) {
		return <React.Fragment></React.Fragment>
	}

	const providerAccountService = new ProviderAccountService()

	const saveNLikMoreAccounts = () => {
		props.navigate(Constants.ROUTE_LANDING_MODULE)
	}

	const saveNFinish = event => {
		eventCapture = event
		props.handleCloseAppHandler(eventCapture)
	}

	let [cnfPopupState, cnfPopupStateSetState] = useState({
		showPopup: false
	})

	const showHidePopUp = flag => {
		cnfPopupStateSetState({
			showPopup: flag
		})
	}

	const deleteProviderAccountCallBack = (_error, _response) => {
		if (!_error) {
		}
	}

	const cancelExitHandler = function(event) {
		eventCapture = event
		props.stopPolling()
		providerAccountService.deleteProviderAccount(
			{ providerAccountId: props.providerAccountId },
			deleteProviderAccountCallBack.bind(this)
		)
		Postmessage.addUpdateProviderAccountsData({
			status: 'DELETED',
			reason:
				'User canceled the linking process confirming account deletion.',
			requestId: props.requestId,
			// additionalStatus: "DELETED",
			providerAccountId: props.providerAccountId
		})
		props.handleCloseAppHandler(eventCapture)
	}

	const disablePopupOnCancel = getParam(AppParams.DISABLE_POPUP_ON_CANCEL)
	const disableLinkMoreAdd = getParam(AppParams.DISABLE_LINK_MORE_FOR_ADD)
	const disabelLinkMoreEdit = getParam(AppParams.DISABLE_LINK_MORE_FOR_EDIT)
	const disabelLinkMoreRefresh = getParam(
		AppParams.DISABLE_LINK_MORE_FOR_REFRESH
	)
	const disabelLinkMoreStandard = getParam(
		AppParams.DISABLE_LINK_MORE_FOR_STANDARD
	)

	const isDisplayDeleteConfPopUp = event => {
		if (disablePopupOnCancel) {
			cancelExitHandler(event)
		} else {
			showHidePopUp(true)
		}
	}

	let linMoreBtnText = getString(
		AppStrings.ACCOUNT_SUMMARY_SAVE_AND_LINK_MORE_ACCOUNTS_BUTTON_TEXT
	)
	let autoId = AutoIds.ACCOUNT_SUMMARY_BUTTON_SAVENLINKMOREACCOUNTS
	if (props.allDeleted) {
		linMoreBtnText = getString(
			AppStrings.ACCOUNT_SUMMARY_LINK_MORE_ACCOUNTS_BUTTON_TEXT
		)
		autoId = AutoIds.ACCOUNT_SUMMARY_BUTTON_LINK_MORE_ACCOUNTS
	}
	let productType = getParam(AppParams.PRODUCT_TYPE)

	let showLinkMoreAccountsButton = true

	/* Description: The below condition is to show/hide the link more accounts button
	 */

	if (productType === AppConstants.AGGREGATION_FLOW_NAME) {
		showLinkMoreAccountsButton = true
	} else {
		if (getParam(AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION)) {
			showLinkMoreAccountsButton = false
			if (
				productType ==
					AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME &&
				props.appflow === AppConstants.APP_FLOW_AGGREGATION
			) {
				showLinkMoreAccountsButton = true
			}
		} else {
			showLinkMoreAccountsButton = true
			if (
				productType ==
					AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME &&
				props.appflow === AppConstants.APP_FLOW_VERIFICATION
			) {
				showLinkMoreAccountsButton = false
			}
		}
	}

	let isSaveFineBtnDisabled = false
	if (
		productType == AppConstants.VERIFICATION_FLOW_NAME &&
		Object.keys(props.selectedAccounts).length == 0
	) {
		isSaveFineBtnDisabled = true
	}

	/* Description: The isNextBtnDisable variable is set to true only when the at least one
	 * account is selected. Or if there is only one account.
	 */
	let isNextBtnDisable = false
	if (
		productType == AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME &&
		Object.keys(props.selectedAccounts).length == 0
	) {
		isNextBtnDisable = true
	}

	let bgColorInline = {
		backgroundColor: props.currentProvider.hexCode1
	}
	let bgColorInlineSecondary = {
		backgroundColor: props.currentProvider.hexCode2
	}

	const isDeeplink = props.deeplinkData
		? props.deeplinkData.isDeeplink
		: false
	const deeplinkType = isDeeplink ? props.deeplinkData.deeplinkType : null
	const isEditRefreshDeeplink =
		isDeeplink &&
		(deeplinkType == DeeplinkConstants.FLOW_TYPES['REFRESH'] ||
			deeplinkType == DeeplinkConstants.FLOW_TYPES['EDIT_CREDENTIALS'])

	/* Description: showNextButton() returns the NEXT button when then PRODUCT_TYPE is
	 * IAV+AGG and the app-flow is "VERIFICATION". Otherwise this returns null.
	 */
	let showNextButton = () => {
		if (
			productType ==
				AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME &&
			props.appflow === AppConstants.APP_FLOW_VERIFICATION
		) {
			return (
				<Button
					id="next-btn"
					name="next-btn"
					style={bgColorInline}
					label={'NEXT'}
					disabled={isNextBtnDisable}
					onClick={props.nextButtonCallback.bind(this)}
					autoid={'ToDO'}
				/>
			)
		} else {
			return null
		}
	}

	/* Description: showSaveAndFinishButton() returns the save&Finish button.
	 */
	let showSaveAndFinishButton = () => {
		if (!props.allDeleted) {
			if (
				productType == AppConstants.VERIFICATION_FLOW_NAME ||
				productType == AppConstants.AGGREGATION_FLOW_NAME ||
				(productType ==
					AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME &&
					props.appflow === AppConstants.APP_FLOW_AGGREGATION)
			) {
				return (
					<Button
						id="save-finish-btn"
						name="save-finish-btn"
						style={bgColorInline}
						label={getString(
							AppStrings.ACCOUNT_SUMMARY_SAVE_AND_FINISH_BUTTON_TEXT
						)}
						disabled={isSaveFineBtnDisabled}
						onClick={saveNFinish.bind(this)}
						autoid={AutoIds.ACCOUNT_SUMMARY_BUTTON_SAVENFINISH}
					/>
				)
			} else return null
		} else return null
	}

	let showLinkMoreAccountButton = () => {
		if (showLinkMoreAccountsButton && !isEditRefreshDeeplink) {
			return (
				<Button
					id="link-more-acocunt-btn"
					name="link-more-acocunt-btn"
					variant="secondary"
					style={
						props.allDeleted
							? bgColorInline
							: bgColorInlineSecondary
					}
					label={linMoreBtnText}
					onClick={saveNLikMoreAccounts.bind(this)}
					autoid={autoId}
				/>
			)
		} else return null
	}

	let showCancelButton = () => {
		if (!isEditRefreshDeeplink) {
			return (
				<Button
					id="cancel-btn"
					name="cancel-btn"
					variant="tertiary"
					label={getString(
						AppStrings.ACCOUNT_SUMMARY_CANCEL_BUTTON_TEXT
					)}
					onClick={isDisplayDeleteConfPopUp.bind(this)}
					autoid={AutoIds.ACCOUNT_SUMMARY_BUTTON_CANCEL}
				/>
			)
		} else return null
	}

	return (
		<div className="button-container">
			{showNextButton()}
			{showSaveAndFinishButton()}
			{showLinkMoreAccountButton()}
			{showCancelButton()}

			{cnfPopupState.showPopup && (
				<Modal
					backDropEnabled={true}
					onBackDropClick={() => showHidePopUp(false)}
					crossIconEnabled={true}
					show={cnfPopupState.showPopup}
					className="small custom-align"
					onCrossIconClick={() => showHidePopUp(false)}
				>
					<div style={{ color: props.currentProvider.hexCode1 }}>
						<div>
							{' '}
							{getString(
								AppStrings.ACCOUNT_SUMMARY_CANCEL_POPUP_CONFIRMATION_TEXT_1
							)}{' '}
						</div>
						<div>
							{' '}
							{getString(
								AppStrings.ACCOUNT_SUMMARY_CANCEL_POPUP_CONFIRMATION_TEXT_2
							)}{' '}
						</div>
					</div>
					<div className="modal-button-wrapper">
						<Button
							id="continue-linking-accounts"
							name="continue-linking-accounts"
							style={bgColorInline}
							label={getString(
								AppStrings.ACCOUNT_SUMMARY_CANCEL_POPUP_CONTINUE_LINKING_ACCOUNTS_BUTTON_TEXT
							)}
							onClick={showHidePopUp.bind(this, false)}
							autoid={
								AutoIds.ACCOUNT_SUMMARY_BUTTON_LINK_MORE_ACCOUNTS
							}
						/>
						<Button
							id="exit"
							name="exit"
							variant="danger"
							reversed={true}
							label={getString(
								AppStrings.ACCOUNT_SUMMARY_DELETE_POPUP_EXIT_BUTTON_TEXT
							)}
							onClick={cancelExitHandler.bind(this)}
							autoid={
								AutoIds.ACCOUNT_SUMMARY_BUTTON_LINK_MORE_ACCOUNTS
							}
						/>
					</div>
				</Modal>
			)}
		</div>
	)
}

export default ActSummaryButtons
