import React, { useState } from 'react'
import {
	getString,
	AppStrings,
	AutoIds,
	getParam,
	AppParams
} from '../../../../conf'
import { Link } from './../../../../../../framework/react/components/Link'
import PfileModal from '../../../../../../framework/react/components/Modal/PfileModal'
import { CheckBox } from './../../../../../../framework/react/components/CheckBox'

const Tnc = props => {
	let tncType = getParam(AppParams.TNC_TYPE)
	let tncUrl = getParam(AppParams.LOGIN_EXTERNAL_TNC_URL)

	let [tncPopupState, tncPopupStateSetState] = useState({
		showPopup: false
	})

	const fetchTncContent = file_name => {
		tncPopupStateSetState({
			showPopup: true,
			fileName: file_name
		})
	}

	const closePopup = () => {
		tncPopupStateSetState({
			showPopup: false
		})
	}

	let getTncText = () => {
		let anchorAttributes = null
		switch (tncType) {
			case 'external':
				anchorAttributes = (
					<a
						target="_blank"
						href={tncUrl}
						className="external"
						onFocus={props.onFocus}
						onBlur={props.onBlur}
					>
						{BrandUtils.getString('login_tnc', 'fastlink')}
					</a>
				)
				break
			case 'popup':
				anchorAttributes = (
					<Link
						onFocus={props.onFocus}
						onBlur={props.onBlur}
						lable={BrandUtils.getString('login_tnc', 'fastlink')}
						classes="tnc-link"
						onClick={fetchTncContent.bind(this, 'tnc')}
					/>
				)
				break
		}
		return anchorAttributes
	}

	let selectionProps = {
		'data-id': props.tncCheckBox.checkBoxId,
		checked: props.isCheckBoxChecked,
		hexCode1: props.hexCode1,
		hexCode2: props.hexCode2,
		key: 'key' + props.isCheckBoxChecked + props.btnClicked,
		error: !props.isCheckBoxChecked && props.btnClicked,
		onChange: props.tncCheckBox.handleTncCheckBox
	}

	return (
		<div
			className={'checkbox-wrapper text'}
			autoid="login-page-label-submit-help-text"
		>
			{props.tncCheckBoxParamValue && <CheckBox {...selectionProps} />}
			<div className="tnc-line">
				{BrandUtils.getString('login_tnc_prefix', 'fastlink')}{' '}
				{getTncText()}
			</div>
			{tncPopupState.showPopup && (
				<PfileModal
					show={tncPopupState.showPopup}
					backDropEnabled={true}
					onBackDropClick={closePopup.bind(this)}
					crossIconEnabled={true}
					onCrossIconClick={closePopup.bind(this)}
					fileName={tncPopupState.fileName}
				></PfileModal>
			)}
		</div>
	)
}
export default Tnc
