import React, { Component } from 'react'
import AccountListView from './views/AccountListView'
import './style/index.scss'
import WithState from './../../hoc/WithState'

class SuccessModule extends Component {
	constructor(props) {
		super(props)
		this.props = props
		this.state = {}
	}

	static propTypes = {}

	static defaultProps = {}

	componentDidMount() {}

	renderSubView() {
		let _view = '...'
		_view = <AccountListView {...this.props} />
		return _view
	}

	render() {
		return <React.Fragment>{this.renderSubView()}</React.Fragment>
	}
}

export default WithState('currentProvider', SuccessModule)
