import React, { Component } from 'react'

import { AppStrings, getString, AutoIds } from '../../../../conf'
import { SearchField } from '../../../../../../framework/react/components/InputField'

const SearchFieldView = props => {
	return (
		<div className="row">
			<div className="col-12">
				<div
					className="search-bar-cnr"
					autoid={AutoIds.LANDING_SEARCHFIELD_CONTAINER}
				>
					{/* <div className="search-bar-wrapper row"> */}
					{/* <div className="search-field col-md-5"> */}
					<SearchField
						value={props.searchString}
						placeholder={getString(AppStrings.SEARCH)}
						showClearField={true}
						showSearchIcon={true}
						onChange={props.onChange}
					/>
				</div>
			</div>
			{props.isSearchMode && props.haveSearchResult ? (
				<div className="search-info">
					<div className="text">
						{getString(AppStrings.SITE_SORT_ORDER)}
					</div>
				</div>
			) : null}
		</div>
		// </div>
		// </div>
	)
}

export default SearchFieldView
