import React from 'react'
import { Provider } from 'react-redux'
import SpinnerMsg from '../../sections/SpinnerMsg'
import configureStore from 'redux-mock-store'

const mockStore = configureStore([]);


describe('spinning message', () => {
  let container = null;
  let isLoading= true;
  beforeEach(() => {
    container = null;
  });



  it('Check if spinner module rendered', () => {
    isLoading= true;
    let renderComponent = () => {
      let store = mockStore({
        search: { providers: [] }
      });
      container = mount(<Provider store={store}>

        <SpinnerMsg
          isLoading ={isLoading}/>

      </Provider>)
    };
    act(() => {
      renderComponent()
    });
    expect(container.find('div#data-refresh-label')).toHaveLength(1)
  });
  it('Check if spinner module not rendered', () => {
    isLoading= false;
    let renderComponent = () => {
      let store = mockStore({
        search: { providers: [] }
      });
      container = mount(<Provider store={store}>

        <SpinnerMsg
          isLoading ={isLoading}/>

      </Provider>)
    };
    act(() => {
      renderComponent()
    });
    expect(container.find('div#data-refresh-label')).toHaveLength(0)
  });
});



