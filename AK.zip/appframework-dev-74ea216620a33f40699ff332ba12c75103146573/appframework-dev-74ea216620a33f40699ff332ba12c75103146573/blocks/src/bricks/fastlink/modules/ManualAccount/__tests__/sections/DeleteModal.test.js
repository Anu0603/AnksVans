import React from 'react'
import { Modal } from './../../../../../../framework/react/components/Modal'
import { Button } from './../../../../../../framework/react/components/Button'
import DeleteModal from '../../sections/DeleteModal'

jest.mock('./../../../../../../framework/react/components/Modal')

describe('<DeleteModal> section', () => {
	let container = null
	let spy = jest.fn()

	let modalRoot = global.document.createElement('div')
	modalRoot.setAttribute('id', 'modal-root')
	let body = global.document.querySelector('body')
	body.appendChild(modalRoot)

	beforeEach(() => {
		container = null
	})

	it('Check whether Delete Modal section rendered', () => {
		act(() => {
			container = shallow(<DeleteModal />)
		})
		expect(container.find('.manual-delete-popup')).toHaveLength(1)
	})

	it('Simulate click on cross icon', () => {
		act(() => {
			container = shallow(<DeleteModal showHidePopUp={spy} />)
		})
		container.find('.manual-delete-popup').prop('onCrossIconClick')()
		expect(spy).toHaveBeenCalled()
	})

	it('Simulate click on backdrop', () => {
		act(() => {
			container = shallow(<DeleteModal showHidePopUp={spy} />)
		})
		container.find('.manual-delete-popup').prop('onBackDropClick')()
		expect(spy).toHaveBeenCalled()
	})

	it('Simulate click on exit button', () => {
		act(() => {
			container = shallow(<DeleteModal showHidePopUp={spy} />)
		})
		container.find('#exit').prop('onClick')()
		expect(spy).toHaveBeenCalled()
	})
})
