import React from 'react'
import { Provider } from 'react-redux'
import SiteSelectionModule from './../index'
import { store } from './../../../../../framework/react/store/store'

jest.mock('./../views/SiteSelectionView', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="site-selection-view"></div>
		}
	}
})

describe('Landing Module', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	let renderComponent = () => {
		container = mount(
			<Provider store={store}>
				<SiteSelectionModule />
			</Provider>
		)
	}

	it('Check whether Site Selection module rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('div.site-selection-view')).toHaveLength(1)
	})
})
