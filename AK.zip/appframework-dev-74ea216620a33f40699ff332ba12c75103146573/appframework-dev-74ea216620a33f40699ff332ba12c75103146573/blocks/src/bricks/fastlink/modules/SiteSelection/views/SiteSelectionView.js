import React, { Component } from 'react'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'

import { AppParams, getParam } from '../../../conf'

import { Spinner } from '@framework/react/components/Spinner'

import SearchFieldSection from './../sections/SearchField'
import PopularSitesSection from './../sections/PopularSites'
import SearchResultSection from './../sections/SearchResult'
import FooterSection from './../sections/Footer'

import CONSTANTS from '../../../router/Constant'
import ProviderService from './../../../services/provider/ProviderService'
import CDVModule from './../../CDV'

import Parser from '../dataparser/Parser'
import AppConstants from '../../../conf/constants/AppConstants'

class SiteSelectionView extends Component {
	constructor(props) {
		super(props)
		this.state = {
			isLoading: true,
			isSearchMode: false,
			haveSearchResult: false,
			isSearching: true,
			searchString: ''
		}
		this.clarField = this.previousValue = 1
		this.searchFieldRef = React.createRef()
	}

	static propTypes = {
		searchResult: PropTypes.array
	}

	static defaultProps = {
		onFetchProvider: function() {},
		navigate: function() {},
		providers: [],
		searchResult: []
	}

	componentDidMount() {
		if (this.props.providers && this.props.providers.length) {
			this.setState({
				isLoading: false,
				isSearchMode: false
			})
		} else {
			this.getProvidersCall()
		}
	}
	componentDidUpdate(prevProps, prevState) {
		if (
			this.clarField != this.previousValue &&
			this.searchFieldRef.current
		) {
			this.searchFieldRef.current.querySelector('input').focus()
		}
	}
	getProvidersCall() {
		let _self = this
		let popularSites
		ProviderService.getPopularProviders(
			{
				/*
				 * TBD: isMobile check needs to be done. No support from Framework.
				 * Will update it after the frameworks support.
				 * AppParams.PROVIDERS_SEARCH_COUNT_MOBILE
				 */
				top: getParam(AppParams.POPULAR_PROVIDERS_COUNT)
			},
			(_error, _response) => {
				if (_error) {
					let routingModule = CONSTANTS.ROUTE_ERROR_MODULE
					let errordata = {
						errorOccured: true,
						errorCode: 'TECH_ERROR'
					}
					this.props.navigate(routingModule, errordata)
				} else {
					popularSites = Parser.parsePopularSitesData(_response)
					this.props.onFetchProvider(popularSites)
					_self.setState({
						isLoading: false,
						isSearchMode: false
					})
				}
			}
		)
	}

	navigateToSite(_site) {
		this.props.navigate(CONSTANTS.ROUTE_LOGIN_MODULE, {
			providerId: _site.id
		})
	}

	navigateToManualAccounts() {
		this.props.navigate(CONSTANTS.ROUTE_MANUAL_ACCOUNT_MODULE)
	}

	navigateToRealEstate() {
		this.props.navigate(CONSTANTS.ROUTE_REAL_ESTATE_MODULE)
	}

	getSearchSiteCall(siteSearchString) {
		let _self = this
		let searchedSiteData
		ProviderService.getSearchProviders(
			{
				name: siteSearchString,
				/*
				 * FIXME/TBD: isMobile check needs to be done. No support from Framework.
				 * Will update it after the frameworks support.
				 * AppParams.POPULAR_PROVIDERS_COUNT_MOBILE
				 */
				top: getParam(AppParams.PROVIDERS_SEARCH_COUNT)
			},
			(_error, _response) => {
				if (_error) {
					console.log('Could not fetch search result')
				} else {
					searchedSiteData = Parser.parseSearchedSitesData(_response)
					this.setState({
						searchResult: searchedSiteData,
						haveSearchResult:
							this.state.searchResult &&
							this.state.searchResult.length > 0
								? true
								: false,
						isSearching: false
					})
				}
			}
		)
	}

	searchSite(e) {
		this.setState({
			searchString: e.target.value,
			isSearchMode: e.target.value ? true : false,
			isSearching: true
		})
		this.getSearchSiteCall(e.target.value)
		this.previousValue = this.clarField
		if (!e.target.value) {
			this.clarField++
		}
	}

	toggleToPopularSites(e) {
		this.setState({
			isSearchMode: false
		})
	}

	render() {
		return (
			<div id={'landing-module'} className={'flex-pane landing-module'}>
				<div className={'header'}></div>
				<div className="content-wrapper" ref={this.searchFieldRef}>
					{this.state.isLoading ? (
						<Spinner
							id="largeSpinner"
							name="someButtonName"
							classes="aaa"
							size="lg"
							children={
								<div className="empty-string">&nbsp;</div>
							}
						/>
					) : (
						<React.Fragment>
							<SearchFieldSection
								haveSearchResult={this.state.haveSearchResult}
								isSearchMode={this.state.isSearchMode}
								searchString={this.state.searchString}
								key={'searchKey' + this.clarField}
								onChange={e => {
									this.searchSite(e)
								}}
							/>
							{this.state.isSearchMode ? (
								<SearchResultSection
									isSearching={this.state.isSearching}
									navigateToSite={this.navigateToSite.bind(
										this
									)}
									searchResult={this.state.searchResult}
									searchString={this.state.searchString}
									toggleToPopularSites={this.toggleToPopularSites.bind(
										this
									)}
									navigate={this.props.navigate}
								/>
							) : (
								<div
									className="card-list-wrapper section-container"
									autoid={AutoIds.LANDING_SITES_CONTAINER}
								>
									<PopularSitesSection
										navigate={this.props.navigate.bind(
											this
										)}
										navigateToSite={this.navigateToSite.bind(
											this
										)}
										navigateToRealEstate={this.navigateToRealEstate.bind(
											this
										)}
										navigateToManualAccounts={this.navigateToManualAccounts.bind(
											this
										)}
										providers={this.props.providers}
									/>

									{getParam(AppParams.ENABLE_CDV) &&
									getParam(AppParams.SHOW_CDV_ON_SEARCH) &&
									!(
										this.state.isLoading ||
										this.state.isSearchMode
									) ? (
										<div className="cdv-search-container">
											<CDVModule
												{...this.props}
												path={
													AppConstants.CDV_PATH_INVOKE
												}
											/>
										</div>
									) : null}

									{getParam(
										AppParams.SHOW_LANDING_SCREEN_FOOTER
									) ? (
										<FooterSection
											showPolicyView={
												!(
													this.state.isLoading ||
													this.state.isSearchMode
												)
											}
										/>
									) : null}
								</div>
							)}
						</React.Fragment>
					)}
				</div>
			</div>
		)
	}
}

const mapStateToProps = state => {
	return {
		providers: state.fastlink.siteSelection.providers
	}
}

const mapDispatchToProps = dispatch => {
	return {
		onFetchProvider: providers => {
			dispatch({
				type: 'FETCH_PROVIDERS',
				payload: { providers: providers }
			})
		}
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(SiteSelectionView)
