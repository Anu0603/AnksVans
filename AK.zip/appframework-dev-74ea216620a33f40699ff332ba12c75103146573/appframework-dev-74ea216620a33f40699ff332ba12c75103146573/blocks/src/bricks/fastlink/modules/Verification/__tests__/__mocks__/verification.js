export default {
	verification: [
		{
			verificationId: 3324,
			providerAccountId: 9999,
			verificationType: 'MATCHING',
			accountId: 10295778,
			verificationStatus: 'SUCCESS',
			reason: 'DATA_NOT_AVAILABLE',
			verificationDate: '2015-09-21T14:46:23Z'
		},
		{
			verificationId: 3325,
			providerAccountId: 9999,
			verificationType: 'MATCHING',
			accountId: 10295777,
			verificationStatus: 'FAILED',
			verificationDate: '2015-09-21T14:46:23Z'
		}
	]
}
