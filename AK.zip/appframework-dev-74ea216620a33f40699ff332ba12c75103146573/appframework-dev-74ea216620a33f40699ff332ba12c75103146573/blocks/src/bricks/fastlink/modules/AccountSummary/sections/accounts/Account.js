import { CurrencyFormatter } from '../../../../../../framework/react/components/CurrencyFormatter'

import React from 'react'
const Account = props => {
	let colorInline = {
		color: props.currentProvider.hexCode1
	}
	return (
		<div className="list-ph">
			<div className="list-title">{props.accountName}</div>
			{(props.accountType || props.accountNumber) && (
				<div className="list-sub-title">
					<span className="text-capitalize">
						{props.accountType.toLowerCase()}
					</span>{' '}
					{props.accountType && props.accountNumber ? '|' : ''}{' '}
					<span className="text-lowercase">
						{props.accountNumber}
					</span>
				</div>
			)}
			{props.amount != undefined && (
				<CurrencyFormatter
					style={colorInline}
					quantity={props.amount}
					currency={props.currency}
					negative={props.negativeCurrency}
					classes="list-second-sub-title"
				></CurrencyFormatter>
			)}
		</div>
	)
}

export default Account
