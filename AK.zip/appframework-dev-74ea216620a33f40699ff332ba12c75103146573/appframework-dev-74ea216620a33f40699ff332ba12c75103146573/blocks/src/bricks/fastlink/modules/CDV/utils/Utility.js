import { AppParams, getParam, AppStrings, getString } from '@fastlinkRoot/conf'

export default {
	isCDVEnabled: () => {
		return getParam(AppParams.ENABLE_CDV)
	},

	formatAccountNumber(accountNumber) {
		let accountNumberStr = accountNumber ? accountNumber.toString() : ''
		if (accountNumberStr.length > 4) {
			accountNumberStr = accountNumberStr.substring(
				accountNumberStr.length - 4
			)
			return (
				getString(AppStrings.ACCOUNT_NUMBER_MASK_CHARACTER) +
				accountNumberStr
			)
		} else {
			return accountNumberStr
		}
	},

	getDefaultAccTypeSelected() {
		return getParam(AppParams.CDV_INITIATE_ACCOUNTTYPE_SELECTION)
	}
}
