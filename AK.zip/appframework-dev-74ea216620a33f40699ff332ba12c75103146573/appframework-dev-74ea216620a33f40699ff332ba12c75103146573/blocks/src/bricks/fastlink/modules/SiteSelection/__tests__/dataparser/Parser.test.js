import Parser from './../../dataparser/Parser'

import ProviderData from './../__mocks__/provider'

describe('Data Parser', () => {
	it('Check whether parsePopularSitesData method returns parsed sites', () => {
		let providersCount = ProviderData.provider.length
		let result = Parser.parsePopularSitesData(ProviderData)

		expect(result.length).toBe(providersCount)
	})

	it('Check whether parsePopularSitesData return empty array of provider property not part of data', () => {
		let result = Parser.parsePopularSitesData({})
		expect(result.length).toBe(0)
	})

	it('Check whether parseSearchedSitesData method returns parsed sites', () => {
		let providersCount = ProviderData.provider.length
		let result = Parser.parseSearchedSitesData(ProviderData)

		expect(result.length).toBe(providersCount)
	})

	it('Check whether parseSearchedSitesData return empty array of provider property not part of data', () => {
		let result = Parser.parseSearchedSitesData({})
		expect(result.length).toBe(0)
	})
})
