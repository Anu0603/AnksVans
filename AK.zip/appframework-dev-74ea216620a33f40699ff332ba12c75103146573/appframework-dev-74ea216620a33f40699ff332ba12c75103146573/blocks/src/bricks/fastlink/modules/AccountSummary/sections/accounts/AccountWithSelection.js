import Account from './Account'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../conf'

import React, { useState } from 'react'
import { CheckBox } from './../../../../../../framework/react/components/CheckBox'
import { Radio } from './../../../../../../framework/react/components/RadioButton'

const AccountWithSelection = props => {
	let hexCode1 = props.currentProvider.hexCode1
	let hexCode2 = props.currentProvider.hexCode2

	let accountSelectionHandler = checked => {
		//Radio option click
		if (typeof checked == 'object') {
			props.selectionOnChange({
				id: props.id,
				checked: checked.target.checked,
				clearList: true
			})
		} else {
			props.selectionOnChange({ id: props.id, checked: checked })
		}
	}

	const accountSelectionType = getParam(
		AppParams.SUCCESS_ACCOUNT_SELECTION_TYPE
	)

	let selectionProps = {
		'data-id': props.id,
		disabled: props.disabled,
		checked: props.checked,
		hexCode1: hexCode1,
		hexCode2: hexCode2,
		onChange: accountSelectionHandler.bind(this)
	}

	let getAccountSelectionElement = () => {
		let element = null
		let key = props.id
		if (props.checked) {
			key = key + 'checked'
		}

		//If a single account, don't display selection option
		//The AND Condition to show the disabled checkbox in the Aggregation screen of the IAV+AGG combined flow.
		if (props.accountLength == 1 && !selectionProps.disabled) {
			return <React.Fragment></React.Fragment>
		}

		switch (accountSelectionType) {
			case AppConstants.VERIFICATION_MULTI_ACCOUNT_SELECTION:
				element = <CheckBox key={key} {...selectionProps} />
				break

			case AppConstants.VERIFICATION_SINGLE_ACCOUNT_SELECTION:
				if (selectionProps.disabled) {
					element = <CheckBox key={key} {...selectionProps} />
				} else {
					selectionProps.className = 'radio'
					selectionProps.id = props.id + ''
					selectionProps.name = 'account-selection-single'
					element = <Radio {...selectionProps} />
				}
				break
		}
		return element
	}

	return (
		<React.Fragment>
			<Account {...props} />
			<div className="list-item-right">
				{getAccountSelectionElement()}
			</div>
		</React.Fragment>
	)
}
export default AccountWithSelection
