import React, { Component } from 'react'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from './../../../../conf'
const Reset = props => {
	let getResetText = () => {
		return (
			<a
				target="_blank"
				href={props.loginUrl}
				onFocus={props.onFocus}
				onBlur={props.onBlur}
			>
				{getString('login_reset')}
			</a>
		)
	}

	return (
		<div
			className={'align-center text reset-margin opacity-50'}
			autoid="loginpage-link-reset-password-link"
		>
			{getResetText()}
		</div>
	)
}
export default Reset
