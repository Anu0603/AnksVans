import React from 'react'
import { Provider } from 'react-redux'
import { createStore, combineReducers } from 'redux'
import props from '../__mocks__/props'
import SuccessView from '../../views/SuccessView'
import initialStateData from '../__mocks__/successViewData'
import { AppStrings, getString, AppParams } from '../../../../../fastlink/conf'
import { getParam } from '../../../../conf/utilities/Utilities'
import realEstateReducer from './../../../../store/reducers/realEstate'
import configureStore from 'redux-mock-store'
import AccountsService from '../../../../services/account/AccountsService'
jest.mock('../../helper/RealEstateHelper')
jest.mock('../../../../../fastlink/conf')
jest.mock('../../../../conf/utilities/Utilities')
const showNextViewMock = jest.fn()
const navigateViewMock = jest.fn()
const handleCloseAppHandlerMock = jest.fn()
const mockStore = configureStore([])
jest.mock('../../../../services/account/RealEstateService', () => {
	return jest.fn().mockImplementation(() => {
		return {
			getRealEstate: () => {
				return new Promise(resolve => {
					resolve({
						account: [
							{
								accountName: 'qwd',
								id: 12424575,
								homeValue: { amount: 123.0, currency: 'USD' },
								valuationType: 'MANUAL'
							}
						]
					})
				})
			}
		}
	})
})

jest.mock('../../views/DeleteModal', () => {
	return {
		__esModule: true,
		default: props => {
			return (
				<div className="modal-content">
					<button
						id="cancel-modal"
						onClick={() => {
							props.showHidePopUp(false)
						}}
					></button>
					<button
						id="delete-button"
						onClick={() => {
							props.handleDelete()
						}}
					></button>
				</div>
			)
		}
	}
})

jest.mock('../../views/SmartzipModal', () => {
	return {
		__esModule: true,
		default: props => {
			return (
				<div className="modal-content">
					<button
						id="cancel-modal"
						onClick={() => {
							props.showHideSmartzipPopup(false)
						}}
					></button>
				</div>
			)
		}
	}
})

describe('Real Estate Success view', () => {
	let container = null
	let store = null
	let appParam = {
		disable_realestate_edit: false
	}

	// const rootReducer = combineReducers({
	// 	realEstate: realEstateReducer
	// })

	getParam.mockImplementation(key => {
		if (key === AppParams.DISABLE_REALESTATE_EDIT)
			return appParam.disable_realestate_edit
	})

	getString.mockImplementation(_key => {
		switch (_key) {
			case AppStrings.REAL_ESTATE_VIEW_ACCOUNT_TITLE:
				return 'View Real Estate Account'
			case AppStrings.REAL_ESTATE_SAVE_FINISH_BUTTON_LABEL:
				return 'Save & Finish'
			case AppStrings.REAL_ESTATE_SAVE_AND_LINK_MORE_BUTTON_LABEL:
				return 'Save & Link More Accounts'
			case AppStrings.REAL_ESTATE_SEE_MORE_DETAILS_TEXT:
				return 'Save & Link More Accounts'
			case AppStrings.ERROR_CANCEL_BUTTON_TEXT:
				return 'Cancel'
			default:
				break
		}
	})

	let deeplinkData = {
		isDeeplink: false
	}

	beforeEach(() => {
		container = null
		// store = createStore(rootReducer)
	})

	const setAppParam = paramValue => {
		appParam = { appParam, ...paramValue }
	}

	let renderComponent = () => {
		store = mockStore({
			realEstate: { accounts: [] },
			deeplink: deeplinkData
		})
		container = mount(
			<Provider store={store}>
				<SuccessView
					{...props.successViewProps}
					showNextView={showNextViewMock}
					navigate={navigateViewMock}
					handleCloseAppHandler={handleCloseAppHandlerMock}
				/>
			</Provider>
		)
	}

	const setState = data => {
		container
			.childAt(0)
			.childAt(0)
			.setState(data)
	}

	it('Check whether Success view Container is rendered', () => {
		renderComponent()
		expect(container.find('.section-container')).toHaveLength(1)
	})
	it('Check if spinner and Page header is showing before state is set', () => {
		renderComponent()
		expect(container.find('.section-header .title').text()).toEqual(
			'View Real Estate Account'
		)
		expect(container.find('.spinner-wrapper')).toHaveLength(1)
	})
	it('Check if Amount rendered', () => {
		renderComponent()
		setState(initialStateData.manualAccountData)
		// container
		// 	.find('SuccessView')
		// 	.instance()
		// 	.setState(initialStateData)

		expect(container.find('.currency')).toHaveLength(1)
		expect(container.find('.currency').text()).toContain(
			initialStateData.manualAccountData.amount
		)
	})

	it('Check if Account Name rendered', () => {
		renderComponent()
		setState(initialStateData.manualAccountData)

		expect(container.find('.sub-section .title')).toHaveLength(1)
		expect(container.find('.sub-section .title').text()).toEqual(
			initialStateData.manualAccountData.accountName
		)
	})

	it('Check if Buttons are rendered', () => {
		renderComponent()
		setState(initialStateData.manualAccountData)

		expect(container.find('.btn-tertiary').text()).toEqual('Cancel')
		expect(container.find('.btn-secondary').text()).toEqual(
			'Save & Link More Accounts'
		)
		expect(container.find('.btn-primary').text()).toEqual('Save & Finish')
	})

	it('Check if edit icon rendered', () => {
		renderComponent()
		setState(initialStateData.manualAccountData)
		expect(container.find('.fa-edit')).toHaveLength(1)
	})

	it('Check if smartzip link rendered for System account', () => {
		renderComponent()
		setState(initialStateData.automaticAccountData)
		expect(container.find('.info-txt .info-link')).toHaveLength(2)
	})
	it('Check if smartzip links are not rendered for Manual account', () => {
		renderComponent()
		setState(initialStateData.manualAccountData)
		expect(container.find('.info-txt .info-link')).toHaveLength(0)
	})
	it('Edit icon should not be there if DISABLE_REALESTATE_EDIT is true', () => {
		setAppParam({ disable_realestate_edit: true })
		renderComponent()
		setState(initialStateData.manualAccountData)
		expect(container.find('.fa-edit')).toHaveLength(0)
		setAppParam({ disable_realestate_edit: false })
	})
	it('Modal should Render on Cancel Click', () => {
		renderComponent()
		setState(initialStateData.manualAccountData)
		container
			.childAt(0)
			.childAt(0)
			.instance().realEstateDataResp = { account: [{ accountName: '' }] }
		container.find('.btn-wrapper .btn-tertiary').simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
	})
	it('Simulate Save and Finish click', () => {
		renderComponent()
		setState(initialStateData.manualAccountData)
		container
			.childAt(0)
			.childAt(0)
			.instance().realEstateDataResp = { account: [{ accountName: '' }] }
		container.find('.btn-wrapper .btn-primary').simulate('click')
		expect(handleCloseAppHandlerMock).toBeCalled()
	})

	it('Modal should Render on SmartZip link Click', () => {
		renderComponent()
		setState(initialStateData.automaticAccountData)
		container
			.find('.info-txt .info-link')
			.first()
			.simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
	})

	it('Navigate on edit click', () => {
		renderComponent()
		setState(initialStateData.manualAccountData)
		container
			.childAt(0)
			.childAt(0)
			.instance().realEstateDataResp = { account: [{ accountName: '' }] }
		container.find('.fa-edit').simulate('click')
		expect(showNextViewMock).toBeCalled()
	})

	it('Navigate on Save & link click', () => {
		renderComponent()
		setState(initialStateData.manualAccountData)
		container.find('.btn-secondary').simulate('click')
		expect(navigateViewMock).toBeCalled()
	})

	it('Simulate smartzip modal button click', () => {
		renderComponent()
		setState(initialStateData.automaticAccountData)
		container
			.find('.info-txt .info-link')
			.first()
			.simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
		container.find('#cancel-modal').simulate('click')
	})

	it('Simulate Delete modal Cancel click', () => {
		renderComponent()
		setState(initialStateData.manualAccountData)
		container
			.childAt(0)
			.childAt(0)
			.instance().realEstateDataResp = { account: [{ accountName: '' }] }
		container.find('.btn-wrapper .btn-tertiary').simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
		container.find('#cancel-modal').simulate('click')
	})

	it('Simulate Delete modal delete click', () => {
		const mock = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		mock.mockReturnValue(
			new Promise(resolve => {
				resolve({})
			})
		)
		renderComponent()
		setState(initialStateData.manualAccountData)
		container
			.childAt(0)
			.childAt(0)
			.instance().realEstateDataResp = { account: [{ accountName: '' }] }
		container.find('.btn-wrapper .btn-tertiary').simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
		container.find('#delete-button').simulate('click')
	})

	it('Simulate Delete Error on  delete click', () => {
		const mock = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		mock.mockReturnValue(Promise.reject({}))
		renderComponent()
		setState(initialStateData.manualAccountData)
		container
			.childAt(0)
			.childAt(0)
			.instance().realEstateDataResp = { account: [{ accountName: '' }] }
		container.find('.btn-wrapper .btn-tertiary').simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
		container.find('#delete-button').simulate('click')
	})

	it('Save & Link more , Cancel button should not render if deeplink ', () => {
		const mock = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		mock.mockReturnValue(Promise.reject({}))
		deeplinkData = {
			isDeeplink: true
		}
		renderComponent()
		setState(initialStateData.manualAccountData)
		expect(container.find('.btn-tertiary').hostNodes()).toHaveLength(0)
		expect(container.find('.btn-secondary').hostNodes()).toHaveLength(0)
		expect(container.find('.btn-primary').hostNodes()).toHaveLength(1)
	})
})
