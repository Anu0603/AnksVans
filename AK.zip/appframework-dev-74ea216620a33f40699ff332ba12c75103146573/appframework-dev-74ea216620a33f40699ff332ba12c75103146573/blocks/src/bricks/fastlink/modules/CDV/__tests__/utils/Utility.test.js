import Utility from './../../utils/Utility'
import { AppParams, getParam, getString, AppStrings } from './../../../../conf'

jest.mock('./../../../../conf')

describe('CDV Utility', () => {
	it('Check isCDVEnabled should return getParam Value in case it is false', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'enable_cdv') {
					return false
				}
			})
		})
		let isCDVEnabled = Utility.isCDVEnabled()
		expect(isCDVEnabled).toEqual(false)
	})

	it('Check isCDVEnabled should return getParam Value in case it is true', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'enable_cdv') {
					return true
				}
			})
		})
		let isCDVEnabled = Utility.isCDVEnabled()
		expect(isCDVEnabled).toEqual(true)
	})

	it('Check formatAccountNumber should return proper format for account number more than 4 numbers are being passed', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'enable_cdv') {
					return true
				}
			})
			getString.mockImplementation(_key => {
				if (_key == AppStrings.ACCOUNT_NUMBER_MASK_CHARACTER) {
					return 'x-'
				}
			})
		})
		let formattedAccountNumber = Utility.formatAccountNumber(98765432101234)
		expect(formattedAccountNumber).toEqual('x-1234')
	})

	it('Check formatAccountNumber should return proper format for account number less than 4 numbers are being passed', () => {
		let formattedAccountNumber = Utility.formatAccountNumber(123)
		expect(formattedAccountNumber).toEqual('123')
	})

	it('Check formatAccountNumber should return proper format for account number as null being passed', () => {
		let formattedAccountNumber = Utility.formatAccountNumber()
		expect(formattedAccountNumber).toEqual('')
	})

	it('Check getDefaultAccTypeSelected should return required configurations for ', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == AppParams.CDV_INITIATE_ACCOUNTTYPE_SELECTION) {
					return AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
				}
			})
		})

		let defaultAccTypeSelected = Utility.getDefaultAccTypeSelected()
		expect(defaultAccTypeSelected).toEqual(
			AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
		)
	})
})
