import React from 'react'
import { Provider } from 'react-redux'

import CDVModule from './../index'
import AppConstants from '../../../conf/constants/AppConstants'
import configureStore from 'redux-mock-store'
const mockStore = configureStore([])

jest.mock('./../views/CDVBaseView', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="cdvbase-view"></div>
		}
	}
})

describe('CDV Module', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	let renderComponent = () => {
		let store = mockStore({})

		container = mount(
			<Provider store={store}>
				<CDVModule path={AppConstants.CDV_PATH_INVOKE} />
			</Provider>
		)
	}

	it('Check whether CDV module is rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('div.cdvbase-view')).toHaveLength(1)
	})
})
