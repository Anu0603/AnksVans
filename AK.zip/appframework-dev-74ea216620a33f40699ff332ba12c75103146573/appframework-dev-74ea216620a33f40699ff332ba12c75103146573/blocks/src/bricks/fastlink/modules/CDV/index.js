import React, { Component } from 'react'
import './style/index.scss'
import CDVBaseView from './views/CDVBaseView'

class CDVModule extends Component {
	constructor(props) {
		super(props)
	}

	render() {
		return <CDVBaseView {...this.props} />
	}
}
export default CDVModule
