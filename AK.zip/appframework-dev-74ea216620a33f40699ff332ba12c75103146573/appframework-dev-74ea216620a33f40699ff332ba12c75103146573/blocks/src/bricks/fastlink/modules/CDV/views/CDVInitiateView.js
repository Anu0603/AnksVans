import React, { Component } from 'react'
import { connect } from 'react-redux'

import AppConstants from '../../../conf/constants/AppConstants'
import Constants from './../../../router/Constant'
import CDVInitiateFormView from '../components/initiate/form'
import CDVInitiateSuccessView from '../components/initiate/success'
import ProviderDetailsServices from '../../../services/provider/ProviderDetailsServices'
import VerificationService from '../../../services/cdv/VerificationService'
import CDVErrorView from './CDVErrorView'
import { AppStrings, getString, AutoIds } from '../../../conf'
import Utility from '../utils/Utility'

class CDVInitiateView extends Component {
	constructor(props) {
		super(props)
		this.state = {
			errors: [],
			accountType: Utility.getDefaultAccTypeSelected(),
			routingNumber: props.routingNumber ? props.routingNumber + '' : '',
			accountNumber: ''
		}
		this.providerDetailsServices = new ProviderDetailsServices()
		this.verificationService = new VerificationService()
		this.isDeeplink = props.deeplinkData
			? props.deeplinkData.isDeeplink
			: false
	}

	handleStartVerification() {
		let _isValidForm = this.validateInitiateForm()
		if (_isValidForm) {
			this.validateSumInfoRoutingNumber()
		} else {
			return false
		}
	}

	validateSumInfoRoutingNumber() {
		this.providerDetailsServices.getProviderDetailsByRTN(
			{
				name: this.state.routingNumber
			},
			(_error, _response) => {
				let _errors = []
				if (_error) {
					_errors.push(
						AppConstants.CDV_INITIATE_ERROR_ROUTING_NUMBER_NOT_FOUND
					)
				} else {
					if (_response.name != null) {
						this.setState({
							id: _response.id,
							name: _response.name
						})
						this.initiateVerification()
					} else {
						_errors.push(
							AppConstants.CDV_INITIATE_ERROR_ROUTING_NUMBER_NOT_FOUND
						)
					}
				}
				this.setState({
					errors: _errors
				})
			}
		)
	}

	initiateVerification() {
		this.verificationService.initiateVerification(
			{
				routingNumber: this.state.routingNumber,
				accountNumber: this.state.accountNumber,
				accountType: this.state.accountType.toUpperCase()
			},
			(_error, _response) => {
				this.updateVerificationResults(_response)
			}
		)
	}

	validateInitiateForm() {
		let _accountNumberTestExpression = /^([0-9-]{4,17})$/,
			_routingNumberTestExpression = /^([0-9]{9})$/

		let _routingNumber = this.state.routingNumber,
			_accountNumber = this.state.accountNumber,
			_accountType = this.state.accountType,
			_errors = []

		if (!_routingNumber || _routingNumber.trim().length == 0) {
			_errors.push(AppConstants.CDV_INITIATE_ERROR_ROUTING_NUMBER_EMPTY)
		} else if (!_routingNumberTestExpression.test(_routingNumber.trim())) {
			_errors.push(AppConstants.CDV_INITIATE_ERROR_ROUTING_NUMBER_INVALID)
		}
		if (!_accountNumber || _accountNumber.trim().length == 0) {
			_errors.push(AppConstants.CDV_INITIATE_ERROR_ACCOUNT_NUMBER_EMPTY)
		} else if (!_accountNumberTestExpression.test(_accountNumber.trim())) {
			_errors.push(AppConstants.CDV_INITIATE_ERROR_ACCOUNT_NUMBER_INVALID)
		}
		this.setState({
			errors: _errors
		})
		return _errors.length == 0 ? true : false
	}

	getIsFieldEmpty(fieldType) {
		let _isEmpty = false
		switch (fieldType) {
			case 'routingNumber':
				if (
					this.state.errors.includes(
						AppConstants.CDV_INITIATE_ERROR_ROUTING_NUMBER_EMPTY
					)
				) {
					_isEmpty = true
				}
				break

			case 'accountNumber':
				if (
					this.state.errors.includes(
						AppConstants.CDV_INITIATE_ERROR_ACCOUNT_NUMBER_EMPTY
					)
				) {
					_isEmpty = true
				}
				break
		}
		return _isEmpty
	}

	getErrorDetails(fieldType) {
		let _errorMessage = null
		switch (fieldType) {
			case 'routingNumber':
				if (
					this.state.errors.includes(
						AppConstants.CDV_INITIATE_ERROR_ROUTING_NUMBER_INVALID
					)
				) {
					_errorMessage = getString(
						AppStrings.CDV_ERROR_ROUTING_NUMBER_NOT_VALID
					)
				} else if (
					this.state.errors.includes(
						AppConstants.CDV_INITIATE_ERROR_ROUTING_NUMBER_NOT_FOUND
					)
				) {
					_errorMessage = getString(
						AppStrings.CDV_ERROR_ROUTING_NUMBER_NOT_FOUND
					)
				}
				break

			case 'accountNumber':
				if (
					this.state.errors.includes(
						AppConstants.CDV_INITIATE_ERROR_ACCOUNT_NUMBER_INVALID
					)
				) {
					_errorMessage = getString(
						AppStrings.CDV_ERROR_ACCOUNT_NUMBER_NOT_VALID
					)
				}
				break
		}
		return _errorMessage
	}

	updateVerificationResults(response) {
		this.props.onFetchVerificationInfo(response)
		this.props.toggleHeader(false)
	}

	handleCloseAction() {
		if (this.isDeeplink) {
			this.props.handleCloseAppHandler()
		} else {
			this.props.toggleHeader(true)
			this.props.navigate(Constants.ROUTE_LANDING_MODULE)
		}
	}

	onAccountTypeChange(event) {
		this.setState({
			accountType: event.target.value
		})
	}

	onRoutingNumberChange(event) {
		this.setState({
			routingNumber: event.target.value
		})
	}

	onAccountNumberChange(event) {
		this.setState({
			accountNumber: event.target.value
		})
	}

	renderInitiateView() {
		let _cdvInitiateView = null
		let _status =
			this.props.verificationInfo && this.props.verificationInfo.status
				? this.props.verificationInfo.status
				: 'NEW'
		let _reason =
			this.props.verificationInfo && this.props.verificationInfo.reason
				? this.props.verificationInfo.reason
				: null

		switch (_status) {
			case 'NEW':
				_cdvInitiateView = (
					<CDVInitiateFormView
						routingNumber={this.props.routingNumber}
						accountNumber={this.props.accountNumber}
						onAccountTypeChange={this.onAccountTypeChange.bind(
							this
						)}
						accountTypeSelection={this.state.accountType}
						onRoutingNumberChange={this.onRoutingNumberChange.bind(
							this
						)}
						onAccountNumberChange={this.onAccountNumberChange.bind(
							this
						)}
						isRoutingNumberEmpty={this.getIsFieldEmpty(
							'routingNumber'
						)}
						routingNumberError={this.getErrorDetails(
							'routingNumber'
						)}
						isAccountNumberEmpty={this.getIsFieldEmpty(
							'accountNumber'
						)}
						accountNumberError={this.getErrorDetails(
							'accountNumber'
						)}
						onSubmit={this.handleStartVerification.bind(this)}
					/>
				)
				break

			case 'INITIATED':
				_cdvInitiateView = (
					<CDVInitiateSuccessView
						onClose={this.handleCloseAction.bind(this)}
					/>
				)
				break

			case 'FAILED':
				if (_reason === 'ALREADY_INITIATED') {
					_cdvInitiateView = _cdvInitiateView = (
						<CDVInitiateSuccessView
							onClose={this.handleCloseAction.bind(this)}
							status={AppConstants.CDV_INITIATE_STATUS_INPROGRESS}
						/>
					)
				} else if (_reason === 'ALREADY_COMPLETED') {
					_cdvInitiateView = _cdvInitiateView = (
						<CDVErrorView
							errorCode={
								AppConstants.CDV_ERROR_INITIATE_VERIFICATION_ALREADY_COMPLETED
							}
						/>
					)
				} else {
					_cdvInitiateView = _cdvInitiateView = (
						<CDVErrorView
							errorCode={
								AppConstants.CDV_ERROR_INITIATE_VERIFICATION_UNKNOWN
							}
						/>
					)
				}
				break

			default:
				_cdvInitiateView = _cdvInitiateView = (
					<CDVErrorView
						errorCode={AppConstants.CDV_ERROR_INVALID_FLOW}
					/>
				)
				break
		}

		return _cdvInitiateView
	}

	render() {
		return (
			<React.Fragment>
				<div
					className="cdv-wrapper"
					autoid={AutoIds.CDV_INITIATE_CONTAINER}
				>
					{this.renderInitiateView()}
				</div>
			</React.Fragment>
		)
	}
}

const mapStateToProps = state => {
	return {
		verificationInfo: state.cdv.verificationInfo
	}
}

const mapDispatchToProps = dispatch => {
	return {
		onFetchVerificationInfo: verificationInfo =>
			dispatch({
				type: 'FETCH_CDV_VERIFICATION_INFO',
				payload: { verificationInfo: verificationInfo }
			})
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(CDVInitiateView)
