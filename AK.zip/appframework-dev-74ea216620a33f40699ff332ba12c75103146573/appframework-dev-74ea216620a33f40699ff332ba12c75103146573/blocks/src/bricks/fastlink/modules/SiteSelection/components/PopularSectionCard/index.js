import React, { useState } from 'react'

import classNames from 'classnames'
import PropTypes from 'prop-types'

import { AppParams, getParam } from '../../../../conf'
import {
	Icon,
	IconNameMap
} from '../../../../../../framework/react/components/Icon'

const PopularSectionCard = props => {
	let { data, cardType, classes, ...attr } = props

	const [isShowDefaultLogo, handleShowDefaultLogo] = useState(false)
	//FIXME: Add the feature switch to show the Site/Institution name
	let isShowSiteText = getParam(AppParams.SHOW_SITE_NAME_IN_CARD),
		_cardContent = null

	//FIXME: Check whetehr logo has the default image. If YES then show the site name(Enable the isShowSiteText tp true)

	const classList = classNames(
		classes,
		'site-card',
		isShowSiteText && 'img-logo-with-text',
		cardType == 'other-account-card' && 'other-account-card text-card'
	)

	let onError = () => {
		handleShowDefaultLogo(true)
	}

	if (cardType == 'site-card') {
		_cardContent = isShowDefaultLogo ? (
			<React.Fragment>
				<Icon
					iconClass={'fa-university'}
					type="fal"
					style={{ color: '#747474', fontSize: 24 }}
				/>
				<div className={'site-name'} title={data.name}>
					{data.name}
				</div>
			</React.Fragment>
		) : (
			<React.Fragment>
				<img
					src={Application.Utilities.getSiteLogoResourceServiceURL({
						siteId: data.id,
						url: data.logo
					})}
					alt={data.name}
					onError={onError}
				/>
				{isShowSiteText ? (
					<div className={'site-name'} title={data.name}>
						{data.name}
					</div>
				) : null}
			</React.Fragment>
		)
	} else {
		//other-account-card
		_cardContent = (
			<React.Fragment>
				<div className="other-account-card">
					<Icon iconClass={IconNameMap['add-circle']} />
					<span className="account-label">{data.text}</span>
				</div>
			</React.Fragment>
		)
	}

	return (
		<div className={classList} {...attr}>
			{_cardContent}
		</div>
	)
}

PopularSectionCard.propTypes = {
	data: PropTypes.object,
	classes: PropTypes.string,
	onClickHandler: PropTypes.func
}

PopularSectionCard.defaultProps = {
	cardType: 'site-card' // site-info | custom-account
}

export default PopularSectionCard
