import React from 'react'
import { createStore } from 'redux'
import { Provider } from 'react-redux'
import ActSummaryButtons from '../../sections/ActSummaryButtons'
import { Button } from '../../../../../../framework/react/components/Button'
import { Modal } from '../../../../../../framework/react/components/Modal'
import currentProviderMock from './../__mocks__/currentProvider'
import providerReducer from '../../../../store/reducers/providerInfo'
import configureStore from 'redux-mock-store'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../../fastlink/conf/index'
import { debug } from 'webpack'
import { shallow } from 'enzyme'
import DeeplinkConstants from './../../../../filters/deeplink/DeeplinkConstants'

jest.mock('./../../../../conf')

jest.mock('../../../../../../framework/react/components/Modal', () => {
	return {
		__esModule: true,
		Modal: () => <div className="modal-content"></div>
	}
})

describe('Account summary buttons', () => {
	let container = null
	let navigate
	let currentProvider
	let selectedAccounts
	let containerList
	let providerAccountId
	let allDeleted
	let nextButtonCallback
	let appflow
	let store
	let renderComponent

	beforeEach(() => {
		container = null
		navigate = jest.fn()
		currentProvider = {}
		selectedAccounts = {}
		containerList = ['bank']
		providerAccountId = '123456'
		allDeleted = false

		nextButtonCallback = jest.fn()
		appflow = 'VERIFICATION'

		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'AGGR'
			} else if (AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION) {
				return false
			}
		})

		store = createStore(providerReducer, {
			currentProvider: currentProviderMock
		})

		renderComponent = props => {
			container = mount(
				<Provider store={store}>
					<ActSummaryButtons
						navigate={navigate}
						currentProvider={props.currentProvider}
						selectedAccounts={props.selectedAccounts}
						containerList={props.containerList}
						providerAccountId={props.providerAccountId}
						allDeleted={props.allDeleted}
						appflow={props.appflow}
						nextButtonCallback={props.nextButtonCallback}
						handleCloseAppHandler={
							props.handleCloseAppHandler || function() {}
						}
						stopPolling={props.stopPolling || function() {}}
						deeplinkData={props.deeplinkData}
					/>
				</Provider>
			)
		}
	})

	it('Test if account summary buttons Container is loaded', () => {
		allDeleted = true
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
	})
	it('Test if Save and Finish button is not rendered when all accounts are deleted', () => {
		allDeleted = true
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}

		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(0)
	})
	it('Test if Save and Finish button is not rendered when product_type is not defined correctly', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return ''
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}

		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(0)
	})
	it('Agg - Test if container list is empty and allDeleted is false no buttons will be mounted.', () => {
		containerList = []
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(0)
	})
	it('Agg - Test if Cancel button is rendered', () => {
		allDeleted = true
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
	})
	it('Agg - Test if Cancel button handler is called', () => {
		Application.Wrapper.close = jest.fn(key => {
			return ''
		})
		let handleCloseAppHandler = jest.fn(key => {
			return ''
		})
		//stopPolling

		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'AGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			} else if (_key == AppParams.DISABLE_POPUP_ON_CANCEL) {
				return true
			}
		})

		allDeleted = true
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			handleCloseAppHandler: handleCloseAppHandler
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
		container.find('.button-container button#cancel-btn').simulate('click')
		expect(handleCloseAppHandler).toBeCalled()
	})
	it('Agg - Test if Cancel button handler is called when the DISABLE_POPUP_ON_CANCEL is false, it should open a popup', () => {
		Application.Wrapper.close = jest.fn(key => {
			return ''
		})
		let handleCloseAppHandler = jest.fn(key => {
			return ''
		})
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'AGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			} else if (_key == AppParams.DISABLE_POPUP_ON_CANCEL) {
				return false
			}
		})

		allDeleted = true
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			handleCloseAppHandler: handleCloseAppHandler
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
		container.find('.button-container button#cancel-btn').simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
	})
	it('Agg - Test if Save and Finish button is rendered', () => {
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}
		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(1)
	})
	it('Agg - Test if Save and Finish button handler is called', () => {
		Application.Wrapper.close = jest.fn(key => {
			return ''
		})
		let handleCloseAppHandler = jest.fn(key => {
			return ''
		})
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'AGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			} else if (_key == AppParams.DISABLE_POPUP_ON_CANCEL) {
				return true
			}
		})

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			handleCloseAppHandler: handleCloseAppHandler
		}
		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(1)
		container
			.find('.button-container button#save-finish-btn')
			.simulate('click')

		expect(handleCloseAppHandler).toBeCalled()
	})
	it('Agg - Test if Save and Link more account button is rendered', () => {
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}
		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(1)
	})
	it('Agg - Test if Save and Link more account button handler is called', () => {
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}
		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(1)
	})
	it('Agg - Test if Link more account button is rendered - when "disable_link_more_btn_for_verification" is false', () => {
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}

		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(1)
	})
	it('Agg - Test if Link more account button is rendered - when "disable_link_more_btn_for_verification" is true', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'AGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}

		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(1)
	})
	it('IAV - Test if Cancel button is rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VEERIFICATION'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		allDeleted = true
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
	})
	it('IAV - Test if Cancel button handler is called', () => {
		Application.Wrapper.close = jest.fn(key => {
			return ''
		})
		let handleCloseAppHandler = jest.fn(key => {
			return ''
		})
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VEERIFICATION'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			} else if (_key == AppParams.DISABLE_POPUP_ON_CANCEL) {
				return true
			}
		})

		allDeleted = true
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			handleCloseAppHandler: handleCloseAppHandler
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
		container.find('.button-container button#cancel-btn').simulate('click')
		expect(handleCloseAppHandler).toBeCalled()
	})
	it('IAV - Test if Cancel button handler is called when the DISABLE_POPUP_ON_CANCEL is false, it should open a popup', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VEERIFICATION'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			} else if (_key == AppParams.DISABLE_POPUP_ON_CANCEL) {
				return false
			}
		})

		allDeleted = true
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
		container.find('.button-container button#cancel-btn').simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
	})
	it('IAV - Test if Save and finish button is rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATION'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})
		let handleCloseAppHandler = jest.fn(key => {
			return ''
		})
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			handleCloseAppHandler: handleCloseAppHandler
		}

		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(1)
	})
	it('IAV - Test if Link more account button is rendered - when "disable_link_more_btn_for_verification" is false', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATION'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return false
			}
		})

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}
		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(1)
	})
	it('IAV - Test if Link more account button is not rendered - when "disable_link_more_btn_for_verification" is true', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATION'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}
		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(0)
	})
	// it('IAV - Test if the Link more account button handler is called', () => {})
	it('IAV+AGG - IAV - Test if Cancel button is rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		allDeleted = true

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
	})
	it('IAV+AGG - IAV - Test if Cancel button handler is called', () => {
		Application.Wrapper.close = jest.fn(key => {
			return ''
		})
		let handleCloseAppHandler = jest.fn(key => {
			return ''
		})
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			} else if (_key == AppParams.DISABLE_POPUP_ON_CANCEL) {
				return true
			}
		})

		allDeleted = true

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			nextButtonCallback: nextButtonCallback,
			handleCloseAppHandler: handleCloseAppHandler
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
		container.find('.button-container button#cancel-btn').simulate('click')
	})
	it('IAV+AGG - IAV - Test if Cancel button handler is called when the DISABLE_POPUP_ON_CANCEL is false, it should open a popup', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VEERIFICATION'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			} else if (_key == AppParams.DISABLE_POPUP_ON_CANCEL) {
				return false
			}
		})

		allDeleted = true

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			nextButtonCallback: nextButtonCallback
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
		container.find('.button-container button#cancel-btn').simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
	})
	it('IAV+AGG - IAV - Test if Next button is rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		allDeleted = true

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			nextButtonCallback: nextButtonCallback
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#next-btn')
		).toHaveLength(1)
	})
	it('IAV+AGG - IAV - Test if Next button is disabled for no selected accounts', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		allDeleted = true

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			nextButtonCallback: nextButtonCallback
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#next-btn')
		).toHaveLength(1)
		container.find('.button-container button#next-btn').simulate('click')
		expect(nextButtonCallback).not.toBeCalled()
	})
	it('IAV+AGG - IAV - Test if Next button handler is called', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		allDeleted = true

		selectedAccounts = {
			'1234': true
		}
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			nextButtonCallback: nextButtonCallback
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#next-btn')
		).toHaveLength(1)
		container.find('.button-container button#next-btn').simulate('click')
		expect(nextButtonCallback).toBeCalled()
	})
	it('IAV+AGG - IAV - Test if Save and Finish button is not rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		allDeleted = true

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			nextButtonCallback: nextButtonCallback
		}

		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(0)
	})
	it('IAV+AGG - IAV - Test if Link more account button is not rendered - when "disable_link_more_btn_for_verification" is false', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return false
			}
		})

		allDeleted = true

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			nextButtonCallback: nextButtonCallback
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(0)
	})
	it('IAV+AGG - IAV - Test if Link more account button is not rendered - when "disable_link_more_btn_for_verification" is true', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		allDeleted = true

		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			nextButtonCallback: nextButtonCallback
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(0)
	})
	it('IAV+AGG - Agg - Test if Cancel button is rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		allDeleted = true
		appflow = 'AGGREGATION'
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			nextButtonCallback: nextButtonCallback
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
	})
	it('IAV+AGG - Agg - Test if Cancel button handler is called', () => {
		Application.Wrapper.close = jest.fn(key => {
			return ''
		})
		let handleCloseAppHandler = jest.fn(key => {
			return ''
		})
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			} else if (_key == AppParams.DISABLE_POPUP_ON_CANCEL) {
				return true
			}
		})

		allDeleted = true
		appflow = 'AGGREGATION'
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			handleCloseAppHandler: handleCloseAppHandler
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
		container.find('.button-container button#cancel-btn').simulate('click')
		expect(handleCloseAppHandler).toBeCalled()
	})
	it('IAV+AGG - Agg - Test if Cancel button handler is called when the DISABLE_POPUP_ON_CANCEL is false, it should open a popup', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			} else if (_key == AppParams.DISABLE_POPUP_ON_CANCEL) {
				return false
			}
		})

		allDeleted = true
		appflow = 'AGGREGATION'
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow
		}

		act(() => {
			renderComponent(props)
		})
		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
		container.find('.button-container button#cancel-btn').simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
	})
	it('IAV+AGG - Agg - Test if Save and Finish button is rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		appflow = 'AGGREGATION'
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow
		}

		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(1)
	})
	it('IAV+AGG - Agg - Test if Save and Finish button handler is called', () => {
		Application.Wrapper.close = jest.fn(key => {
			return ''
		})
		let handleCloseAppHandler = jest.fn(key => {
			return ''
		})
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		appflow = 'AGGREGATION'
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			handleCloseAppHandler: handleCloseAppHandler
		}

		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(1)
		container
			.find('.button-container button#save-finish-btn')
			.simulate('click')
		expect(handleCloseAppHandler).toBeCalled()
	})
	it('IAV+AGG - Agg - Test if Link more account button is rendered - when "disable_link_more_btn_for_verification" is false', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return false
			}
		})

		appflow = 'AGGREGATION'
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow
		}

		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(1)
	})
	it('IAV+AGG - Agg - Test if Link more account button is rendered - when "disable_link_more_btn_for_verification" is true', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			} else if (
				_key == AppParams.DISABLE_LINK_MORE_BTN_FOR_VERIFICATION
			) {
				return true
			}
		})

		appflow = 'AGGREGATION'
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			appflow: appflow,
			nextButtonCallback: nextButtonCallback
		}

		act(() => {
			renderComponent(props)
		})

		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(1)
	})
	it('DEEPLINK : ADD - Test if all buttons are rendered', () => {
		allDeleted = false
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			deeplinkData: {
				isDeeplink: true,
				deeplinkType: DeeplinkConstants.FLOW_TYPES.ACCOUNT_ADDITION
			}
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(1)
		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(1)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(1)
	})

	it('DEEPLINK : REFRESH - Test if only Save And Finish button is rendered', () => {
		allDeleted = false
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			deeplinkData: {
				isDeeplink: true,
				deeplinkType: DeeplinkConstants.FLOW_TYPES.REFRESH
			}
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(1)
		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(0)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(0)
	})

	it('DEEPLINK : EDIT - Test if only Save And Finish button is rendered', () => {
		allDeleted = false
		let props = {
			navigate: navigate,
			currentProvider: currentProvider,
			selectedAccounts: selectedAccounts,
			containerList: containerList,
			providerAccountId: providerAccountId,
			allDeleted: allDeleted,
			deeplinkData: {
				isDeeplink: true,
				deeplinkType: DeeplinkConstants.FLOW_TYPES.EDIT_CREDENTIALS
			}
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.button-container')).toHaveLength(1)
		expect(
			container.find('.button-container button#save-finish-btn')
		).toHaveLength(1)
		expect(
			container.find('.button-container button#link-more-acocunt-btn')
		).toHaveLength(0)
		expect(
			container.find('.button-container button#cancel-btn')
		).toHaveLength(0)
	})
})
// it('IAV+AGG - Agg - Test if Save and Link more account button handler is called', () => {})
