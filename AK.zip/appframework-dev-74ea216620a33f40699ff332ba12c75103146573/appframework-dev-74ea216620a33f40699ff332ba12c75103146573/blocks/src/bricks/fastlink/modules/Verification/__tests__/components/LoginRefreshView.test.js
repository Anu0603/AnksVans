import React from 'react'
import LoginRefreshView from '../../components/LoginRefreshView'
import configureStore from 'redux-mock-store'

const mockStore = configureStore([])

import { getString } from '../../../../conf'
jest.mock('../../../../conf')

describe('Login Refresh View Section', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	let props = { currentProvider: { hexCode2: '#454545' } }

	it('Check if Login Refresh View is rendered', () => {
		act(() => {
			container = shallow(<LoginRefreshView {...props} />)
		})
		expect(container.find('.login-message-wrapper')).toHaveLength(1)
	})

	it('Check if login refresh spinner is rendered', () => {
		container = mount(<LoginRefreshView {...props} />)
		expect(container.find('.spinner')).toHaveLength(1)
	})

	it('Check if verifying login text is shown', () => {
		let text = 'Securely Verifying Your Login...'
		act(() => {
			getString.mockImplementation(_key => {
				if (_key == 'verification_login_stepper_text') {
					return text
				}
				return ''
			})
			container = mount(<LoginRefreshView {...props} />)
		})
		expect(container.find('.login-refresh-label').text()).toEqual(text)
	})
})
