import React from 'react'
import Constants from '../../../../router/Constant'
import {
    getString,
    AppStrings,
    AutoIds,
    getParam,
    AppParams
} from '../../../../conf'
import Postmessage from "./../../../../components/ExternalNotification";

class Timer extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            time: {},
            seconds: Math.floor(props.timeinSeconds / 1000)
        }
        this.timer = 0
        this.startTimer = this.startTimer.bind(this)
        this.countDown = this.countDown.bind(this)
        this.startTimer()
    }

    static defaultProps = {
		time: {},
		seconds: 0,
		updateProviderdetails: () => {},
		navigate: () => {}
	}

    secondsToTime(secs) {
        let divisor_for_minutes = secs % (60 * 60)
        let minutes = Math.floor(divisor_for_minutes / 60)

        let divisor_for_seconds = divisor_for_minutes % 60
        let seconds = Math.ceil(divisor_for_seconds)
        if (seconds <= 9) {
            seconds = '0' + seconds
        }

        let obj = {
            mimute: minutes,
            seconds: seconds
        }
        return obj
    }

    componentDidMount() {
        let timeLeftVar = this.secondsToTime(this.state.seconds)
        this.setState({ time: timeLeftVar })
    }

    startTimer() {
        if (this.timer == 0 && this.state.seconds > 0) {
            this.timer = setInterval(this.countDown, 1000)
        }
    }

    componentWillUnmount() {
        clearInterval(this.timer)
    }

    shouldComponentUpdate(nextProps, nextState) {
        if (nextState.seconds == 0) {
            return false
        }
        return true
    }

    countDown() {
        // Remove one second, set state so a re-render happens.
        let seconds = this.state.seconds - 1
        this.setState({
            time: this.secondsToTime(seconds),
            seconds: seconds
        })

        // Check if we're at zero.
        if (seconds == 0) {
            clearInterval(this.timer)
            // Reset the redux store data
            this.props.updateProviderdetails({
                providerAccountId: this.props.providerAccountId,
                status: '',
                additionalStatus: '',
                requestId: ''
            })
            this.props.navigate(Constants.ROUTE_ERROR_MODULE, {
                errorCode: 'MFA_INFO_NOT_PROVIDED_IN_REAL_TIME_BY_USER_VIA_APP',
                providerAccountId: this.props.providerAccountId
            })
            Postmessage.addUpdateProviderAccountsData({
                status: "FAILED",
                requestId: this.props.requestId,
                additionalStatus: "MFA_INFO_NOT_PROVIDED_IN_REAL_TIME_BY_USER_VIA_APP",
                providerAccountId: this.props.providerAccountId
            });
        }
    }

    render() {
        return (
            <div className={'row timer-wrapper'} autoid="mfa-page-timer">
                {getString(AppStrings.MFA_TIMER_TEXT)} {this.state.time.mimute}:
                {this.state.time.seconds}
            </div>
        )
    }
}

export default Timer
