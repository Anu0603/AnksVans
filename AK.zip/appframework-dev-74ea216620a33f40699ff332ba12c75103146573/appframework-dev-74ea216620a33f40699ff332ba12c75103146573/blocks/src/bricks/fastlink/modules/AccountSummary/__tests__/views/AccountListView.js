import React from 'react'

import AccountListView from './../../views/AccountListView'

describe('Sample Test Case', () => {
	it('Sample Test Case', () => {
		expect(1 + 1).toBe(2)
	})
})
