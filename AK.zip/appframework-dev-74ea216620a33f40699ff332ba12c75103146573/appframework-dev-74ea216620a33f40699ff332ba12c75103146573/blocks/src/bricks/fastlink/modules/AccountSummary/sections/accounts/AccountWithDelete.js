import Account from './Account'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../conf'

import React, { useState } from 'react'
import { Button } from '../../../../../../framework/react/components/Button'
import { Modal } from './../../../../../../framework/react/components/Modal'
import AccountsService from '../../../../services/account/AccountsService'
import { Icon } from '../../../../../../framework/react/components/Icon'

const AccountWithDelete = props => {
	const accountsService = new AccountsService()
	const disableTrashIcon = getParam(AppParams.DISABLE_TRASH_ICON)
	const disabelPopupOnDelete = getParam(AppParams.DISABLE_POPUP_ON_DELETE)

	let bgColorInline = {
		backgroundColor: props.currentProvider.hexCode1
	}

	const showHidePopUp = flag => {
		deletePopupStateSetState({
			showPopup: flag
		})
		console.log(deletePopupState.showPopup)
	}

	let [deletePopupState, deletePopupStateSetState] = useState({
		showPopup: false
	})

	const deleteAccountHandler = function() {
		accountsService.deleteAccount({ accountId: props.id }).then(
			() => {
				props.deleteCallback(props.id)
			},
			() => {
				props.deleteCallback(null)
			}
		)
	}

	const isDisplayDeleteConfPopUp = () => {
		if (disabelPopupOnDelete) {
			deleteAccountHandler()
		} else {
			showHidePopUp(true)
		}
	}

	let colorInline = {
		color: props.currentProvider.hexCode1
	}
	return (
		<React.Fragment>
			<Account {...props} />
			{!disableTrashIcon && (
				<div className="list-item-right">
					<a onClick={isDisplayDeleteConfPopUp.bind(this)}>
						<Icon iconClass="fa-trash-alt" style={colorInline} />
					</a>
				</div>
			)}
			{deletePopupState.showPopup && (
				<Modal
					backDropEnabled={true}
					onBackDropClick={() => showHidePopUp(false)}
					crossIconEnabled={true}
					show={deletePopupState.showPopup}
					className="small custom-align"
					onCrossIconClick={() => showHidePopUp(false)}
				>
					<div className="delete-cnf-msg" style={colorInline}>
						{getString(
							AppStrings.ACCOUNT_SUMMARY_DELETE_POPUP_CONFIRMATION_TEXT
						)}
					</div>
					<div className="modal-button-wrapper">
						<Button
							id="keepAccount"
							name="keepAccount"
							style={bgColorInline}
							label={getString(
								AppStrings.ACCOUNT_SUMMARY_DELETE_POPUP_KEEP_ACCOUNT_BUTTON_TEXT
							)}
							onClick={showHidePopUp.bind(this, false)}
							autoid={
								AutoIds.ACCOUNT_SUMMARY_BUTTON_LINK_MORE_ACCOUNTS
							}
						/>
						<Button
							id="deleteAccount"
							name="deleteAccount"
							variant="danger"
							reversed={true}
							label={getString(
								AppStrings.ACCOUNT_SUMMARY_DELETE_POPUP_DELETE_ACCOUNT_BUTTON_TEXT
							)}
							onClick={() => deleteAccountHandler()}
							autoid={
								AutoIds.ACCOUNT_SUMMARY_BUTTON_LINK_MORE_ACCOUNTS
							}
						/>
					</div>
				</Modal>
			)}
		</React.Fragment>
	)
}
export default AccountWithDelete
