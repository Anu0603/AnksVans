const landingViewProps = {
	editMode: {
		data: {
			editAccount: {
				CONTAINER: 'realEstate',
				providerAccountId: 11306769,
				accountName: 'qwe',
				id: 12411774,
				providerName: 'Custom Real Estate',
				accountType: 'REAL_ESTATE',
				isManual: true,
				includeInNetWorth: true,
				homeValue: { amount: 123, currency: 'AUD' },
				valuationType: 'MANUAL',
				address: { street: '', city: '', state: '', zip: '' }
			},
			isEdit: true,
			id: '123'
		}
	},
	addMode: {
		data: {}
	}
}

const successViewProps = { data: { id: 123 } }

export default {
	landingViewProps,
	successViewProps
}
