import React, { useRef } from 'react'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../conf'

import EnableAccountInfo from './EnableAllAccounts'
import { AccountList } from './AccountList'
import AccountSummaryTitle from './AccountSummaryTitle'

const ContainerList = props => {
	let accountListRef = useRef()
	let {
		selectedAccounts,
		containerAccountList,
		containerList,
		selectionOnChange,
		deleteCallback,
		allSelectionOnChange,
		currentProvider,
		appflow
	} = props

	/* verificationContainers is a list of all the Verification eligible containers give in th
	 * param.
	 */
	const verificationContainers = getParam(
		AppParams.VERIFICATION_ELIGBLE_CONTAINERS
	)

	/* Description: The accountAlias is a plain array of all the accounts of
	 * all the verification eligible containers.
	 * Note: There is no segregation in this array based on the container type. Do not use accountsAlias
	 * for any account modification related operations. Use it only for length calculations.
	 */
	let accountsAlias = []
	verificationContainers.forEach(container => {
		if (containerAccountList[container]) {
			accountsAlias.push(...containerAccountList[container])
		}
	})

	const isAllAccountsSelected = () => {
		let count = 0

		let containerAccountslength = accountsAlias && accountsAlias.length
		count = count + containerAccountslength

		if (count == 0 || Object.keys(containerAccountList).length == 0) {
			return false
		}
		return Object.keys(selectedAccounts).length == count
	}

	const accountSelectionType = getParam(
		AppParams.SUCCESS_ACCOUNT_SELECTION_TYPE
	)

	/*
    Fliter the verified accounts
  */
	const filterFailedAccounts = () => {
		if (!props.verifiedAccounts) {
			return
		}
		/* Description: Filter the successfully verified accounts from the containerAccountList
		 * for all the verification eligible containers and update the containerAccountList with the
		 * successfully veerified accounts by discarding the verification failed accounts.
		 */
		verificationContainers.forEach(container => {
			let bankAccounts = Object.assign(
				{},
				containerAccountList[container]
			)
			let tempList = []
			for (let i in bankAccounts) {
				if (
					Object.keys(props.verifiedAccounts).length >= 1 &&
					props.verifiedAccounts[bankAccounts[i].id] &&
					props.verifiedAccounts[bankAccounts[i].id].status
				) {
					tempList.push(bankAccounts[i])
				}
			}
			if (props.verifiedAccounts.length != 0) {
				containerAccountList[container] = tempList
			}
		})
	}

	/*
    If flow is verification, display bank accounts only
  */
	const selectFirstElmentForSingleSelection = () => {
		containerList = [] //Clear container list and add bank continaer only

		/* Update the containerList with the Verification eligible accounts, so that the
		 * list would be rendered only for the allowed containers.
		 */
		verificationContainers.forEach(container => {
			containerList.push(container)
		})

		/* Basically if accountsAlias.lenght is 0 it means something is not correct and nothing will be shown
		 * on the verification screen
		 */
		if (!accountsAlias.length) {
			containerList = []
		}

		/* The single select check to selecte the first account by default is removed because,
		 * for single account selection also, there shouldn't be any account selected by default.
		 */
		if (
			(accountsAlias && accountsAlias.length) === 1 &&
			Object.keys(selectedAccounts).length == 0
		) {
			accountsAlias[0].checked = true
			selectionOnChange({
				id: accountsAlias[0].id,
				checked: true,
				clearList: true
			})
		}
	}

	filterFailedAccounts()

	let multiSelect =
		accountSelectionType ==
		AppConstants.VERIFICATION_MULTI_ACCOUNT_SELECTION

	/* isSingleAccount flag is used to manage the accountSummaryTitle for single/multi account
	 * and also decide whether to show/hide the "Enable all accounts" checkbox on the screen.
	 */
	let isSingleAccount = false
	let accountsCount = 0
	/* The accountsCount is calculated for all the accounts of all the eligible container.
	 * Because there might be a scenario where, each eligible container have single account. but, still it is not a single
	 * account state and we have to show the "Enable all accounts" checkbox.
	 */
	verificationContainers.forEach(container => {
		accountsCount =
			accountsCount +
			(containerAccountList[container] &&
			containerAccountList[container].length
				? containerAccountList[container].length
				: 0)
	})

	if (accountsCount <= 1) {
		isSingleAccount = true
	}

	const getAccountSummaryTitle = () => {
		return (
			<React.Fragment>
				<AccountSummaryTitle
					appflow={appflow}
					isSingleAccount={isSingleAccount}
					currentProvider={props.currentProvider}
					deeplinkData={props.deeplinkData}
				/>
			</React.Fragment>
		)
	}

	const selectInfoDetailsForVerification = () => {
		if (verificationContainers.length > 0) {
			/* Description: This code is to sort the BANK container account based on the AccountId to maintain the order
			 * on the verificaiton screen when Navigated back from the Aggregation screen.
			 *
			 * The loop on verificationContainers will sort the accounts at the container level.
			 */
			verificationContainers.forEach(container => {
				let tempContainerList = containerAccountList[container]
				if (tempContainerList && tempContainerList.length > 0) {
					tempContainerList.sort((bankone, banktwo) => {
						return Number(banktwo.id) > Number(bankone.id) ? -1 : 1
					})
				}
				containerAccountList[container] = tempContainerList
			})

			selectFirstElmentForSingleSelection()
			const isAllCheckBoxSelected = isAllAccountsSelected()
			return (
				<React.Fragment>
					{multiSelect && !isSingleAccount && (
						<EnableAccountInfo
							checked={isAllCheckBoxSelected}
							currentProvider={currentProvider}
							allSelectionOnChange={allSelectionOnChange}
						/>
					)}
				</React.Fragment>
			)
		} else null
	}

	const getSelectInfoDetails = () => {
		switch (getParam(AppParams.PRODUCT_TYPE)) {
			case AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME:
				/* Description: This conditional check is to maintain the view based on the app-flow when the
				 * application is re-rendered.
				 */
				if (appflow === AppConstants.APP_FLOW_VERIFICATION) {
					return selectInfoDetailsForVerification()
				} else {
					/* Description: This code is to sort the selected BANK container account.
					 * To support the requirement for showing the selected accounts on top of the list, the accounts
					 * which were selected on the verification screen.
					 *
					 * The loop on verificationContainers will sort the accounts at the container level.
					 */
					verificationContainers.forEach(container => {
						let tempContainerList = containerAccountList[container]
						if (tempContainerList && tempContainerList.length > 0) {
							tempContainerList.sort((bankone, banktwo) => {
								return (
									Number(banktwo.checked) -
									Number(bankone.checked)
								)
							})
						}
						containerAccountList[container] = tempContainerList
					})
				}
				break
			case AppConstants.VERIFICATION_FLOW_NAME:
				return selectInfoDetailsForVerification()
			default:
				console.log('Aggregation Product Type')
		}
	}

	return (
		<React.Fragment>
			{getAccountSummaryTitle()}
			{getSelectInfoDetails()}
			<div
				ref={accountListRef}
				className="accounts-wrapper"
				autoid="success-accounts-list"
			>
				{containerList.map((_element, index) => {
					if (
						containerAccountList[_element] &&
						containerAccountList[_element].length > 0
					) {
						return (
							<AccountList
								key={_element}
								title={_element}
								currentProvider={props.currentProvider}
								list={containerAccountList[_element]}
								accountLength={accountsAlias.length}
								selectionOnChange={selectionOnChange}
								deleteCallback={deleteCallback}
								appflow={appflow}
							/>
						)
					}
				})}
			</div>
		</React.Fragment>
	)
}
export default ContainerList
