import React from 'react'
import CDVInitiateFormView from './../../../../components/initiate/form'
import AppConstants from '../../../../../../conf/constants/AppConstants'

jest.mock('./../../../../../../../../framework/react/components/Modal')

describe('CDV Initiate View - Form View', () => {
	let container = null
	beforeEach(() => {
		container = null
	})

	it('Check whether form section is rendered', () => {
		act(() => {
			container = shallow(<CDVInitiateFormView />)
		})
		expect(container.find('div.cdv-form-container')).toHaveLength(1)
	})

	it('Check whether account type options are rendered', () => {
		act(() => {
			container = shallow(<CDVInitiateFormView />)
		})
		expect(
			container.find('div.account-type').children('.account-type-options')
		).toHaveLength(1)
		expect(
			container
				.find('div.account-type')
				.children('.account-type-options')
				.children('#account-type-savings')
		).toHaveLength(1)
		expect(
			container
				.find('div.account-type')
				.children('.account-type-options')
				.children('#account-type-checking')
		).toHaveLength(1)
	})

	it('Check whether routing number field is rendered', () => {
		act(() => {
			container = shallow(<CDVInitiateFormView />)
		})
		expect(container.find('#routing-number')).toHaveLength(1)
	})

	it('Check whether account number fields are rendered', () => {
		act(() => {
			container = shallow(<CDVInitiateFormView />)
		})
		expect(container.find('#account-number')).toHaveLength(1)
		expect(
			container
				.find('div.info-txt')
				.first()
				.children()
				.last('.help-text')
		).toHaveLength(1)
	})

	it('Check whether detail info section is rendered', () => {
		act(() => {
			container = shallow(<CDVInitiateFormView />)
		})
		expect(container.find('div.info-txt').last()).toHaveLength(1)
	})

	it('Check whether help content link section is rendered', () => {
		act(() => {
			container = shallow(<CDVInitiateFormView />)
		})
		expect(container.find('div.helpContent')).toHaveLength(1)
	})

	it('Check whether Start verification button is rendered and clickable', () => {
		act(() => {
			container = shallow(<CDVInitiateFormView />)
		})
		expect(
			container
				.find('div.buttons-wrapper')
				.children()
				.simulate('click')
		)
	})

	it('Check whether help icon is clickable', () => {
		act(() => {
			container = shallow(<CDVInitiateFormView />)
		})
		expect(container.state().showHelpPopup).toEqual(false)
		container
			.find('div.info-txt')
			.first()
			.children()
			.first()
			.simulate('click')
		expect(container.state().showHelpPopup).toEqual(true)
		container
			.find('div.info-txt')
			.first()
			.children()
			.first()
			.simulate('click')
		expect(container.state().showHelpPopup).toEqual(false)
	})

	it('Check whether help label is clickable', () => {
		act(() => {
			container = shallow(<CDVInitiateFormView />)
		})
		expect(container.state().showHelpPopup).toEqual(false)
		container
			.find('div.info-txt')
			.first()
			.children()
			.last('.help-text')
			.simulate('click')
		expect(container.state().showHelpPopup).toEqual(true)
		container
			.find('div.info-txt')
			.first()
			.children()
			.last('.help-text')
			.simulate('click')
		expect(container.state().showHelpPopup).toEqual(false)
	})

	it('Check whether radio button is clickable by calling callbacks for both savings and checking', () => {
		let accountTypeChangedValue = null
		act(() => {
			container = shallow(
				<CDVInitiateFormView
					accountTypeSelection={
						AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
					}
					onAccountTypeChange={function(event) {
						accountTypeChangedValue = event.target.value
					}}
				/>
			)
		})
		accountTypeChangedValue = container
			.find('div.account-type')
			.children('.account-type-options')
			.children('#account-type-savings')
			.props().checked
			? AppConstants.CDV_INITIATE_ACC_TYPE_SAVINGS
			: AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
		expect(accountTypeChangedValue).toEqual(
			AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
		)

		container
			.find('div.account-type')
			.children('.account-type-options')
			.children('#account-type-savings')
			.simulate('change', {
				target: { value: AppConstants.CDV_INITIATE_ACC_TYPE_SAVINGS }
			})
		expect(accountTypeChangedValue).toEqual(
			AppConstants.CDV_INITIATE_ACC_TYPE_SAVINGS
		)
		container
			.find('div.account-type')
			.children('.account-type-options')
			.children('#account-type-savings')
			.simulate('change', {
				target: { value: AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING }
			})
		expect(accountTypeChangedValue).toEqual(
			AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
		)
	})

	it('Check whether radio button is selected as CHECKING when accountTypeSelection is passed as CHECKING', () => {
		let accountTypeChangedValue = null
		act(() => {
			container = shallow(
				<CDVInitiateFormView
					accountTypeSelection={
						AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
					}
				/>
			)
		})
		accountTypeChangedValue = container
			.find('div.account-type')
			.children('.account-type-options')
			.children('#account-type-savings')
			.props().checked
			? AppConstants.CDV_INITIATE_ACC_TYPE_SAVINGS
			: AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
		expect(accountTypeChangedValue).toEqual(
			AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
		)
	})

	it('Check whether radio button is selected as CHECKING when accountTypeSelection is passed as SAVINGS', () => {
		let accountTypeChangedValue = null
		act(() => {
			container = shallow(
				<CDVInitiateFormView
					accountTypeSelection={
						AppConstants.CDV_INITIATE_ACC_TYPE_SAVINGS
					}
				/>
			)
		})
		accountTypeChangedValue = container
			.find('div.account-type')
			.children('.account-type-options')
			.children('#account-type-savings')
			.props().checked
			? AppConstants.CDV_INITIATE_ACC_TYPE_SAVINGS
			: AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
		expect(accountTypeChangedValue).toEqual(
			AppConstants.CDV_INITIATE_ACC_TYPE_SAVINGS
		)
	})

	it('Check whether radio number change is calling the onRoutingNumberChange callback', () => {
		let onRoutingNumberChangeCalled = false
		act(() => {
			container = shallow(
				<CDVInitiateFormView
					accountTypeSelection={
						AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
					}
					onRoutingNumberChange={function(event) {
						onRoutingNumberChangeCalled = true
					}}
				/>
			)
		})
		expect(onRoutingNumberChangeCalled).toEqual(false)
		container.find('#routing-number').simulate('change')
		expect(onRoutingNumberChangeCalled).toEqual(true)
	})

	it('Check whether account number change is calling the onAccountNumberChange callback', () => {
		let onAccountNumberChangeCalled = false
		act(() => {
			container = shallow(
				<CDVInitiateFormView
					accountTypeSelection={
						AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
					}
					onAccountNumberChange={function(event) {
						onAccountNumberChangeCalled = true
					}}
				/>
			)
		})
		expect(onAccountNumberChangeCalled).toEqual(false)
		container.find('#account-number').simulate('blur')
		setTimeout(function() {
			expect(onAccountNumberChangeCalled).toEqual(true)
		}, 100)
	})

	it('Check whether routingNumberError is rendered', () => {
		act(() => {
			container = mount(
				<CDVInitiateFormView
					accountTypeSelection={
						AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
					}
					routingNumberError="Routing Number Not Valid"
				/>
			)
		})
		expect(
			container
				.find('div.form-content .tfield-container')
				.first()
				.hasClass('error')
		).toEqual(true)
	})

	it('Check whether accountNumberError is rendered', () => {
		act(() => {
			container = mount(
				<CDVInitiateFormView
					accountTypeSelection={
						AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
					}
					accountNumberError="Account Number Not Valid"
				/>
			)
		})
		expect(
			container
				.find('div.form-content .tfield-container')
				.last()
				.hasClass('error')
		).toEqual(true)
	})
})
