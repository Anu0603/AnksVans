import React, { Component } from 'react'
import FormBuilder from './../../../components/FormBuilder'
import SiteLoginFormParser from './../../../components/FormBuilder/SiteLoginFormParser'
import './../style/index.scss'
import ProviderAccountService from '../../../services/provider/ProviderAccountService'
import { Button } from './../../../../../framework/react/components/Button'
import WithState from './../../../hoc/WithState'
import Constants from '../../../router/Constant'
import { connect } from 'react-redux'
import { getString, AppStrings } from '../../../conf'
import Timer from './../components/timer'

class SiteLoginView extends Component {
	constructor(props) {
		super(props)
		this.providerAccountId = this.props.providerAccountId
		this.requestId = this.props.requestId
		this.mfaLoginForm = this.props.mfaLoginForm
		this.state = {
			mfaTimeout: this.mfaLoginForm.mfaTimeout,
			form: SiteLoginFormParser({
				formComponents: this.mfaLoginForm.row,
				providerAccountId: this.providerAccountId,
				formType: this.mfaLoginForm.formType
			}).getParserFormFieldsToDisplay()
		}
		this.providerAccountService = new ProviderAccountService()
		this.formSubtionRef = React.createRef()
	}

	static propTypes = {}

	static defaultProps = {
		navigate: () => {}
	}

	loginSubmitbtnhandler(response) {
		if (response) {
			this.props.updateProviderdetails(response)
			this.props.navigate(Constants.ROUTE_VERIFICATION_MODULE, response)
		}
	}

	handleSubmitBtnPress(fieldVlaue) {
		this.providerAccountService
			.addAccount({
				providerAccountId: this.props.providerAccountId,
				fieldVlaues: fieldVlaue,
				formType: this.mfaLoginForm.formType,
				mfaForm: this.props.mfaLoginForm.row
			})
			.then(this.loginSubmitbtnhandler.bind(this))
			.catch(e => {
				console.log(e)
			})
	}

	onSiteElementsFocus = event => {
		/* istanbul ignore else */
		if (event.target.type == 'button') {
			event.target.style.borderColor = this.props.currentProvider.hexCode2
		} else {
			event.target.style.outlineColor = this.props.currentProvider.hexCode2
		}
	}

	onSiteElementsBlur = event => {
		/* istanbul ignore else */
		if (event.target.type == 'button') {
			event.target.style.borderColor = 'inherit'
		} else {
			event.target.style.outlineColor = 'inherit'
		}
	}

	render() {
		let btnStyle = { color: this.props.currentProvider.hexCode1 }
		return (
			<div className="row login-form-wrapper">
				<div className="form-content align-form mfa">
					<div className="text info-text">
						{getString(AppStrings.MFA_INFO_TEXT)}
					</div>
					<FormBuilder
						form={this.state.form}
						autoId={'mfapage-form-fields'}
						btnClickCallback={this.handleSubmitBtnPress.bind(this)}
					>
						<Timer
							timeinSeconds={this.state.mfaTimeout}
							providerAccountId={this.providerAccountId}
							requestId={this.requestId}
							updateProviderdetails={
								this.props.updateProviderdetails
							}
							navigate={this.props.navigate}
						/>
						<div className={'button-wrapper'}>
							<Button
								style={btnStyle}
								classes="next-action-btn"
								size="md"
								variant="secondary"
								fullWidth={true}
								label="Submit"
								autoid="mfa-page-submit-btn"
								onFocus={this.onSiteElementsFocus.bind(this)}
								onBlur={this.onSiteElementsBlur.bind(this)}
							></Button>
						</div>
					</FormBuilder>
				</div>
			</div>
		)
	}
}

const mapDispatchToProps = dispatch => {
	return {
		updateProviderdetails: providerDetails =>
			dispatch({
				type: 'FETCH_PROVIDER_ACCOUNTS',
				payload: providerDetails
			})
	}
}

export default connect(
	null,
	mapDispatchToProps
)(WithState('currentProvider', SiteLoginView))
