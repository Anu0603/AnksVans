import React from 'react'
import PreVerificationView from './../../../components/invoke/preVerificationView'
import ProviderData from './../../__mocks__/provider'

describe('CDV Invoke View - Pre Verification', () => {
	let container = null
	beforeEach(() => {
		container = null
	})

	it('Check whether pre verification section is rendered without provider', () => {
		act(() => {
			container = shallow(<PreVerificationView />)
		})
		expect(container.find('div.cdv-invoke-pre-ver-content')).toHaveLength(1)
	})

	it('Check whether pre verification section is rendered with provider', () => {
		act(() => {
			container = shallow(
				<PreVerificationView provider={ProviderData.provider} />
			)
		})
		expect(container.find('div.cdv-invoke-pre-ver-content')).toHaveLength(1)
	})

	it('Check whether demarcate section is rendered ', () => {
		act(() => {
			container = shallow(
				<PreVerificationView provider={ProviderData.provider} />
			)
		})
		expect(
			container.find('div.cdv-invoke-pre-ver-content .demarcate')
		).toHaveLength(1)
	})

	it('Check whether text content is rendered ', () => {
		act(() => {
			container = shallow(
				<PreVerificationView provider={ProviderData.provider} />
			)
		})
		expect(
			container.find('div.cdv-invoke-pre-ver-content .text-content')
		).toHaveLength(1)
	})

	it('Check whether button is rendered ', () => {
		act(() => {
			container = shallow(
				<PreVerificationView provider={ProviderData.provider} />
			)
		})
		expect(
			container.find('div.cdv-invoke-pre-ver-content .btn-wrapper')
		).toHaveLength(1)
	})

	it('Check whether button label is of primary color', () => {
		act(() => {
			container = shallow(
				<PreVerificationView provider={ProviderData.provider} />
			)
		})
		expect(
			container
				.find('.btn-wrapper')
				.children(0)
				.prop('style')['color']
		).toEqual('#3E0046')
	})

	it('Check whether class passed to component is attached to the compnent base element', () => {
		act(() => {
			container = shallow(
				<PreVerificationView
					classes="abc"
					provider={ProviderData.provider}
				/>
			)
		})
		expect(
			container.find('div.cdv-invoke-pre-ver-content').prop('className')
		).toMatch(/abc/)
	})

	it('Check whether info icon is clickable', () => {
		act(() => {
			container = shallow(
				<PreVerificationView provider={ProviderData.provider} />
			)
		})
		expect(container.state().showInfoPopup).toEqual(false)
		container
			.find('.text-content')
			.children('.text')
			.last()
			.children('.tooltip-spacer')
			.children()
			.simulate('click')
		expect(container.state().showInfoPopup).toEqual(true)
		container
			.find('.text-content')
			.children('.text')
			.last()
			.children('.tooltip-spacer')
			.children()
			.simulate('click')
		expect(container.state().showInfoPopup).toEqual(false)
	})
})
