import React, { Component } from 'react'
import { connect } from 'react-redux'
import { Button } from '../../../../../framework/react/components/Button'
import CONSTANTS from './../../../router/Constant'
import {
	Icon,
	IconNameMap
} from '../../../../../framework/react/components/Icon'
import RealEstateService from '../../../services/account/RealEstateService'
import AccountsService from '../../../services/account/AccountsService'
import { CurrencyFormatter } from './../../../../../framework/react/components/CurrencyFormatter'
import { AppStrings, getString, AppParams } from '../../../../fastlink/conf'
import SmartzipModal from './SmartzipModal'
import DeleteModal from './DeleteModal'
import ErrorBanner from './../../../components/Error/ErrorBanner'
import ErrorContent from './../../../components/Error/ErrorContent'
import { getParam } from '../../../conf/utilities/Utilities'
import { Spinner } from '../../../../../framework/react/components/Spinner'
class SuccessView extends Component {
	constructor(props) {
		super(props)
		this.state = {
			curreny: '',
			amount: '',
			accountName: props.data.accountName,
			valuationType: '',
			showSmartZipPopup: false,
			showCancelCnfModal: false,
			errorReason: '',
			errorStatus: '',
			showSpinner: true
		}

		this.realEstateService = new RealEstateService()
		this.realEstateDataResp
	}

	static propTypes = {}

	static defaultProps = {}

	showHideSmartzipPopup = flag => {
		this.setState({ showSmartZipPopup: flag })
	}

	componentDidMount() {
		const id = this.props.data.id

		this.realEstateService.getRealEstate({ id }).then(resp => {
			resp.account[0].accountName = this.props.data.accountName
			this.realEstateDataResp = resp
			this.props.onAddRealEstate(resp)
			this.setState({
				currency: resp.account[0].homeValue.currency,
				amount: resp.account[0].homeValue.amount,
				valuationType: resp.account[0].valuationType,
				// accountName: resp.account[0].accountName,
				showSpinner: false
			})
		})
	}

	handleEdit() {
		this.props.showNextView('RE_LANDING_VIEW', {
			isEdit: true,
			editAccount: this.realEstateDataResp.account[0]
		})
	}

	handleDelete() {
		const accountId = this.props.data.id
		new AccountsService().deleteAccount({ accountId }).then(
			() => {
				this.setState({ showCancelCnfModal: false })
				this.props.onDelete(accountId)
				this.props.navigate(CONSTANTS.ROUTE_LANDING_MODULE)
			},
			error => {
				console.log('error occured while deleting', error)
				this.setState({
					showCancelCnfModal: false,
					errorReason: 'REAL_ESTATE_UNABLE_TO_DELETE',
					errorStatus: 'REAL_ESTATE_UNABLE_TO_DELETE'
				})
			}
		)
	}

	render() {
		return (
			<div className="section-container">
				{this.state.showSmartZipPopup && (
					<SmartzipModal
						showHideSmartzipPopup={flag => {
							this.showHideSmartzipPopup(flag)
						}}
					/>
				)}

				{this.state.showCancelCnfModal && (
					<DeleteModal
						showHidePopUp={flag => {
							this.setState({ showCancelCnfModal: flag })
						}}
						handleDelete={this.handleDelete.bind(this)}
						accountName={
							this.realEstateDataResp.account[0].accountName
						}
					/>
				)}

				<div className="section-header">
					<div className="title">
						{getString(AppStrings.REAL_ESTATE_VIEW_ACCOUNT_TITLE)}
					</div>
				</div>
				{this.state.showSpinner ? (
					<Spinner id="largeSpinner" size="lg" />
				) : (
					<div>
						{this.state.errorStatus && (
							<React.Fragment>
								<ErrorBanner
									errorCode={this.state.errorReason}
								/>
								<ErrorContent
									errorCode={this.state.errorReason}
								/>
							</React.Fragment>
						)}

						<div className="form-content">
							<div className="sub-section pad-tb-2x sub-edit">
								<div className="title" id="accountname">
									{this.state.accountName}
								</div>
								{this.state.valuationType === 'SYSTEM' && (
									<div
										className="info-txt"
										id="smartzip-info-text-1"
									>
										{getString(
											AppStrings.REAL_ESTATE_SEE_MORE_DETAILS_TEXT
										)}
										<a
											onClick={this.showHideSmartzipPopup.bind(
												true
											)}
											className="info-link"
										>
											{getString(
												AppStrings.REAL_ESTATE_SMARTZIP
											)}
										</a>
									</div>
								)}
								{!getParam(
									AppParams.DISABLE_REALESTATE_EDIT
								) && (
									<Icon
										type="fal"
										iconClass={IconNameMap['edit-icon']}
										onClick={this.handleEdit.bind(this)}
									/>
								)}
								{this.state.currency && (
									<CurrencyFormatter
										id="currency"
										// style={colorInline}
										quantity={parseFloat(this.state.amount)}
										currency={this.state.currency}
										// negative={props.negativeCurrency}
										classes="list-second-sub-title"
									/>
								)}
							</div>
							<div className="pad-tb-2x btn-wrapper">
								<Button
									variant="primary"
									label={getString(
										AppStrings.REAL_ESTATE_SAVE_FINISH_BUTTON_LABEL
									)}
									fullWidth
									onClick={e => {
										// this.props.navigate(CONSTANTS.ROUTE_LANDING_MODULE);
										// Application.Wrapper.close()
										this.props.handleCloseAppHandler(e)
									}}
								/>
								{!this.props.isDeeplink && (
									<Button
										variant="secondary"
										label={getString(
											AppStrings.REAL_ESTATE_SAVE_AND_LINK_MORE_BUTTON_LABEL
										)}
										fullWidth
										onClick={() =>
											this.props.navigate(
												CONSTANTS.ROUTE_LANDING_MODULE
											)
										}
									/>
								)}

								{!this.props.isDeeplink && (
									<Button
										variant="tertiary"
										label={getString(
											AppStrings.ERROR_CANCEL_BUTTON_TEXT
										)}
										fullWidth
										onClick={() =>
											this.setState({
												showCancelCnfModal: true
											})
										}
									/>
								)}
							</div>
							{this.state.valuationType === 'SYSTEM' && (
								<div
									id="smartzip-info-text-2"
									className="info-txt txt-center"
								>
									{getString(
										AppStrings.REAL_ESTATE_FOOTER_TEXT
									)}{' '}
									<a
										onClick={this.showHideSmartzipPopup.bind(
											true
										)}
										className="info-link"
									>
										{getString(
											AppStrings.REAL_ESTATE_SMARTZIP_FOOTER_TEXT
										)}
									</a>
								</div>
							)}
						</div>
					</div>
				)}
			</div>
		)
	}
}

const mapStateToProps = state => {
	return {
		isDeeplink: state.deeplink.isDeeplink
	}
}

const mapDispatchToProps = dispatch => {
	return {
		onAddRealEstate: realEstateDetails =>
			dispatch({
				type: 'ADD_REAL_ESTATE_ACCOUNT',
				payload: { realEstate: realEstateDetails.account[0] }
			}),
		onDelete: accountID =>
			dispatch({
				type: 'REMOVE_REAL_ESTATE_ACCOUNT',
				payload: { accountID }
			})
	}
}
export default connect(mapStateToProps, mapDispatchToProps)(SuccessView)
