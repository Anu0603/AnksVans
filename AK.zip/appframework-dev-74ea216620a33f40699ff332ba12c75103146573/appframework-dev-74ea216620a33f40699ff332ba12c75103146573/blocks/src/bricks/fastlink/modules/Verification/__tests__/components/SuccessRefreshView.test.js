import React from 'react'
import SuccessRefreshView from '../../components/SuccessRefreshView'
import configureMockStore from 'redux-mock-store'
import { Provider } from 'react-redux'

const mockStore = configureMockStore()
const store = mockStore({})

import { getString } from '../../../../conf'
jest.mock('../../../../conf')

describe('Success Refresh View Section', () => {
	let container = null

	beforeEach(() => {
		container = null
	})
	let props = { currentProvider: { hexCode2: '#454545' } }

	it('Check if Success Refresh View is rendered', () => {
		act(() => {
			container = mount(
				<Provider store={store}>
					<SuccessRefreshView {...props} />
				</Provider>
			)
		})
		expect(container.find('.success-message-wrapper')).toHaveLength(1)
	})

	it('Check if success icon is rendered', () => {
		act(() => {
			container = mount(
				<Provider store={store}>
					<SuccessRefreshView {...props} />
				</Provider>
			)
		})
		expect(container.find('.success-refresh-icon')).toHaveLength(1)
	})

	it('Check if success text is shown', () => {
		let text = 'SUCCESS'
		act(() => {
			getString.mockImplementation(_key => {
				if (_key == 'verification_success_text') {
					return text
				}
				return ''
			})
			container = mount(
				<Provider store={store}>
					<SuccessRefreshView {...props} />
				</Provider>
			)
		})
		expect(container.find('.text').text()).toEqual(text)
	})
})
