import React from 'react'
import { Provider } from 'react-redux'
import configureStore from 'redux-mock-store'
import AcocuntSummaryTitle from '../../../sections/accounts/AccountSummaryTitle'
import { configure, shallow, mount } from 'enzyme'
import { Icon } from '../../../../../../../framework/react/components/Icon'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../../../fastlink/conf/index'
import DeeplinkConstants from './../../../../../filters/deeplink/DeeplinkConstants'

const mockStore = configureStore([])

jest.mock('../../../../../../fastlink/conf/index')

jest.mock('../../../../../../../framework/react/components/Modal', () => {
	return {
		__esModule: true,
		Modal: props => {
			props.onCrossIconClick()
			props.onBackDropClick()

			return <div className="modal-view"></div>
		}
	}
})
jest.mock('../../../../../../../framework/react/components/Icon')

describe('account summary title', () => {
	let container = null
	let isSingleAccount = false
	let currentProvider = 'institution name'
	let appflow = 'AGGR'

	beforeEach(() => {
		jest.clearAllMocks()
		container = null
	})

	it('Check if account summary title is loaded and pop up is closed', () => {
		isSingleAccount = false
		currentProvider = 'institution name'
		Icon.mockImplementation(prop => {
			prop.onClick()
		})
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AcocuntSummaryTitle
						isSingleAccount={isSingleAccount}
						currentProvider={currentProvider}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'VERIFICATIONPLUSAGGR'
			})
			renderComponent()
		})
		expect(container.find('div.account-summary-title')).toHaveLength(1)
	})
	it('Check if account summary title is loaded', () => {
		isSingleAccount = false
		currentProvider = 'institution name'
		appflow = 'VERIFICATION'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AcocuntSummaryTitle
						isSingleAccount={isSingleAccount}
						currentProvider={currentProvider}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'VERIFICATIONPLUSAGGR'
			})
			renderComponent()
		})
		expect(container.find('div.account-summary-title')).toHaveLength(1)
	})

	it('Check if account summary title is loaded', () => {
		isSingleAccount = false
		currentProvider = 'institution name'
		appflow = 'VERIFICATION'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AcocuntSummaryTitle
						isSingleAccount={isSingleAccount}
						currentProvider={currentProvider}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.SUCCESS_ACCOUNT_SELECTION_TYPE) {
					return AppConstants.VERIFICATION_SINGLE_ACCOUNT_SELECTION
				} else {
					return 'VERIFICATIONPLUSAGGR'
				}
			})
			renderComponent()
		})
		expect(container.find('div.account-summary-title')).toHaveLength(1)
	})

	it('Check if account summary title is loaded for single account', () => {
		isSingleAccount = true
		currentProvider = 'institution name'

		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AcocuntSummaryTitle
						isSingleAccount={isSingleAccount}
						currentProvider={currentProvider}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'VERIFICATION'
			})
			renderComponent()
		})
		expect(container.find('div.account-summary-title')).toHaveLength(1)
	})
	it('Check if account summary title is loaded for single account', () => {
		isSingleAccount = false
		currentProvider = 'institution name'

		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AcocuntSummaryTitle
						isSingleAccount={isSingleAccount}
						currentProvider={currentProvider}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'AGGR'
			})
			renderComponent()
		})
		expect(container.find('div.account-summary-title')).toHaveLength(1)
	})

	it('DEEPLINK - ADD - Check if account summary title is loaded', () => {
		isSingleAccount = false
		currentProvider = 'institution name'

		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			let deeplinkData = {
				isDeeplink: true,
				deeplinkType: DeeplinkConstants.FLOW_TYPES.ACCOUNT_ADDITION
			}
			container = mount(
				<Provider store={store}>
					<AcocuntSummaryTitle
						isSingleAccount={isSingleAccount}
						currentProvider={currentProvider}
						appflow={appflow}
						deeplinkData={deeplinkData}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'AGGR'
			})
			renderComponent()
		})
		expect(container.find('div.account-summary-title')).toHaveLength(1)
	})

	it('DEEPLINK - EDIT - Check if account summary title is loaded', () => {
		isSingleAccount = false
		currentProvider = 'institution name'

		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			let deeplinkData = {
				isDeeplink: true,
				deeplinkType: DeeplinkConstants.FLOW_TYPES.EDIT_CREDENTIALS
			}
			container = mount(
				<Provider store={store}>
					<AcocuntSummaryTitle
						isSingleAccount={isSingleAccount}
						currentProvider={currentProvider}
						appflow={appflow}
						deeplinkData={deeplinkData}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'AGGR'
			})
			renderComponent()
		})
		expect(container.find('div.account-summary-title')).toHaveLength(0)
	})

	it('DEEPLINK - REFRESH - Check if account summary title is loaded', () => {
		isSingleAccount = false
		currentProvider = 'institution name'

		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			let deeplinkData = {
				isDeeplink: true,
				deeplinkType: DeeplinkConstants.FLOW_TYPES.REFRESH
			}
			container = mount(
				<Provider store={store}>
					<AcocuntSummaryTitle
						isSingleAccount={isSingleAccount}
						currentProvider={currentProvider}
						appflow={appflow}
						deeplinkData={deeplinkData}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'AGGR'
			})
			renderComponent()
		})
		expect(container.find('div.account-summary-title')).toHaveLength(0)
	})
})
