import React from 'react'
import { Provider } from 'react-redux'
import ProviderData from './../../../__mocks__/provider'
import CDVCompleteFormView from './../../../../components/complete/form'
import configureStore from 'redux-mock-store'

const mockStore = configureStore([])
describe('CDV Complete View - Form View', () => {
	let container = null
	beforeEach(() => {
		container = null
	})

	let renderComponent = props => {
		let store = mockStore({
			currentProvider: ProviderData.provider,
			cdv: {
				verificationInfo: {}
			}
		})
		container = mount(
			<Provider store={store}>
				<CDVCompleteFormView
					{...props}
					currentProvider={ProviderData.provider}
				/>
			</Provider>
		)
	}

	it('Check whether form section and its elements are rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('div#cdv-complete-form')).toHaveLength(1)
		expect(container.find('div#info')).toHaveLength(1)
		expect(container.find('div#info').children('.text-info')).toHaveLength(
			1
		)
		expect(container.find('div#info').children('.title')).toHaveLength(1)
		expect(container.find('div#info-details')).toHaveLength(1)
		expect(container.find('div#info-details #account-number')).toHaveLength(
			1
		)
		expect(container.find('div#info-details #routing-number')).toHaveLength(
			1
		)
		expect(container.find('div#info-details #account-type')).toHaveLength(1)
		expect(container.find('div#input-form')).toHaveLength(1)
		expect(container.find('div#btn-wrapper')).toHaveLength(1)
		expect(container.find('div#btn-wrapper .next-action-btn')).toHaveLength(
			1
		)
	})

	it('Check whether form  info like account number, RTN, and acocunt type is correctly rendered', () => {
		act(() => {
			renderComponent({
				accountNumber: '98765432101234',
				routingNumber: '999999989',
				accountType: 'CHECKING',
				numberOfCredit: 2,
				isDebitEnabled: true
			})
		})
		expect(
			container
				.find('div#info-details #account-number')
				.contains('98765432101234')
		).toEqual(true)
		expect(
			container
				.find('div#info-details #routing-number')
				.contains('999999989')
		).toEqual(true)
		expect(
			container
				.find('div#info-details #account-type')
				.contains('checking')
		).toEqual(true)
	})

	it('Check whether form elements like credit and debit fields are correctly rendered for default values', () => {
		act(() => {
			renderComponent({
				accountNumber: '98765432101234',
				routingNumber: '999999989',
				accountType: 'CHECKING',
				numberOfCredit: 2,
				isDebitEnabled: true
			})
		})
		expect(container.find('div#input-form .deposit').length).toEqual(2)
		expect(container.find('div#input-form .withdrawal').length).toEqual(1)
	})

	it('Check whether form elements like credit and debit fields are correctly rendered for cobranded values', () => {
		act(() => {
			renderComponent({
				accountNumber: '98765432101234',
				routingNumber: '999999989',
				accountType: 'CHECKING',
				numberOfCredit: 4,
				isDebitEnabled: false
			})
		})
		expect(container.find('div#input-form .deposit').length).toEqual(4)
		expect(container.find('div#input-form .withdrawal').length).toEqual(0)
	})

	it('Check whether change in credit textfields calls the onCreditChange callback', () => {
		let onCreditChangeCalled = false

		act(() => {
			renderComponent({
				accountNumber: '98765432101234',
				routingNumber: '999999989',
				accountType: 'CHECKING',
				numberOfCredit: 2,
				isDebitEnabled: true,
				onCreditChange: function(event) {
					onCreditChangeCalled = true
				}
			})
		})
		expect(onCreditChangeCalled).toEqual(false)
		container
			.find('div#input-form .deposit')
			.first()
			.simulate('change')
		expect(onCreditChangeCalled).toEqual(true)

		onCreditChangeCalled = false
		container
			.find('div#input-form .deposit')
			.last()
			.simulate('change')
		expect(onCreditChangeCalled).toEqual(true)
	})

	it('Check whether change in debit textfields calls the onDebitChange callback', () => {
		let onDebitChangeCalled = false

		act(() => {
			renderComponent({
				accountNumber: '98765432101234',
				routingNumber: '999999989',
				accountType: 'CHECKING',
				numberOfCredit: 2,
				isDebitEnabled: true,
				onDebitChange: function(event) {
					onDebitChangeCalled = true
				}
			})
		})
		expect(onDebitChangeCalled).toEqual(false)
		container.find('div#input-form .withdrawal').simulate('change')
		expect(onDebitChangeCalled).toEqual(true)
	})

	it('Check whether click on submit button calls the onSubmit callback', () => {
		let onSubmitCalled = false

		act(() => {
			renderComponent({
				accountNumber: '98765432101234',
				routingNumber: '999999989',
				accountType: 'CHECKING',
				numberOfCredit: 2,
				isDebitEnabled: true,
				onSubmit: function(event) {
					onSubmitCalled = true
				}
			})
		})
		expect(onSubmitCalled).toEqual(false)
		container.find('div#btn-wrapper .next-action-btn').simulate('click')
		expect(onSubmitCalled).toEqual(true)
	})

	it('Check whether creditAmountErrors is rendered', () => {
		act(() => {
			renderComponent({
				accountNumber: '98765432101234',
				routingNumber: '999999989',
				accountType: 'CHECKING',
				numberOfCredit: 2,
				isDebitEnabled: true,
				creditAmountErrors: [
					'Credit Amount Not Valid',
					'Credit Amount Not Valid'
				]
			})
		})
		expect(
			container
				.find('.message-cnr')
				.first()
				.find('span')
				.text()
		).toEqual('Credit Amount Not Valid')
	})

	it('Check whether debitAmountErrors is rendered', () => {
		act(() => {
			renderComponent({
				accountNumber: '98765432101234',
				routingNumber: '999999989',
				accountType: 'CHECKING',
				numberOfCredit: 2,
				isDebitEnabled: true,
				debitAmountErrors: ['Debit Amount Not Valid']
			})
		})
		expect(
			container
				.find('.message-cnr')
				.last()
				.find('span')
				.text()
		).toEqual('Debit Amount Not Valid')
	})

	it('Check whether error section is rendered when isDataMisMatch is passed a true', () => {
		act(() => {
			renderComponent({
				accountNumber: '98765432101234',
				routingNumber: '999999989',
				accountType: 'CHECKING',
				numberOfCredit: 2,
				isDebitEnabled: true,
				isDataMisMatch: true
			})
		})
		expect(container.find('#cdv-compplete-error-section')).toHaveLength(1)
	})
})
