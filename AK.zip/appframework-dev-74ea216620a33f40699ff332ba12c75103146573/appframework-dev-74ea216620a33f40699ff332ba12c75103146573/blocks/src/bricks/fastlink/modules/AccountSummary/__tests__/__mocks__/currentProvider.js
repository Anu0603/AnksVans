const currentProvider = {
	id: 16442,
	hexCode1: '#084C8D',
	hexCode2: '#FE7506',
	name: 'Dag Site Multilevel',
	loginUrl: 'http://64.14.28.129/dag/index.do',
	favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_16442.SVG',
	logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_16442_1_1.PNG',
	authType: 'MFA_CREDENTIALS',
	countryISOCode: 'US',
	formType: 'login',
	loginForm: [
		{
			id: 150864,
			label: 'Username',
			form: '0001',
			fieldRowChoice: '0001',
			field: [
				{
					id: 65501,
					name: 'LOGIN',
					type: 'text',
					value: '',
					isOptional: false,
					valueEditable: true,
					placeHolder: 'Username'
				}
			]
		},
		{
			id: 150865,
			label: 'Password',
			form: '0001',
			fieldRowChoice: '0002',
			field: [
				{
					id: 65502,
					name: 'PASSWORD',
					type: 'password',
					value: '',
					isOptional: false,
					valueEditable: true,
					placeHolder: 'Password'
				}
			]
		}
	],
	tncValue: 1,
	showTnc: true
}

export default currentProvider
