import { AppStrings, getString } from '../../../../fastlink/conf'
const getCurrencyDropdownOptions = currencyOptionsParams => {
	return currencyOptionsParams.map(option => {
		return {
			displayText: getString('currency_' + option.toLowerCase()),
			optionValue: option
		}
	})
}

const buildDataObj = function() {
	let data = {}
	if (this.state.valuationType === 'manual') {
		data.homeValue = {
			amount: this.state.amount,
			currency: this.state.currency
		}
	} else {
		if (this.state.multiAddress.length === 0 || this.keepOrEditAddress) {
			data.address = {
				street: this.state.addressLine1,
				zip: this.state.zip ? this.state.zip : undefined,
				city: this.state.city ? this.state.city : undefined,
				state: this.state.stateName ? this.state.stateName : undefined
			}
		}
		if (this.state.multiAddress.length > 1 && !this.keepOrEditAddress) {
			data.address = this.state.multiAddress[
				this.state.selectedAddressIndex
			]
		}
	}
	data.includeInNetWorth = String(this.state.includeInNetWorth).toUpperCase()
	data.accountName = this.state.accountName
	data.valuationType = this.state.valuationType.toUpperCase()
	return data
}

const validateManualAccountFields = function() {
	this.errors.amountError = !this.state.amount
		? getString(AppStrings.ERROR_REQUIRED_FIELD)
		: ''

	this.errors.accountNameError = !this.state.accountName
		? getString(AppStrings.ERROR_REQUIRED_FIELD)
		: ''

	if (!this.errors.amountError) {
		this.errors.amountError = !/^\s*-?\d+(\.\d{1,2})?\s*$/.test(
			this.state.amount
		)
			? getString(AppStrings.REAL_ESTATE_ERROR_INVALID_VALUE)
			: this.errors.amountError
	}
	if (this.state.amount.indexOf('.') !== -1) {
		if (this.state.amount.length > 14) {
			this.errors.amountError = getString(
				AppStrings.REAL_ESTATE_ERROR_INVALID_VALUE
			)
		}
		const valueBeforeDecimal = this.state.amount.substr(
			0,
			this.state.amount.indexOf('.')
		)
		if (valueBeforeDecimal.length > 11) {
			this.errors.amountError = getString(
				AppStrings.REAL_ESTATE_ERROR_INVALID_VALUE
			)
		}
	}
	if (this.state.amount.indexOf('.') == -1 && this.state.amount.length > 11) {
		this.errors.amountError = getString(
			AppStrings.REAL_ESTATE_ERROR_INVALID_VALUE
		)
	}

	return !(this.errors.amountError || this.errors.accountNameError)
}

const validateAutomaticFields = function() {
	this.errors.accountNameError = !this.state.accountName
		? getString(AppStrings.ERROR_REQUIRED_FIELD)
		: ''

	this.errors.streetError = !this.state.addressLine1
		? getString(AppStrings.ERROR_REQUIRED_FIELD)
		: ''

	this.errors.cityError =
		!this.state.city && !this.state.zip
			? getString(AppStrings.ERROR_REQUIRED_FIELD)
			: ''
	this.errors.stateNameError =
		!this.state.stateName && !this.state.zip
			? getString(AppStrings.ERROR_REQUIRED_FIELD)
			: ''
	this.errors.zipError =
		!this.state.zip && !this.state.city && !this.state.stateName
			? getString(AppStrings.ERROR_REQUIRED_FIELD)
			: ''

	return !(
		this.errors.streetError ||
		this.errors.accountNameError ||
		this.errors.cityError ||
		this.errors.stateNameError ||
		this.errors.zipError
	)
}

const displayErrors = function() {
	if (this.state.valuationType === 'manual') {
		this.setState({
			errors: {
				...this.state.errors,
				amount: this.errors.amountError,
				accountName: this.errors.accountNameError
			}
		})
	} else {
		this.setState({
			errors: {
				...this.state.errors,
				accountName: this.errors.accountNameError,
				addressLine1: this.errors.streetError,
				city: this.errors.cityError,
				stateName: this.errors.stateNameError,
				zip: this.errors.zipError
			}
		})
	}
}

const getValuationType = function(disableManual, disableSystem) {
	if ((!disableManual && !disableSystem) || disableManual) {
		return 'system'
	}
	if (disableSystem) {
		return 'manual'
	}
}

const parseResponse = function(accountDetails) {
	accountDetails.amount = accountDetails.homeValue.amount.toString()
	accountDetails.currency = accountDetails.homeValue.currency
	accountDetails.valuationType = accountDetails.valuationType.toLowerCase()
	accountDetails.stateName = accountDetails.address
		? accountDetails.address.state.toLowerCase()
		: ''
	accountDetails.addressLine1 = accountDetails.address
		? accountDetails.address.street.toLowerCase()
		: ''
	accountDetails.city = accountDetails.address
		? accountDetails.address.city.toLowerCase()
		: ''
	accountDetails.zip = accountDetails.address
		? accountDetails.address.zip.toLowerCase()
		: ''
	accountDetails.currencyOptions = this.state.currencyOptions.map(item => {
		item.selected =
			item.optionValue === accountDetails.homeValue.currency
				? true
				: false
		return item
	})
}
export default {
	getCurrencyDropdownOptions,
	validateManualAccountFields,
	validateAutomaticFields,
	displayErrors,
	getValuationType,
	buildDataObj,
	parseResponse
}
