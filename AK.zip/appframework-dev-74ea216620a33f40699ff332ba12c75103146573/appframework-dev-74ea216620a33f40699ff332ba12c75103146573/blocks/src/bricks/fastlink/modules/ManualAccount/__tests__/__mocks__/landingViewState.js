export default {
	state: {
		accountName: 'Test',
		amount: '123',
		currency: 'USD',
		includeInNetWorth: true,
		errorReason: '',
		errorStatus: '',
		errors: {
			addressLine1: '',
			city: '',
			stateName: '',
			zip: '',
			amount: '',
			accountName: ''
		}
	}
}
