import React from 'react'
import { Provider } from 'react-redux'
import { AccountList } from '../../../sections/accounts/AccountList'
import configureStore from 'redux-mock-store'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../../../fastlink/conf/index'
const mockStore = configureStore([])

jest.mock('../../../../../../fastlink/conf/index')
jest.mock('../../../sections/accounts/AccountWithDelete', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="account-with-selection-view"></div>
		}
	}
})
jest.mock('../../../sections/accounts/AccountWithSelection', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="account-with-delete-view"></div>
		}
	}
})

describe('Account list', () => {
	let container = null
	let _element = 'bank'
	let currentProvider = 'institution name'
	let selectionOnChange = function() {}
	let deleteCallback = function() {}
	let appflow = 'AGGR'
	let containerAccountList = {}
	beforeEach(() => {
		containerAccountList = {
			bank: [
				{
					accountType: 'Savings',
					accountNumber: '12345',
					accountName: 'Test account3',
					amount: 12.34,
					currency: 'USD',
					negativeCurrency: true
				},
				{
					accountType: 'Savings',
					accountNumber: '123456',
					accountName: 'Test account1',
					amount: 22.34,
					currency: 'USD',
					negativeCurrency: true,
					checked: true
				},
				{
					accountType: 'Savings',
					accountNumber: '1234567',
					accountName: 'Test account2',
					amount: 2.34,
					currency: 'USD',
					negativeCurrency: true
				}
			]
		}
		container = null
	})

	it('Check if account list is loaded', () => {
		currentProvider = 'institution name'

		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountList
						key={_element}
						title={_element}
						currentProvider={currentProvider}
						list={containerAccountList[_element]}
						selectionOnChange={selectionOnChange}
						deleteCallback={deleteCallback}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'AGGR'
			})
			renderComponent()
		})
		expect(container.find('div.account-with-selection-view')).toHaveLength(
			3
		)
		expect(container.find('div.list-header').text()).toEqual('bank')
	})
	it('Check if account list is loaded', () => {
		currentProvider = 'institution name'

		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountList
						key={_element}
						title={_element}
						currentProvider={currentProvider}
						list={containerAccountList[_element]}
						selectionOnChange={selectionOnChange}
						deleteCallback={deleteCallback}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'VERIFICATIONPLUSAGGR'
			})
			renderComponent()
		})
		expect(container.find('div.list-header').text()).toEqual('bank')
		expect(container.find('div.account-with-selection-view')).toHaveLength(
			2
		)
	})
	it('Check if account list is loaded', () => {
		currentProvider = 'institution name'
		appflow = 'VERIFICATION'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountList
						key={_element}
						title={_element}
						currentProvider={currentProvider}
						list={containerAccountList[_element]}
						selectionOnChange={selectionOnChange}
						deleteCallback={deleteCallback}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'VERIFICATIONPLUSAGGR'
			})
			renderComponent()
		})
		expect(container.find('div.list-header').text()).toEqual('bank')
		expect(container.find('div.account-with-delete-view')).toHaveLength(3)
	})
	it('Check if account list is loaded', () => {
		currentProvider = 'institution name'
		appflow = 'VERIFICATION'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountList
						key={_element}
						title={_element}
						currentProvider={currentProvider}
						list={containerAccountList[_element]}
						selectionOnChange={selectionOnChange}
						deleteCallback={deleteCallback}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'VERIFICATION'
			})
			renderComponent()
		})
		expect(container.find('div.list-header').text()).toEqual('bank')
		expect(container.find('div.account-with-delete-view')).toHaveLength(3)
	})
})
