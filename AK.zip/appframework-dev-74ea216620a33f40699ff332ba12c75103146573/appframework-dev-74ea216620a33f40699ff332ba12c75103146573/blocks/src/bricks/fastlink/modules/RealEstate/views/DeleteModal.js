import React, { Component } from 'react'
import { AppStrings, getString } from '../../../../fastlink/conf'
import { Modal } from '../../../../../framework/react/components/Modal'
import { Button } from '../../../../../framework/react/components/Button'

const DeleteModal = props => {
	return (
		<Modal
			backDropEnabled={true}
			onBackDropClick={() => props.showHidePopUp(false)}
			crossIconEnabled={true}
			show={true}
			className="small"
			onCrossIconClick={() => props.showHidePopUp(false)}
		>
			<div className="help-text" id="confirm-text">
				{getString(
					AppStrings.ACCOUNT_SUMMARY_DELETE_POPUP_CONFIRMATION_TEXT
				)}
			</div>
			<div className="modal-button-wrapper">
				<Button
					id="continue-deleting-account"
					name="continue-deleting-account"
					label={getString(AppStrings.DELETE_BUTTON_TEXT)}
					onClick={props.handleDelete}
					// autoid={AutoIds.ACCOUNT_SUMMARY_BUTTON_LINK_MORE_ACCOUNTS}
				/>
				<Button
					id="exit"
					name="exit"
					variant="danger"
					reversed={true}
					label={getString(AppStrings.POPUP_CANCEL_BUTTON)}
					onClick={() => props.showHidePopUp(false)}
					// autoid={AutoIds.ACCOUNT_SUMMARY_BUTTON_LINK_MORE_ACCOUNTS}
				/>
			</div>
		</Modal>
	)
}
DeleteModal.defaultProps = {
	accountName: ''
}

export default DeleteModal
