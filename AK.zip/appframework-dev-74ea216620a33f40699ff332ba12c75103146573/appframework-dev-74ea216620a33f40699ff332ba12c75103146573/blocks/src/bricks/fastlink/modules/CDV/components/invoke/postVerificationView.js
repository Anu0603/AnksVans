import React, { Component } from 'react'
import classNames from 'classnames'
import { AppStrings, getString, AutoIds } from '../../../../conf'
import { Button } from '../../../../../../framework/react/components/Button'
import {
	Icon,
	IconNameMap
} from '../../../../../../framework/react/components/Icon'

import { Modal } from '../../../../../../framework/react/components/Modal'

class PostVerificationView extends Component {
	constructor(props) {
		super(props)
		this.state = {
			showInfoPopup: false,
			popupContent: getString(
				AppStrings.CDV_INVOKE_VERIFICATION_INFO_TEXT
			),
			providerView: this.props.provider ? true : false,
			noVerifiableAccount: this.props.noVerifiableAccount
		}
	}

	getInfoIconModalPopup() {
		return (
			<Modal
				className="small info-icon-modal"
				show={this.state.showInfoPopup}
				backDropEnabled={true}
				onBackDropClick={this.toggleInfoIcon.bind(this)}
				crossIconEnabled={true}
				onCrossIconClick={this.toggleInfoIcon.bind(this)}
			>
				<div
					dangerouslySetInnerHTML={{
						__html: this.state.popupContent
					}}
				></div>
			</Modal>
		)
	}

	toggleInfoIcon() {
		this.setState({
			showInfoPopup: !this.state.showInfoPopup
		})
	}

	render() {
		const baseClass = 'cdv-invoke-post-ver-content section-footer'
		let titleStyle = {
			color: this.state.providerView ? this.props.provider.hexCode1 : null
		}
		let btnStyle = {
			backgroundColor: this.state.providerView
				? this.props.provider.hexCode1
				: null
		}

		const classList = classNames(
			`${baseClass}`,
			this.props.classes && `${this.props.classes}`
		)

		return (
			<div className={classList}>
				<div className="sub-section">
					<span className="demarcate pad-tb-2x">
						{getString(
							AppStrings.CDV_INVOKE_POST_VERIFICATION_DEMARCATION_TEXT
						)}
					</span>
					<div className="text-content pad-tb-2x txt-center">
						<div className="title" style={titleStyle}>
							{getString(
								AppStrings.CDV_INVOKE_POST_VERIFICATION_TITLE
							)}
						</div>
						<div className="text text-info">
							{getString(
								AppStrings.CDV_INVOKE_POST_VERIFICATION_TEXT
							)}
							<span className="tooltip-spacer">
								<Icon
									classes="info-icon"
									iconClass={IconNameMap['info-circle']}
									onClick={e => {
										this.toggleInfoIcon()
									}}
								/>
							</span>
						</div>
					</div>
					<div className="btn-wrapper pad-b-2x">
						<Button
							style={this.state.providerView ? btnStyle : null}
							classes="enter-btn"
							size="md"
							variant="primary"
							fullWidth={true}
							label={getString(
								AppStrings.CDV_INVOKE_POST_VERIFICATION_BUTTON_TEXT
							)}
							autoid="login-page-button-submit-button"
							onClick={this.props.onSubmit}
						></Button>
					</div>
					<div>{this.getInfoIconModalPopup()}</div>
				</div>
			</div>
		)
	}
}
export default PostVerificationView
