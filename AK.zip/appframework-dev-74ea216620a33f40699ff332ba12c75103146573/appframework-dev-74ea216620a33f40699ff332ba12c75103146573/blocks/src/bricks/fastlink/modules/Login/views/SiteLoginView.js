import React, { Component } from 'react'
import FormBuilder from './../../../components/FormBuilder'
import SiteLoginFormParser from './../../../components/FormBuilder/SiteLoginFormParser'
import './../style/index.scss'
import ProviderAccountService from '@fastlinkRoot/services/provider/ProviderAccountService'
import { Button } from './../../../../../framework/react/components/Button'

import Tnc from './../sections/tnc'
import Reset from './../sections/reset'
import CommonService from '../../../services/common/MemPrefService'
import { getParam, AppParams } from '../../../conf'
import LoginRefreshView from './../../Verification/components/LoginRefreshView'
import CDVModule from './../../CDV'
import AppConstants from '../../../conf/constants/AppConstants'
import ErrorBanner from './../../../components/Error/ErrorBanner'
import ErrorContent from './../../../components/Error/ErrorContent'
import { AppStrings, getString } from '@fastlinkRoot/conf'

class SiteLoginView extends Component {
	constructor(props) {
		super(props)
		this.state = {
			form: SiteLoginFormParser({
				formComponents: this.props.form,
				formType: this.props.subViewType
			}).getParserFormFieldsToDisplay(),
			isLoginFormSubmitted: false
		}

		this.providerAccountService = new ProviderAccountService()
		this.commonService = new CommonService()
		this.formSubtionRef = React.createRef()
		this.inlineError = false
		this.tncCheckBox = {}
		this.tncCheckBox.handleTncCheckBox = this.handleTncCheckBox.bind(this)
		this.tncCheckBox.checkBoxId = 'tncCheckBoxId'
		this.tncCheckBoxParamValue = getParam('login_show_tnc_checkbox')
	}

	static propTypes = {}

	static defaultProps = {}

	// Need to callback handler required
	handleTncCheckBox(value) {}

	loginSubmitbtnhandler(response) {
		// Not required callback here
		if (this.props.showTnc) {
			this.commonService.setMemPrefValue({
				prefKey: 'externalAccTncRevision',
				perfValue: ['' + getParam(AppParams.TNC_VERSION)]
			})
		}
		if (response && this.props.onLoginComplete) {
			this.props.onLoginComplete(response)
		}
	}

	handleSubmitBtnPress(fieldVlaue) {
		this.providerAccountService
			.addAccount({
				providerId: this.props.providerId,
				providerAccountId: this.props.providerAccountId,
				formType: this.props.subViewType,
				fieldVlaues: fieldVlaue
			})
			.then(
				this.loginSubmitbtnhandler.bind(this),
				this.handleFailure.bind(this)
			)
		this.setState({ isLoginFormSubmitted: true })
	}

	handleFailure = () => {
		this.inlineError = true
		this.setState({
			isLoginFormSubmitted: false
		})
	}

	displayInlineError = () => {
		if (this.inlineError) {
			return (
				<React.Fragment>
					<ErrorBanner errorCode={'TECH_DIFF'} />
					<ErrorContent errorCode={'TECH_DIFF'} />
				</React.Fragment>
			)
		}
	}
	componentDidMount() {
		let anchorElemtns = document.querySelectorAll('.login-help-text a')
		for (let i = 0; i < anchorElemtns.length; i++) {
			console.log('anchorElemtns' + anchorElemtns[i])
			let href = anchorElemtns[i].getAttribute('href').substring(2)
			href = href.substring(0, href.length - 2)
			anchorElemtns[i].setAttribute('href', href)
		}
	}
	componentDidUpdate(prevProps, prevState) {
		this.inlineError = false
	}

	displayErrorSection = () => {
		if (this.props.errorOccured) {
			return (
				<React.Fragment>
					<ErrorBanner errorCode={this.props.errorCode} />
					<ErrorContent errorCode={this.props.errorCode} />
				</React.Fragment>
			)
		}
	}

	onSiteElementsFocus = event => {
		if (event.target.type == 'button') {
			event.target.style.borderColor = this.props.currentProvider.hexCode2
		} else {
			event.target.style.outlineColor = this.props.currentProvider.hexCode2
		}
	}

	onSiteElementsBlur = event => {
		if (event.target.type == 'button') {
			event.target.style.borderColor = 'inherit'
		} else {
			event.target.style.outlineColor = 'inherit'
		}
	}

	render() {
		let btnStyle = { color: this.props.currentProvider.hexCode1 }
		return (
			<React.Fragment>
				{this.state.isLoginFormSubmitted ? (
					<LoginRefreshView {...this.props} />
				) : (
					<div>
						{this.displayErrorSection()}
						{this.displayInlineError()}

						<div className="login-form-wrapper">
							{this.props.helpText && (
								<div
									className="login-help-text form-content pad-lr-sx"
									dangerouslySetInnerHTML={{
										__html: this.props.helpText
									}}
								></div>
							)}
							<div className="form-content">
								<span className="edit-credentials-text">
									{this.props.isEditDeeplink &&
										getString(
											AppStrings.LOGIN_EDIT_CREDENTIALS_LABEL
										)}
								</span>
								<FormBuilder
									form={this.state.form}
									btnClickCallback={this.handleSubmitBtnPress.bind(
										this
									)}
								>
									{this.props.showTnc && (
										<Tnc
											{...this.props.currentProvider}
											tncCheckBox={this.tncCheckBox}
											tncCheckBoxParamValue={
												this.tncCheckBoxParamValue
											}
											onFocus={this.onSiteElementsFocus.bind(
												this
											)}
											onBlur={this.onSiteElementsBlur.bind(
												this
											)}
										/>
									)}
									<div className={'button-wrapper'}>
										<Button
											style={btnStyle}
											classes="next-action-btn"
											size="md"
											variant="secondary"
											fullWidth={true}
											label={
												this.props.isEditDeeplink
													? getString(
															AppStrings.LOGIN_UPDATE_BUTTON_TEXT
													  )
													: getString(
															AppStrings.LOGIN_SUBMIT_BUTTON_TEXT
													  )
											}
											autoid="login-page-button-submit-button"
											onFocus={this.onSiteElementsFocus.bind(
												this
											)}
											onBlur={this.onSiteElementsBlur.bind(
												this
											)}
										></Button>
									</div>
								</FormBuilder>
								{!this.props.isEditDeeplink && (
									<Reset
										{...this.props.currentProvider}
										onFocus={this.onSiteElementsFocus.bind(
											this
										)}
										onBlur={this.onSiteElementsBlur.bind(
											this
										)}
									/>
								)}
							</div>
							{getParam(AppParams.ENABLE_CDV) &&
								(getParam(AppParams.SHOW_CDV_ON_LOGIN) ||
									this.props.errorOccured) && (
									<div className="cdv-login-container">
										<CDVModule
											navigate={this.props.navigate}
											provider={
												this.props.currentProvider
											}
											path={AppConstants.CDV_PATH_INVOKE}
										/>
									</div>
								)}
						</div>
					</div>
				)}
			</React.Fragment>
		)
	}
}

export default SiteLoginView
