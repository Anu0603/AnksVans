import React from 'react'
import { Provider } from 'react-redux'
import VerificationModule from '../index'
import configureStore from 'redux-mock-store'

const mockStore = configureStore([])

jest.mock('../views/VerificationView', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="verification-view"></div>
		}
	}
})

describe('Verification Module', () => {
	let container = null
	beforeEach(() => {
		container = null
	})

	let renderComponent = () => {
		let store = mockStore({
			search: { providers: [] }
		})
		container = mount(
			<Provider store={store}>
				<VerificationModule />
			</Provider>
		)
	}

	it('Check if verification module rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('div.verification-view')).toHaveLength(1)
	})
})
