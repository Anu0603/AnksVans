import React, { Component } from 'react'

import SiteSelectionView from './views/SiteSelectionView'
import './style/index.scss'

class SiteSelectionModule extends Component {
	constructor(props) {
		super(props)
		this.state = {}
	}

	static propTypes = {}

	static defaultProps = {}

	componentDidMount() {}

	render() {
		return <SiteSelectionView navigate={this.props.navigate} />
	}
}

export default SiteSelectionModule
