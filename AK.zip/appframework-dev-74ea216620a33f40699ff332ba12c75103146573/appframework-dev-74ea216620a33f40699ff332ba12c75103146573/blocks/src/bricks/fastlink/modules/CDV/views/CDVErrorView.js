import React, { Component } from 'react'
import { ErrorPage } from '../../../components/Error/'
import SiteBgColor from './../../../hoc/SiteBgColor'
import WithState from './../../../hoc/WithState'
import { AutoIds } from '../../../conf'

class CDVErrorView extends Component {
	constructor(props) {
		super(props)
	}

	render() {
		return (
			<div
				className="cdv-error-section"
				autoid={AutoIds.CDV_ERROR_CONTAINER}
			>
				<ErrorPage errorCode={this.props.errorCode} />
			</div>
		)
	}
}

export default WithState('currentProvider', SiteBgColor(CDVErrorView))
