import React from 'react'
import { Provider } from 'react-redux'
import utils from '../../utils/utils'
import ConnectedLandingView, { LandingView } from '../../views/LandingView'
import { createStore } from 'redux'
import currentProviderMock from './../__mocks__/currentProvider'
import providerReducer from './../../../../store/reducers/providerInfo'
import propsMock from '../__mocks__/props'
import { Button } from '../../../../../../framework/react/components/Button'
import Dropdown from '../../../../../../framework/react/components/Dropdown'
import { _AppParams } from '../../../../conf/constants/param'
import { getParam, getString } from '../../../../conf'
import ManualAccountService from '../../../../services/account/ManualAccountService'
import AccountsService from '../../../../services/account/AccountsService'
import ErrorBanner from '../../../../components/Error/ErrorBanner'

jest.mock('../../../../conf')
jest.mock('../../../../conf/utilities/Utilities')
jest.mock('moment', () => {
	const moment = jest.requireActual('moment')

	return moment
})

jest.mock('../../sections/DeleteModal', () => {
	return {
		__esModule: true,
		default: props => {
			return (
				<div className="modal-content">
					<button
						id="cancel-modal"
						onClick={() => {
							props.showHidePopUp(false)
						}}
					></button>
					<button
						id="delete-button"
						onClick={() => {
							props.handleDelete()
						}}
					></button>
				</div>
			)
		}
	}
})
jest.mock('./../../../../components/Error/ErrorBanner', () => {
	return {
		__esModule: true,
		default: () => <div className="alert-error"></div>
	}
})
jest.mock('./../../../../components/Error/ErrorContent', () => {
	return {
		__esModule: true,
		default: () => <div className="alert-detail"></div>
	}
})

utils.getCurrencyDropdownOptions = jest.fn().mockReturnValue([
	{
		displayText: 'USD',
		optionValue: 'USD'
	},
	{
		displayText: 'AUD',
		optionValue: 'AUD'
	}
])
utils.getFields = jest.fn().mockReturnValue([
	{
		id: 'account-name',
		name: 'accountName',
		type: 'text',
		properties: {
			value: 'Test',
			error: false,
			errorMessage: '',
			required: true,
			placeholder: 'Account Name',
			default: ''
		}
	},
	{
		id: 'account-number',
		name: 'accountNumber',
		type: 'text',
		properties: {
			value: 123098231,
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Account Number',
			default: ''
		}
	},
	{
		id: 'amount-due',
		name: 'amountDue',
		type: 'text',
		properties: {
			value: 230.77,
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Amount Due',
			default: ''
		}
	},
	{
		name: 'assetVsLiability',
		type: 'radio',
		properties: {
			value: 'asset',
			options: [
				{
					id: 'option-asset',
					name: 'asset-vs-liability',
					value: 'asset',
					label: 'Asset',
					checked: true
				},
				{
					id: 'option-liability',
					name: 'asset-vs-liability',
					value: 'liability',
					label: 'Liability',
					checked: false
				}
			]
		}
	},
	{
		id: 'balance',
		name: 'balance',
		type: 'text',
		properties: {
			value: 123.45,
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Balance',
			default: ''
		}
	},
	{
		id: 'currency',
		name: 'currency',
		type: 'dropdown',
		properties: {
			value: 'AUD',
			options: [
				{
					displayText: 'Australian Dollar(AUD)',
					optionValue: 'AUD',
					selected: true
				},
				{
					displayText: 'US Dollar(USD)',
					optionValue: 'USD',
					selected: false
				}
			],
			default: 'USD',
			placeholder: 'Currency'
		}
	},
	// {
	//   name: "frequency",
	//   type: "dropdown",
	//   properties: {
	//     value: "",
	//     options: getFrequencyOptions(),
	//     default: ""
	//   }
	// },
	{
		id: 'include-in-net-worth',
		name: 'includeInNetWorth',
		type: 'toggle',
		properties: {
			value: false,
			options: [
				{
					id: 'option-asset',
					name: 'include-in-net-worth',
					value: true,
					checked: true
				},
				{
					id: 'option-liability',
					name: 'include-in-net-worth',
					value: false,
					checked: false
				}
			]
		}
	},
	{
		id: 'memo',
		name: 'memo',
		type: 'text',
		properties: {
			value: 'Test memo.',
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Memo',
			default: ''
		}
	},
	{
		id: 'due-date',
		name: 'dueDate',
		type: 'datepicker',
		properties: {
			value: '2/2/2022',
			placeholder: 'Due Date'
		}
	},
	{
		id: 'nickname',
		name: 'nickname',
		type: 'text',
		properties: {
			value: 'Nickname',
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Nickname',
			default: ''
		}
	}
])

describe('Manual Account landing view', () => {
	let container = null
	let spy = null

	let appParam = {
		supported_currency: ['AUD', 'USD']
	}

	getParam.mockImplementation(key => {
		if (key === AppParams.SUPPORTED_CURRENCY)
			return appParam.supported_currency
		if (key === AppParams.ERROR_DISCRIPTION_TOOLTIP)
			return appParam.error_description_tooltip
	})

	getString.mockImplementation(_key => {
		switch (_key) {
			case AppStrings.ERROR_CANCEL_BUTTON_TEXT:
				return 'Cancel'
			default:
				break
		}
	})

	const setAppParam = paramValue => {
		appParam = { appParam, ...paramValue }
	}

	let props = propsMock

	beforeEach(() => {
		container = null
		spy = null
	})

	let renderComponent = () => {
		let store = createStore(providerReducer, {
			currentProvider: currentProviderMock
		})

		container = mount(
			<Provider store={store}>
				<ConnectedLandingView {...props.landingViewProps} />
			</Provider>
		)

		container
			.childAt(0)
			.childAt(0)
			.setState({
				accountTypeOptions: [
					{
						displayText: 'Savings',
						optionValue: 'SAVINGS',
						selected: true
					},
					{
						displayText: 'Checking',
						optionValue: 'CHECKING',
						selected: false
					}
				],
				selectedContainer: 'bank'
			})
		container.update()
	}

	it('Check whether landing view is rendered', () => {
		act(() => {
			renderComponent()
		})

		expect(container.find('.section-container')).toHaveLength(1)
	})

	it('Check whether landing view is rendered in non-edit mode', () => {
		const newProps = { ...props.landingViewProps, data: { isEdit: false } }
		const mountedContainer = mount(<LandingView {...newProps} />)

		const mock = jest.spyOn(utils, 'getFields')
		const instance = mountedContainer.instance()

		expect(mock).toHaveBeenCalled()
		expect(mountedContainer.find('.section-container')).toHaveLength(1)
		expect(instance.state.selectedAccountTypeValue).toBe('SAVINGS')
	})

	it('Check whether fields are mapped correctly', () => {
		// setAppParam({ disable_realestate_edit: true })
		const element = mount(<LandingView {...props.landingViewProps} />)

		element.setState({
			accountTypeOptions: [
				{
					displayText: 'Savings',
					optionValue: 'SAVINGS',
					selected: true
				},
				{
					displayText: 'Checking',
					optionValue: 'CHECKING',
					selected: false
				}
			],
			selectedContainer: 'bank'
		})

		element.update()

		const utilSpy = jest.spyOn(utils, 'getFields')
		spy = jest.spyOn(element.instance(), 'handleContainerChange')
		element.instance().forceUpdate()

		let dropdown = element.find(Dropdown).first()
		dropdown.prop('onChange')(() => null, {
			value: {
				displayText: 'Checking',
				optionValue: 'CHECKING',
				selected: true
			}
		})

		element.setState({
			fields: utils.getFields('BANK')
		})

		element.update()

		expect(spy).toHaveBeenCalled()
		expect(utilSpy).toHaveBeenCalled()
	})

	it('Check whether fields are validated on clicking Next', () => {
		const mock = jest.spyOn(
			ManualAccountService.prototype,
			'addManualAccount'
		)
		mock.mockReturnValue(
			new Promise(resolve => {
				resolve({
					account: [{ id: 4589743, accountName: 'Test' }]
				})
			})
		)
		const newMock = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		newMock.mockReturnValue(
			new Promise(resolve => {
				resolve({})
			})
		)
		// const submitSpy = jest.spyOn()

		act(() => {
			renderComponent()
		})

		container = container.childAt(0).childAt(0)

		spy = jest.spyOn(container.instance(), 'validateManualAccountFields')
		container.instance().forceUpdate()

		let button = container.find(Button).first()
		button.simulate('click')

		expect(mock).toHaveBeenCalled()
		expect(spy).toHaveBeenCalled()
	})

	it('Check whether input change updates state', () => {
		container = mount(<LandingView {...props.landingViewProps} />)
		spy = jest.spyOn(container.instance(), 'changeToStateInput')
		container.update()

		container.instance().changeToStateInput()

		// expect(container.state().selectedAccountTypeValue).toBe('CHECKING')
		expect(spy).toHaveBeenCalled()
	})

	it('Check whether radio change updates state', () => {
		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.instance()
			.changeToStateRadio(null, 'assetVsLiability', 1, true)

		let avlField = container
			.childAt(0)
			.childAt(0)
			.state()
			.fields.filter(c => c.name === 'assetVsLiability') // console.log(
		// 	container
		// 		.childAt(0)
		// 		.childAt(0)
		// 		.instance()
		// )

		expect(avlField[0].properties.value).toBe(true)
	})

	it('Check whether toggle change updates state', () => {
		container = mount(<LandingView {...props.landingViewProps} />)
		spy = jest.spyOn(container.instance(), 'changeToStateToggle')
		container.update()

		container.instance().changeToStateToggle()

		// expect(container.state().selectedAccountTypeValue).toBe('CHECKING')
		expect(spy).toHaveBeenCalled()
	})

	it('Check whether dropdown change updates state', () => {
		act(() => {
			renderComponent()
		})

		let currencyObj = {
			value: {
				displayText: 'USD',
				optionValue: 'USD',
				selected: true
			}
		}

		container
			.childAt(0)
			.childAt(0)
			.instance()
			.changeToStateDropdown(null, currencyObj, 'currency')

		let currencyField = container
			.childAt(0)
			.childAt(0)
			.state()
			.fields.filter(c => c.name === 'currency')

		container.update()

		expect(currencyField[0].properties.value).toBe('USD')
	})

	it('Check whether datepicker change updates state', () => {
		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.instance()
			.changeToStateDatePicker(null, 'dueDate')

		let ddField = container
			.childAt(0)
			.childAt(0)
			.state()
			.fields.filter(c => c.name === 'dueDate')

		ddField[0].properties.value = '04/27/2021'

		container.update()

		expect(ddField[0].properties.value).toBe('04/27/2021')
	})

	it('Submits correctly when clicking Next button', () => {
		spy = jest.spyOn(ManualAccountService.prototype, 'addManualAccount')
		spy.mockReturnValue(
			new Promise(resolve => {
				resolve({
					account: [{ id: 4589743, accountName: 'Test' }]
				})
			})
		)

		act(() => {
			renderComponent()
		})

		container
			.find(Button)
			.first()
			.simulate('click')
		expect(spy).toHaveBeenCalled()
	})

	it('Deletes account when clicking from delete modal', () => {
		spy = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		spy.mockReturnValue(
			new Promise(resolve => {
				resolve({})
			})
		)

		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.setState({ showDeleteModal: true })

		expect(container.find('.modal-content')).toHaveLength(1)

		container
			.childAt(0)
			.childAt(0)
			.instance()
			.handleDelete()

		expect(spy).toHaveBeenCalled()
	})

	it('Returns an error if delete fails', () => {
		spy = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		spy.mockReturnValue(
			new Promise((resolve, reject) => {
				reject('error')
			})
		)

		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.instance()
			.handleDelete()

		expect(spy).toHaveBeenCalled()
	})

	it('Correctly fires silent delete event', () => {
		spy = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		spy.mockReturnValue(
			new Promise(resolve => {
				resolve({})
			})
		)

		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.instance()
			.silentDelete()

		expect(spy).toHaveBeenCalled()
	})

	it('Shows error banner when an error occurs', () => {
		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.setState({ showErrorBanner: true })

		expect(container.find(ErrorBanner)).toHaveLength(1)
	})
})
