export default {
	provider: [
		{
			PRIORITY: 'POPULAR',
			id: 9001,
			name: 'DagInvestments',
			loginUrl: 'http://dag2.yodlee.com/dag/index.do',
			baseUrl: 'http://dag2.yodlee.com/dag/index.do',
			favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_Default.SVG',
			logo:
				'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_9001_1_1_test.PNG',
			status: 'Supported',
			isConsentRequired: false,
			authType: 'CREDENTIALS',
			languageISOCode: 'EN',
			primaryLanguageISOCode: 'EN',
			countryISOCode: 'CA',
			lastModified: '2019-05-07T23:50:00Z',
			forgetPasswordUrl: 'http://dag2.yodlee.com/dag/index.do',
			isAutoRefreshEnabled: true,
			dataset: [
				{
					name: 'ACCT_PROFILE',
					attribute: [
						{
							name: 'FULL_ACCT_NUMBER',
							container: ['investment'],
						},
						{
							name: 'HOLDER_NAME',
							container: ['investment'],
						},
					],
				},
				{
					name: 'BASIC_AGG_DATA',
					attribute: [
						{
							name: 'ACCOUNT_DETAILS',
							container: ['investment'],
						},
						{
							name: 'HOLDINGS',
							container: ['investment'],
						},
						{
							name: 'TRANSACTIONS',
							containerAttributes: {
								INVESTMENT: {
									numberOfTransactionDays: 90,
								},
							},
							container: ['investment'],
						},
						{
							name: 'BASIC_ACCOUNT_INFO',
							container: ['investment'],
						},
					],
				},
				{
					name: 'ADVANCE_AGG_DATA',
					attribute: [
						{
							name: 'COVERAGE',
							container: ['investment'],
						},
					],
				},
			],
			isAddedByUser: 'false',
		},
		{
			PRIORITY: 'POPULAR',
			id: 2852,
			name: 'Bank of America',
			loginUrl:
				'https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go',
			baseUrl1: 'https://www.bankofamerica.com/',
			favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_2852.SVG',
			logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_2852_1_2.SVG',
			status: 'Supported',
			isConsentRequired: false,
			authType: 'CREDENTIALS',
			languageISOCode: 'EN',
			primaryLanguageISOCode: 'EN',
			countryISOCode: 'US',
			lastModified: '2020-02-12T15:24:00Z',
			forgetPasswordUrl:
				'https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go',
			isAutoRefreshEnabled: true,
			capability: [
				{
					name: 'CHALLENGE_DEPOSIT_VERIFICATION',
					container: ['bank'],
				},
			],
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					attribute: [
						{
							name: 'ACCOUNT_DETAILS',
							container: ['bank'],
						},
						{
							name: 'TRANSACTIONS',
							containerAttributes: {
								BANK: {
									numberOfTransactionDays: 365,
								},
							},
							container: ['bank'],
						},
						{
							name: 'BASIC_ACCOUNT_INFO',
							container: ['bank'],
						},
					],
				},
				{
					name: 'DOCUMENT',
					attribute: [
						{
							name: 'STATEMENTS',
							container: ['bank'],
						},
					],
				},
				{
					name: 'ACCT_PROFILE',
					attribute: [
						{
							name: 'FULL_ACCT_NUMBER',
							container: ['bank'],
						},
						{
							name: 'BANK_TRANSFER_CODE',
							container: ['bank'],
						},
						{
							name: 'HOLDER_NAME',
							container: ['bank'],
						},
						{
							name: 'HOLDER_DETAILS',
							container: ['bank'],
						},
					],
				},
			],
			isAddedByUser: 'true',
		},
		{
			PRIORITY: 'POPULAR',
			id: 18769,
			name: 'Dag Site Captcha',
			loginUrl: 'http://64.14.28.129/dag/index.do',
			baseUrl: 'http://64.14.28.129/dag/index.do',
			favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_Default.SVG',
			logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_18769_1_1.PNG',
			status: 'Supported',
			isConsentRequired: false,
			authType: 'MFA_CREDENTIALS',
			languageISOCode: 'EN',
			primaryLanguageISOCode: 'EN',
			countryISOCode: 'US',
			lastModified: '2020-02-05T18:11:21Z',
			forgetPasswordUrl: 'http://64.14.28.129/dag/index.do',
			isAutoRefreshEnabled: true,
			capability: [
				{
					name: 'CHALLENGE_DEPOSIT_VERIFICATION',
					container: ['bank'],
				},
			],
			dataset: [
				{
					name: 'ACCT_PROFILE',
					attribute: [
						{
							name: 'FULL_ACCT_NUMBER',
							container: ['bank'],
						},
						{
							name: 'BANK_TRANSFER_CODE',
							container: ['bank'],
						},
						{
							name: 'HOLDER_NAME',
							container: ['bank'],
						},
					],
				},
				{
					name: 'DOCUMENT',
					attribute: [
						{
							name: 'STATEMENTS',
							container: ['bank'],
						},
					],
				},
				{
					name: 'BASIC_AGG_DATA',
					attribute: [
						{
							name: 'ACCOUNT_DETAILS',
							container: ['bank'],
						},
						{
							name: 'TRANSACTIONS',
							containerAttributes: {
								BANK: {
									numberOfTransactionDays: 90,
								},
							},
							container: ['bank'],
						},
						{
							name: 'BASIC_ACCOUNT_INFO',
							container: ['bank'],
						},
					],
				},
			],
			isAddedByUser: 'false',
		},
		{
			PRIORITY: 'POPULAR',
			id: 19686,
			name: 'HSBC',
			loginUrl:
				'https://www.hsbc.com.my/1/2/!ut/p/c5/04_SB8K8xLLM9MSSzPy8xBz9CP0os3gDCxNvAz9vzyAXA2cPRxMPywBDAwgAykdiyjv5w-WJ0e1v6m5g6RNiYWngbeRvHGRqbECc7uDUvPjQYH0_j_zcVP1I_ShzDMWeniYwxZE5qemJyZXY1XljqgvN0w_Lyy_KBYZBQW5oRLm3jyMAwombdA!!/dl3/d3/L0lJSklna21BL0lKakFBTXlBQkVSQ0pBISEvNEZHZ3NvMFZ2emE5SUFnIS83XzA4NEswTktJUkQwQ0hBNEhJSTQwMDAwMDAwL05mR01WMzcyNzAwMDQ!/',
			baseUrl: 'http://www.hsbc.com.my/',
			favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_19686.PNG',
			logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_19686_22_2.SVG',
			status: 'Beta',
			isConsentRequired: false,
			authType: 'MFA_CREDENTIALS',
			languageISOCode: 'EN',
			primaryLanguageISOCode: 'EN',
			countryISOCode: 'MY',
			lastModified: '2020-01-07T08:00:35Z',
			forgetPasswordUrl:
				'https://www.hsbc.com.my/1/2/!ut/p/c5/04_SB8K8xLLM9MSSzPy8xBz9CP0os3gDCxNvAz9vzyAXA2cPRxMPywBDAwgAykdiyjv5w-WJ0e1v6m5g6RNiYWngbeRvHGRqbECc7uDUvPjQYH0_j_zcVP1I_ShzDMWeniYwxZE5qemJyZXY1XljqgvN0w_Lyy_KBYZBQW5oRLm3jyMAwombdA!!/dl3/d3/L0lJSklna21BL0lKakFBTXlBQkVSQ0pBISEvNEZHZ3NvMFZ2emE5SUFnIS83XzA4NEswTktJUkQwQ0hBNEhJSTQwMDAwMDAwL05mR01WMzcyNzAwMDQ!/',
			isAutoRefreshEnabled: false,
			dataset: [
				{
					name: 'ACCT_PROFILE',
					attribute: [
						{
							name: 'FULL_ACCT_NUMBER',
							container: ['bank', 'investment'],
						},
						{
							name: 'BANK_TRANSFER_CODE',
							container: ['bank', 'investment'],
						},
						{
							name: 'HOLDER_NAME',
							container: ['bank', 'investment'],
						},
						{
							name: 'HOLDER_DETAILS',
							container: ['bank', 'investment'],
						},
					],
				},
				{
					name: 'BASIC_AGG_DATA',
					attribute: [
						{
							name: 'ACCOUNT_DETAILS',
							container: [
								'reward',
								'bank',
								'loan',
								'investment',
								'creditCard',
							],
						},
						{
							name: 'HOLDINGS',
							container: ['investment'],
						},
						{
							name: 'STATEMENTS',
							container: ['loan', 'creditCard'],
						},
						{
							name: 'TRANSACTIONS',
							containerAttributes: {
								LOAN: {
									numberOfTransactionDays: 90,
								},
								BANK: {
									numberOfTransactionDays: 90,
								},
								INVESTMENT: {
									numberOfTransactionDays: 90,
								},
								CREDITCARD: {
									numberOfTransactionDays: 90,
								},
							},
							container: [
								'loan',
								'bank',
								'investment',
								'creditCard',
							],
						},
						{
							name: 'BASIC_ACCOUNT_INFO',
							container: [
								'reward',
								'bank',
								'loan',
								'investment',
								'creditCard',
							],
						},
					],
				},
			],
			isAddedByUser: 'false',
		},
		{
			PRIORITY: 'POPULAR',
			id: 16609,
			name: 'OCBC Bank',
			loginUrl: 'https://internet.ocbc.com/internet-banking/',
			baseUrl: 'https://www.ocbc.com/group/group-home.html',
			favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_16609.PNG',
			logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_16609_26_1.PNG',
			status: 'Supported',
			isConsentRequired: false,
			authType: 'MFA_CREDENTIALS',
			languageISOCode: 'EN',
			primaryLanguageISOCode: 'EN',
			countryISOCode: 'SG',
			lastModified: '2020-01-17T14:16:07Z',
			forgetPasswordUrl:
				'https://internet.ocbc.com/internet-banking/inbregistration/index',
			isAutoRefreshEnabled: true,
			dataset: [
				{
					name: 'DOCUMENT',
					attribute: [
						{
							name: 'STATEMENTS',
							container: ['bank', 'investment'],
						},
						{
							name: 'TAX',
							container: ['bank', 'investment'],
						},
						{
							name: 'EBILLS',
							container: ['loan', 'creditCard'],
						},
					],
				},
				{
					name: 'BASIC_AGG_DATA',
					attribute: [
						{
							name: 'ACCOUNT_DETAILS',
							container: [
								'bank',
								'loan',
								'investment',
								'creditCard',
							],
						},
						{
							name: 'HOLDINGS',
							container: ['investment'],
						},
						{
							name: 'STATEMENTS',
							container: ['loan', 'creditCard'],
						},
						{
							name: 'TRANSACTIONS',
							containerAttributes: {
								LOAN: {
									numberOfTransactionDays: 90,
								},
								BANK: {
									numberOfTransactionDays: 90,
								},
								INVESTMENT: {
									numberOfTransactionDays: 90,
								},
								CREDITCARD: {
									numberOfTransactionDays: 90,
								},
							},
							container: [
								'loan',
								'bank',
								'investment',
								'creditCard',
							],
						},
						{
							name: 'BASIC_ACCOUNT_INFO',
							container: [
								'bank',
								'loan',
								'investment',
								'creditCard',
							],
						},
					],
				},
				{
					name: 'ACCT_PROFILE',
					attribute: [
						{
							name: 'FULL_ACCT_NUMBER',
							container: ['bank', 'investment'],
						},
						{
							name: 'BANK_TRANSFER_CODE',
							container: ['bank', 'investment'],
						},
						{
							name: 'HOLDER_NAME',
							container: ['bank', 'investment'],
						},
					],
				},
			],
			isAddedByUser: 'false',
		},
		{
			PRIORITY: 'POPULAR',
			id: 12099,
			name: 'St. George Bank',
			loginUrl: 'https://ibanking.stgeorge.com.au/ibank/loginPage.action',
			baseUrl: 'http://www.stgeorge.com.au/',
			favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_12099.PNG',
			logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_12099_3_1.PNG',
			status: 'Supported',
			isConsentRequired: false,
			authType: 'CREDENTIALS',
			languageISOCode: 'EN',
			primaryLanguageISOCode: 'EN',
			countryISOCode: 'AU',
			lastModified: '2018-08-28T17:29:00Z',
			forgetPasswordUrl: 'http://www.stgeorge.com.au/contact-us',
			isAutoRefreshEnabled: true,
			loginHelp: 'Please enter your St George online account credentials',
			dataset: [
				{
					name: 'DOCUMENT',
					attribute: [
						{
							name: 'STATEMENTS',
							container: ['bank'],
						},
					],
				},
				{
					name: 'ACCT_PROFILE',
					attribute: [
						{
							name: 'FULL_ACCT_NUMBER',
							container: ['bank'],
						},
						{
							name: 'BANK_TRANSFER_CODE',
							container: ['bank'],
						},
						{
							name: 'HOLDER_NAME',
							container: ['bank'],
						},
						{
							name: 'HOLDER_DETAILS',
							container: ['bank'],
						},
					],
				},
				{
					name: 'BASIC_AGG_DATA',
					attribute: [
						{
							name: 'ACCOUNT_DETAILS',
							container: [
								'insurance',
								'bank',
								'loan',
								'creditCard',
							],
						},
						{
							name: 'HOLDINGS',
							container: ['insurance'],
						},
						{
							name: 'STATEMENTS',
							container: ['insurance', 'loan', 'creditCard'],
						},
						{
							name: 'TRANSACTIONS',
							containerAttributes: {
								INSURANCE: {
									numberOfTransactionDays: 90,
								},
								LOAN: {
									numberOfTransactionDays: 365,
								},
								BANK: {
									numberOfTransactionDays: 365,
								},
								CREDITCARD: {
									numberOfTransactionDays: 180,
								},
							},
							container: [
								'insurance',
								'loan',
								'bank',
								'creditCard',
							],
						},
						{
							name: 'BASIC_ACCOUNT_INFO',
							container: [
								'insurance',
								'bank',
								'loan',
								'creditCard',
							],
						},
					],
				},
			],
			isAddedByUser: 'false',
		},
		{
			PRIORITY: 'POPULAR',
			id: 10642,
			name: 'Zillow.com',
			loginUrl: 'http://www.zillow.com/',
			baseUrl: 'http://www.zillow.com/',
			favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_10642.SVG',
			logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_10642_1_2.SVG',
			status: 'Supported',
			isConsentRequired: false,
			authType: 'CREDENTIALS',
			languageISOCode: 'EN',
			primaryLanguageISOCode: 'EN',
			countryISOCode: 'US',
			lastModified: '2020-01-29T11:42:35Z',
			forgetPasswordUrl: 'http://www.zillow.com/',
			isAutoRefreshEnabled: true,
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					attribute: [
						{
							name: 'ACCOUNT_DETAILS',
							container: ['realEstate'],
						},
						{
							name: 'BASIC_ACCOUNT_INFO',
							container: ['realEstate'],
						},
					],
				},
			],
			isAddedByUser: 'false',
		},
		{
			PRIORITY: 'POPULAR',
			id: 21,
			name: 'Charles Schwab',
			loginUrl:
				'https://lms.schwab.com/Login?ClientId=schwab-secondary&StartInSetId=1&enableAppD=false&RedirectUri=client.schwab.com/Login/Signon/AuthCodeHandler.ashx',
			baseUrl: 'http://www.schwab.com/',
			favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_21.SVG',
			logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_21_1_2.SVG',
			status: 'Supported',
			isConsentRequired: false,
			authType: 'MFA_CREDENTIALS',
			languageISOCode: 'EN',
			primaryLanguageISOCode: 'EN',
			countryISOCode: 'US',
			lastModified: '2020-02-06T20:26:00Z',
			forgetPasswordUrl:
				'https://client.schwab.com/Areas/Login/ForgotPassword/FYPIdentification.aspx',
			isAutoRefreshEnabled: true,
			capability: [
				{
					name: 'CHALLENGE_DEPOSIT_VERIFICATION',
					container: ['bank'],
				},
			],
			dataset: [
				{
					name: 'ACCT_PROFILE',
					attribute: [
						{
							name: 'FULL_ACCT_NUMBER',
							container: ['bank'],
						},
						{
							name: 'BANK_TRANSFER_CODE',
							container: ['bank'],
						},
						{
							name: 'HOLDER_NAME',
							container: ['bank', 'investment'],
						},
						{
							name: 'HOLDER_DETAILS',
							container: ['bank'],
						},
					],
				},
				{
					name: 'BASIC_AGG_DATA',
					attribute: [
						{
							name: 'ACCOUNT_DETAILS',
							container: ['bank', 'investment'],
						},
						{
							name: 'HOLDINGS',
							container: ['investment'],
						},
						{
							name: 'TRANSACTIONS',
							containerAttributes: {
								BANK: {
									numberOfTransactionDays: 365,
								},
								INVESTMENT: {
									numberOfTransactionDays: 365,
								},
							},
							container: ['bank', 'investment'],
						},
						{
							name: 'BASIC_ACCOUNT_INFO',
							container: ['bank', 'investment'],
						},
					],
				},
				{
					name: 'DOCUMENT',
					attribute: [
						{
							name: 'STATEMENTS',
							container: ['bank', 'investment'],
						},
					],
				},
			],
			isAddedByUser: 'false',
		},
		{
			PRIORITY: 'POPULAR',
			id: 5,
			name: 'Wells Fargo',
			loginUrl:
				'https://connect.secure.wellsfargo.com/auth/login/present?origin=yodlee',
			baseUrl: 'https://www.wellsfargo.com/',
			favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_5.SVG',
			logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_5_1_2.SVG',
			status: 'Supported',
			isConsentRequired: false,
			authType: 'MFA_CREDENTIALS',
			languageISOCode: 'EN',
			primaryLanguageISOCode: 'EN',
			countryISOCode: 'US',
			lastModified: '2020-02-19T15:05:14Z',
			forgetPasswordUrl:
				'https://oam.wellsfargo.com/oamo/identity/help/passwordhelp',
			isAutoRefreshEnabled: true,
			loginHelp:
				'If you are unable to add this external account, ensure your mobile number is registered or up-to-date with Wells Fargo. To register or update your phone number online, navigate to your profile in the Wells Fargo site, and select My profile > Update Contact Information > Phone Numbers. You can also call Wells Fargo support to register your phone number.',
			capability: [
				{
					name: 'CHALLENGE_DEPOSIT_VERIFICATION',
					container: ['bank'],
				},
			],
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					attribute: [
						{
							name: 'ACCOUNT_DETAILS',
							container: [
								'bank',
								'loan',
								'investment',
								'creditCard',
							],
						},
						{
							name: 'HOLDINGS',
							container: ['investment'],
						},
						{
							name: 'STATEMENTS',
							container: ['loan', 'creditCard'],
						},
						{
							name: 'TRANSACTIONS',
							containerAttributes: {
								LOAN: {
									numberOfTransactionDays: 90,
								},
								BANK: {
									numberOfTransactionDays: 365,
								},
								INVESTMENT: {
									numberOfTransactionDays: 365,
								},
								CREDITCARD: {
									numberOfTransactionDays: 90,
								},
							},
							container: [
								'loan',
								'bank',
								'investment',
								'creditCard',
							],
						},
						{
							name: 'BASIC_ACCOUNT_INFO',
							container: [
								'bank',
								'loan',
								'investment',
								'creditCard',
							],
						},
					],
				},
				{
					name: 'DOCUMENT',
					attribute: [
						{
							name: 'STATEMENTS',
							container: ['bank', 'investment'],
						},
						{
							name: 'TAX',
							container: ['bank', 'investment'],
						},
						{
							name: 'EBILLS',
							container: ['loan', 'creditCard'],
						},
					],
				},
				{
					name: 'ACCT_PROFILE',
					attribute: [
						{
							name: 'FULL_ACCT_NUMBER',
							container: ['bank', 'investment'],
						},
						{
							name: 'BANK_TRANSFER_CODE',
							container: ['bank'],
						},
						{
							name: 'HOLDER_NAME',
							container: ['bank', 'investment'],
						},
					],
				},
			],
			isAddedByUser: 'false',
		},
	],
}
