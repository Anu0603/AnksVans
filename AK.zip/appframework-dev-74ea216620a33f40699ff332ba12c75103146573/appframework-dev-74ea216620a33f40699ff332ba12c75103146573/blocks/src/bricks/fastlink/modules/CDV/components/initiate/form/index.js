import React, { Component } from 'react'
import { AppStrings, getString, AutoIds } from '../../../../../conf'
import {
	TextField,
	PasswordField
} from '../../../../../../../framework/react/components/InputField'
import { Button } from '../../../../../../../framework/react/components/Button'
import { Icon } from '../../../../../../../framework/react/components/Icon'
import { Modal } from '../../../../../../../framework/react/components/Modal'
import { Radio } from './../../../../../../../framework/react/components/RadioButton'
import { Link } from '../../../../../../../framework/react/components/Link'
import AppConstants from '../../../../../conf/constants/AppConstants'

class CDVInitiateFormView extends Component {
	constructor(props) {
		super(props)
		this.state = {
			showHelpPopup: false
		}
	}

	// TODO RTN image
	getHelpIconModalPopup() {
		return (
			<Modal
				className="small help-icon-modal"
				show={this.state.showHelpPopup}
				backDropEnabled={true}
				onBackDropClick={this.toggleHelpIcon.bind(this)}
				crossIconEnabled={true}
				onCrossIconClick={this.toggleHelpIcon.bind(this)}
			>
				<span className="help-title">
					{getString(
						AppStrings.CDV_INITIATE_VERIFICATION_FORM_HELP_POPUP_TITLE_TEXT
					)}
				</span>
				<img
					className="content-img"
					src={Application.Utilities.getImageResourceServiceURL(
						'check-image.png'
					)}
				/>
			</Modal>
		)
	}

	toggleHelpIcon() {
		this.setState({
			showHelpPopup: !this.state.showHelpPopup
		})
	}

	render() {
		return (
			<div
				className="cdv-form-container section-container"
				autoid={AutoIds.CDV_COMMON_AUTOID}
			>
				<div className="form-header section-header">
					<div className="title">
						{getString(
							AppStrings.CDV_INITIATE_VERIFICATION_INFO_TITLE
						)}
					</div>
				</div>

				<div className="form-content">
					<div className="account-type">
						<span className="label">
							{getString(
								AppStrings.CDV_INITIATE_VERIFICATION_FORM_ACCOUNT_TYPE_TEXT
							)}
						</span>
						<div className="account-type-options">
							<Radio
								name="account-type"
								id="account-type-checking"
								value={
									AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
								}
								label={getString(
									AppStrings.CDV_INITIATE_VERIFICATION_FORM_ACCOUNT_TYPE_CHECKING_TEXT
								)}
								key="account-type-checking"
								onChange={this.props.onAccountTypeChange}
								checked={
									this.props.accountTypeSelection ===
									AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
										? true
										: false
								}
							/>
							<Radio
								name="account-type"
								id="account-type-savings"
								value={
									AppConstants.CDV_INITIATE_ACC_TYPE_SAVINGS
								}
								label={getString(
									AppStrings.CDV_INITIATE_VERIFICATION_FORM_ACCOUNT_TYPE_SAVINGS_TEXT
								)}
								key="account-type-savings"
								onChange={this.props.onAccountTypeChange}
								checked={
									this.props.accountTypeSelection ===
									AppConstants.CDV_INITIATE_ACC_TYPE_SAVINGS
										? true
										: false
								}
							/>
						</div>
					</div>

					<TextField
						placeholder={getString(
							AppStrings.CDV_INITIATE_VERIFICATION_FORM_ROUTING_NUMBER_TEXT
						)}
						value={
							this.props.routingNumber
								? this.props.routingNumber + ''
								: null
						}
						id="routing-number"
						maxLength="9"
						autoComplete="off"
						autoCapitalize="off"
						autoCorrect="off"
						spellCheck="false"
						inputclass="routing-number-textfield"
						containerClass="cnr-class"
						autoid=""
						onChange={this.props.onRoutingNumberChange}
						key="routing-number"
						error={
							this.props.isRoutingNumberEmpty ||
							this.props.routingNumberError != null
						}
						errorMessage={this.props.routingNumberError}
					/>

					<TextField
						placeholder={getString(
							AppStrings.CDV_INITIATE_VERIFICATION_FORM_ACCOUNT_NUMBER_TEXT
						)}
						id="account-number"
						maxLength="17"
						autoComplete="off"
						autoCapitalize="off"
						autoCorrect="off"
						spellCheck="false"
						inputclass="account-number-textfield"
						containerClass="cnr-class"
						autoid=""
						onChange={this.props.onAccountNumberChange}
						key="account-number"
						error={
							this.props.isAccountNumberEmpty ||
							this.props.accountNumberError != null
						}
						errorMessage={this.props.accountNumberError}
					/>
					<div className="info-txt">
						<Icon
							type="fal"
							iconClass="fa-question-circle"
							onClick={e => {
								this.toggleHelpIcon()
							}}
						/>
						<Link
							lable={getString(
								AppStrings.CDV_INITIATE_VERIFICATION_FORM_HELP_TEXT
							)}
							classes="help-text"
							onClick={e => {
								this.toggleHelpIcon()
							}}
						/>
					</div>

					<div className="buttons-wrapper">
						<Button
							classes="initiate-btn"
							size="md"
							variant="primary"
							fullWidth={true}
							label={getString(
								AppStrings.CDV_INITIATE_VERIFICATION_FORM_SUBMIT_BUTTON_TEXT
							)}
							autoid="initiate-button-submit-button"
							onClick={this.props.onSubmit}
						></Button>
					</div>

					<div className="info-txt">
						{getString(
							AppStrings.CDV_INITIATE_VERIFICATION_FORM_DETAIL_INFO_TEXT
						)}
					</div>
				</div>

				<div className="helpContent">
					{this.getHelpIconModalPopup()}
				</div>
			</div>
		)
	}
}
export default CDVInitiateFormView
