import React, { Children } from 'react'

import MFAWrapper from '../../views/mfa'
import { createStore } from 'redux'
import { Provider } from 'react-redux'
import currentProviderMock from './../__mocks__/currentProvider'
import mfaLoginFormMock from './../__mocks__/mfaForm'
import providerReducer from './../../../../store/reducers/providerInfo'

import ProviderAccountService from '../../../../services/provider/ProviderAccountService'
import providerAccountRefreshInfo from './../__mocks__/providerAccountRefreshInfo'

jest.mock('../../../../services/provider/ProviderAccountService')
jest.mock('./../../../../components/FormBuilder', () => props => {
	return (
		<div className={'form-builder'}>
			<div>
				<button
					className={'sample-submit'}
					onClick={e => {
						props.btnClickCallback(123456)
					}}
				/>
			</div>
			<div className={'child-wrap'}>{props.children}</div>
		</div>
	)
})

describe('MFA View', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	let renderComponent = props => {
		let store = createStore(providerReducer, {
			currentProvider: currentProviderMock
		})

		container = mount(
			<Provider store={store}>
				<MFAWrapper {...props} />
			</Provider>
		)
	}

	it('Check whether MFA view has been rendered', () => {
		let props = {
			mfaLoginForm: mfaLoginFormMock,
			providerAccountId: 11270514
		}

		ProviderAccountService.mockImplementation(() => {
			return {
				addAccount: _options => {
					return Promise.resolve(providerAccountRefreshInfo)
				}
			}
		})

		act(() => {
			renderComponent(props)
		})
		container.find('.sample-submit').simulate('click')

		expect(container.find('.login-form-wrapper').length).toEqual(1)
		expect(container.find('.form-builder').length).toEqual(1)
	})

	it('Simulate the events in the MFA View', () => {
		let props = {
			mfaLoginForm: mfaLoginFormMock,
			providerAccountId: 11270514
		}

		ProviderAccountService.mockImplementation(() => {
			return {
				addAccount: _options => {
					return Promise.reject({ error: 'sample Error' })
				}
			}
		})

		act(() => {
			renderComponent(props)
		})

		container
			.find('.next-action-btn')
			.first()
			.simulate('blur')
		container
			.find('.next-action-btn')
			.first()
			.simulate('focus')

		let containerStyleOpacity = container.find('.next-action-btn').props()
			.style.color
		expect(containerStyleOpacity).toEqual('#084C8D')
	})
})
