import React from 'react'

import PopularSectionCard from '../../components/PopularSectionCard'

import { getParam } from '../../../../conf'
jest.mock('../../../../conf')

describe('<SiteCard> Component', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check whether Site Card Component rendered', () => {
		act(() => {
			let siteInfo = {
				id: 9001,
				name: 'Test Site',
				logo: ''
			}
			container = shallow(<PopularSectionCard data={siteInfo} />)
		})
		expect(container.find('.site-card')).toHaveLength(1)
	})

	it('Check whether Real Estate Card rendered', () => {
		act(() => {
			let _data = {
				text: 'Real Estate'
			}
			container = shallow(
				<PopularSectionCard
					cardType={'other-account-card'}
					data={_data}
				/>
			)
		})
		expect(container.find('.site-card')).toHaveLength(1)
	})

	it('Check whether site name displayed when show_popular_site_name key set to true', () => {
		let siteInfo = {
			id: 9001,
			name: 'Test Site',
			logo: ''
		}

		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'show_popular_site_name') {
					return true
				}
			})

			container = mount(<PopularSectionCard data={siteInfo} />)
		})
		expect(container.find('.site-card .site-name')).toHaveLength(1)
		expect(container.find('.site-card .site-name').text()).toBe(
			siteInfo.name
		)
	})

	it('Check whether default image shown when logo has error', () => {
		let siteInfo = {
			id: 9001,
			name: 'Test Site',
			logo: 'test.junk'
		}

		act(() => {
			container = mount(<PopularSectionCard data={siteInfo} />)
		})
		container.find('.site-card img').simulate('error')
		expect(container.find('.site-card .fa-university')).toHaveLength(1)
	})
})
