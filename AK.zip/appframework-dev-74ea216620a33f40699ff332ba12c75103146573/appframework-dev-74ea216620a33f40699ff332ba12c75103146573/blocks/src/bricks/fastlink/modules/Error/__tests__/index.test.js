import React from 'react'
import ErrorModule from './../index'

jest.mock('./../../../components/Error/ErrorPage', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="error-page"></div>
		}
	}
})

jest.mock('./../../../components/Error/TechnicalError/', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="tech-error-page"></div>
		}
	}
})

describe('Error Module', () => {
	let container = null
	beforeEach(() => {
		container = null
	})

	it('Check whether error page has rendered', () => {
		act(() => {
			container = mount(<ErrorModule />)
		})
		expect(container.find('div.error-page')).toHaveLength(1)
	})

	it('Check whether tech error has rendered', () => {
		act(() => {
			container = mount(<ErrorModule isTechDiff={true} />)
		})
		expect(container.find('div.tech-error-page')).toHaveLength(1)
	})
})
