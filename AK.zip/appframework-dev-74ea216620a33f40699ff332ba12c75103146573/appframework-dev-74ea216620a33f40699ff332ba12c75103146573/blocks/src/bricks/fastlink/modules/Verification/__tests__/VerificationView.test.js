import React, { Suspense } from 'react'
import { Provider } from 'react-redux'
import VerificationView from './../views/VerificationView'
import { AppParams, getParam } from './../../../conf'
import { AppStrings, getString } from './../../../conf'
import ProviderData from './__mocks__/provider'
import configureStore from 'redux-mock-store'

jest.mock('./../../../conf')

const mockStore = configureStore([])

describe('Verification View:: Aggregation UTs', () => {
	let container = null
	beforeEach(() => {
		container = null
		getParam.mockImplementation(_key => {
			if (_key == AppParams.DISABLE_VERIFICATION_SUCCESS_PAGE) {
				return false
			} else if (_key == AppParams.PRODUCT_TYPE) {
				return 'AGGR'
			}
		})

		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.VERIFICATION_LOGIN_STEPPER_TEXT:
					return 'Securely Verifying Your Login...'
				case AppStrings.VERIFICATION_DATA_STEPPER_TEXT:
					return 'Retrieving Data...'
				case AppStrings.VERIFICATION_SUCCESS_TEXT:
					return 'SUCCESS'
				default:
					return ''
			}
		})

		FLUtil.getFlowName = jest.fn(key => {
			return 'AGGR'
		})
		Application.Wrapper.sendPostMessage = jest.fn(key => {
			return ''
		})
	})

	let renderComponent = (status, additionalStatus, props) => {
		let store = mockStore({
			currentProvider: ProviderData.provider,
			refresh: {
				status: status,
				additionalStatus: additionalStatus,
				mfaLoginForm: null
			}
		})
		container = mount(
			<Provider store={store}>
				<VerificationView
					{...props}
					currentProvider={ProviderData.provider}
				/>
			</Provider>
		)
	}

	it('Check whether Verification View with Login Refresh View is rendered for default status', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('.login-message-wrapper')).toHaveLength(1)
		expect(
			container.find('.login-message-wrapper .login-refresh-label').text()
		).toEqual('Securely Verifying Your Login...')
	})

	it("Check whether Verification View is rendered with spinner colors as provider's colors", () => {
		act(() => {
			renderComponent()
		})
		expect(
			container
				.find('.login-message-wrapper')
				.find('.spinner')
				.prop('style')['borderColor']
		).toEqual('#ffffff')
		expect(
			container
				.find('.login-message-wrapper')
				.find('.spinner')
				.prop('style')['borderTopColor']
		).toEqual('#40B8BD')
	})

	it('Check whether Login Refresh View is rendered in case of refresh status as LOGIN_IN_PROGRESS', () => {
		act(() => {
			renderComponent('LOGIN_IN_PROGRESS')
		})
		expect(container.find('.login-message-wrapper')).toHaveLength(1)
		expect(
			container.find('.login-message-wrapper .login-refresh-label').text()
		).toEqual('Securely Verifying Your Login...')
		expect(
			container
				.find('.login-message-wrapper')
				.find('.spinner')
				.prop('style')['borderColor']
		).toEqual('#ffffff')
		expect(
			container
				.find('.login-message-wrapper')
				.find('.spinner')
				.prop('style')['borderTopColor']
		).toEqual('#40B8BD')
	})

	it('Check whether Data Refresh View is rendered in case of refresh status as IN_PROGRESS and addiitonal status as NULL', () => {
		act(() => {
			renderComponent('IN_PROGRESS')
		})
		expect(container.find('.data-message-wrapper')).toHaveLength(1)
		expect(
			container.find('.data-message-wrapper .data-refresh-label').text()
		).toEqual('Retrieving Data...')
		expect(
			container
				.find('.data-message-wrapper')
				.find('.spinner')
				.prop('style')['borderColor']
		).toEqual('#ffffff')
		expect(
			container
				.find('.data-message-wrapper')
				.find('.spinner')
				.prop('style')['borderTopColor']
		).toEqual('#40B8BD')
	})

	it('Check whether Success View is rendered in case of refresh status as IN_PROGRESS and addiitonal status is ACCT_SUMMARY_RECEIVED', () => {
		act(() => {
			renderComponent('IN_PROGRESS', 'ACCT_SUMMARY_RECEIVED')
		})
		expect(container.find('.success-message-wrapper')).toHaveLength(1)
		expect(
			container
				.find('.success-message-wrapper #success-refresh-label')
				.text()
		).toEqual('SUCCESS')
		expect(
			container.find('.success-message-wrapper .success-refresh-icon')
		).toHaveLength(1)
	})

	it('Check whether Success View is rendered in case of refresh status as IN_PROGRESS and addiitonal status is AVAILABLE_DATA_RETRIEVED', () => {
		act(() => {
			renderComponent('IN_PROGRESS', 'AVAILABLE_DATA_RETRIEVED')
		})
		expect(container.find('.success-message-wrapper')).toHaveLength(1)
		expect(
			container
				.find('.success-message-wrapper #success-refresh-label')
				.text()
		).toEqual('SUCCESS')
		expect(
			container.find('.success-message-wrapper .success-refresh-icon')
		).toHaveLength(1)
	})

	it(
		'Check whether Redirection to Accunt Summary View happens in case of success page is disabled and ' +
			'refresh status as IN_PROGRESS and addiitonal status is ACCT_SUMMARY_RECEIVED',
		() => {
			act(() => {
				getParam.mockImplementation(_key => {
					if (_key == AppParams.DISABLE_VERIFICATION_SUCCESS_PAGE) {
						return true
					}
				})
				renderComponent('IN_PROGRESS', 'ACCT_SUMMARY_RECEIVED')
			})
			expect(container.find('.success-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.success-message-wrapper #success-refresh-label')
					.text()
			).toEqual('SUCCESS')
			expect(
				container.find('.success-message-wrapper .success-refresh-icon')
			).toHaveLength(1)
		}
	)

	it('Check whether Data Refresh View is rendered in case of refresh status as IN_PROGRESS and addiitonal status as USER_INPUT_REQUIRED', () => {
		act(() => {
			renderComponent('IN_PROGRESS', 'USER_INPUT_REQUIRED')
		})
		expect(container.find('.data-message-wrapper')).toHaveLength(1)
		expect(
			container.find('.data-message-wrapper .data-refresh-label').text()
		).toEqual('Retrieving Data...')
		expect(
			container
				.find('.data-message-wrapper')
				.find('.spinner')
				.prop('style')['borderColor']
		).toEqual('#ffffff')
		expect(
			container
				.find('.data-message-wrapper')
				.find('.spinner')
				.prop('style')['borderTopColor']
		).toEqual('#40B8BD')
	})
})

describe('Verification View:: IAV - DS FLOW', () => {
	let container = null
	beforeEach(() => {
		container = null
		getParam.mockImplementation(_key => {
			if (_key == AppParams.DISABLE_VERIFICATION_SUCCESS_PAGE) {
				return false
			} else if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATION'
			}
		})

		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.VERIFICATION_LOGIN_STEPPER_TEXT:
					return 'Securely Verifying Your Login...'
					break
				case AppStrings.VERIFICATION_DATA_STEPPER_TEXT:
					return 'Retrieving Data...'
					break
				case AppStrings.VERIFICATION_SUCCESS_TEXT:
					return 'SUCCESS'
					break
				default:
					break
			}
		})

		FLUtil.getFlowName = jest.fn(key => {
			return 'VERIFICATION'
		})

		FLUtil.isMSFlowEnabled = jest.fn(key => {
			return false
		})
	})

	let renderComponent = (status, additionalStatus, props) => {
		let store = mockStore({
			currentProvider: ProviderData.provider,
			refresh: {
				status: status,
				additionalStatus: additionalStatus,
				mfaLoginForm: null
			}
		})
		container = mount(
			<Provider store={store}>
				<VerificationView
					{...props}
					currentProvider={ProviderData.provider}
				/>
			</Provider>
		)
	}

	it('Check whether Verification View with Login Refresh View is rendered for default status', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('.login-message-wrapper')).toHaveLength(1)
		expect(
			container.find('.login-message-wrapper .login-refresh-label').text()
		).toEqual('Securely Verifying Your Login...')
	})

	it("Check whether Verification View is rendered with spinner colors as provider's colors", () => {
		act(() => {
			renderComponent()
		})
		expect(
			container
				.find('.login-message-wrapper')
				.find('.spinner')
				.prop('style')['borderColor']
		).toEqual('#ffffff')
		expect(
			container
				.find('.login-message-wrapper')
				.find('.spinner')
				.prop('style')['borderTopColor']
		).toEqual('#40B8BD')
	})

	it('componentWillUnmount should be called on unmount', () => {
		let renderComponent1 = (status, additionalStatus, props) => {
			let store = mockStore({
				currentProvider: ProviderData.provider,
				refresh: {
					status: status,
					additionalStatus: additionalStatus,
					mfaLoginForm: null
				}
			})
			container = shallow(
				<Provider store={store}>
					<VerificationView
						{...props}
						currentProvider={ProviderData.provider}
					/>
				</Provider>
			)
		}
		act(() => {
			renderComponent1()
		})
		// const componentWillUnmount = jest.spyOn(
		// 	container.instance(),
		// 	'componentWillUnmount'
		// )
		// container.unmount()
		// expect(componentWillUnmount).toHaveBeenCalled()

		// wrapper = shallow(<Mycomponent  {...props}/>)
		container.setProps({ location: { pathname: 'testUrl2' } })
		container.update()
		container.unmount()
		// expect(showUrl.calledOnce).toBe(true)
	})

	it('Check whether Login Refresh View is rendered in case of refresh status as LOGIN_IN_PROGRESS', () => {
		act(() => {
			renderComponent('LOGIN_IN_PROGRESS')
		})
		expect(container.find('.login-message-wrapper')).toHaveLength(1)
		expect(
			container.find('.login-message-wrapper .login-refresh-label').text()
		).toEqual('Securely Verifying Your Login...')
		expect(
			container
				.find('.login-message-wrapper')
				.find('.spinner')
				.prop('style')['borderColor']
		).toEqual('#ffffff')
		expect(
			container
				.find('.login-message-wrapper')
				.find('.spinner')
				.prop('style')['borderTopColor']
		).toEqual('#40B8BD')
	})

	it('Check whether Data Refresh View is rendered in case of refresh status as IN_PROGRESS and addiitonal status as NULL', () => {
		act(() => {
			renderComponent('IN_PROGRESS')
		})
		expect(container.find('.data-message-wrapper')).toHaveLength(1)
		expect(
			container.find('.data-message-wrapper .data-refresh-label').text()
		).toEqual('Retrieving Data...')
		expect(
			container
				.find('.data-message-wrapper')
				.find('.spinner')
				.prop('style')['borderColor']
		).toEqual('#ffffff')
		expect(
			container
				.find('.data-message-wrapper')
				.find('.spinner')
				.prop('style')['borderTopColor']
		).toEqual('#40B8BD')
	})

	it('Check whether Data Refresh View is rendered in case of refresh status as IN_PROGRESS and addiitonal status is ACCT_SUMMARY_RECEIVED', () => {
		act(() => {
			renderComponent('IN_PROGRESS', 'ACCT_SUMMARY_RECEIVED')
		})
		expect(container.find('.data-message-wrapper')).toHaveLength(1)
		expect(
			container.find('.data-message-wrapper .data-refresh-label').text()
		).toEqual('Retrieving Data...')
		expect(
			container
				.find('.data-message-wrapper')
				.find('.spinner')
				.prop('style')['borderColor']
		).toEqual('#ffffff')
		expect(
			container
				.find('.data-message-wrapper')
				.find('.spinner')
				.prop('style')['borderTopColor']
		).toEqual('#40B8BD')
	})

	it('Check whether Success View is rendered in case of refresh status as IN_PROGRESS and addiitonal status is AVAILABLE_DATA_RETRIEVED', () => {
		act(() => {
			renderComponent('IN_PROGRESS', 'AVAILABLE_DATA_RETRIEVED')
		})
		expect(container.find('.success-message-wrapper')).toHaveLength(1)
		expect(
			container
				.find('.success-message-wrapper #success-refresh-label')
				.text()
		).toEqual('SUCCESS')
		expect(
			container.find('.success-message-wrapper .success-refresh-icon')
		).toHaveLength(1)
	})

	it(
		'Check whether Redirection to Data Refresh View happens in case of success page is disabled and ' +
			'refresh status as IN_PROGRESS and addiitonal status is ACCT_SUMMARY_RECEIVED',
		() => {
			act(() => {
				getParam.mockImplementation(_key => {
					if (_key == AppParams.DISABLE_VERIFICATION_SUCCESS_PAGE) {
						return true
					}
				})
				renderComponent('IN_PROGRESS', 'ACCT_SUMMARY_RECEIVED')
			})
			expect(container.find('.data-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.data-message-wrapper .data-refresh-label')
					.text()
			).toEqual('Retrieving Data...')
			expect(
				container
					.find('.data-message-wrapper')
					.find('.spinner')
					.prop('style')['borderColor']
			).toEqual('#ffffff')
			expect(
				container
					.find('.data-message-wrapper')
					.find('.spinner')
					.prop('style')['borderTopColor']
			).toEqual('#40B8BD')
		}
	)

	it('Check whether Data Refresh View is rendered in case of refresh status as IN_PROGRESS and addiitonal status as USER_INPUT_REQUIRED', () => {
		act(() => {
			renderComponent('IN_PROGRESS', 'USER_INPUT_REQUIRED')
		})
		expect(container.find('.data-message-wrapper')).toHaveLength(1)
		expect(
			container.find('.data-message-wrapper .data-refresh-label').text()
		).toEqual('Retrieving Data...')
		expect(
			container
				.find('.data-message-wrapper')
				.find('.spinner')
				.prop('style')['borderColor']
		).toEqual('#ffffff')
		expect(
			container
				.find('.data-message-wrapper')
				.find('.spinner')
				.prop('style')['borderTopColor']
		).toEqual('#40B8BD')
	})

	describe('Verification View:: IAV - MS FLOW', () => {
		let container = null
		beforeEach(() => {
			container = null
			getParam.mockImplementation(_key => {
				if (_key == AppParams.DISABLE_VERIFICATION_SUCCESS_PAGE) {
					return false
				} else if (_key == AppParams.PRODUCT_TYPE) {
					return 'VERIFICATION'
				}
			})

			getString.mockImplementation(_key => {
				switch (_key) {
					case AppStrings.VERIFICATION_LOGIN_STEPPER_TEXT:
						return 'Securely Verifying Your Login...'
						break
					case AppStrings.VERIFICATION_DATA_STEPPER_TEXT:
						return 'Retrieving Data...'
						break
					case AppStrings.VERIFICATION_SUCCESS_TEXT:
						return 'SUCCESS'
						break
					default:
						break
				}
			})

			FLUtil.getFlowName = jest.fn(key => {
				return 'VERIFICATION'
			})

			FLUtil.isMSFlowEnabled = jest.fn(key => {
				return true
			})
		})

		let renderComponent = (status, additionalStatus, props) => {
			let store = mockStore({
				currentProvider: ProviderData.provider,
				refresh: {
					status: status,
					additionalStatus: additionalStatus,
					mfaLoginForm: null
				}
			})
			container = mount(
				<Provider store={store}>
					<VerificationView
						{...props}
						currentProvider={ProviderData.provider}
					/>
				</Provider>
			)
		}

		it('Check whether Verification View with Login Refresh View is rendered for default status', () => {
			act(() => {
				renderComponent()
			})
			expect(container.find('.login-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.login-message-wrapper .login-refresh-label')
					.text()
			).toEqual('Securely Verifying Your Login...')
		})

		it("Check whether Verification View is rendered with spinner colors as provider's colors", () => {
			act(() => {
				renderComponent()
			})
			expect(
				container
					.find('.login-message-wrapper')
					.find('.spinner')
					.prop('style')['borderColor']
			).toEqual('#ffffff')
			expect(
				container
					.find('.login-message-wrapper')
					.find('.spinner')
					.prop('style')['borderTopColor']
			).toEqual('#40B8BD')
		})

		it('Check whether Login Refresh View is rendered in case of refresh status as LOGIN_IN_PROGRESS', () => {
			act(() => {
				renderComponent('LOGIN_IN_PROGRESS')
			})
			expect(container.find('.login-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.login-message-wrapper .login-refresh-label')
					.text()
			).toEqual('Securely Verifying Your Login...')
			expect(
				container
					.find('.login-message-wrapper')
					.find('.spinner')
					.prop('style')['borderColor']
			).toEqual('#ffffff')
			expect(
				container
					.find('.login-message-wrapper')
					.find('.spinner')
					.prop('style')['borderTopColor']
			).toEqual('#40B8BD')
		})

		it('Check whether Data Refresh View is rendered in case of refresh status as IN_PROGRESS and addiitonal status as NULL', () => {
			act(() => {
				renderComponent('IN_PROGRESS')
			})
			expect(container.find('.data-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.data-message-wrapper .data-refresh-label')
					.text()
			).toEqual('Retrieving Data...')
			expect(
				container
					.find('.data-message-wrapper')
					.find('.spinner')
					.prop('style')['borderColor']
			).toEqual('#ffffff')
			expect(
				container
					.find('.data-message-wrapper')
					.find('.spinner')
					.prop('style')['borderTopColor']
			).toEqual('#40B8BD')
		})

		it('Check whether Data Refresh View is rendered in case of refresh status as IN_PROGRESS and addiitonal status is ACCT_SUMMARY_RECEIVED', () => {
			act(() => {
				renderComponent('IN_PROGRESS', 'ACCT_SUMMARY_RECEIVED')
			})
			expect(container.find('.data-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.data-message-wrapper .data-refresh-label')
					.text()
			).toEqual('Retrieving Data...')
			expect(
				container
					.find('.data-message-wrapper')
					.find('.spinner')
					.prop('style')['borderColor']
			).toEqual('#ffffff')
			expect(
				container
					.find('.data-message-wrapper')
					.find('.spinner')
					.prop('style')['borderTopColor']
			).toEqual('#40B8BD')
		})

		it('Check whether Data Refresh View is rendered in case of refresh status as IN_PROGRESS and addiitonal status is AVAILABLE_DATA_RETRIEVED', () => {
			act(() => {
				renderComponent('IN_PROGRESS', 'AVAILABLE_DATA_RETRIEVED')
			})
			expect(container.find('.data-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.data-message-wrapper .data-refresh-label')
					.text()
			).toEqual('Retrieving Data...')
			expect(
				container
					.find('.data-message-wrapper')
					.find('.spinner')
					.prop('style')['borderColor']
			).toEqual('#ffffff')
			expect(
				container
					.find('.data-message-wrapper')
					.find('.spinner')
					.prop('style')['borderTopColor']
			).toEqual('#40B8BD')
		})

		it(
			'Check whether Redirection to Data Refresh View happens in case of success page is disabled and ' +
				'refresh status as IN_PROGRESS and addiitonal status is ACCT_SUMMARY_RECEIVED',
			() => {
				act(() => {
					getParam.mockImplementation(_key => {
						if (
							_key == AppParams.DISABLE_VERIFICATION_SUCCESS_PAGE
						) {
							return true
						}
					})
					renderComponent('IN_PROGRESS', 'ACCT_SUMMARY_RECEIVED')
				})
				expect(container.find('.data-message-wrapper')).toHaveLength(1)
				expect(
					container
						.find('.data-message-wrapper .data-refresh-label')
						.text()
				).toEqual('Retrieving Data...')
				expect(
					container
						.find('.data-message-wrapper')
						.find('.spinner')
						.prop('style')['borderColor']
				).toEqual('#ffffff')
				expect(
					container
						.find('.data-message-wrapper')
						.find('.spinner')
						.prop('style')['borderTopColor']
				).toEqual('#40B8BD')
			}
		)

		it('Check whether Data Refresh View is rendered in case of refresh status as IN_PROGRESS and addiitonal status as USER_INPUT_REQUIRED', () => {
			act(() => {
				renderComponent('IN_PROGRESS', 'USER_INPUT_REQUIRED')
			})
			expect(container.find('.data-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.data-message-wrapper .data-refresh-label')
					.text()
			).toEqual('Retrieving Data...')
			expect(
				container
					.find('.data-message-wrapper')
					.find('.spinner')
					.prop('style')['borderColor']
			).toEqual('#ffffff')
			expect(
				container
					.find('.data-message-wrapper')
					.find('.spinner')
					.prop('style')['borderTopColor']
			).toEqual('#40B8BD')
		})

		it('Check whether Success View is rendered in case of refresh status as MATCHING_COMPLETED', () => {
			act(() => {
				renderComponent('MATCHING_COMPLETED')
			})
			expect(container.find('.success-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.success-message-wrapper #success-refresh-label')
					.text()
			).toEqual('SUCCESS')
			expect(
				container.find('.success-message-wrapper .success-refresh-icon')
			).toHaveLength(1)
		})

		it('Check whether LoginRefresh View is rendered in case of refresh status as MATCHING_FAILED', () => {
			act(() => {
				renderComponent('MATCHING_FAILED')
			})
			expect(container.find('.login-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.login-message-wrapper .login-refresh-label')
					.text()
			).toEqual('Securely Verifying Your Login...')
			expect(
				container
					.find('.login-message-wrapper')
					.find('.spinner')
					.prop('style')['borderColor']
			).toEqual('#ffffff')
			expect(
				container
					.find('.login-message-wrapper')
					.find('.spinner')
					.prop('style')['borderTopColor']
			).toEqual('#40B8BD')
		})

		it('Check whether Success View is rendered in case of refresh status as ACCOUNT_SUMMARY', () => {
			act(() => {
				renderComponent('ACCOUNT_SUMMARY')
			})
			expect(container.find('.success-message-wrapper')).toHaveLength(1)
			expect(
				container
					.find('.success-message-wrapper #success-refresh-label')
					.text()
			).toEqual('SUCCESS')
			expect(
				container.find('.success-message-wrapper .success-refresh-icon')
			).toHaveLength(1)
		})
	})
})
