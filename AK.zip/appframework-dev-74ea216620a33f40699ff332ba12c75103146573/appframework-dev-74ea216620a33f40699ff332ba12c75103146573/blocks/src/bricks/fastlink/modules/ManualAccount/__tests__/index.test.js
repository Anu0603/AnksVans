import React from 'react'
import { Provider } from 'react-redux'
import utils from '../utils/utils'
import { createStore, combineReducers } from 'redux'
import manualAccountReducer from './../../../store/reducers/manualAccount'
import ManualAccountModule from './../index'

jest.mock('./../views/SuccessView')
utils.getCurrencyDropdownOptions = jest.fn().mockReturnValue([
	{
		displayText: 'USD',
		optionValue: 'USD'
	},
	{
		displayText: 'AUD',
		optionValue: 'AUD'
	}
])
utils.getFields = jest.fn().mockReturnValue([
	{
		id: 'account-name',
		name: 'accountName',
		type: 'text',
		properties: {
			value: 'Test',
			error: false,
			errorMessage: '',
			required: true,
			placeholder: 'Account Name',
			default: ''
		}
	},
	{
		id: 'account-number',
		name: 'accountNumber',
		type: 'text',
		properties: {
			value: 123098231,
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Account Number',
			default: ''
		}
	},
	{
		id: 'amount-due',
		name: 'amountDue',
		type: 'text',
		properties: {
			value: 230.77,
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Amount Due',
			default: ''
		}
	},
	{
		name: 'assetVsLiability',
		type: 'radio',
		properties: {
			value: 'asset',
			options: [
				{
					id: 'option-asset',
					name: 'asset-vs-liability',
					value: 'asset',
					label: 'Asset',
					checked: true
				},
				{
					id: 'option-liability',
					name: 'asset-vs-liability',
					value: 'liability',
					label: 'Liability',
					checked: false
				}
			]
		}
	},
	{
		id: 'balance',
		name: 'balance',
		type: 'text',
		properties: {
			value: 123.45,
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Balance',
			default: ''
		}
	},
	{
		id: 'currency',
		name: 'currency',
		type: 'dropdown',
		properties: {
			value: 'AUD',
			options: [
				{
					displayText: 'Australian Dollar(AUD)',
					optionValue: 'AUD',
					selected: true
				},
				{
					displayText: 'US Dollar(USD)',
					optionValue: 'USD',
					selected: false
				}
			],
			default: 'USD',
			placeholder: 'Currency'
		}
	},
	// {
	//   name: "frequency",
	//   type: "dropdown",
	//   properties: {
	//     value: "",
	//     options: getFrequencyOptions(),
	//     default: ""
	//   }
	// },
	{
		id: 'include-in-net-worth',
		name: 'includeInNetWorth',
		type: 'toggle',
		properties: {
			value: false,
			options: [
				{
					id: 'option-asset',
					name: 'include-in-net-worth',
					value: true,
					checked: true
				},
				{
					id: 'option-liability',
					name: 'include-in-net-worth',
					value: false,
					checked: false
				}
			]
		}
	},
	{
		id: 'memo',
		name: 'memo',
		type: 'text',
		properties: {
			value: 'Test memo.',
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Memo',
			default: ''
		}
	},
	{
		id: 'due-date',
		name: 'dueDate',
		type: 'datepicker',
		properties: {
			value: '2/2/2022',
			placeholder: 'Due Date'
		}
	},
	{
		id: 'nickname',
		name: 'nickname',
		type: 'text',
		properties: {
			value: 'Nickname',
			error: false,
			errorMessage: '',
			required: false,
			placeholder: 'Nickname',
			default: ''
		}
	}
])

describe('Manual Account Module', () => {
	let container = null
	let store = null
	const rootReducer = combineReducers({
		manualAccount: manualAccountReducer
	})
	beforeEach(() => {
		container = null
		store = createStore(rootReducer)
	})

	let renderComponent = () => {
		container = mount(
			<Provider store={store}>
				<ManualAccountModule />
			</Provider>
		)
	}

	it('Check whether Real estate module is rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('#manual-account-container')).toHaveLength(1)
	})
	it('Check whether current View Landing View', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('#manual-account-container')).toHaveLength(1)
	})

	it('Check whether current View is Success View', () => {
		act(() => {
			renderComponent()
		})
		container.childAt(0).setState({ currentView: 'MA_SUCCESS' })
		container
			.childAt(0)
			.instance()
			.onShowNextView('MA_SUCCESS')
		expect(container.childAt(0).instance().state.currentView).toBe(
			'MA_SUCCESS'
		)
	})
})
