import React from 'react'
import { Provider } from 'react-redux'
import configureStore from 'redux-mock-store'
import AccountWithSelection from '../../../sections/accounts/AccountWithSelection'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../../../fastlink/conf/index'

const mockStore = configureStore([])

jest.mock('../../../../../../fastlink/conf/index')
jest.mock('../../../sections/accounts/Account', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="account-view"></div>
		}
	}
})
describe('account with selection', () => {
	let container = null
	let navigate = false
	let classList = []
	let accountLength = 0
	let props = {}
	let selectionOnChange = function() {}
	let allSelectionOnChange = function() {}
	let deleteCallback = function() {}
	beforeEach(() => {
		container = null
	})

	it('Check if account selection is loaded with multi account', () => {
		navigate = false
		classList = ['']
		accountLength = 3
		props.currentProvider = {}
		props.currentProvider.hexCode1 = '404040'
		props.currentProvider.hexCode1 = '404041'
		props.accountType = 'Savings'
		props.accountNumber = '1234'
		props.accountName = 'Test account'
		props.amount = 2.34
		props.currency = 'USD'
		props.negativeCurrency = true
		props.checked = false
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountWithSelection
						{...props}
						accountLength={accountLength}
						classList={classList}
						selectionOnChange={selectionOnChange}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'MULTI_ACCOUNT'
			})
			renderComponent()
		})
		container.find('button').simulate('click')
		expect(container.find('div.account-view')).toHaveLength(1)
		expect(container.find('button')).toHaveLength(1)
	})

	it('Check if account selection is loaded with single account and unchecked checkbox', () => {
		navigate = false
		classList = ['']
		accountLength = 3
		props.currentProvider = {}
		props.currentProvider.hexCode1 = '404040'
		props.currentProvider.hexCode1 = '404041'
		props.accountType = 'Savings'
		props.accountNumber = '1234'
		props.accountName = 'Test account'
		props.amount = 2.34
		props.currency = 'USD'
		props.negativeCurrency = true
		props.checked = false
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountWithSelection
						{...props}
						accountLength={accountLength}
						classList={classList}
						selectionOnChange={selectionOnChange}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'SINGLE_ACCOUNT'
			})
			renderComponent()
		})
		expect(container.find('div.account-view')).toHaveLength(1)
		expect(container.find('button')).toHaveLength(0)
	})
	it('Check if account selection is loaded With checkbox', () => {
		navigate = false
		classList = ['']
		accountLength = 3
		props.currentProvider = {}
		props.currentProvider.hexCode1 = '404040'
		props.currentProvider.hexCode1 = '404041'
		props.accountType = 'Savings'
		props.accountNumber = '1234'
		props.accountName = 'Test account'
		props.amount = 2.34
		props.currency = 'USD'
		props.negativeCurrency = true
		props.checked = false
		props.disabled = true
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountWithSelection
						{...props}
						accountLength={accountLength}
						classList={classList}
						selectionOnChange={selectionOnChange}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'SINGLE_ACCOUNT'
			})
			renderComponent()
			console.log(container)
		})
		expect(container.find('div.account-view')).toHaveLength(1)
		expect(container.find('button')).toHaveLength(1)
	})

	it('Check if account selection is loaded without checkbox', () => {
		navigate = false
		classList = ['']
		accountLength = 3
		props.currentProvider = {}
		props.currentProvider.hexCode1 = '404040'
		props.currentProvider.hexCode1 = '404041'
		props.accountType = 'Savings'
		props.accountNumber = '1234'
		props.accountName = 'Test account'
		props.amount = 2.34
		props.currency = 'USD'
		props.negativeCurrency = true
		props.checked = false
		props.disabled = false
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountWithSelection
						{...props}
						accountLength={accountLength}
						classList={classList}
						selectionOnChange={selectionOnChange}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'SINGLE_ACCOUNT'
			})
			renderComponent()
		})
		expect(container.find('div.account-view')).toHaveLength(1)
		expect(container.find('button')).toHaveLength(0)
	})

	it('Check if account selection with single account is loaded wioth single account', () => {
		navigate = false
		classList = ['']
		accountLength = 1
		props.currentProvider = {}
		props.currentProvider.hexCode1 = '404040'
		props.currentProvider.hexCode1 = '404041'
		props.accountType = 'Savings'
		props.accountNumber = '1234'
		props.accountName = 'Test account'
		props.amount = 2.34
		props.currency = 'USD'
		props.negativeCurrency = true
		props.checked = true
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountWithSelection
						{...props}
						accountLength={accountLength}
						classList={classList}
						selectionOnChange={selectionOnChange}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				return 'SINGLE_ACCOUNT'
			})
			renderComponent()
		})
		expect(container.find('div.account-view')).toHaveLength(1)
		expect(container.find('button')).toHaveLength(0)
	})
})
