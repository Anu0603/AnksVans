import React from 'react'

import PopularSitesSection from '../../sections/PopularSites'

import ProviderData from './../__mocks__/provider'
import { getParam } from '../../../../conf'
jest.mock('../../../../conf')

describe('Popular Sites Section', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check whether popular sites section container rendered', () => {
		act(() => {
			container = shallow(<PopularSitesSection />)
		})
		expect(container.find('ul.card-list')).toHaveLength(1)
	})

	it('Check whether popular sites rendered', () => {
		act(() => {
			container = mount(
				<PopularSitesSection providers={ProviderData.provider} />
			)
		})
		container
			.find('ul .site-card')
			.first()
			.simulate('click')
		expect(container.find('ul .site-card')).toHaveLength(
			ProviderData.provider.length
		)
	})

	it('Check whether real estate account card rendered', () => {
		let realEstateCardClicked = false
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'enable_real_estate') {
					return true
				}
			})
			container = mount(
				<PopularSitesSection
					providers={ProviderData.provider}
					navigateToRealEstate={function() {
						realEstateCardClicked = true
					}}
				/>
			)
		})
		expect(realEstateCardClicked).toEqual(false)
		container.find('ul .real-estate-card').simulate('click')
		expect(realEstateCardClicked).toEqual(true)
	})

	it('Check whether manual account card rendered', () => {
		let manualCardClicked = false
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'enable_manual_account') {
					return true
				}
			})

			container = mount(
				<PopularSitesSection
					providers={ProviderData.provider}
					navigateToManualAccounts={function() {
						manualCardClicked = true
					}}
				/>
			)
		})

		expect(manualCardClicked).toEqual(false)
		container.find('ul .manual-card').simulate('click')
		expect(manualCardClicked).toEqual(true)
	})
})
