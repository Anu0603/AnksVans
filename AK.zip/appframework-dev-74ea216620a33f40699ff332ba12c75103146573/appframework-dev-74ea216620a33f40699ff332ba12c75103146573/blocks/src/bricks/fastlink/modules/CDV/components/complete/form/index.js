import React, { Component } from 'react'
import { AppStrings, getString, AutoIds } from '../../../../../conf'
import {
	NumberField,
	PasswordField
} from '../../../../../../../framework/react/components/InputField'
import { Button } from '../../../../../../../framework/react/components/Button'
import SiteBgColor from '../../../../../hoc/SiteBgColor'
import WithState from './../../../../../hoc/WithState'
import ErrorBanner from './../../../../../components/Error/ErrorBanner'

class CDVCompleteFormView extends Component {
	constructor(props) {
		super(props)
	}

	componentDidMount() {}

	createCreditFields() {
		let creditFields = []
		for (let i = 0; i < this.props.numberOfCredit; i++) {
			creditFields.push(
				<NumberField
					key={i}
					id={'credit_' + i}
					placeholder={getString(
						AppStrings.CDV_COMPLETE_VERIFICATION_FORM_DEPOSIT_PREFIX +
							(i + 1) +
							AppStrings.CDV_COMPLETE_VERIFICATION_FORM_DEPOSIT_POSTFIX
					)}
					inputclass="deposit"
					containerClass={'cnr-deposit-' + i}
					autoid=""
					data-cr-id={i}
					onChange={this.props.onCreditChange}
					predecorator={{ icon: 'far fa-dollar-sign' }}
					error={
						(this.props.creditEmptyFieldErrors &&
							this.props.creditEmptyFieldErrors[i]) ||
						(this.props.creditAmountErrors &&
							this.props.creditAmountErrors[i] != null)
					}
					errorMessage={
						this.props.creditAmountErrors
							? this.props.creditAmountErrors[i]
							: null
					}
				/>
			)
		}
		return creditFields
	}

	createDebitFields() {
		if (this.props.isDebitEnabled) {
			return (
				<NumberField
					placeholder={getString(
						AppStrings.CDV_COMPLETE_VERIFICATION_FORM_WITHDRAWAL_TEXT
					)}
					id={'debit'}
					inputclass="withdrawal"
					containerClass="cnr-withdrawal"
					autoid=""
					data-dr-id={1}
					onChange={this.props.onDebitChange}
					predecorator={{ icon: 'far fa-dollar-sign' }}
					error={
						(this.props.debitEmptyFieldErrors &&
							this.props.debitEmptyFieldErrors[0]) ||
						(this.props.debitAmountErrors &&
							this.props.debitAmountErrors[0] != null)
					}
					errorMessage={
						this.props.debitAmountErrors
							? this.props.debitAmountErrors[0]
							: null
					}
				/>
			)
		}
	}

	render() {
		let btnStyle = { color: this.props.currentProvider.hexCode1 }
		return (
			<div>
				{this.props.isDataMisMatch ? (
					<ErrorBanner
						className="cdv-complete-error"
						id="cdv-compplete-error-section"
						errorCode={
							AppConstants.CDV_ERROR_COMPLETE_INCORRECT_AMOUNT
						}
					/>
				) : null}
				<div
					className="cdv-complete-form section-container"
					id="cdv-complete-form"
					autoid={AutoIds.CDV_COMMON_AUTOID}
				>
					<div className="form-content">
						<div className="sub-section pad-b-2x" id="info">
							<div className="title">
								{getString(
									AppStrings.CDV_COMPLETE_VERIFICATION_INFO_TITLE
								)}
							</div>
							<div className="text-info">
								{getString(
									AppStrings.CDV_COMPLETE_VERIFICATION_INFO_TEXT
								)}
							</div>
						</div>
						<div className="seperator"></div>
						<div
							className="sub-section pad-tb-2x"
							id="info-details"
						>
							<div
								className="form-field-label"
								id="account-number"
							>
								{getString(
									AppStrings.CDV_COMPLETE_VERIFICATION_ACCOUNT_INFO_ACCOUNT_NUMBER_TEXT
								)}{' '}
								: {this.props.accountNumber}
							</div>
							<div
								className="form-field-label"
								id="routing-number"
							>
								{getString(
									AppStrings.CDV_COMPLETE_VERIFICATION_ACCOUNT_INFO_ROUTING_NUMBER_TEXT
								)}{' '}
								: {this.props.routingNumber}
							</div>
							<div
								className="form-field-label text-capitalize"
								id="account-type"
							>
								{getString(
									AppStrings.CDV_COMPLETE_VERIFICATION_ACCOUNT_INFO_ACCOUNT_TYPE_TEXT
								)}{' '}
								:{' '}
								{this.props.accountType
									? this.props.accountType.toLowerCase()
									: ''}
							</div>
						</div>
						<div className="amount-inputs" id="input-form">
							{this.createCreditFields()}
							{this.createDebitFields()}
						</div>
						<div
							className="submit-btn-wrapper pad-tb-2x"
							id="btn-wrapper"
						>
							<Button
								classes="next-action-btn"
								size="md"
								variant="secondary"
								fullWidth={true}
								label={getString(
									AppStrings.CDV_COMPLETE_VERIFICATION_FORM_SUBMIT_BUTTON_TEXT
								)}
								autoid="login-page-button-submit-button"
								onClick={this.props.onSubmit}
								style={btnStyle}
							></Button>
						</div>
					</div>
				</div>
			</div>
		)
	}
}

export default WithState('currentProvider', SiteBgColor(CDVCompleteFormView))
