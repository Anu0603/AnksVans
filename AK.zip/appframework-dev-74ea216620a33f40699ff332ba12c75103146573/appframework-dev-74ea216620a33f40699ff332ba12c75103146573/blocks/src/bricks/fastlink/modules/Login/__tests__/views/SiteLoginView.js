import React from 'react'
import { configure, shallow, mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { act } from 'react-dom/test-utils'
import SiteLoginView from "./../../views/SiteLoginView";
import { createStore, combineReducers, applyMiddleware, compose } from "redux";

configure({ adapter: new Adapter() });

import {getString} from "../../../../conf";
jest.mock("../../../../conf")
import providerInfo from "./../../../../store/reducers/providerInfo";

describe('Reset Section', () => {

    let container = null
    let store = null

    const rootReducer = combineReducers({
        curentProvider: providerInfo,
    })

    beforeEach(() => {
        container = null

        store = createStore(
            rootReducer
        )
    })

    it('Check whether reset componenet rendered or not', () => {
        let resetString = "Reset password";
        act(() => {
            getString.mockImplementation((_key) => {
                if (_key == 'login_reset') {
                    return resetString
                }
            })
            
            container = shallow(<SiteLoginView subViewType={"LOGIN"} 
            form = {[{"id":121254,"label":"Username","form":"0001","fieldRowChoice":"0001","field":[{"id":12,"name":"LOGIN","size":20,"maxLength":14,"type":"text","value":"","isOptional":false,"valueEditable":true}]},{"id":121253,"label":"Password","form":"0001","fieldRowChoice":"0002","field":[{"id":13,"name":"PASSWORD","size":20,"maxLength":32,"type":"password","value":"","isOptional":false,"valueEditable":true}]}]}
             tncValue = {1} showTnc = {true} providerId= {5} currentProvider ={{hexCode1:"#000", hexCode2: "#000"}} />)
        })
        expect(container.find('div.login-form-wrapper')).toHaveLength(1)
    })
})