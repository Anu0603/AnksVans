import React, { Component } from 'react'
import { AppStrings, getString, AutoIds } from '../../../../../conf'
import { Button } from '../../../../../../../framework/react/components/Button'
import { Icon } from '../../../../../../../framework/react/components/Icon'
import SiteBgColor from './../../../../../hoc/SiteBgColor'
import WithState from './../../../../../hoc/WithState'

class CDVCompleteSuccessView extends Component {
	constructor(props) {
		super(props)
	}

	render() {
		let btnStyle = { color: this.props.currentProvider.hexCode1 }
		return (
			<div
				className="complete-success-wrapper"
				autoid={AutoIds.CDV_COMMON_AUTOID}
			>
				<div id="complete-success-label" className="title">
					{getString(AppStrings.CDV_COMPLETE_SUCCESS_TITLE)}
				</div>
				<Icon
					id="complete-success-icon"
					classes="complete-success-icon"
					iconClass="fa-shield-check"
					type="fas"
				/>
				<Button
					classes="complete-success-btn"
					size="md"
					variant="secondary"
					label={getString(
						AppStrings.CDV_COMPLETE_SUCCESS_BUTTON_TEXT
					)}
					onClick={this.props.onClose}
					style={btnStyle}
				></Button>
			</div>
		)
	}
}
export default WithState('currentProvider', SiteBgColor(CDVCompleteSuccessView))
