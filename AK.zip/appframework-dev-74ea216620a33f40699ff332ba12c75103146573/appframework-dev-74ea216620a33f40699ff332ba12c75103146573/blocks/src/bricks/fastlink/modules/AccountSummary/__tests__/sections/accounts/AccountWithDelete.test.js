import React from 'react'
import { Provider } from 'react-redux'
import configureStore from 'redux-mock-store'
import AccountsService from '../../../../../services/account/AccountsService'
import AccountWithDelete from '../../../sections/accounts/AccountWithDelete'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../../../fastlink/conf/index'

const mockStore = configureStore([])
const mockDeleteAccount = jest.spyOn(AccountsService.prototype, 'deleteAccount')
mockDeleteAccount.mockReturnValue(
	new Promise(resolve => {
		resolve({})
	})
)
jest.mock('../../../../../../../framework/react/components/Modal', () => {
	return {
		__esModule: true,
		Modal: props => {
			props.onCrossIconClick()
			props.onBackDropClick()
			if (
				props.children &&
				props.children[1] &&
				props.children[1].props &&
				props.children[1].props.children[1]
			) {
				props.children[1].props.children[1].props.onClick()
			}
			return <div className="modal-view"></div>
		}
	}
})
jest.mock('../../../../../../fastlink/conf/index')
jest.mock('../../../sections/accounts/Account', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="account-view"></div>
		}
	}
})
describe('account with delete', () => {
	let container = null
	let navigate = false
	let classList = []
	let accountLength = 0
	let props = {}
	let selectionOnChange = function() {}
	let allSelectionOnChange = function() {}
	let deleteCallback = function() {}
	beforeEach(() => {
		container = null
	})

	it('Check if account delete loaded successfully and delete pop up not triggered', () => {
		navigate = false
		classList = ['']
		accountLength = 3
		props.currentProvider = {}
		props.currentProvider.hexCode1 = '404040'
		props.currentProvider.hexCode1 = '404041'
		props.accountType = 'Savings'
		props.accountNumber = '1234'
		props.accountName = 'Test account'
		props.amount = 2.34
		props.currency = 'USD'
		props.negativeCurrency = true
		props.checked = false
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountWithDelete
						{...props}
						classList={classList}
						currentProvider={props.currentProvider}
						deleteCallback={deleteCallback}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.DISABLE_TRASH_ICON) {
					return false
				}
				if (_key === AppParams.DISABLE_POPUP_ON_DELETE) {
					return true
				}
				return 'MULTI_ACCOUNT'
			})
			renderComponent()
		})
		container.find('a').simulate('click')
		expect(container.find('a')).toHaveLength(1)
		expect(container.find('div.account-view')).toHaveLength(1)
	})

	it('Check if account account delete loaded successfully and delete pop up triggered', () => {
		navigate = false
		classList = ['']
		accountLength = 3
		props.currentProvider = {}
		props.currentProvider.hexCode1 = '404040'
		props.currentProvider.hexCode1 = '404041'
		props.accountType = 'Savings'
		props.accountNumber = '1234'
		props.accountName = 'Test account'
		props.amount = 2.34
		props.currency = 'USD'
		props.negativeCurrency = true
		props.checked = false
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountWithDelete
						{...props}
						classList={classList}
						currentProvider={props.currentProvider}
						deleteCallback={deleteCallback}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.DISABLE_TRASH_ICON) {
					return false
				}
				if (_key === AppParams.DISABLE_POPUP_ON_DELETE) {
					return false
				}
				return 'MULTI_ACCOUNT'
			})
			renderComponent()
		})
		container.find('a').simulate('click')
		expect(container.find('a')).toHaveLength(1)
		expect(container.find('div.account-view')).toHaveLength(1)
	})

	it('Check if account delete loaded with no delete button', () => {
		navigate = false
		classList = ['']
		accountLength = 3
		props.currentProvider = {}
		props.currentProvider.hexCode1 = '404040'
		props.currentProvider.hexCode1 = '404041'
		props.accountType = 'Savings'
		props.accountNumber = '1234'
		props.accountName = 'Test account'
		props.amount = 2.34
		props.currency = 'USD'
		props.negativeCurrency = true
		props.checked = false
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<AccountWithDelete
						{...props}
						classList={classList}
						currentProvider={props.currentProvider}
						deleteCallback={deleteCallback}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.DISABLE_TRASH_ICON) {
					return true
				}
				if (_key === AppParams.DISABLE_POPUP_ON_DELETE) {
					return true
				}
				return 'MULTI_ACCOUNT'
			})
			renderComponent()
		})
		expect(container.find('a')).toHaveLength(0)
		expect(container.find('div.account-view')).toHaveLength(1)
	})
})
