import React, { Component } from 'react'
import { connect } from 'react-redux'

import { Spinner } from './../../../../../framework/react/components/Spinner'
import SiteLogo from './../../../components/SiteLogo'
import CDVCompleteFormView from '../components/complete/form'
import VerificationService from '../../../services/cdv/VerificationService'
import ProviderDetailsServices from '../../../services/provider/ProviderDetailsServices'

import ParamKeyService from '../../../services/common/ParamKeyService'
import AppConstants from '../../../conf/constants/AppConstants'
import CDVErrorView from './CDVErrorView'
import CDVInitiateSuccessView from './../components/initiate/success'
import CDVCompleteSuccessView from './../components/complete/success'
import Utility from './../utils/Utility'
import Constants from './../../../router/Constant'
import { AppStrings, getString, AutoIds } from '../../../conf'
import TechErrorConstants from '../../../components/Error/TechnicalError/TechErrorConstants'

class CDVCompleteView extends Component {
	constructor(props) {
		super(props)
		this.state = {
			errors: [],
			creditDetails: [],
			debitDetails: [],
			creditErrors: [],
			debitErrors: []
		}
		this.accountId = this.props.accountId
		this.verificationService = new VerificationService()
		this.paramKeyService = new ParamKeyService()
		this.providerDetailsService = new ProviderDetailsServices()
		this.isDeeplink = props.deeplinkData
			? props.deeplinkData.isDeeplink
			: false
	}

	componentDidMount() {
		this.getVerificationInfo()
	}

	getVerificationInfo() {
		this.verificationService.getVerificationInfo(
			{
				accountId: this.accountId
			},
			(_error, _response) => {
				this.updateVerificationInfo(_response)
			}
		)
	}

	updateVerificationInfo(response) {
		var self = this
		if (response.status === AppConstants.CDV_STATUS_DEPOSITED) {
			self.getCreditDebitDetails(function() {
				self.updateProviderDetails(response)
			})
		} else if (response.status === AppConstants.CDV_STATUS_INITIATED) {
			self.props.onFetchVerificationInfo(response)
			self.props.toggleHeader(false)
		} else if (response.status === AppConstants.CDV_STATUS_SUCCESS) {
			self.updateProviderDetails(
				response,
				AppConstants.CDV_STATUS_ALREADY_SUCCESS
			)
		} else if (response.status === AppConstants.CDV_STATUS_FAILED) {
			if (response.reason == 'DATA_MISMATCH') {
				response.status = 'DEPOSITED'
				response.reason = null
				self.getCreditDebitDetails(function() {
					self.updateProviderDetails(response)
				})
			} else {
				self.updateProviderDetails(
					response,
					AppConstants.CDV_STATUS_ALREADY_FAILED
				)
			}
		} else {
			self.props.handleTechDiff(
				TechErrorConstants.getAPIError(
					{ errorCode: response.status },
					TechErrorConstants.API_TYPE.VERIFICATION_INFO
				)
			)
		}
	}

	getCreditDebitDetails(callBack) {
		this.paramKeyService.getParamKeyValue(
			{
				paramKeyString:
					AppConstants.CDV_NUMBER_OF_CREDITS_PARAM_KEY_ID +
					',' +
					AppConstants.CDV_IS_DEBIT_ENABLED_PARAM_KEY_ID
			},
			(_error, _response) => {
				this.updateParamValues(_response, callBack)
			}
		)
	}

	updateParamValues(response, callBack) {
		let numberOfCredit = 0,
			isDebitEnabled = false

		for (let i in response) {
			let paramKeyObj = response[i]
			if (
				paramKeyObj.id ==
				AppConstants.CDV_NUMBER_OF_CREDITS_PARAM_KEY_ID
			) {
				numberOfCredit = parseInt(paramKeyObj.value)
			}

			if (
				paramKeyObj.id ==
					AppConstants.CDV_IS_DEBIT_ENABLED_PARAM_KEY_ID &&
				paramKeyObj.value == '1'
			) {
				isDebitEnabled = true
			}
		}
		let creditDebitInfo = {
			numberOfCredit: numberOfCredit,
			isDebitEnabled: isDebitEnabled
		}
		if (numberOfCredit > 0) {
			this.setState({
				creditDetails: new Array(numberOfCredit),
				creditErrors: new Array(numberOfCredit)
			})
		}
		if (isDebitEnabled) {
			this.setState({
				debitDetails: new Array(1),
				debitErrors: new Array(1)
			})
		}
		this.props.onFetchCreditDebitInfo(creditDebitInfo)
		callBack()
	}

	updateProviderDetails(response, status) {
		var self = this
		self.providerDetailsService.getProviderDetailsByRTN(
			{
				name: response.routingNumber
			},
			(_error, _response) => {
				if (_response && (_response.id || _response.name)) {
					self.props.dispatchProviderdetails(_response)
					if (status) {
						let _modifiedResponse = Object.assign({}, response)
						_modifiedResponse.status = status
						self.props.onFetchVerificationInfo(_modifiedResponse)
					} else {
						self.props.onFetchVerificationInfo(response)
					}
				} else {
					self.props.handleTechDiff(AppConstants.ERROR_TECH_DIFF)
				}
			}
		)
	}

	onCreditChange(creditElement) {
		let creditIndex = creditElement.target.getAttribute('data-cr-id')
		const updatedCreditDetails = [...this.state.creditDetails]
		updatedCreditDetails[creditIndex] = creditElement.target.value
			? creditElement.target.value.trim()
			: creditElement.target.value

		this.setState({
			creditDetails: updatedCreditDetails
		})
	}

	onDebitChange(debitElement) {
		this.state.debitDetails[0] = debitElement.target.value
			? debitElement.target.value.trim()
			: debitElement.target.value
	}

	handleSubmitTransaction() {
		if (this.validateSubmitForm()) {
			this.verificationService.submitVerificationDetails(
				{
					accountId: this.accountId,
					providerAccountId: this.props.verificationInfo
						.providerAccountId,
					creditDetails: this.state.creditDetails,
					debitDetails: this.state.debitDetails
				},
				(_error, _response) => {
					this.updateVerificationResults(_response)
				}
			)
		} else {
			return false
		}
	}

	validateSubmitForm() {
		let _accountNumberTestExpression = /^(\d+)?([.]?\d{0,7})?$/
		let _creditDetails = this.state.creditDetails,
			_debitDetails = this.state.debitDetails,
			_creditErrors = [],
			_debitErrors = []

		for (let index = 0; index < _creditDetails.length; index++) {
			if (!_creditDetails[index]) {
				_creditErrors[index] =
					AppConstants.CDV_INITIATE_ERROR_CREDIT_AMOUNT_EMPTY
			} else if (
				!_accountNumberTestExpression.test(
					_creditDetails[index].trim()
				) ||
				isNaN(_creditDetails[index].trim())
			) {
				_creditErrors[index] =
					AppConstants.CDV_INITIATE_ERROR_CREDIT_AMOUNT_INVALID
			}
		}
		this.setState({
			creditErrors: _creditErrors
		})

		if (_debitDetails) {
			if (!_debitDetails[0]) {
				_debitErrors[0] =
					AppConstants.CDV_INITIATE_ERROR_DEBIT_AMOUNT_EMPTY
			} else if (
				!_accountNumberTestExpression.test(_debitDetails[0].trim()) ||
				isNaN(_debitDetails[0].trim())
			) {
				_debitErrors[0] =
					AppConstants.CDV_INITIATE_ERROR_DEBIT_AMOUNT_INVALID
			}
		}
		this.setState({
			creditErrors: _creditErrors,
			debitErrors: _debitErrors
		})
		return _creditErrors.length > 0 || _debitErrors.length > 0
			? false
			: true
	}

	updateVerificationResults(response) {
		if (
			response &&
			response.status === 'FAILED' &&
			response.reason === 'DATA_MISMATCH'
		) {
			response.status = 'DEPOSITED'
			this.props.onFetchVerificationInfo(response)
		} else {
			this.props.onFetchVerificationInfo(response)
		}
	}

	handleCloseAction() {
		if (this.isDeeplink) {
			this.props.handleCloseAppHandler()
		} else {
			this.props.toggleHeader(true)
			this.props.navigate(Constants.ROUTE_LANDING_MODULE)
		}
	}

	handleCompleteCloseAction() {
		if (this.isDeeplink) {
			this.props.handleCloseAppHandler()
		} else {
			this.props.navigate(Constants.ROUTE_LANDING_MODULE)
		}
	}

	getEmptyFieldErrors(fieldType) {
		let _isEmptyArray = []
		switch (fieldType) {
			case 'creditAmount':
				let _creditErrors = this.state.creditErrors
				for (let index = 0; index < _creditErrors.length; index++) {
					if (
						_creditErrors[index] ==
						AppConstants.CDV_INITIATE_ERROR_CREDIT_AMOUNT_EMPTY
					) {
						_isEmptyArray[index] = true
					} else {
						_isEmptyArray[index] = false
					}
				}
				break
			case 'debitAmount':
				let _debitErrors = this.state.debitErrors
				if (
					_debitErrors[0] ==
					AppConstants.CDV_INITIATE_ERROR_DEBIT_AMOUNT_EMPTY
				) {
					_isEmptyArray[0] = true
				} else {
					_isEmptyArray[0] = false
				}
				break
		}
		return _isEmptyArray
	}

	getErrorDetails(fieldType) {
		let _errorMessage = []
		switch (fieldType) {
			case 'creditAmount':
				let _creditErrors = this.state.creditErrors
				for (let index = 0; index < _creditErrors.length; index++) {
					if (
						_creditErrors[index] ==
						AppConstants.CDV_INITIATE_ERROR_CREDIT_AMOUNT_INVALID
					) {
						_errorMessage[index] = getString(
							AppStrings.CDV_ERROR_AMOUNT_NOT_VALID
						)
					}
				}
				break
			case 'debitAmount':
				let _debitErrors = this.state.debitErrors
				if (
					_debitErrors[0] ==
					AppConstants.CDV_INITIATE_ERROR_DEBIT_AMOUNT_INVALID
				) {
					_errorMessage[0] = getString(
						AppStrings.CDV_ERROR_AMOUNT_NOT_VALID
					)
				}
				break
		}
		return _errorMessage
	}

	renderCompleteView() {
		let _cdvCompleteView = null
		let _status = this.props.verificationInfo.status
		let _reason = this.props.verificationInfo.reason

		switch (_status) {
			case AppConstants.CDV_STATUS_DEPOSITED:
				_cdvCompleteView = (
					<CDVCompleteFormView
						accountNumber={Utility.formatAccountNumber(
							this.props.verificationInfo.accountNumber
						)}
						routingNumber={
							this.props.verificationInfo.routingNumber
						}
						accountType={this.props.verificationInfo.accountType}
						numberOfCredit={
							this.props.creditDebitInfo.numberOfCredit
						}
						isDebitEnabled={
							this.props.creditDebitInfo.isDebitEnabled
						}
						onCreditChange={this.onCreditChange.bind(this)}
						onDebitChange={this.onDebitChange.bind(this)}
						onSubmit={this.handleSubmitTransaction.bind(this)}
						creditEmptyFieldErrors={this.getEmptyFieldErrors(
							'creditAmount'
						)}
						creditAmountErrors={this.getErrorDetails(
							'creditAmount'
						)}
						debitEmptyFieldErrors={this.getEmptyFieldErrors(
							'debitAmount'
						)}
						debitAmountErrors={this.getErrorDetails('debitAmount')}
						currentProvider={this.state.currentProvider}
						isDataMisMatch={_reason == 'DATA_MISMATCH'}
					/>
				)
				break

			case AppConstants.CDV_STATUS_INITIATED:
				_cdvCompleteView = (
					<CDVInitiateSuccessView
						onClose={this.handleCloseAction.bind(this)}
						status="INPROGRESS"
					/>
				)
				break

			case AppConstants.CDV_STATUS_SUCCESS:
				_cdvCompleteView = (
					<CDVCompleteSuccessView
						onClose={this.handleCompleteCloseAction.bind(this)}
						{...this.props}
					/>
				)
				break

			case AppConstants.CDV_STATUS_ALREADY_SUCCESS:
				_cdvCompleteView = (
					<CDVErrorView
						errorCode={
							AppConstants.CDV_ERROR_COMPLETE_ALREADY_SUCCESS
						}
					/>
				)
				break

			case AppConstants.CDV_STATUS_FAILED:
				_cdvCompleteView = (
					<CDVErrorView
						errorCode={AppConstants.CDV_ERROR_COMPLETE_FAILED}
					/>
				)
				break

			case AppConstants.CDV_STATUS_ALREADY_FAILED:
				_cdvCompleteView = (
					<CDVErrorView
						errorCode={
							AppConstants.CDV_ERROR_COMPLETE_ALREADY_FAILED
						}
					/>
				)
				break

			case AppConstants.CDV_STATUS_TECH_ERROR:
				_cdvCompleteView = (
					<CDVErrorView errorCode={AppConstants.ERROR_TECH_DIFF} />
				)
				break

			default:
				_cdvCompleteView = (
					<Spinner
						id="largeSpinner"
						name="someButtonName"
						classes="aaa"
						size="lg"
					/>
				)
				break
		}
		return _cdvCompleteView
	}

	render() {
		return (
			<React.Fragment>
				<div
					className="cdv-complete-wrapper cdv-wrapper"
					autoid={AutoIds.CDV_COMPLETE_CONTAINER}
				>
					{this.renderCompleteView()}
				</div>
			</React.Fragment>
		)
	}
}

const mapStateToProps = state => {
	return {
		verificationInfo: state.cdv.verificationInfo,
		creditDebitInfo: state.cdv.creditDebitInfo,
		currentProvider: state.currentProvider
	}
}

const mapDispatchToProps = dispatch => {
	return {
		onFetchVerificationInfo: verificationInfo =>
			dispatch({
				type: 'FETCH_CDV_VERIFICATION_INFO',
				payload: { verificationInfo: verificationInfo }
			}),
		onFetchCreditDebitInfo: creditDebitInfo =>
			dispatch({
				type: 'FETCH_CDV_CREDIT_DEBIT_INFO',
				payload: { creditDebitInfo: creditDebitInfo }
			}),

		dispatchProviderdetails: provderInfo =>
			dispatch({
				type: 'SELECTED_PROVIDER_DATA',
				payload: provderInfo
			})
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(CDVCompleteView)
