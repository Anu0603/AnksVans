import React from 'react'
import { Provider } from 'react-redux'
import SuccessModule from '../index'
import configureStore from 'redux-mock-store'

const mockStore = configureStore([]);

jest.mock("../views/AccountListView", () => {
  return {
    __esModule: true,
    default: () => {
      return <div className="verification-view"></div>;
    },
  }
});

describe('account summary Module', () => {
  let container = null;
  beforeEach(() => {
    container = null
  });
  let props = {"providerAccountId":11288505,"providerId":16441,"status":"IN_PROGRESS","requestId":"72DD5Wb+zWqZ5KiqgPCqwRgONtM=","additionalStatus":"ACCT_SUMMARY_RECEIVED","currentProvider":{"id":16441,"hexCode1":"#161413","hexCode2":"#20A73E","name":"Dag Site","loginUrl":"http://64.14.28.129/dag/index.do","favicon":"https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_16441.SVG","logo":"https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_16441_1_2.SVG","authType":"CREDENTIALS","countryISOCode":"US","formType":"login","loginForm":[{"id":150862,"label":"Username","form":"0001","fieldRowChoice":"0001","field":[{"id":65499,"name":"LOGIN","type":"text","value":"","isOptional":false,"valueEditable":true,"placeHolder":"Username"}]},{"id":150863,"label":"Password","form":"0001","fieldRowChoice":"0002","field":[{"id":65500,"name":"PASSWORD","type":"password","value":"","isOptional":false,"valueEditable":true,"placeHolder":"Password"}]}],"tncValue":1,"showTnc":true},"verifiedAccounts":[]};

  let renderComponent = () => {
    let store = mockStore({
      search: { providers: [] }
    });
    container = mount(<Provider store={store}>

      <SuccessModule
        props ={props}/>

    </Provider>)
    //container = mount(<SuccessModule props ={props} store={store}></SuccessModule>)
  };

  it('Check if verification module rendered', () => {
    act(() => {
      renderComponent()
    });
    expect(container.find('div.verification-view')).toHaveLength(1)
  });
});



