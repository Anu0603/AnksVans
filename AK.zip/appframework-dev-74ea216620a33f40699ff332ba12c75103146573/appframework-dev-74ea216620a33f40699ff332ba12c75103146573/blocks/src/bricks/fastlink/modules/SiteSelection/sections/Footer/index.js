import React, { Component, useState } from 'react'
import {
	AppStrings,
	getString,
	AutoIds,
	getParam,
	AppParams,
} from '../../../../conf'
import { Link } from './../../../../../../framework/react/components/Link'
import PfileModal from '../../../../../../framework/react/components/Modal/PfileModal'

const PolicyView = props => {
	let showPrivacyPolicy = getParam(AppParams.SHOW_PRIVACY_POLICY)
	let showSecurityPolicy = getParam(AppParams.SHOW_SECURITY_POLICY)

	let [policyPopupState, policyPopupStateSetState] = useState({
		showPopup: false,
		// popupContent: null
	})

	const fetchPolicyContent = file_name => {
		policyPopupStateSetState({
			showPopup: true,
			fileName: file_name,
		})
	}

	const closePolicyPopup = () => {
		policyPopupStateSetState({
			showPopup: false,
		})
	}

	return props.showPolicyView ? (
		<React.Fragment>
			<div className={'footer'} autoid={AutoIds.LANDING_FOOTER}>
				{showPrivacyPolicy ? (
					<span className="footer-text">
						<Link
							lable={getString(AppStrings.PRIVACY_POLICY)}
							classes="privacy-policy policy-link"
							onClick={fetchPolicyContent.bind(
								this,
								'privacypolicy'
							)}
						/>
					</span>
				) : null}

				{showPrivacyPolicy && showSecurityPolicy ? (
					<span className="link-seperator policy-link">|</span>
				) : null}

				{showSecurityPolicy ? (
					<span className="footer-text">
						<Link
							lable={getString(AppStrings.SECURITY_POLICY)}
							classes="security-policy policy-link"
							onClick={fetchPolicyContent.bind(
								this,
								'securitypolicy'
							)}
						/>
					</span>
				) : null}
			</div>

			{policyPopupState.showPopup && (
				<PfileModal
					show={policyPopupState.showPopup}
					backDropEnabled={true}
					onBackDropClick={closePolicyPopup.bind(this)}
					crossIconEnabled={true}
					onCrossIconClick={closePolicyPopup.bind(this)}
					fileName={policyPopupState.fileName}
				></PfileModal>
			)}
		</React.Fragment>
	) : null
}

export default PolicyView
