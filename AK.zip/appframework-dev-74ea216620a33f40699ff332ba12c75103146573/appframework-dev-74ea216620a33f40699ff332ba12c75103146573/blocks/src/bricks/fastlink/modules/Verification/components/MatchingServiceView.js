import React, { Component } from "react";
import { AppStrings, getString, AutoIds } from "../../../conf";
import { Spinner } from "./../../../../../framework/react/components/Spinner";
import MatchingService from "./../../../services/provider/VerificationService";

class DataRefreshView extends Component {
  constructor(props) {
    super(props);
    this.matchingService = new MatchingService();
  }

  componentDidMount() {
    let mactchingResponse = this.matchingService.matchingVerification({
      providerAccountId: this.props.providerAccountId
    });
    mactchingResponse.then(this.redirectToSummarPage.bind(this), this.failedHandler.bind(this));
  }

  failedHandler(){
    let nextDetails = {navigationStatus:"MATCHING_FAILED",additionalStatus:"VERIFICATION_FAILED"};
    this.props.setNavigationStatus(nextDetails);
  }

  redirectToSummarPage(response){
    let nextDetails = {navigationStatus:"MATCHING_COMPLETED",verifiedAccounts:response};
    let failedAccount = 0;
    for(let accountId in response){
       if(!response[accountId].status){
        failedAccount++;
       }
    }
    if(failedAccount == Object.keys(response).length){
      nextDetails.navigationStatus = "MATCHING_FAILED";
      nextDetails.additionalStatus = "VERIFICATION_FAILED";
    }
    this.props.setNavigationStatus(nextDetails);
  }
  
  render() {
    return (
      <div
        className="data-message-wrapper flex-center"
        autoid={AutoIds.VERIFICATION_DATA_STEPPER_CONTAINER}
      >
        <Spinner
          id="data-spinner"
          size="lg"
          color={this.props.currentProvider.hexCode2}
          circleColor="#ffffff"
          class="data-spinner"
          children={
            <div id="data-refresh-label" className="data-refresh-label">
                {getString(AppStrings.VERIFICATION_DATA_STEPPER_TEXT)}
            </div>
          }
        />
      </div>
    );
  }
}

export default DataRefreshView;
