import React from 'react'
import { Provider } from 'react-redux'
import configureStore from 'redux-mock-store'
import propsMock from '../__mocks__/props'
import {
	AppStrings,
	getString,
	AppParams,
	getParam
} from '../../../../../fastlink/conf'
import ConnectedSuccessView, { SuccessView } from '../../views/SuccessView'
import AccountsService from '../../../../services/account/AccountsService'
import ManualAccountService from '../../../../services/account/ManualAccountService'

const mockStore = configureStore([])

jest.mock('../../../../../fastlink/conf')
jest.mock('../../../../services/account/ManualAccountService', () => {
	return jest.fn().mockImplementation(() => {
		return {
			getManualAccount: () => {
				return new Promise(resolve => {
					resolve({
						account: [
							{
								accountName: 'test',
								id: 12345678,
								balance: { amount: 123.17, currency: 'USD' }
							}
						]
					})
				})
			}
		}
	})
})

jest.mock('../../sections/DeleteModal', () => {
	return {
		__esModule: true,
		default: props => {
			return (
				<div className="modal-content">
					<button
						id="cancel-modal"
						onClick={() => {
							props.showHidePopUp(false)
						}}
					></button>
					<button
						id="delete-button"
						onClick={() => {
							props.handleDelete()
						}}
					></button>
				</div>
			)
		}
	}
})
jest.mock('./../../../../components/Error/ErrorBanner', () => {
	return {
		__esModule: true,
		default: () => <div className="alert-error"></div>
	}
})
jest.mock('./../../../../components/Error/ErrorContent', () => {
	return {
		__esModule: true,
		default: () => <div className="alert-detail"></div>
	}
})

global.Application = {
	BaseService: {
		makecall: () => {}
	},
	Wrapper: {
		close: () => {}
	}
}

describe('Manual Account success view', () => {
	let container = null
	let spy = null
	let store = mockStore({})
	let props = propsMock
	let initialState = {
		showSpinner: false,
		showDeleteModal: false,
		currency: 'USD',
		balanceInt: 123,
		accountName: 'Test',
		accountType: 'SAVINGS'
	}
	let appParam = {
		container_list: ['bank', 'creditCard']
	}

	getParam.mockImplementation(key => {
		if (key === AppParams.CONTAINER_LIST) return appParam.container_list
	})

	getString.mockImplementation(_key => {
		switch (_key) {
			case AppStrings.ERROR_CANCEL_BUTTON_TEXT:
				return 'Cancel'
			default:
				break
		}
	})

	const setAppParam = paramValue => {
		appParam = { appParam, ...paramValue }
	}

	beforeEach(() => {
		container = null
		spy = null
	})

	let renderComponent = () => {
		container = mount(
			<Provider store={store}>
				<ConnectedSuccessView
					{...props.successViewProps}
					navigate={jest.fn()}
				/>
			</Provider>
		)
	}

	const setState = data => {
		container
			.childAt(0)
			.childAt(0)
			.setState(data)
	}

	it('Check whether landing view is rendered', () => {
		act(() => {
			renderComponent()
		})

		setState(initialState)

		expect(container.find('.section-container')).toHaveLength(1)
	})

	it('Check whether there are errors', () => {
		act(() => {
			renderComponent()
		})

		// const mock = ManualAccountService(() => {
		// 	return {
		// 		getManualAccount: () =>
		// 			new Promise((resolve, reject) => {
		// 				reject(new Error())
		// 			})
		// 	}
		// })
		// const result = mock.getManualAccount()

		// console.log(result)
		setState({ errorStatus: true })

		// expect(mock).toHaveBeenCalled()
		expect(container.find('.alert-error')).toHaveLength(1)
		expect(container.find('.alert-detail')).toHaveLength(1)
	})

	it('Renders account details', () => {
		act(() => {
			renderComponent()
		})

		setState(initialState)

		container.update()

		expect(container.find('.sub-section .title').text()).toBe('Test')
		expect(container.find('.sub-section .info-txt').text()).toBe('savings')
		expect(container.find('.currency').text()).toBe('$123.00')
	})

	it('Renders buttons', () => {
		act(() => {
			renderComponent()
		})

		setState(initialState)

		container.update()

		expect(container.find('.save-and-finish-btn')).toHaveLength(1)
		expect(container.find('.save-and-link-btn')).toHaveLength(1)
		expect(container.find('.cancel-btn')).toHaveLength(1)
	})

	it('Closes the app on clicking Save and Finish button', () => {
		act(() => {
			renderComponent()
		})

		setState(initialState)

		container.update()

		let spy = jest.spyOn(Application.Wrapper, 'close')

		container.find('.save-and-finish-btn').prop('onClick')()

		expect(spy).toHaveBeenCalled()
	})

	it('Navigates on clicking Save and Link button', () => {
		act(() => {
			renderComponent()
		})

		setState(initialState)

		container.update()

		let spy = jest.spyOn(
			container
				.childAt(0)
				.childAt(0)
				.props(),
			'navigate'
		)
		container.update()

		container
			.childAt(0)
			.childAt(0)
			.find('.save-and-link-btn')
			.prop('onClick')()

		expect(spy).toHaveBeenCalled()
	})

	it('Should delete account from modal', () => {
		const mock = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		mock.mockReturnValue(
			new Promise(resolve => {
				resolve({})
			})
		)

		act(() => {
			renderComponent()
		})

		setState({ showDeleteModal: true })
		container.find('#delete-button').simulate('click')

		expect(mock).toHaveBeenCalled()
	})

	it('Should throw error if account cannot be deleted', () => {
		const mock = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		mock.mockReturnValue(
			new Promise((resolve, reject) => {
				reject({})
			})
		)

		act(() => {
			renderComponent()
		})

		setState({ showDeleteModal: true })
		container.find('#delete-button').simulate('click')

		expect(mock).toHaveBeenCalled()
	})

	it('Should route back to landing view when clicking Edit Icon', () => {
		act(() => {
			renderComponent()
		})

		let spy = jest.spyOn(
			container
				.childAt(0)
				.childAt(0)
				.instance(),
			'handleEdit'
		)

		setState(initialState)

		container.update()
		container.find('.fa-edit').prop('onClick')()

		expect(spy).toHaveBeenCalled()
	})

	it('Should set state on clicking cancel button', () => {
		act(() => {
			renderComponent()
		})

		setState(initialState)

		container.find('.cancel-btn').prop('onClick')()

		expect(
			container
				.childAt(0)
				.childAt(0)
				.state().showDeleteModal
		).toBe(true)
	})
})
