import React, { Component } from 'react'
import {
	getString,
	AppStrings,
	AutoIds,
	getParam,
	AppParams
} from '../../../../conf'

import { Icon } from './../../../../../../framework/react/components/Icon'
import { Link } from './../../../../../../framework/react/components/Link'
import { Spinner } from './../../../../../../framework/react/components/Spinner'
import CDVModule from './../../../CDV'
import AppConstants from '../../../../conf/constants/AppConstants'

const SearchResultView = props => {
	const getSiteName = (siteName, countryCode) => {
		let sName,
			prefLocale = PARAM.userInfo.prefs.locale
		if (!countryCode || prefLocale.includes(countryCode)) {
			sName = siteName
		} else {
			sName =
				siteName +
				' (' +
				getString(
					AppConstants.ISO_COUNTRY_NAME_PREFIX +
						countryCode.toLowerCase()
				) +
				')'
		}
		return sName
	}

	return (
		<div
			className="search-list-wrapper row"
			autoid={AutoIds.LANDING_SEARCH_RESULTS_CONTAINER}
		>
			{props.isSearching ? (
				<Spinner
					id="largeSpinner"
					name="someButtonName"
					classes=""
					size="lg"
				/>
			) : props.searchResult.length ? (
				<ul className="site-search-list col-md-12">
					{props.searchResult.map((site, index) => {
						// remove http(s):// and last /
						let updatedBaseUrl = site.baseUrl
							? site.baseUrl.replace(/\w*:\/\/|\/$/g, '')
							: ''

						return (
							<li className="site-search-row-cnr" key={index}>
								<a
									onClick={props.navigateToSite.bind(
										this,
										site
									)}
								>
									{getParam(
										AppParams.SHOW_PROVIDERS_FAVICON
									) ? (
										<img
											className="aside"
											src={Application.Utilities.getFavIconResourceServiceURL(
												{
													siteId: site.id,
													url: site.favicon
												}
											)}
										/>
									) : null}

									{getParam(
										AppParams.SHOW_PROVIDERS_BASE_URL
									) ? (
										<div
											className="site-text ellipsify-text"
											title={getSiteName(
												site.name,
												site.countryISOCode
											)}
										>
											<p>
												{getSiteName(
													site.name,
													site.countryISOCode
												)}{' '}
											</p>
											<span
												className="col-md-12 base-url-cnr"
												title={updatedBaseUrl}
											>
												{updatedBaseUrl}
											</span>
										</div>
									) : (
										<div
											className="site-text"
											title={getSiteName(
												site.name,
												site.countryISOCode
											)}
										>
											<p>
												{getSiteName(
													site.name,
													site.countryISOCode
												)}
											</p>
										</div>
									)}
									{getParam(
										AppParams.SHOW_PROVIDERS_ALREADY_ADDED_ICON
									) && site.isAddedByUser !== 'false' ? (
										<Icon iconClass="fa-check-circle aside" />
									) : null}
								</a>
							</li>
						)
					})}
				</ul>
			) : (
				<div className="no-data-message">
					<p>
						{getString(AppStrings.NO_SEARCH_RESULT_LINE_ONE)}
						<span className="search-text">
							{props.searchString}
						</span>
						.
					</p>
					<p>
						{getString(AppStrings.NO_SEARCH_RESULT_LINE_TWO)}
						<Link
							lable={
								' ' + getString(AppStrings.SEARCH_DIFFERENT_FI)
							}
							onClick={props.toggleToPopularSites}
						/>
					</p>
				</div>
			)}
			{!props.isSearching && getParam(AppParams.ENABLE_CDV) ? (
				<div className="cdv-search-result-container">
					<CDVModule {...props} path={AppConstants.CDV_PATH_INVOKE} />
				</div>
			) : null}
		</div>
	)
}

SearchResultView.defaultProps = {
	navigateToSite: function() {}
}

export default SearchResultView
