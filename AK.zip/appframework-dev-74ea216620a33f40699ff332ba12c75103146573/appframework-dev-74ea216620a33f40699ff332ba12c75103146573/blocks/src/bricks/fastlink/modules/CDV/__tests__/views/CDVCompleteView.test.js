import React from 'react'
import { Provider } from 'react-redux'
import CDVCompleteView from './../../views/CDVCompleteView'

import configureStore from 'redux-mock-store'

import ProviderRTNData from './../__mocks__/providerByRTN'
import VerificationData from './../__mocks__/verification'
import ParamKeys from './../__mocks__/paramKeys'

import AppConstants from '../../../../conf/constants/AppConstants'
import { AppParams, getParam } from './../../../../conf'
import { AppStrings, getString, AutoIds } from '../../../../conf'
import ProviderDetailsServices from './../../../../services/provider/ProviderDetailsServices'
import VerificationService from './../../../../services/cdv/VerificationService'
import ParamKeyService from './../../../../services/common/ParamKeyService'
import DeeplinkConstants from '../../../../filters/deeplink/DeeplinkConstants'

jest.mock('./../../../../conf')
jest.mock('./../../../../services/provider/ProviderDetailsServices')
jest.mock('./../../../../services/cdv/VerificationService')
jest.mock('./../../../../services/common/ParamKeyService')

const mockStore = configureStore([])

describe.only('CDV Complete View', () => {
	let container = null

	beforeEach(() => {
		container = null

		getParam.mockImplementation(_key => {
			if (_key == AppParams.CDV_INITIATE_ACCOUNTTYPE_SELECTION) {
				return AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
			} else if (_key == AppParams.ERROR_DISCRIPTION_TOOLTIP) {
				return ['INCORRECT_CREDENTIALS']
			} else if (
				_key == AppParams.CDV_PRE_VERIFICATION_INVOKE_ENABLED_ERRORS
			) {
				return [
					'INCORRECT_CREDENTIALS',
					'ACCOUNT_LOCKED',
					'BETA_SITE_DEV_IN_PROGRESS',
					'SITE_BLOCKING_ERROR',
					'UNEXPECTED_SITE_ERROR',
					'SITE_UNAVAILABLE',
					'TECH_ERROR',
					'GENERIC',
					'DATASET_NOT_SUPPORTED',
					'VERIFICATION_FAILED'
				]
			} else if (
				_key == AppParams.CDV_POST_VERIFICATION_INVOKE_ENABLED_ERRORS
			) {
				return []
			} else if (_key == AppParams.ENABLE_CDV) {
				return true
			}
		})

		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.CDV_ERROR_ROUTING_NUMBER_NOT_VALID:
					return 'Routing number not valid'
					break

				case AppStrings.CDV_ERROR_AMOUNT_NOT_VALID:
					return 'Amount Not Valid'
					break

				case AppStrings.ACCOUNT_NUMBER_MASK_CHARACTER:
					return 'x-'
					break

				default:
					break
			}
		})
	})

	let renderComponent = (status, props) => {
		ProviderDetailsServices.mockImplementation(() => {
			return {
				getProviderDetailsByRTN: (_options, _callback) => {
					// site associated
					if (_options.name == '999999989') {
						_callback(null, ProviderRTNData.providerMap['NORMAL'])

						// site not associated
					} else if (_options.name == '011402118') {
						_callback(
							null,
							ProviderRTNData.providerMap['SITE_NOT_ASSOCIATED']
						)

						// API issue
					} else if (_options.name == '000000000') {
						_callback({ error: 'error' }, null)

						// invalid RTN
					} else {
						_callback(
							null,
							ProviderRTNData.providerMap['RTN_NOT_FOUND']
						)
					}
				}
			}
		})

		ParamKeyService.mockImplementation(() => {
			return {
				getParamKeyValue: (_options, _callback) => {
					_callback(null, ParamKeys.params)
				}
			}
		})

		VerificationService.mockImplementation(() => {
			return {
				getVerificationInfo: (_options, _callback) => {
					_callback(null, VerificationData.verificationMap[status])
				},

				submitVerificationDetails: (_options, _callback) => {
					if (_options.debitDetails[0] == '0.03') {
						_callback(
							null,
							VerificationData.verificationMap['DATA_MISMATCH']
						)
					} else {
						_callback(
							null,
							VerificationData.verificationMap[
								AppConstants.CDV_STATUS_SUCCESS
							]
						)
					}
				}
			}
		})

		props = !props ? {} : props
		if (!props.deeplinkData) {
			props.deeplinkData = {
				isDeeplink: false,
				deeplinkType: null
			}
		}

		let store = mockStore({
			currentProvider: ProviderRTNData.providerMap['NORMAL'],
			cdv: {
				verificationInfo: VerificationData.verificationMap[status],
				creditDebitInfo: {
					numberOfCredit: 2,
					isDebitEnabled: true
				}
			}
		})

		container = mount(
			<Provider store={store}>
				<CDVCompleteView
					{...props}
					toggleHeader={function() {}}
					handleTechDiff={function() {}}
				/>
			</Provider>
		)
	}

	it('Check whether CDV Initiated Form View is rendered when status is INITIATED', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_INITIATED)
		})
		expect(
			container.find('div.cdv-complete-wrapper .message-wrapper')
		).toHaveLength(1)
	})

	it('Check whether CDV Error Form View with Error: error-cdv-complete-already-success, is rendered when status is ALREADY SUCCESS', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_ALREADY_SUCCESS)
		})
		expect(
			container.find('div.error-cdv-complete-already-success')
		).toHaveLength(1)
	})

	it('Check whether CDV Error Form View with Error: error-cdv-complete-failed, is rendered when status is FAILED', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_FAILED)
		})
		expect(container.find('div.error-cdv-complete-failed')).toHaveLength(1)
	})

	it('Check whether CDV Error Form View with Error: error-cdv-complete-failed, is rendered when status is FAILED', () => {
		act(() => {
			renderComponent('UNKNOWN_FAILED')
		})
		expect(container.find('div.error-cdv-complete-failed')).toHaveLength(1)
	})

	it('Check whether CDV Error Form View with Error: error-cdv-complete-already-failed, is rendered when status is ALREADY_FAILED', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_ALREADY_FAILED)
		})
		expect(
			container.find('div.error-cdv-complete-already-failed')
		).toHaveLength(1)
	})

	it('Check whether CDV Error Form View with Error: error-tech-diff, is rendered when status is TECH_ERROR', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_TECH_ERROR)
		})
		expect(container.find('div.error-tech-diff')).toHaveLength(1)
	})

	it('DEEPLINK: Check whether CDV Deeplink Error is rendered with Error: error-tech-diff, is rendered when status is CDV_STATUS_INVALID_ACCOUNT_ID', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_INVALID_ACCOUNT_ID)
		})
		expect(container.find('div.error-tech-diff')).toHaveLength(1)
	})

	it('Check whether CDV Complete Form View with spinner is rendered when status is not known yet', () => {
		act(() => {
			renderComponent('SOMETHING')
		})
		expect(container.find('div.spinner-wrapper')).toHaveLength(1)
	})

	it('Check whether CDV Complete Form View is rendered when status is DEPOSITED', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_DEPOSITED)
		})
		expect(container.find('div.cdv-complete-wrapper')).toHaveLength(1)
		expect(
			container.find('div.cdv-complete-wrapper #info .title')
		).toHaveLength(1)
		expect(
			container.find('div.cdv-complete-wrapper #info .text-info')
		).toHaveLength(1)

		expect(
			container
				.find('div.cdv-complete-wrapper #account-number')
				.text()
				.substring(3)
		).toEqual('x-1234')
		expect(
			container
				.find('div.cdv-complete-wrapper #account-type')
				.text()
				.substring(3)
		).toEqual('checking')
		expect(
			container
				.find('div.cdv-complete-wrapper #routing-number')
				.text()
				.substring(3)
		).toEqual('999999989')
		expect(
			container.find('div.cdv-complete-wrapper #input-form')
		).toHaveLength(1)
		expect(
			container.find(
				'div.cdv-complete-wrapper #btn-wrapper .next-action-btn'
			)
		).toHaveLength(1)

		expect(
			container.find('div.cdv-complete-wrapper .deposit#credit_0')
		).toHaveLength(1)
		expect(
			container.find('div.cdv-complete-wrapper .deposit#credit_1')
		).toHaveLength(1)
		expect(
			container.find('div.cdv-complete-wrapper .withdrawal#debit')
		).toHaveLength(1)
	})

	it('Check whether CDV Complete Form renders error for amount fields if kept empty on submit', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_DEPOSITED)
		})
		container.find('.next-action-btn').simulate('click')
		expect(container.find('.cnr-deposit-0').hasClass('error')).toEqual(true)
		expect(container.find('.cnr-deposit-1').hasClass('error')).toEqual(true)
		expect(container.find('.cnr-withdrawal').hasClass('error')).toEqual(
			true
		)

		container.find('.cnr-deposit-0 .deposit').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 0
				}
			}
		})
		container.find('.cnr-deposit-1 .deposit').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 1
				}
			}
		})
		container
			.find('.cnr-withdrawal .withdrawal')
			.simulate('change', { target: { value: '0.02' } })
		container.find('.next-action-btn').simulate('click')

		expect(container.find('.cnr-deposit-0').hasClass('error')).toEqual(
			false
		)
		expect(container.find('.cnr-deposit-1').hasClass('error')).toEqual(
			false
		)
		expect(container.find('.cnr-withdrawal').hasClass('error')).toEqual(
			false
		)
	})

	it('Check whether CDV Complete Form renders error for amount fields if kept one of it are empty on submit', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_DEPOSITED)
		})
		container.find('.cnr-deposit-0 .deposit').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 0
				}
			}
		})
		container.find('.next-action-btn').simulate('click')
		expect(container.find('.cnr-deposit-1').hasClass('error')).toEqual(true)
		expect(container.find('.cnr-withdrawal').hasClass('error')).toEqual(
			true
		)

		container.find('.cnr-deposit-0 .deposit').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 0
				}
			}
		})
		container.find('.cnr-deposit-1 .deposit').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 1
				}
			}
		})
		container
			.find('.cnr-withdrawal .withdrawal')
			.simulate('change', { target: { value: '0.02' } })
		container.find('.next-action-btn').simulate('click')
		expect(container.find('.cnr-deposit-1').hasClass('error')).toEqual(
			false
		)
		expect(container.find('.cnr-withdrawal').hasClass('error')).toEqual(
			false
		)
	})

	it('Check whether CDV Complete Form renders error for amount fields if kept one of credit field as invalid on submit', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_DEPOSITED)
		})
		container.find('.cnr-deposit-0 .deposit').simulate('change', {
			target: {
				value: 'aaaa',
				getAttribute: function() {
					return 0
				}
			}
		})
		container.find('.next-action-btn').simulate('click')
		expect(container.find('.cnr-deposit-0').hasClass('error')).toEqual(true)

		container.find('.cnr-deposit-0 .deposit').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 0
				}
			}
		})
		container.find('.next-action-btn').simulate('click')
		expect(container.find('.cnr-deposit-0').hasClass('error')).toEqual(
			false
		)
	})

	it('Check whether CDV Complete Form renders error for amount fields if kept one of debit field as invalid on submit', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_DEPOSITED)
		})
		container.find('.cnr-withdrawal .withdrawal').simulate('change', {
			target: {
				value: 'aaaa',
				getAttribute: function() {
					return 0
				}
			}
		})
		container.find('.next-action-btn').simulate('click')
		expect(container.find('.cnr-withdrawal').hasClass('error')).toEqual(
			true
		)

		container.find('.cnr-withdrawal .withdrawal').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 0
				}
			}
		})
		container.find('.next-action-btn').simulate('click')
		expect(container.find('.cnr-withdrawal').hasClass('error')).toEqual(
			false
		)
	})

	it('Check whether CDV Complete Form gets submitted with Status as SUCCESS', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_DEPOSITED)
		})
		container.find('.cnr-deposit-0 .deposit').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 0
				}
			}
		})
		container.find('.cnr-deposit-1 .deposit').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 1
				}
			}
		})
		container
			.find('.cnr-withdrawal .withdrawal')
			.simulate('change', { target: { value: '0.02' } })
		container.find('.next-action-btn').simulate('click')
	})

	it('Check whether Close Button is clickable in CDV Initiate Success Form when status is INITIATED', () => {
		let isCloseCallNavigated = false
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_INITIATED, {
				navigate: function() {
					isCloseCallNavigated = true
				}
			})
		})
		expect(isCloseCallNavigated).toEqual(false)
		container.find('.initiate-success-btn').simulate('click')
		expect(isCloseCallNavigated).toEqual(true)
	})

	it('DEEPLINK: Check whether Close Button is clickable in CDV Initiate Success Form when status is INITIATED', () => {
		let isCloseCallNavigated = false
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_INITIATED, {
				handleCloseAppHandler: function() {
					isCloseCallNavigated = true
				},
				deeplinkData: {
					isDeeplink: true,
					deeplinkType:
						DeeplinkConstants.FLOW_TYPES.INITIATE_VERIFICATION
				}
			})
		})
		expect(isCloseCallNavigated).toEqual(false)
		container.find('.initiate-success-btn').simulate('click')
		expect(isCloseCallNavigated).toEqual(true)
	})

	it('Check whether CDV Success Form is rendered and Close Button is clickable in CDV Success Form when status is SUCCESS', () => {
		let isCloseCallNavigated = false
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_SUCCESS, {
				navigate: function() {
					isCloseCallNavigated = true
				}
			})
		})
		expect(
			container.find('div.cdv-complete-wrapper .complete-success-wrapper')
		).toHaveLength(1)
		expect(isCloseCallNavigated).toEqual(false)
		container.find('.complete-success-btn').simulate('click')
		expect(isCloseCallNavigated).toEqual(true)
	})

	it('DEEPLINK: Check whether CDV Success Form is rendered and Close Button is clickable in CDV Success Form when status is SUCCESS', () => {
		let isCloseCallNavigated = false
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_SUCCESS, {
				handleCloseAppHandler: function() {
					isCloseCallNavigated = true
				},
				deeplinkData: {
					isDeeplink: true,
					deeplinkType:
						DeeplinkConstants.FLOW_TYPES.COMPLETE_VERIFICATION
				}
			})
		})
		expect(
			container.find('div.cdv-complete-wrapper .complete-success-wrapper')
		).toHaveLength(1)
		expect(isCloseCallNavigated).toEqual(false)
		container.find('.complete-success-btn').simulate('click')
		expect(isCloseCallNavigated).toEqual(true)
	})

	it('Check whether CDV Error Form View is rendered when status is FAILED with reason as DATA_MISMATCH', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_DEPOSITED)
		})
		container.find('.cnr-deposit-0 .deposit').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 0
				}
			}
		})
		container.find('.cnr-deposit-1 .deposit').simulate('change', {
			target: {
				value: '0.01',
				getAttribute: function() {
					return 1
				}
			}
		})
		container
			.find('.cnr-withdrawal .withdrawal')
			.simulate('change', { target: { value: '0.03' } })
		container.find('.next-action-btn').simulate('click')
	})
})
