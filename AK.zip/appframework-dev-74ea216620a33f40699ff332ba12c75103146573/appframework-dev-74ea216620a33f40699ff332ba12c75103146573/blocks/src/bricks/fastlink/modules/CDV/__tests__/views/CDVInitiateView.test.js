import React from 'react'
import { Provider } from 'react-redux'
import CDVInitiateView from './../../views/CDVInitiateView'
import configureStore from 'redux-mock-store'
import AppConstants from '../../../../conf/constants/AppConstants'
import VerificationData from './../__mocks__/verification'
import ProviderData from './../__mocks__/provider'
import ProviderRTNData from './../__mocks__/providerByRTN'
import { AppParams, getParam } from './../../../../conf'
import { AppStrings, getString, AutoIds } from '../../../../conf'
import ProviderDetailsServices from './../../../../services/provider/ProviderDetailsServices'
import VerificationService from './../../../../services/cdv/VerificationService'
import DeeplinkConstants from '../../../../filters/deeplink/DeeplinkConstants'

jest.mock('./../../../../../../framework/react/components/Modal')
jest.mock('./../../../../conf')
jest.mock('./../../../../services/provider/ProviderDetailsServices')
jest.mock('./../../../../services/cdv/VerificationService')

const mockStore = configureStore([])

describe.only('CDV Initiate View', () => {
	let container = null
	beforeEach(() => {
		container = null

		getParam.mockImplementation(_key => {
			if (_key == AppParams.CDV_INITIATE_ACCOUNTTYPE_SELECTION) {
				return AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
			} else if (_key == AppParams.ERROR_DISCRIPTION_TOOLTIP) {
				return ['INCORRECT_CREDENTIALS']
			} else if (
				_key == AppParams.CDV_PRE_VERIFICATION_INVOKE_ENABLED_ERRORS
			) {
				return [
					'INCORRECT_CREDENTIALS',
					'ACCOUNT_LOCKED',
					'BETA_SITE_DEV_IN_PROGRESS',
					'SITE_BLOCKING_ERROR',
					'UNEXPECTED_SITE_ERROR',
					'SITE_UNAVAILABLE',
					'TECH_ERROR',
					'GENERIC',
					'DATASET_NOT_SUPPORTED',
					'VERIFICATION_FAILED'
				]
			} else if (
				_key == AppParams.CDV_POST_VERIFICATION_INVOKE_ENABLED_ERRORS
			) {
				return []
			} else if (_key == AppParams.ENABLE_CDV) {
				return true
			}
		})

		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.CDV_ERROR_ROUTING_NUMBER_NOT_VALID:
					return 'Routing number not valid'
					break

				case AppStrings.CDV_ERROR_ACCOUNT_NUMBER_NOT_VALID:
					return 'Account number not valid'
					break

				case AppStrings.CDV_ERROR_ROUTING_NUMBER_NOT_FOUND:
					return 'Routing Number not found'
					break

				default:
					break
			}
		})
	})

	let renderComponent = (status, props) => {
		status = status ? status : AppConstants.CDV_STATUS_NEW

		ProviderDetailsServices.mockImplementation(() => {
			return {
				getProviderDetailsByRTN: (_options, _callback) => {
					// site associated
					if (_options.name == '999999989') {
						_callback(null, ProviderRTNData.providerMap['NORMAL'])

						// site not associated
					} else if (_options.name == '011402118') {
						_callback(
							null,
							ProviderRTNData.providerMap['SITE_NOT_ASSOCIATED']
						)

						// API issue
					} else if (_options.name == '000000000') {
						_callback({ error: 'error' }, null)

						// invalid RTN
					} else {
						_callback(
							null,
							ProviderRTNData.providerMap['RTN_NOT_FOUND']
						)
					}
				}
			}
		})

		VerificationService.mockImplementation(() => {
			return {
				initiateVerification: (_options, _callback) => {
					// site associated or // site not associated
					if (
						_options.routingNumber == '999999989' ||
						_options.routingNumber == '011402118'
					) {
						_callback(
							null,
							VerificationData.verificationMap[
								AppConstants.CDV_STATUS_INITIATED
							]
						)
					} else {
						_callback(
							null,
							VerificationData.verificationMap[
								AppConstants.CDV_STATUS_FAILED
							]
						)
					}
				}
			}
		})

		let store = mockStore({
			currentProvider: ProviderData.provider,
			cdv: {
				verificationInfo: VerificationData.verificationMap[status]
			}
		})

		props = !props ? {} : props
		if (!props.deeplinkData) {
			props.deeplinkData = {
				isDeeplink: false,
				deeplinkType: null
			}
		}

		container = mount(
			<Provider store={store}>
				<CDVInitiateView {...props} toggleHeader={function() {}} />
			</Provider>
		)
	}

	it('Check whether CDV Initiate Form View is rendered', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_NEW)
		})
		expect(container.find('div.cdv-form-container')).toHaveLength(1)
	})

	it('Check whether CDV Initiate Success View is rendered when initial state is INITIATED', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_INITIATED)
		})
		expect(container.find('div.message-wrapper')).toHaveLength(1)
	})

	it('Check whether CDV Initiate Success View is rendered when initial state is ALREADY_INITIATED', () => {
		act(() => {
			renderComponent(
				AppConstants.CDV_ERROR_INITIATE_VERIFICATION_ALREADY_INITIATED
			)
		})
		expect(container.find('div.message-wrapper')).toHaveLength(1)
	})

	it('Check whether CDV Error View (error-already-completed) is rendered when initial state is ALREADY_COMPLETED', () => {
		act(() => {
			renderComponent(
				AppConstants.CDV_ERROR_INITIATE_VERIFICATION_ALREADY_COMPLETED
			)
		})
		expect(container.find('div.error-already-completed')).toHaveLength(1)
	})

	it('Check whether CDV Error View (error-cdv-initiate-verification-unknown) is rendered when initial state is FAILED with UNKNOWN REASON', () => {
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_FAILED)
		})
		expect(
			container.find('div.error-cdv-initiate-verification-unknown')
		).toHaveLength(1)
	})

	it('Check whether CDV Error View (error-invalid-flow) is rendered when state is NOT KNOWN', () => {
		act(() => {
			renderComponent('SOMETHING')
		})
		expect(container.find('div.error-cdv-invalid-flow')).toHaveLength(1)
	})

	it('Check whether CDV Initiate Form View is rendered when state is NULL and is Fresh State', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('div.cdv-form-container')).toHaveLength(1)
	})

	it('Check whether CDV Initiate Form submit for empty account number and RTN invokes handleStartVerification and set errors', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('#routing-number .error-decorator')).toHaveLength(
			0
		)
		expect(container.find('#account-number .error-decorator')).toHaveLength(
			0
		)
		container.find('.initiate-btn').simulate('click')
		expect(container.find('#routing-number .error-decorator')).toHaveLength(
			1
		)
		expect(container.find('#account-number .error-decorator')).toHaveLength(
			1
		)
	})

	it('Check whether for less than 4 digit account number error is shown and when rentered with correct account number it remove errors', () => {
		act(() => {
			renderComponent()
		})
		container
			.find('.input-field-cnr #account-number')
			.simulate('change', { target: { value: '123' } })
		container.find('.initiate-btn').simulate('click')
		expect(container.find('#account-number .message-cnr').text()).toEqual(
			'Account number not valid'
		)
		container
			.find('.input-field-cnr #account-number')
			.simulate('change', { target: { value: '1234' } })
		container.find('.initiate-btn').simulate('click')
		expect(container.find('#account-number .message-cnr').length).toEqual(0)
	})

	it('Check whether for less than 9 digit routing number error is shown and when rentered with correct routing number it remove errors', () => {
		act(() => {
			renderComponent()
		})
		container
			.find('.input-field-cnr #routing-number')
			.simulate('change', { target: { value: '99999998' } })
		container.find('.initiate-btn').simulate('click')
		expect(container.find('#routing-number .message-cnr').text()).toEqual(
			'Routing number not valid'
		)
		container
			.find('.input-field-cnr #routing-number')
			.simulate('change', { target: { value: '999999989' } })
		container.find('.initiate-btn').simulate('click')
		expect(container.find('#routing-number .message-cnr').length).toEqual(0)
	})

	it('Check whether for non supported RTN, error is shown and when rentered with correct routing number it remove errors', () => {
		act(() => {
			renderComponent()
		})
		container
			.find('.input-field-cnr #account-number')
			.simulate('change', { target: { value: '1234' } })
		container
			.find('.input-field-cnr #routing-number')
			.simulate('change', { target: { value: '123456789' } })
		container.find('.initiate-btn').simulate('click')
		expect(container.find('#routing-number .message-cnr').text()).toEqual(
			'Routing Number not found'
		)
		container
			.find('.input-field-cnr #routing-number')
			.simulate('change', { target: { value: '999999989' } })
		container.find('.initiate-btn').simulate('click')
		expect(container.find('#routing-number .message-cnr').length).toEqual(0)
	})

	it('Check whether for site not associated supported RTN, error is not shown', () => {
		act(() => {
			renderComponent()
		})
		container
			.find('.input-field-cnr #account-number')
			.simulate('change', { target: { value: '1234' } })
		container
			.find('.input-field-cnr #routing-number')
			.simulate('change', { target: { value: '011402118' } })
		container.find('.initiate-btn').simulate('click')

		expect(container.find('#routing-number .message-cnr').length).toEqual(0)
	})

	it('Check whether for API issue for privder search for RTN, error is shown as: Routing Number not found', () => {
		act(() => {
			renderComponent()
		})

		container
			.find('.input-field-cnr #account-number')
			.simulate('change', { target: { value: '1234' } })
		container
			.find('.input-field-cnr #routing-number')
			.simulate('change', { target: { value: '000000000' } })
		container.find('.initiate-btn').simulate('click')
		expect(container.find('#routing-number .message-cnr').text()).toEqual(
			'Routing Number not found'
		)
		container
			.find('.input-field-cnr #routing-number')
			.simulate('change', { target: { value: '999999989' } })
		container.find('.initiate-btn').simulate('click')
		expect(container.find('#routing-number .message-cnr').length).toEqual(0)
	})

	it('Check whether valid form data works and calls initiate verifications successfully', () => {
		act(() => {
			renderComponent()
		})
		container
			.find('.input-field-cnr #account-number')
			.simulate('change', { target: { value: '1234' } })
		container
			.find('.input-field-cnr #routing-number')
			.simulate('change', { target: { value: '999999989' } })
		container.find('.initiate-btn').simulate('click')
	})

	it('Check whether account Type change works and initiate verifications', () => {
		act(() => {
			renderComponent()
		})
		container
			.find('.input-field-cnr #account-number')
			.simulate('change', { target: { value: '1234' } })
		container
			.find('.input-field-cnr #routing-number')
			.simulate('change', { target: { value: '999999989' } })
		container
			.find('.input-radio-cnr #account-type-savings')
			.simulate('change', {
				target: { value: AppConstants.CDV_INITIATE_ACC_TYPE_SAVINGS }
			})

		container.find('.initiate-btn').simulate('click')
	})

	it('Check whether CDV Initiate Success View is rendered when initial state is INITIATED and click on close button works', () => {
		let isCloseCallNavigated = false
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_INITIATED, {
				navigate: function() {
					isCloseCallNavigated = true
				}
			})
		})
		expect(isCloseCallNavigated).toEqual(false)
		container.find('.initiate-success-btn').simulate('click')
		expect(isCloseCallNavigated).toEqual(true)
	})

	it('Check whether CDV Initiate Success View is rendered when initial state is CDV_ERROR_INITIATE_VERIFICATION_ALREADY_INITIATED and click on close button works', () => {
		let isCloseCallNavigated = false
		act(() => {
			renderComponent(
				AppConstants.CDV_ERROR_INITIATE_VERIFICATION_ALREADY_INITIATED,
				{
					navigate: function() {
						isCloseCallNavigated = true
					}
				}
			)
		})
		expect(isCloseCallNavigated).toEqual(false)
		container.find('.initiate-success-btn').simulate('click')
		expect(isCloseCallNavigated).toEqual(true)
	})

	it('DEEPLINK: Check whether CDV Initiate Success View is rendered when initial state is INITIATED and click on close button works', () => {
		let isCloseCallNavigated = false
		act(() => {
			renderComponent(AppConstants.CDV_STATUS_INITIATED, {
				handleCloseAppHandler: function() {
					isCloseCallNavigated = true
				},
				deeplinkData: {
					isDeeplink: true,
					deeplinkType:
						DeeplinkConstants.FLOW_TYPES.INITIATE_VERIFICATION
				}
			})
		})
		expect(isCloseCallNavigated).toEqual(false)
		container.find('.initiate-success-btn').simulate('click')
		expect(isCloseCallNavigated).toEqual(true)
	})

	// it('DEEPLINK: Check whether CDV Initiate Success View is rendered when initial state is CDV_ERROR_INITIATE_VERIFICATION_ALREADY_INITIATED and click on close button works', () => {
	// 	let isCloseCallNavigated = false
	// 	act(() => {
	// 		renderComponent(
	// 			AppConstants.CDV_ERROR_INITIATE_VERIFICATION_ALREADY_INITIATED,
	// 			{
	// 				handleCloseAppHandler: function() {
	// 					isCloseCallNavigated = true
	// 				},
	// 				deeplinkData: {
	// 					isDeeplink: true,
	// 					deeplinkType:
	// 						DeeplinkConstants.FLOW_TYPES.INITIATE_VERIFICATION
	// 				}
	// 			}
	// 		)
	// 	})
	// 	expect(isCloseCallNavigated).toEqual(false)
	// 	container.find('.initiate-success-btn').simulate('click')
	// 	expect(isCloseCallNavigated).toEqual(true)
	// })
})
