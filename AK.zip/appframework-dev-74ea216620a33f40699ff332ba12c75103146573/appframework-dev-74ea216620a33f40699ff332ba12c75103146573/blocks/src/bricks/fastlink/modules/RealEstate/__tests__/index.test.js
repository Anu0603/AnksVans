import React from 'react'
import { Provider } from 'react-redux'
import realEstateHelper from '../helper/RealEstateHelper'
import RealEstateModule from './../index'
import { createStore, combineReducers } from 'redux'
import realEstateReducer from './../../../store/reducers/realEstate'
jest.mock('../helper/RealEstateHelper')
jest.mock('../views/SuccessView', () => {
	return {
		__esModule: true,
		default: props => {
			return <div></div>
		}
	}
})
jest.mock('../views/LandingView', () => {
	return {
		__esModule: true,
		default: props => {
			return <div></div>
		}
	}
})
realEstateHelper.getCurrencyDropdownOptions.mockImplementation(() => {
	return ['AUD', 'USD']
})
describe('Real Estate Module', () => {
	let container = null
	let store = null
	const rootReducer = combineReducers({
		realEstate: realEstateReducer
	})
	beforeEach(() => {
		container = null
		store = createStore(rootReducer)
	})

	let renderComponent = () => {
		container = mount(
			<Provider store={store}>
				<RealEstateModule />
			</Provider>
		)
	}

	it('Check whether Real estate module is rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('#real-estate-container')).toHaveLength(1)
	})
	it('Check whether current View Landing View', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('#real-estate-container')).toHaveLength(1)
	})

	it('Check whether current View is  Success View', () => {
		act(() => {
			renderComponent()
		})
		container.childAt(0).setState({ currentView: 'RE_SUCCESS' })
		container
			.childAt(0)
			.instance()
			.onShowNextView('RE_SUCCESS')
		expect(container.childAt(0).instance().state.currentView).toBe(
			'RE_SUCCESS'
		)
	})
})
