import React, { Suspense } from 'react'
import { Provider } from 'react-redux'
import AccountListView from '../../views/AccountListView'
import { AppParams, getParam } from './../../../../conf'
import { AppStrings, getString } from './../../../../conf'
import ProviderData from './../__mocks__/currentProvider'
import configureStore from 'redux-mock-store'
import {
	Icon,
	IconNameMap
} from '../../../../../../framework/react/components/Icon'
import ProviderAccountPolling from '../../../../concept/api/polling/ProviderAccountPolling'
import AccountsPolling from '../../../../concept/api/polling/AccountsPolling'
import DeeplinkConstants from './../../../../filters/deeplink/DeeplinkConstants'

jest.mock('./../../../../conf')

jest.mock('../../../../concept/api/polling/ProviderAccountPolling')
jest.mock('../../../../concept/api/polling/AccountsPolling')

jest.mock('../../sections/ActSummaryButtons', () => {
	return {
		__esModule: true,
		default: props => {
			return <div className="account-summary-buttons-view"></div>
		}
	}
})

jest.mock('../../sections/ActSummaryHelpText', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="account-summary-help-text-view"></div>
		}
	}
})

jest.mock('../../sections/SpinnerMsg', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="spinning-msg--view"></div>
		}
	}
})

jest.mock('../../sections/accounts', () => {
	return {
		__esModule: true,
		default: props => {
			props.deleteCallback(1)
			return <div className="accounts-view"></div>
		}
	}
})
jest.mock('../../../CDV', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="CDV-view"></div>
		}
	}
})
jest.mock('react-dom', () => ({
	findDOMNode: function() {
		return { setAttribute: function() {} }
	}
}))
jest.mock(
	'../../../../../../../node_modules/react-redux/lib/utils/batch.js',
	() => ({
		setBatch: jest.fn(),
		getBatch: () => fn => fn()
	})
)
let backIconRef = React.createRef()
let backIcon = (
	<Icon
		ref={backIconRef}
		type="fal"
		iconClass={IconNameMap['chevron-left']}
	/>
)

const mockStore = configureStore([])

describe.only('Account list view', () => {
	let container = null
	beforeEach(() => {
		container = null

		FLUtil.getFlowName = jest.fn(key => {
			return 'AGGR'
		})
	})

	let renderComponent = (
		status,
		additionalStatus,
		props,
		isDeeplink,
		deeplinkType
	) => {
		let store = mockStore({
			currentProvider: ProviderData,
			refresh: {
				status: status,
				additionalStatus: additionalStatus,
				mfaLoginForm: null
			},
			accounts: {
				response: ''
			},
			deeplink: {
				isDeeplink: isDeeplink ? isDeeplink : false,
				deeplinkType: deeplinkType ? deeplinkType : null
			}
		})
		container = mount(
			<Provider store={store}>
				<AccountListView
					{...props}
					currentProvider={ProviderData}
					backIcon={backIcon}
				/>
			</Provider>
		)
	}

	it('Check whether Account List View is rendered for default status', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == AppParams.CONTAINER_LIST) {
					return ['bank']
				} else if (_key == AppParams.DISABLE_BOTTOM_TEXT) {
					return true
				} else if (_key == AppParams.POLLING_INTERVAL) {
					return 2000
				} else if (_key == AppParams.PRODUCT_TYPE) {
					return 'AGGR'
				} else if (_key == AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				} else if (_key == AppParams.ENABLE_CDV) {
					return false
				}
			})
			renderComponent('IN_PROGRESS', 'ACCT_SUMMARY_RECEIVED')
		})
		expect(container.find('div.account-summary-buttons-view')).toHaveLength(
			1
		)
		expect(container.find('div.CDV-view')).toHaveLength(0)
	})
	it('Check whether Account List View is rendered for Verification with CDV enabled', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == AppParams.CONTAINER_LIST) {
					return ['bank']
				} else if (_key == AppParams.DISABLE_BOTTOM_TEXT) {
					return true
				} else if (_key == AppParams.POLLING_INTERVAL) {
					return 2000
				} else if (_key == AppParams.PRODUCT_TYPE) {
					return 'VERIFICATION'
				} else if (_key == AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				} else if (_key == AppParams.ENABLE_CDV) {
					return true
				}
			})
			renderComponent('IN_PROGRESS', 'ACCT_SUMMARY_RECEIVED')
		})
		expect(container.find('div.account-summary-buttons-view')).toHaveLength(
			1
		)
		expect(container.find('div.CDV-view')).toHaveLength(1)
	})
	it('Check whether Account List View is rendered for verificationplusaggr', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == AppParams.CONTAINER_LIST) {
					return ['bank']
				} else if (_key == AppParams.DISABLE_BOTTOM_TEXT) {
					return true
				} else if (_key == AppParams.POLLING_INTERVAL) {
					return 2000
				} else if (_key == AppParams.PRODUCT_TYPE) {
					return 'VERIFICATIONPLUSAGGR'
				} else if (_key == AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				} else if (_key == AppParams.ENABLE_CDV) {
					return false
				}
			})
			renderComponent('IN_PROGRESS', 'ACCT_SUMMARY_RECEIVED')
		})
		expect(container.find('div.account-summary-buttons-view')).toHaveLength(
			1
		)
		expect(container.find('CDV-view')).toHaveLength(0)
	})

	it('Check whether Account List View is rendered for aggrplusverification', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == AppParams.CONTAINER_LIST) {
					return ['bank']
				} else if (_key == AppParams.DISABLE_BOTTOM_TEXT) {
					return true
				} else if (_key == AppParams.POLLING_INTERVAL) {
					return 2000
				} else if (_key == AppParams.PRODUCT_TYPE) {
					return 'AGGRPLUSVERIFICATION'
				} else if (_key == AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				} else if (_key == AppParams.ENABLE_CDV) {
					return false
				}
			})
			renderComponent('IN_PROGRESS', 'ACCT_SUMMARY_RECEIVED')
		})
		expect(container.find('div.account-summary-buttons-view')).toHaveLength(
			1
		)
		expect(container.find('div.CDV-view')).toHaveLength(0)
	})
	it('Check whether Account List View is rendered for aggrplusverification without container list', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == AppParams.CONTAINER_LIST) {
					return []
				} else if (_key == AppParams.DISABLE_BOTTOM_TEXT) {
					return true
				} else if (_key == AppParams.POLLING_INTERVAL) {
					return 2000
				} else if (_key == AppParams.PRODUCT_TYPE) {
					return 'AGGRPLUSVERIFICATION'
				} else if (_key == AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				} else if (_key == AppParams.ENABLE_CDV) {
					return false
				}
			})
			renderComponent('SUCCESS', 'AVAILABLE_DATA_RETRIEVED')
		})
		expect(container.find('div.account-summary-buttons-view')).toHaveLength(
			1
		)
		expect(container.find('div.CDV-view')).toHaveLength(0)
	})

	it('DEEPLINK - ADD -  Check whether help text is rendered', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == AppParams.CONTAINER_LIST) {
					return []
				} else if (_key == AppParams.DISABLE_BOTTOM_TEXT) {
					return true
				} else if (_key == AppParams.POLLING_INTERVAL) {
					return 2000
				} else if (_key == AppParams.PRODUCT_TYPE) {
					return 'AGGRPLUSVERIFICATION'
				} else if (_key == AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				} else if (_key == AppParams.ENABLE_CDV) {
					return false
				}
			})
			renderComponent(
				'SUCCESS',
				'AVAILABLE_DATA_RETRIEVED',
				null,
				true,
				DeeplinkConstants.FLOW_TYPES.ACCOUNT_ADDITION
			)
		})
		expect(
			container.find('div.account-summary-help-text-view')
		).toHaveLength(1)
	})

	it('DEEPLINK - REFRESH -  Check whether help text is not rendered', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == AppParams.CONTAINER_LIST) {
					return []
				} else if (_key == AppParams.DISABLE_BOTTOM_TEXT) {
					return true
				} else if (_key == AppParams.POLLING_INTERVAL) {
					return 2000
				} else if (_key == AppParams.PRODUCT_TYPE) {
					return 'AGGRPLUSVERIFICATION'
				} else if (_key == AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				} else if (_key == AppParams.ENABLE_CDV) {
					return false
				}
			})
			renderComponent(
				'SUCCESS',
				'AVAILABLE_DATA_RETRIEVED',
				null,
				true,
				DeeplinkConstants.FLOW_TYPES.REFRESH
			)
		})
		expect(
			container.find('div.account-summary-help-text-view')
		).toHaveLength(0)
	})
	it('DEEPLINK - EDIT -  Check whether help text is not rendered', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == AppParams.CONTAINER_LIST) {
					return []
				} else if (_key == AppParams.DISABLE_BOTTOM_TEXT) {
					return true
				} else if (_key == AppParams.POLLING_INTERVAL) {
					return 2000
				} else if (_key == AppParams.PRODUCT_TYPE) {
					return 'AGGRPLUSVERIFICATION'
				} else if (_key == AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				} else if (_key == AppParams.ENABLE_CDV) {
					return false
				}
			})
			renderComponent(
				'SUCCESS',
				'AVAILABLE_DATA_RETRIEVED',
				null,
				true,
				DeeplinkConstants.FLOW_TYPES.EDIT_CREDENTIALS
			)
		})
		expect(
			container.find('div.account-summary-help-text-view')
		).toHaveLength(0)
	})
})
