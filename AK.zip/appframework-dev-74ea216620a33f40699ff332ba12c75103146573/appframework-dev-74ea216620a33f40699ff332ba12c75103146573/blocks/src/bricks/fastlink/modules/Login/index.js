import React, { Component } from 'react'
import PropTypes from 'prop-types'
import Constants from '../../router/Constant'
import SiteLoginView from './views/SiteLoginView'
import ProviderDetailsServices from '../../services/provider/ProviderDetailsServices'
import { connect } from 'react-redux'
import { Spinner } from './../../../../framework/react/components/Spinner'
import { getParam, AppParams } from '../../conf'
import { AppStrings, getString } from './../../conf'
import PKILibrary from '../../common/PKI'
import DeeplinkConstants from '@fastlinkRoot/filters/deeplink/DeeplinkConstants'
import AppConstants from '@fastlinkRoot/conf/constants/AppConstants'
import TechErrorConstants from '../../components/Error/TechnicalError/TechErrorConstants'

class LoginModule extends Component {
	constructor(props) {
		super(props)
		this.isDeeplink = props.deeplinkData
			? props.deeplinkData.isDeeplink
			: false
		this.deeplinkType = this.isDeeplink
			? props.deeplinkData.deeplinkType
			: null

		this.state = {
			subViewType: '',
			isEditDeeplink:
				this.isDeeplink &&
				this.deeplinkType ===
					DeeplinkConstants.FLOW_TYPES['EDIT_CREDENTIALS']
		}

		this.providerDetailsServices = this.state.isEditDeeplink
			? new ProviderDetailsServices()
			: new ProviderDetailsServices(this.getTncData())

		this.editCredForm = null
		new PKILibrary().initializePKI()
	}

	static propTypes = {
		providerId: PropTypes.number
	}

	getTncData() {
		return {
			show_tnc_always: getParam(AppParams.LOGIN_SHOW_TNC_ALWAYS),
			tnc_version: getParam(AppParams.TNC_VERSION),
			one_time_tnc: getParam(AppParams.LOGIN_SHOW_ONETIME_TNC)
		}
	}

	componentDidMount() {
		let providerDetailsPromises = this.providerDetailsServices.getProvidersDetails(
			{
				providerId: this.props.providerId,
				providerAccountId: this.props.providerAccountId
			}
		)
		providerDetailsPromises.then(
			this.checkSetFormFields.bind(this),
			this.apiErrorHandler.bind(this)
		)
	}

	apiErrorHandler(response) {
		this.props.handleTechDiff(
			TechErrorConstants.getAPIError(
				response.providerDetails,
				TechErrorConstants.API_TYPE.PROVIDER_DETAILS
			)
		)
	}

	checkSetFormFields(apiResponse) {
		if (
			this.state.isEditDeeplink &&
			apiResponse.providerAccount &&
			apiResponse.providerAccount.aggregationSource !=
				AppConstants.USER_AGGREGATION_SOURCE
		) {
			this.apiErrorHandler(
				TechErrorConstants.INVALID_OPERATION_PROVIDER_ACCOUNT_ID
			)
		} else {
			if (apiResponse.providerId) {
				///Get cred form and set to instance variable
				this.editCredForm = apiResponse.loginForm
				let providerDetailsPromises = this.providerDetailsServices.getProvidersDetails(
					{ providerId: apiResponse.providerId }
				)
				providerDetailsPromises.then(
					this.setFormFieldsDetails.bind(this),
					this.apiErrorHandler.bind(this)
				)
			} else {
				this.setFormFieldsDetails(apiResponse)
			}
		}
	}

	setFormFieldsDetails = siteInfoWithLoginForm => {
		if (this.editCredForm) {
			siteInfoWithLoginForm.loginForm = this.editCredForm
		}
		this.props.dispatchProviderdetails(siteInfoWithLoginForm)
		this.setState({
			subViewType: siteInfoWithLoginForm.formType.toUpperCase(),
			form: siteInfoWithLoginForm.loginForm,
			providerId: this.props.providerId,
			helpText: siteInfoWithLoginForm.helpText,
			showTnc: siteInfoWithLoginForm.showTnc,
			providerAccountId: this.props.providerAccountId,
			errorOccured: this.props.errorOccured,
			errorCode: this.props.errorCode,
			currentProvider: siteInfoWithLoginForm
		})
	}

	handleSubmitClick() {
		this.props.navigate(Constants.ROUTE_ACCOUNT_SUMMARY_MODULE)
	}

	handleLoginComplete(_data) {
		const { navigate } = this.props
		navigate(Constants.ROUTE_VERIFICATION_MODULE, _data)
	}

	renderSubView() {
		let _view = (
			<Spinner
				id="largeSpinner"
				name="someButtonName"
				classes="aaa"
				color={
					this.props.currentProvider
						? this.props.currentProvider.hexCode2
						: null
				}
				size="lg"
				children={
					this.props.errorOccured &&
					this.props.errorCode == 'INCORRECT_CREDENTIALS' ? (
						<div
							id="login-refresh-label"
							className="login-refresh-label"
						>
							{getString(
								AppStrings.VERIFICATION_LOGIN_STEPPER_TEXT
							)}
						</div>
					) : null
				}
			/>
		)
		switch (this.state.subViewType) {
			case 'LOGIN':
				_view = (
					<SiteLoginView
						{...this.state}
						navigate={this.props.navigate}
						onLoginComplete={this.handleLoginComplete.bind(this)}
					/>
				)
				break
		}
		return _view
	}

	render() {
		return <React.Fragment>{this.renderSubView()}</React.Fragment>
	}
}

const mapStateToProps = state => {
	return {
		deeplinkData: state.deeplink
	}
}

const mapDispatchToProps = dispatch => {
	return {
		dispatchProviderdetails: provderInfo =>
			dispatch({
				type: 'SELECTED_PROVIDER_DATA',
				payload: provderInfo
			})
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(LoginModule)
