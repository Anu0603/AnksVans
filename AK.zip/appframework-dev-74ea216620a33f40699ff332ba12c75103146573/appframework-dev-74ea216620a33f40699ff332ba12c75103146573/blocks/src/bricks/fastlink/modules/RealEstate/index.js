import React, { Component } from 'react'
import PropTypes from 'prop-types'
import LandingView from './views/LandingView'
import SuccessView from './views/SuccessView'

class RealEstateModule extends Component {
	constructor(props) {
		super(props)
		this.state = {
			currentView: this.props.currentView,
			data: this.props
		}
	}

	static propTypes = {
		currentView: PropTypes.string,
		data: PropTypes.object
	}

	static defaultProps = {
		currentView: 'RE_LANDING_VIEW', //RE_LANDING_VIEW | RE_LINK_MORTGAGE | RE_SUCCESS,
		data: {}
	}

	componentDidMount() {}

	onShowNextView(_viewName, _options) {
		console.log(_viewName, _options)
		this.setState({
			currentView: _viewName,
			data: _options
		})
	}

	renderRealEstateView() {
		let View = null

		switch (this.state.currentView) {
			case 'RE_SUCCESS':
				View = SuccessView
				break

			case 'RE_LANDING_VIEW':
			default:
				View = LandingView
		}

		return (
			<View
				navigate={this.props.navigate}
				data={this.state.data}
				showNextView={this.onShowNextView.bind(this)}
				handleTechDiff={this.props.handleTechDiff}
				handleCloseAppHandler={this.props.handleCloseAppHandler}
			/>
		)
	}

	render() {
		return (
			<div id={'real-estate-container'} className="real-estate">
				{this.renderRealEstateView()}
			</div>
		)
	}
}

export default RealEstateModule
