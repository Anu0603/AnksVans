import React from 'react'
import { Provider } from 'react-redux'
import configureStore from 'redux-mock-store'
import EnableAccountInfo from '../../../sections/accounts/EnableAllAccounts'

const mockStore = configureStore([])

describe('enable all accounts', () => {
	let container = null
	let isAllCheckBoxSelected = false
	let currentProvider = 'institution name'

	let allSelectionOnChange = jest.fn()

	beforeEach(() => {
		container = null
	})

	it('Check if no checkbox is selected', () => {
		isAllCheckBoxSelected = false
		currentProvider = 'institution name'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<EnableAccountInfo
						checked={isAllCheckBoxSelected}
						currentProvider={currentProvider}
						allSelectionOnChange={allSelectionOnChange}
					/>
				</Provider>
			)
		}
		act(() => {
			renderComponent()
		})
		expect(allSelectionOnChange.mock.calls.length).toBe(0)
		expect(container.find('div.enable-all-wrapper')).toHaveLength(1)
	})
	it('Check if all checkbox is selected', () => {
		isAllCheckBoxSelected = true
		currentProvider = 'institution name'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<EnableAccountInfo
						checked={isAllCheckBoxSelected}
						currentProvider={currentProvider}
						allSelectionOnChange={allSelectionOnChange}
					/>
				</Provider>
			)
		}
		act(() => {
			renderComponent()
		})
		container.find('button').simulate('click')
		expect(allSelectionOnChange.mock.calls.length).toBe(1)
		expect(container.find('div.enable-all-wrapper')).toHaveLength(1)
	})
})
