import React from 'react'
import { Provider } from 'react-redux'
import ProviderData from './../__mocks__/provider'
import CDVErrorView from './../../views/CDVErrorView'
import { AppParams, getParam } from './../../../../conf'
import { AppStrings, getString, AutoIds } from '../../../../conf'

import configureStore from 'redux-mock-store'
import AppConstants from '../../../../conf/constants/AppConstants'

jest.mock('./../../../../conf')

const mockStore = configureStore([])

describe.only('CDV Error View', () => {
	let container = null

	beforeEach(() => {
		container = null
		getParam.mockImplementation(_key => {
			if (_key == AppParams.ERROR_DISCRIPTION_TOOLTIP) {
				return ['INCORRECT_CREDENTIALS']
			} else if (
				_key == AppParams.CDV_PRE_VERIFICATION_INVOKE_ENABLED_ERRORS
			) {
				return [
					'INCORRECT_CREDENTIALS',
					'ACCOUNT_LOCKED',
					'BETA_SITE_DEV_IN_PROGRESS',
					'SITE_BLOCKING_ERROR',
					'UNEXPECTED_SITE_ERROR',
					'SITE_UNAVAILABLE',
					'TECH_ERROR',
					'GENERIC',
					'DATASET_NOT_SUPPORTED',
					'VERIFICATION_FAILED'
				]
			} else if (
				_key == AppParams.CDV_POST_VERIFICATION_INVOKE_ENABLED_ERRORS
			) {
				return []
			} else if (
				_key ==
				AppParams.ERROR_CDV_INITIATE_VERIFICATION_ALREADY_COMPLETED_BUTTONS
			) {
				return 'CLOSE'
			} else if (_key == AppParams.ENABLE_CDV) {
				return true
			}
		})
		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.CDV_ERROR_ROUTING_NUMBER_NOT_VALID:
					return 'Routing number not valid'
					break

				case AppStrings.ERROR_CDV_INITIATE_VERIFICATION_ALREADY_COMPLETED_TITLE:
					return 'Verfication Status'
					break

				case AppStrings.ERROR_CDV_INITIATE_VERIFICATION_ALREADY_COMPLETED_DESC:
					return 'This account has already completed the verification process.'
					break

				default:
					break
			}
		})
	})

	let renderComponent = props => {
		let store = mockStore({
			currentProvider: ProviderData.provider
		})

		container = mount(
			<Provider store={store}>
				<CDVErrorView {...props} />
			</Provider>
		)
	}

	it('Check whether CDV Error View is rendered', () => {
		act(() => {
			renderComponent({
				errorCode:
					AppConstants.CDV_ERROR_INITIATE_VERIFICATION_ALREADY_COMPLETED
			})
		})
		expect(container.find('div.cdv-error-section')).toHaveLength(1)
		expect(container.find('div.error-already-completed')).toHaveLength(1)
	})
})
