import React, { Component } from 'react'
import Constants from '../../../router/Constant'
import PreVerificationView from './../components/invoke/preVerificationView'
import PostVerificationView from './../components/invoke/postVerificationView'
import AppConstants from '../../../conf/constants/AppConstants'
import { AutoIds } from '../../../conf'

class CDVInvokeView extends Component {
	constructor(props) {
		super(props)
		this.state = {
			subPath: props.subPath
		}
	}

	initiateCDV() {
		let data = {
			path: AppConstants.CDV_PATH_INITIATE
		}
		this.props.navigate(Constants.ROUTE_CDV_MODULE, data)
	}

	renderInvokeView() {
		let _cdvInvokeView = null
		let _subPath = this.state.subPath
		switch (_subPath) {
			case AppConstants.CDV_SUB_PATH_INVOKE_PRE_VERIFICATION:
				_cdvInvokeView = (
					<PreVerificationView
						{...this.props}
						onSubmit={this.initiateCDV.bind(this)}
					/>
				)
				break

			case AppConstants.CDV_SUB_PATH_INVOKE_POST_VERIFICATION:
				_cdvInvokeView = (
					<PostVerificationView
						{...this.props}
						onSubmit={this.initiateCDV.bind(this)}
					/>
				)
				break

			default:
				_cdvInvokeView = (
					<PreVerificationView
						{...this.props}
						onSubmit={this.initiateCDV.bind(this)}
					/>
				)
				break
		}
		return _cdvInvokeView
	}

	render() {
		return (
			<React.Fragment>
				<div
					className="cdv-invoke-wrapper"
					autoid={AutoIds.CDV_INVOKE_CONTAINER}
				>
					{this.renderInvokeView()}
				</div>
			</React.Fragment>
		)
	}
}

export default CDVInvokeView
