import React from 'react'
import Timer from '../index'

describe('Timer Component', () => {
	let container = null

	jest.useFakeTimers()

	beforeEach(() => {
		container = null
	})

	afterEach(() => {
		container.unmount()
	})

	it('Check if Timer component is rendered', () => {
		let props = {
			timeinSeconds: 0,
			providerAccountId: 12345
		}
		act(() => {
			container = mount(<Timer {...props} />)
		})
		container.update()
		expect(container.find('.timer-wrapper')).toHaveLength(1)
		expect(container).toMatchSnapshot()
	})

	it('Check if props are accepted and time is rendered', () => {
		let props = {
			timeinSeconds: 2000,
			providerAccountId: 12345
		}
		act(() => {
			container = mount(<Timer {...props} />)
		})
		container.update()
		expect(container.find('.timer-wrapper').text()).toEqual(' 0:02')
		expect(container).toMatchSnapshot()
		jest.runOnlyPendingTimers()
		expect(container.find('.timer-wrapper').text()).toEqual(' 0:01')
		jest.runOnlyPendingTimers()
	})
})
