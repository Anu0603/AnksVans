import React from 'react'

import FooterSection from '../../sections/Footer'
import { getParam } from '../../../../conf'
jest.mock('../../../../conf')
jest.mock(
	'./../../../../../../framework/react/components/Modal/PfileModal',
	() => {
		return {
			__esModule: true,
			default: props => {
				return (
					<div className="pfile-modal">
						<button onClick={props.onCrossIconClick} />
					</div>
				)
			},
		}
	}
)

describe('Footer Section', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check whether footer section rendered', () => {
		act(() => {
			container = shallow(<FooterSection showPolicyView={true} />)
		})
		expect(container.find('div.footer')).toHaveLength(1)
	})

	it('Check whether footer section not rendered when showPolicyView prop passed as false', () => {
		act(() => {
			container = shallow(<FooterSection showPolicyView={false} />)
		})
		expect(container.find('div.footer')).toHaveLength(0)
	})

	it('Check whether privacy policy link shown', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'show_privacy_policy') {
					return true
				}
			})
			container = mount(<FooterSection showPolicyView={true} />)
		})
		expect(container.find('.privacy-policy')).toHaveLength(1)
	})

	it('Check whether security policy link shown', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'show_security_policy') {
					return true
				}
			})
			container = mount(<FooterSection showPolicyView={true} />)
		})
		expect(container.find('.security-policy')).toHaveLength(1)
	})

	it('Check whether link seperator rendered', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'show_privacy_policy') {
					return true
				}
				if (_key == 'show_security_policy') {
					return true
				}
			})
			container = mount(<FooterSection showPolicyView={true} />)
		})
		expect(container.find('.link-seperator').length).toBeGreaterThan(0)
	})

	it('Check whether links are clickable', () => {
		let mockFn = jest.fn()
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'show_privacy_policy') {
					return true
				}
				if (_key == 'show_security_policy') {
					return true
				}
			})

			container = mount(
				<FooterSection showPolicyView={true} showPopup={true} />
			)
			// container.instance().fetchPolicyContent = mockFn;
		})
		container.find('.privacy-policy').simulate('click')
		container.find('.pfile-modal button').simulate('click')
		// expect(mockFn.mock.calls.length).toBe(1);
	})
})
