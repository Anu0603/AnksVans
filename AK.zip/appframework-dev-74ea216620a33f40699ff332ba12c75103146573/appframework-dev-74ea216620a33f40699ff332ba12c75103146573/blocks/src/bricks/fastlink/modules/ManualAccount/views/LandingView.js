import React, { Component } from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import { TextField } from '../../../../../framework/react/components/InputField'
import Dropdown from '../../../../../framework/react/components/Dropdown'
import { Radio } from '../../../../../framework/react/components/RadioButton'
import DatePicker from '../../../../../framework/react/components/DatePicker'
import { Button } from '../../../../../framework/react/components/Button'
import { Toggle } from '../../../../../framework/react/components/ToggleButton'
import { Spinner } from '../../../../../framework/react/components/Spinner'
import ErrorBanner from '../../../components/Error/ErrorBanner'
import ErrorContent from '../../../components/Error/ErrorContent'
import AccountsService from '../../../../fastlink/services/account/AccountsService'
import ManualAccountService from '../../../../fastlink/services/account/ManualAccountService'
import moment from 'moment'
import utils from '../utils/utils'
// import { getString, getParam } from '../../../conf/utilities/Utilities'
import { AppStrings, AppParams, getString, getParam } from '../../../conf'
import DeleteModal from '../sections/DeleteModal'
import CONSTANTS from './../../../router/Constant'

export class LandingView extends Component {
	constructor(props) {
		super(props)
		this.state = {
			selectedAccountTypeValue: '',
			accountTypeOptions: [],
			selectedContainer: '',
			// containerOptions: getParam(AppParams.CONTAINER_LIST),
			currencyOptions: utils.getCurrencyDropdownOptions(
				getParam(AppParams.SUPPORTED_CURRENCY)
			),
			// frequencyOptions: utils.getFrequencyOptions(),
			fields: this.props.data.prevFieldValues || [],
			showSpinner: false,
			showErrorBanner: false,
			showDeleteModal: false,
			errorReason: '',
			hasErrors: false,
			originalAcctNumber: this.props.data.originalAcctNumber || ''
		}

		this.accountId
		this.editmode = this.props.data.isEdit ? true : false
		this.randomVal = Math.random()

		this.manualAccountService = new ManualAccountService()
		// this.isDeeplink = this.props.deeplinkData.isDeeplink
	}

	static propTypes = {}

	static defaultProps = {}

	componentDidMount() {
		if (this.isDeeplink && !this.props.data.editAccount) {
			// let isEdit =
			// 	this.props.deeplinkData.deeplinkType === 'EDIT_MANUAL'
			// 		? true
			// 		: false
			// if (isEdit) {
			// 	const { accountId } = this.props.deeplinkData.data
			// 	this.accountId = accountId
			// 	this.setState({ editmode: true })
			// 	this.manualAccountService
			// 		.getManualAccount({ id: accountId })
			// 		.then(
			// 			resp => {
			// 				this.props.data.editAccount = resp.account[0]
			// 				utils.getResponse.call(
			// 					this,
			// 					this.props.data.editAccount
			// 				)
			// 				this.setState({
			// 					...this.state,
			// 					...this.props.data.editAccount
			// 				})
			// 				this.setState({ showSpinner: false })
			// 			},
			// 			() => {
			// 				this.setState({ showSpinner: false })
			// 				this.props.handleTechDiff()
			// 			}
			// 		)
			// } else {
			// 	this.setState({ showSpinner: false })
			// }
		} else {
			if (this.editmode) {
				let accountData = this.props.data.editAccount[0]
				let fields = utils.getFields(accountData.accountType)
				let acctTypes = this.getAccountTypeOpts(accountData.accountType)

				let curr = this.props.data.currency
				let prevState = this.props.data.prevState
				let mappedFields = fields.map(item => {
					// if (item.name in accountData) {
					item.properties.value = accountData[item.name] || ''
					// }

					// if (item.name === 'accountNumber') {
					// 	item.properties.value = this.state.originalAcctNumber
					// }

					if (
						typeof accountData[item.name] === 'boolean' &&
						!accountData[item.name]
					) {
						item.properties.value = false
					}

					if (item.name === 'amountDue' || item.name === 'balance') {
						item.properties.value = parseFloat(
							accountData[item.name].amount
						)
					}

					if (item.name === 'currency') {
						item.properties.options = this.state.currencyOptions.map(
							i => {
								if (i.optionValue === curr) {
									i.selected = true
								} else {
									i.selected = false
								}

								return i
							}
						)
						item.properties.value = 'USD'
					}

					return item
				})

				this.setState({
					selectedAccountTypeValue: accountData.accountType,
					selectedContainer: utils.getAccountTypeContainer(
						accountData.accountType
					)[0],
					accountTypeOptions: acctTypes,
					fields: this.props.data.prevFieldValues || mappedFields
				})

				this.accountId = accountData.id
			} else {
				let getFields = utils.getFields('SAVINGS')

				this.changeToStateInput(
					this.originalAcctNumber,
					'accountNumber'
				)

				this.setState({
					selectedAccountTypeValue: 'SAVINGS',
					selectedContainer: 'bank',
					accountTypeOptions: this.getAccountTypeOpts('SAVINGS'),
					fields: getFields.map(item => {
						item.properties.error = false
						item.properties.errorMessage = ''

						if (item.name === 'currency') {
							item.properties.options = this.state.currencyOptions.map(
								i => {
									if (i.optionValue === 'USD') {
										i.selected = true
									} else {
										i.selected = false
									}

									return i
								}
							)
						}

						return item
					})
				})
			}
		}
	}

	componentWillUnmount() {
		this.setState({
			fields: [],
			errorReason: '',
			showErrorBanner: false,
			hasErrors: false
		})
	}

	validateManualAccountFields() {
		let { fields } = this.state

		let mappedFields = fields.map(obj => {
			if (
				obj.properties.hasOwnProperty('required') &&
				obj.properties.required &&
				!obj.properties.value
			) {
				obj.properties.error = true
				obj.properties.errorMessage = getString(
					AppStrings.ERROR_REQUIRED_FIELD
				)
			} else {
				obj.properties.error = false
				obj.properties.errorMessage = ''
			}

			return obj
		})

		let errorsFound = mappedFields.some(
			obj => obj.properties.error === true
		)

		this.setState(
			{
				fields: mappedFields,
				hasErrors: errorsFound
			},
			this.handleSubmit
		)
	}

	getAccountTypeOpts(acctType) {
		return utils.getAccountTypeOptions().map(item => {
			item.selected = item.optionValue === acctType ? true : false
			return item
		})
	}

	deepMerge(...objects) {
		const isObject = obj => obj && typeof obj === 'object'

		return objects.reduce((prev, obj) => {
			Object.keys(obj).forEach(key => {
				const pVal = prev[key]
				const oVal = obj[key]

				if (Array.isArray(pVal) && Array.isArray(oVal)) {
					prev[key] = pVal.concat(...oVal)
				} else if (isObject(pVal) && isObject(oVal)) {
					prev[key] = this.deepMerge(pVal, oVal)
				} else {
					prev[key] = oVal
				}
			})

			return prev
		}, {})
	}

	handleContainerChange(e, d) {
		if (
			!d.value ||
			!this.state.selectedAccountTypeValue ||
			d.value.optionValue === this.state.selectedAccountTypeValue
		)
			return undefined

		let { fields } = this.state
		let selectionValue = d.value.optionValue
		let container = utils.getAccountTypeContainer(selectionValue)
		let initialFields = utils.getFields(selectionValue)

		let compare = [initialFields, fields]
			// .sort((a, b) => b.length - a.length)
			// .reduce((a, b) => a.filter(o => !b.some(v => v.name === o.name)))
			.reduce((a, b) => a.filter(o => b.some(v => v.name !== o.name)))

		let mergedFields = this.deepMerge(fields, compare)

		// debugger

		let output = Object.keys(compare).map(k => compare[k])

		let { accountTypeOptions } = this.state
		accountTypeOptions.map(item => {
			item.selected = item.optionValue === selectionValue ? true : false
			return item
		})

		this.setState({
			selectedAccountTypeValue: selectionValue,
			selectedContainer: container[0],
			accountTypeOptions,
			fields: output
		})
	}

	changeToStateInput(e, fieldName) {
		let { fields } = this.state
		let acctNumber

		let mappedFields = fields.map(f => {
			if (f.name === 'accountNumber') {
				acctNumber = f.properties.value
			}

			if (f.name === fieldName) {
				f.properties.value = e
			}

			return f
		})

		this.setState({
			fields: mappedFields,
			originalAcctNumber: acctNumber
		})
	}

	changeToStateDropdown(e, d, k) {
		let { fields } = this.state

		let key = k
		let val = d.value.optionValue
		let match = fields.filter(f => f.name === key)

		if (!val || val === match[0].properties.value) {
			return
		} else {
			let mappedFields = fields.map(f => {
				if (f.name === key) {
					f.properties.value = val
				}

				return f
			})

			this.setState({
				fields: mappedFields
			})
		}
	}

	changeToStateDatePicker(e, fieldName) {
		let { fields } = this.state
		let formattedDate = moment(new Date(e)).format('MM/DD/YYYY')
		let isDateValid = moment(new Date(formattedDate)).isValid()
		let mappedFields

		if (isDateValid) {
			mappedFields = fields.map(f => {
				if (f.name === fieldName) {
					f.properties.value = formattedDate
				}

				return f
			})
		} else {
			mappedFields = fields.map(f => {
				if (f.name === fieldName) {
					f.properties.value = ''
				}

				return f
			})
		}

		this.setState({
			fields: mappedFields
		})
	}

	changeToStateRadio(e, fieldName, selectedId, selectedValue) {
		let { fields } = this.state

		let mappedFields = fields.map(f => {
			if (f.name === fieldName) {
				f.properties.options.forEach(opt => (opt.checked = false))
				f.properties.options.map(opt => {
					if (opt.id === selectedId) {
						opt.checked = true
					}

					return opt
				})

				f.properties.value = selectedValue
			}

			return f
		})

		this.setState({
			fields: mappedFields
		})
	}

	changeToStateToggle(e, fieldName) {
		let { fields } = this.state

		let mappedFields = fields.map(f => {
			if (f.name === fieldName) {
				f.properties.value = e.target.checked
			}

			return f
		})

		this.setState({ fields: mappedFields })
	}

	handleSubmit() {
		// this.validateManualAccountFields();

		let { fields } = this.state

		if (!this.state.hasErrors) {
			let data = {
				accountType: this.state.selectedAccountTypeValue
			}
			let curr = fields
				.filter(item => item.name === 'currency')
				.map(el => el.properties.value)

			let mappedFields = fields.map(f => {
				if (f.name === 'dueDate') {
					let date = f.properties.value
					f.properties.value = moment(new Date(date)).format(
						'YYYY-MM-DD'
					)
				}

				if (f.name === 'balance' || f.name === 'amountDue') {
					data[f.name] = {
						amount: parseFloat(f.properties.value).toString(),
						currency: curr[0]
					}
				} else {
					data[f.name] = f.properties.value
				}

				if (
					typeof f.properties.value !== 'boolean' &&
					!f.properties.value
				) {
					data[f.name] = null
				}

				return f
			})

			delete data.currency

			this.setState({ fields: mappedFields, showSpinner: true })

			// If editing, delete account and add new instead of PUT
			if (this.editmode) {
				this.silentDelete()
			}

			new ManualAccountService().addManualAccount(data).then(
				resp => {
					this.accountId = resp.account[0].id
					this.props.showNextView('MA_SUCCESS', {
						id: resp.account[0].id,
						originalAcctNumber: this.state.originalAcctNumber,
						container: this.state.selectedContainer,
						prevFieldValues: this.state.fields
					})
				},
				error => {
					this.setState({
						showSpinner: false,
						showErrorBanner: true
					})
				}
			)
		}
	}

	silentDelete() {
		new AccountsService()
			.deleteAccount({ accountId: this.accountId })
			.then(() => {
				this.setState({ showDeleteModal: false })
				this.props.onDelete(this.accountId)
			})
	}

	handleDelete() {
		new AccountsService().deleteAccount({ accountId: this.accountId }).then(
			() => {
				this.setState({ showDeleteModal: false })
				this.props.onDelete(this.accountId)
				this.props.navigate(CONSTANTS.ROUTE_LANDING_MODULE)
			},
			error => {
				console.log('error occured while deleting', error)
				this.setState({
					showDeleteModal: false,
					errorReason: 'MANUAL_ACCOUNT_UNABLE_TO_DELETE',
					errorStatus: 'MANUAL_ACCOUNT_UNABLE_TO_DELETE',
					showErrorBanner: true
				})
			}
		)
	}

	render() {
		return (
			<div>
				{this.state.showDeleteModal && (
					<DeleteModal
						showHidePopUp={flag => {
							this.setState({ showDeleteModal: flag })
						}}
						handleDelete={this.handleDelete.bind(this)}
						accountName={this.state.fields
							.filter(f => f.name === 'accountName')
							.map(i => i.properties.value)
							.join('')}
					/>
				)}

				{this.state.showSpinner ? (
					<Spinner id="largeSpinner" size="lg" />
				) : (
					<div className="section-container">
						<div className="section-header">
							<div className="title">
								{this.editmode
									? getString(
											AppStrings.MANUAL_ACCOUNT_EDIT_ACCOUNT_TITLE
									  )
									: getString(
											AppStrings.MANUAL_ACCOUNT_ADD_ACCOUNT_TITLE
									  )}
							</div>
						</div>

						{this.state.showErrorBanner && !this.state.showSpinner && (
							<React.Fragment>
								<ErrorBanner
									errorCode={this.state.errorReason}
								/>
								<ErrorContent
									errorCode={this.state.errorReason}
								/>
							</React.Fragment>
						)}

						<div className="manual-account-fields form-content">
							<Dropdown
								name="account-types-dropdown"
								labelText={this.editmode ? 'Account Type' : ''}
								htmlId="account-types"
								textFieldKey="account-types"
								options={this.state.accountTypeOptions}
								onChange={this.handleContainerChange.bind(this)}
							/>
							{this.state.fields.map((field, index) => {
								switch (field.type) {
									case 'text':
										return (
											<TextField
												key={index}
												id={'id-' + Math.random()}
												value={field.properties.value.toString()}
												placeholder={
													field.properties.placeholder
												}
												label={
													this.editmode
														? field.properties
																.placeholder
														: null
												}
												onChange={e =>
													this.changeToStateInput(
														e.target.value,
														field.name
													)
												}
												error={field.properties.error}
												errorMessage={
													field.properties
														.errorMessage
												}
												maxLength={
													field.properties.maxLength
												}
											/>
										)

										break
									case 'dropdown':
										return (
											<Dropdown
												name={
													field.properties.value +
													'-dropdown'
												}
												key={index}
												labelText={
													this.editmode
														? field.properties
																.placeholder
														: ''
												}
												textFieldKey={
													field.properties.value
												}
												htmlId={
													field.properties.value +
													'-dropdown'
												}
												options={
													field.properties.options
												}
												onChange={(e, data) => {
													this.changeToStateDropdown(
														e,
														data,
														field.name
													)
												}}
												value={field.properties.value}
											/>
										)

										break
									case 'datepicker':
										return (
											<React.Fragment key={index}>
												{this.editmode &&
													field.properties
														.placeholder && (
														<label className="dd-label">
															{
																field.properties
																	.placeholder
															}
														</label>
													)}
												<DatePicker
													key={
														this.randomVal +
														'-' +
														index
													}
													onChange={e => {
														this.changeToStateDatePicker(
															e,
															field.name
														)
													}}
													error={
														field.properties.error
													}
													errorMessage={
														field.properties
															.errorMessage
													}
													defaultDate={
														field.properties.value
															? moment(
																	field
																		.properties
																		.value,
																	'YYYY-MM-DD'
															  ).utc()
															: undefined
													}
													value={
														field.properties.value
													}
													placeholder={
														field.properties
															.placeholder
													}
													minDate={
														field.properties.minDate
													}
													yearStart={0}
													yearEnd={50}
												/>
											</React.Fragment>
										)

										break
									case 'radio':
										return field.properties.options.map(
											option => {
												return (
													<Radio
														// key={index}
														id={option.id}
														name={option.name}
														value={option.value}
														label={option.label}
														checked={option.checked}
														onChange={e =>
															this.changeToStateRadio(
																e,
																field.name,
																option.id,
																option.value
															)
														}
													/>
												)
											}
										)

										break
									case 'toggle':
										return (
											<Toggle
												key={index}
												id="net-worth-toggle"
												label={getString(
													AppStrings.REAL_ESTATE_INCLUDE_NET_WORTH_LABEL
												)}
												disabled={false}
												currentValue={
													field.properties.value
												}
												onChange={e => {
													this.changeToStateToggle(
														e,
														field.name
													)
												}}
												checked={field.properties.value}
											/>
										)

										break
									default:
										return null
								}
							})}

							<div className="btn-wrapper">
								<Button
									fullWidth
									label={getString(
										AppStrings.NEXT_BUTTON_TEXT
									)}
									onClick={this.validateManualAccountFields.bind(
										this
									)}
								></Button>
								{this.editmode && (
									<Button
										label="Delete Account"
										variant="danger"
										fullWidth
										reversed
										// onClick={this.handleDelete.bind(this)}
										onClick={() =>
											this.setState({
												showDeleteModal: true
											})
										}
									></Button>
								)}
							</div>
						</div>
					</div>
				)}
			</div>
		)
	}
}

const mapStateToProps = state => {
	return {
		// deeplinkData: state.deeplink
	}
}

const mapDispatchToProps = dispatch => {
	return {
		onDelete: accountID =>
			dispatch({
				type: 'REMOVE_MANUAL_ACCOUNT',
				payload: { accountID }
			})
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(LandingView)
