import React from 'react'
import { configure, shallow, mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { act } from 'react-dom/test-utils'

configure({ adapter: new Adapter() });

import ResetSection from './../../../sections/reset'
import {getString} from "../../../../../conf";
jest.mock("../../../../../conf")

describe('Reset Section', () => {

    let container = null

    beforeEach(() => {
        container = null
    })
   

    it('Check whether reset componenet rendered or not', () => {
        let resetString = "Reset password";
        act(() => {
            getString.mockImplementation((_key) => {
                if (_key == 'login_reset') {
                    return resetString
                }
            })
            
            container = shallow(<ResetSection  />)
        })
        expect(container.find('div.text')).toHaveLength(1)
        expect(container.find('div.text').text()).toBe(resetString)
    })
})