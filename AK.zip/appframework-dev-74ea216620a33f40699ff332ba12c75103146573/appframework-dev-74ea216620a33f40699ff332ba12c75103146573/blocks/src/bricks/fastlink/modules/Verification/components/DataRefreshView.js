import React, { Component } from "react";
import { AppStrings, getString, AutoIds } from "../../../conf";
import { Spinner } from "./../../../../../framework/react/components/Spinner";

class DataRefreshView extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div className="data-message-wrapper flex-center" autoid={AutoIds.VERIFICATION_DATA_STEPPER_CONTAINER}>
                <Spinner
                    id="data-spinner"
                    size="lg"
                    color={this.props.currentProvider.hexCode2}
                    circleColor='#ffffff'
                    class="data-spinner"
                    children={
                        <div id="data-refresh-label" className="data-refresh-label">
                            {getString(AppStrings.VERIFICATION_DATA_STEPPER_TEXT)}
                        </div>
                    }
                />
            </div>

        );
    }

}

export default DataRefreshView;