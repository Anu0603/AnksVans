import React, { Component } from 'react'
import { connect } from 'react-redux'
import AppConstants from '@fastlinkRoot/conf/constants/AppConstants'
import CDVErrorView from './CDVErrorView'
import CDVInvokeView from './CDVInvokeView'
import Utility from './../utils/Utility'
import CDVInitiateView from './CDVInitiateView'
import CDVCompleteView from './CDVCompleteView'

// const CDVInitiateView = React.lazy(() => import("./CDVInitiateView"));
// const CDVCompleteView = React.lazy(() => import("./CDVCompleteView"));

class CDVBaseView extends Component {
	constructor(props) {
		super(props)

		this.state = {
			path: Utility.isCDVEnabled()
				? props.path
				: AppConstants.CDV_PATH_INVALID
		}
	}

	renderCDVView() {
		let _cdvView = null
		let _path = this.state.path

		switch (_path) {
			case AppConstants.CDV_PATH_INVOKE:
				_cdvView = <CDVInvokeView {...this.props} />
				break

			case AppConstants.CDV_PATH_INITIATE:
				_cdvView = <CDVInitiateView {...this.props} />
				break

			case AppConstants.CDV_PATH_COMPLETE:
				_cdvView = <CDVCompleteView {...this.props} />
				break

			default:
				_cdvView = (
					<CDVErrorView errorCode={AppConstants.ERROR_TECH_DIFF} />
				)
				break
		}
		return _cdvView
	}

	render() {
		return <React.Fragment>{this.renderCDVView()}</React.Fragment>
	}
}

const mapStateToProps = state => {
	return {
		deeplinkData: state.deeplink
	}
}

export default connect(mapStateToProps, null)(CDVBaseView)
