import React from 'react'
import SiteSelectionView from './../../views/SiteSelectionView'
import ProviderData from '../__mocks__/provider'
import { store } from './../../../../../../framework/react/store/store'
import ProviderService from '../../../../services/provider/ProviderService'
import { getParam } from '../../../../conf'

jest.mock('./../../../../conf')
jest.mock('./../../../../services/provider/ProviderService')

describe('Landing View', () => {
	let container = null

	beforeEach(() => {
		container = null

		ProviderService.getPopularProviders.mockImplementation(
			(_options, _callback) => {
				_callback(null, ProviderData)
			}
		)

		ProviderService.getSearchProviders.mockImplementation(
			(_options, _callback) => {
				_callback(null, ProviderData)
			}
		)

		getParam.mockImplementation(_key => {
			if (
				_key == 'enable_real_estate' ||
				_key == 'enable_manual_account'
			) {
				return true
			}
		})

		container = mount(<SiteSelectionView store={store} />)
	})

	it('Check whether landing View rendered', () => {
		act(() => {
			expect(container.find('div.landing-module')).toHaveLength(1)
		})
	})

	it('Check whether navigateToSite method invoked', () => {
		act(() => {
			container
				.find('ul .site-card')
				.first()
				.simulate('click')
		})
	})

	it('Check whether navigateToSite method invoked', () => {
		act(() => {
			const textField = container.find('.search-bar-cnr input')
			textField.simulate('change', { target: { value: 'bank' } })
		})
	})

	it('Check whether navigateToRealEstate method invoked', () => {
		act(() => {
			container.find('ul .real-estate-card').simulate('click')
		})
	})

	it('Check whether navigateToManualAccounts method invoked', () => {
		act(() => {
			container.find('ul .manual-card').simulate('click')
		})
	})
})
