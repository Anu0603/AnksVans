import React from 'react'
import classNames from 'classnames'
import PropTypes from 'prop-types'

import AccountWithDelete from './AccountWithDelete'
import AccountWithSelection from './AccountWithSelection'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../conf'
import AppConstants from '../../../../conf/constants/AppConstants'

const propTypes = {
	list: PropTypes.array,
	classes: PropTypes.string,
	title: PropTypes.string,
	deleteCallback: PropTypes.func
}
const defaultProps = {
	list: [],
	classes: '',
	title: '',
	deleteCallback: PropTypes.func
}

export const AccountList = props => {
	const {
		list,
		classes,
		title,
		deleteCallback,
		selectionOnChange,
		accountLength
	} = props

	const classList = classNames(classes, 'list')

	let getProductTypeAccount = (index, item) => {
		switch (getParam(AppParams.PRODUCT_TYPE)) {
			case AppConstants.VERIFICATION_FLOW_NAME:
				return (
					<AccountWithSelection
						{...item}
						accountLength={accountLength}
						classList={classList}
						currentProvider={props.currentProvider}
						selectionOnChange={selectionOnChange}
					/>
				)
			/* Description: The below case is to handle the account view to be rendered with selection checkbox or the delete trash icon.
			 */
			case AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME:
				if (props.appflow === AppConstants.APP_FLOW_VERIFICATION) {
					return (
						<AccountWithSelection
							{...item}
							accountLength={accountLength}
							classList={classList}
							currentProvider={props.currentProvider}
							selectionOnChange={selectionOnChange}
						/>
					)
				} else {
					/* Description: The disabled prop is sent to disable the checkbox for the already selected account on the aggregation screen.
					 */
					return item.checked ? (
						<AccountWithSelection
							{...item}
							disabled={item.checked}
							accountLength={accountLength}
							classList={classList}
							currentProvider={props.currentProvider}
							selectionOnChange={selectionOnChange}
						/>
					) : (
						<AccountWithDelete
							{...item}
							classList={classList}
							currentProvider={props.currentProvider}
							deleteCallback={deleteCallback}
						/>
					)
				}
			default:
				return (
					<AccountWithDelete
						{...item}
						classList={classList}
						currentProvider={props.currentProvider}
						deleteCallback={deleteCallback}
					/>
				)
		}
	}

	return (
		<div
			className="account-list-summary"
			autoid={AutoIds.ACCOUNT_SUMMARY_LABEL_PARTIAL + title}
		>
			<div className="list-header">
				{getString(
					AppStrings.ACCOUNT_SUMMARY_TITLE_CONTAINER_PARTIAL +
						title.toLowerCase()
				) || title}
			</div>
			<ul className="lists">
				{list.map((item, i) => (
					<li className={classList} key={'list' + i}>
						{getProductTypeAccount(i, item)}
					</li>
				))}
			</ul>
		</div>
	)
}
AccountList.propTypes = propTypes
AccountList.defaultProps = defaultProps
