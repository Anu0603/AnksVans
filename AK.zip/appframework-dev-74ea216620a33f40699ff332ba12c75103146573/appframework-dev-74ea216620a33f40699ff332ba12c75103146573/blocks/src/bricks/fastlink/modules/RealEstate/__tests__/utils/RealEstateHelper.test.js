import RealEstateHelper from '../../helper/RealEstateHelper'
import data from '../__mocks__/landingViewState'
import { getString } from '../../../../../fastlink/conf'

jest.mock('../../../../../fastlink/conf')

getString.mockImplementation(_key => {
	switch (_key) {
		case 'currency_usd':
			return 'United States Dollar (USD)'

			break
	}
})

describe('Real Estate Helper Module', () => {
	let stateData

	beforeEach(() => {
		stateData = { state: { ...data.state } }
	})

	it('Build data Object for System', () => {
		stateData.state.valuationType = 'system'
		const dataOb = RealEstateHelper.buildDataObj.bind(stateData)()

		expect(dataOb).toMatchObject({
			address: {
				street: 'xyz',
				zip: '123',
				city: 'xyz',
				state: 'xyz'
			},
			includeInNetWorth: 'TRUE',
			accountName: 'qwe',
			valuationType: 'SYSTEM'
		})
	})
	it('Build data Object for System when city state and zip are empty', () => {
		stateData.state.valuationType = 'system'
		stateData.state.city = ''
		stateData.state.stateName = ''
		stateData.state.zip = ''
		const dataOb = RealEstateHelper.buildDataObj.bind(stateData)()

		expect(dataOb).toMatchObject({
			address: {
				street: 'xyz'
			},
			includeInNetWorth: 'TRUE',
			accountName: 'qwe',
			valuationType: 'SYSTEM'
		})
	})

	it('Build data Object for Manual', () => {
		const dataOb = RealEstateHelper.buildDataObj.bind(stateData)()

		expect(dataOb).toMatchObject({
			homeValue: {
				amount: '123',
				currency: 'USD'
			},
			includeInNetWorth: 'TRUE',
			accountName: 'qwe',
			valuationType: 'MANUAL'
		})
	})
	it('should return valuation type ', () => {
		let disableManual = false
		let disableSystem = false
		const valuationType = RealEstateHelper.getValuationType(
			disableManual,
			disableSystem
		)
		expect(valuationType).toEqual('system')
	})

	it('should return valuation type ', () => {
		let disableManual = false
		let disableSystem = true
		const valuationType = RealEstateHelper.getValuationType(
			disableManual,
			disableSystem
		)
		expect(valuationType).toEqual('manual')
	})

	it('Should get currency options', () => {
		const currencyOption = RealEstateHelper.getCurrencyDropdownOptions([
			'USD'
		])

		expect(currencyOption).toMatchObject([
			{
				displayText: 'United States Dollar (USD)',
				optionValue: 'USD'
			}
		])
	})
})
