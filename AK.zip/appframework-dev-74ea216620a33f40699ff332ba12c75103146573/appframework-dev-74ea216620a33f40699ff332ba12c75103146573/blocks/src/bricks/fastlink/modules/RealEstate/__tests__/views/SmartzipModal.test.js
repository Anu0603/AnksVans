import React from 'react'
import SmartzipModal from '../../views/SmartzipModal'
import { getString } from '../../../../conf/utilities/Utilities'
jest.mock('../../../../conf/utilities/Utilities')
const onClickMock = jest.fn()
const onCrossIconClick = jest.fn()

describe('Smartzip Modal Test ', () => {
	let container = null
	const modalRoot = global.document.createElement('div')
	modalRoot.setAttribute('id', 'modal-root')
	const body = global.document.querySelector('body')
	body.appendChild(modalRoot)

	getString.mockImplementation(() => '')

	beforeEach(() => {
		container = null
	})

	it('Check whether Modal Rendered', () => {
		act(() => {
			container = mount(
				<SmartzipModal
					showHidePopUp={onClickMock}
					onCrossIconClick={onCrossIconClick}
				/>
			)
		})

		expect(container.find('.modal-content')).toHaveLength(1)
	})

	it('Simulate cross button click', () => {
		act(() => {
			container = mount(
				<SmartzipModal
					showHideSmartzipPopup={onClickMock}
					onCrossIconClick={onCrossIconClick}
				/>
			)
		})
		container.find('#header-close-btn-container').simulate('click')
		expect(onClickMock).toBeCalled()
	})

	it('Simulate Cancel button click', () => {
		act(() => {
			container = mount(
				<SmartzipModal
					showHideSmartzipPopup={onClickMock}
					onCrossIconClick={onCrossIconClick}
				/>
			)
		})
		container
			.find('#exit')
			.children(0)
			.simulate('click')
		expect(onClickMock).toBeCalled()
	})

	it('Simulate  backdrop click', () => {
		act(() => {
			container = mount(
				<SmartzipModal
					showHideSmartzipPopup={onClickMock}
					onCrossIconClick={onCrossIconClick}
				/>
			)
		})
		container.find('.backDrop').simulate('click')

		expect(onClickMock).toBeCalled()
	})

	it('Simulate  backdrop click', () => {
		act(() => {
			container = mount(
				<SmartzipModal
					showHideSmartzipPopup={onClickMock}
					onCrossIconClick={onCrossIconClick}
				/>
			)
		})
		container
			.find('#continue-smartzip')
			.hostNodes()
			.simulate('click')

		expect(onClickMock).toBeCalled()
	})
})
