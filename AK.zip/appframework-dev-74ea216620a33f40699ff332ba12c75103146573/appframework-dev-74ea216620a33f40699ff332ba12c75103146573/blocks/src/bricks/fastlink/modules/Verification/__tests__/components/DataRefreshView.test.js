import React from 'react'
import DataRefreshView from '../../components/DataRefreshView'

import { getString } from '../../../../conf'
jest.mock('../../../../conf')

describe('Data Refresh View Section', () => {
	let container = null

	beforeEach(() => {
		container = null
	})
	let props = { currentProvider: { hexCode2: '#454545' } }

	it('Check if Data Refresh View is rendered', () => {
		act(() => {
			container = shallow(<DataRefreshView {...props} />)
		})
		expect(container.find('.data-message-wrapper')).toHaveLength(1)
	})

	it('Check if spinner is rendered', () => {
		act(() => {
			container = mount(<DataRefreshView {...props} />)
		})
		expect(container.find('.spinner')).toHaveLength(1)
	})

	it('Check if spinner text is shown', () => {
		let text = 'Retrieving Data...'
		act(() => {
			getString.mockImplementation(_key => {
				if (_key == 'verification_data_stepper_text') {
					return text
				}
				return ''
			})
			container = mount(<DataRefreshView {...props} />)
		})

		expect(container.find('.data-refresh-label').text()).toEqual(text)
	})
})
