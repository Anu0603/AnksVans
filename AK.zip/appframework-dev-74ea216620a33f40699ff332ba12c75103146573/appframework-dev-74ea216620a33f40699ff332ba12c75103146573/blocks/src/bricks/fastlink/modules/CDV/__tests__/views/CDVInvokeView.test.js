import React from 'react'
import CDVInvokeView from './../../views/CDVInvokeView'
import ProviderData from './../__mocks__/provider'
import AppConstants from '../../../../conf/constants/AppConstants'

jest.mock('./../../../../../../framework/react/components/Modal')

describe.only('CDV Invoke View', () => {
	let container = null
	beforeEach(() => {
		container = null
	})

	let renderComponent = props => {
		container = mount(
			<CDVInvokeView {...props} currentProvider={ProviderData.provider} />
		)
	}

	it('Check whether CDV Pre Invoke View is rendered for default sub path', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('div.cdv-invoke-pre-ver-content')).toHaveLength(1)
	})

	it('Check whether CDV Pre Invoke View is rendered for pre sub path', () => {
		act(() => {
			renderComponent({
				subPath: AppConstants.CDV_SUB_PATH_INVOKE_PRE_VERIFICATION
			})
		})
		expect(container.find('div.cdv-invoke-pre-ver-content')).toHaveLength(1)
	})

	it('Check whether CDV Post Invoke View is rendered for post sub path', () => {
		act(() => {
			renderComponent({
				subPath: AppConstants.CDV_SUB_PATH_INVOKE_POST_VERIFICATION
			})
		})
		expect(container.find('div.cdv-invoke-post-ver-content')).toHaveLength(
			1
		)
	})

	it('Check whether CDV Pre Invoke View is rendered for invalid sub path', () => {
		act(() => {
			renderComponent({
				subPath: 'SOMETHING'
			})
		})
		expect(container.find('div.cdv-invoke-pre-ver-content')).toHaveLength(1)
	})

	it('Check whether Initiate CDV invokes successfully', () => {
		let isInitiateFlow = false
		act(() => {
			renderComponent({
				navigate: function() {
					isInitiateFlow = false
				}
			})
		})
		expect(isInitiateFlow).toEqual(false)
		container
			.find('div.cdv-invoke-pre-ver-content')
			.children('.btn-wrapper')
			.find('.enter-btn')
			.simulate('click')
		setTimeout(function() {
			expect(isInitiateFlow).toEqual(true)
		}, 100)
	})
})
