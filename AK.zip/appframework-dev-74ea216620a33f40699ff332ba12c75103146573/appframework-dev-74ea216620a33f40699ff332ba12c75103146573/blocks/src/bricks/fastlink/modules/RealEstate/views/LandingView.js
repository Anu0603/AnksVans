import React, { Component } from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import { TextField } from '../../../../../framework/react/components/InputField'
import { Button } from '../../../../../framework/react/components/Button'
import { Radio } from './../../../../../framework/react/components/RadioButton'
import Dropdown from './../../../../../framework/react/components/Dropdown'
import RealEstateService from '../../../services/account/RealEstateService'
import AccountsService from '../../../services/account/AccountsService'
import CONSTANTS from './../../../router/Constant'
import { Toggle } from '../../../../../framework/react/components/ToggleButton'
import DeleteModal from './DeleteModal'
import { Spinner } from '../../../../../framework/react/components/Spinner'
import ErrorBanner from './../../../components/Error/ErrorBanner'
import ErrorContent from './../../../components/Error/ErrorContent'
import {
	AppStrings,
	getString,
	AppParams,
	getParam
} from '../../../../fastlink/conf'
import SmartzipModal from './SmartzipModal'
import realEstateHelper from '../helper/RealEstateHelper'
class LandingView extends Component {
	constructor(props) {
		super(props)
		this.isDeeplink = this.props.deeplinkData.isDeeplink
		this.editAccount = this.props.data.editAccount
		this.state = {
			editmode: this.props.data.isEdit ? true : false,
			multiAddress: [],
			selectedAddressIndex: 0,
			valuationType: !this.editAccount
				? realEstateHelper.getValuationType(
						getParam(AppParams.DISABLE_REALESTATE_MANUAL),
						getParam(AppParams.DISABLE_REALESTATE_SYSTEM)
				  )
				: this.editAccount.valuationType.toLowerCase(),
			accountName: !this.editAccount ? '' : this.editAccount.accountName,
			addressLine1: this.editAccount
				? this.editAccount.address
					? this.editAccount.address.street.toLowerCase()
					: ''
				: '',
			city: this.editAccount
				? this.editAccount.address
					? this.editAccount.address.city.toLowerCase()
					: ''
				: '',
			stateName: this.editAccount
				? this.editAccount.address
					? this.editAccount.address.state.toLowerCase()
					: ''
				: '',
			zip: this.editAccount
				? this.editAccount.address
					? this.editAccount.address.zip
					: ''
				: '',
			amount: !this.editAccount
				? ''
				: this.editAccount.homeValue
				? this.editAccount.homeValue.amount.toString()
				: '',
			currencyOptions: realEstateHelper
				.getCurrencyDropdownOptions(
					getParam(AppParams.SUPPORTED_CURRENCY)
				)
				.map((item, index) => {
					let option = {
						optionValue: item.optionValue,
						displayText: item.displayText,
						selected: item.optionValue == 'USD' ? true : false
					}
					return option
				}),
			currency: !this.editAccount
				? 'USD'
				: this.editAccount.homeValue
				? this.editAccount.homeValue.currency
				: 'USD',
			showDeleteCnfPopup: false,
			showSmartZipPopup: false,
			includeInNetWorth: this.editAccount
				? this.editAccount.includeInNetWorth
				: true,
			showSpinner: true,
			showSpinnerMessage: false,
			showErrorBanner: false,
			submitButonText: this.editAccount
				? getString(AppStrings.REAL_ESTATE_SUBMIT_BUTTON_TEXT)
				: getString(AppStrings.NEXT_BUTTON_TEXT),
			errorReason: '',
			errorStatus: '',
			errors: {
				addressLine1: '',
				city: '',
				stateName: '',
				zip: '',
				amount: '',
				accountName: ''
			}
		}
		this.errors = {
			amountError: '',
			accountNameError: '',
			streetError: '',
			cityError: '',
			stateNameError: '',
			zipError: ''
		}
		this.realEstateService = new RealEstateService()
		this.accountId
		this.disableManual = getParam(AppParams.DISABLE_REALESTATE_MANUAL)
		this.disableSystem = getParam(AppParams.DISABLE_REALESTATE_SYSTEM)
		this.showApiErrors.bind()

		this.keepOrEditAddress = false
	}

	static propTypes = {
		valuationType: PropTypes.string,
		accountName: PropTypes.string
	}

	// static defaultProps = {
	//     valuationType: 'system',
	//     accountName: ''
	// }

	componentDidMount() {
		// this condition should be false while coming from success screen
		if (this.isDeeplink && !this.editAccount) {
			let isEdit =
				this.props.deeplinkData.deeplinkType === 'EDIT_REAL_ESTATE'
					? true
					: false
			if (isEdit) {
				const { accountId } = this.props.data
				this.accountId = accountId
				this.setState({ editmode: true })
				this.realEstateService.getRealEstate({ id: accountId }).then(
					resp => {
						this.editAccount = resp.account[0]
						// const accountDetails = resp.account[0]
						realEstateHelper.parseResponse.call(
							this,
							this.editAccount
						)
						this.setState({ ...this.state, ...this.editAccount })
						this.setState({
							showSpinner: false,
							submitButonText: getString(
								AppStrings.REAL_ESTATE_SUBMIT_BUTTON_TEXT
							)
						})
					},
					() => {
						this.setState({ showSpinner: false })
						this.props.handleTechDiff()
					}
				)
			} else {
				this.setState({ showSpinner: false })
			}
		} else {
			this.setState({ showSpinner: false })
			const accountData = this.editAccount
			if (this.state.editmode) {
				if (accountData.valuationType === 'MANUAL') {
					this.setState({
						currencyOptions: this.state.currencyOptions.map(
							item => {
								item.selected =
									item.optionValue ===
									accountData.homeValue.currency
										? true
										: false
								return item
							}
						)
					})
				}
				this.accountId = accountData.id
			}
		}
	}

	updateAccountName(e) {
		this.setState({
			accountName: e.target.value
		})
	}
	updateAmount(e) {
		const { name, value } = e.target
		this.setState({ amount: value })
	}

	handleCaluclationTypeChange(e) {
		this.setState({
			...this.state,
			valuationType: e.target.value
		})
	}
	updateAddressLine1(e) {
		const { name, value } = e.target
		this.setState({
			addressLine1: value
		})
	}

	handleCurrencyChange(e, option) {
		option.value.optionValue !== this.state.currency &&
			this.setState({ currency: option.value.optionValue })
	}

	showApiErrors(err) {
		let error
		if (err.details.errorCode === 'Y862') {
			error = 'REAL_ESTATE_ADDRESS_NOT_FOUND'
			this.setState({
				showErrorBanner: true,
				errorReason: error,
				errorStatus: error
			})
		}

		if (err.details.errorCode === 'Y811') {
			error = 'REAL_ESTATE_VALUE_ALREADY_ADDED'
			this.setState({
				showErrorBanner: true,
				errorReason: '',
				errorStatus: error
			})
		}
	}

	submitEdit() {
		let data = realEstateHelper.buildDataObj.bind(this)()
		if (this.state.valuationType === 'manual') {
			data.accountId = this.accountId
			this.realEstateService.editRealEstate(data).then(
				() => {
					this.setState({ showSpinner: false })
					this.props.onDelete(this.accountId)
					this.props.showNextView('RE_SUCCESS', {
						id: this.accountId,
						accountName: this.state.accountName
					})
				},
				err => {
					this.setState({
						showSpinner: false,
						showSpinnerMessage: false
					})
					console.log('Error while editing account', err)
					this.showApiErrors(err)
				}
			)
		} else {
			this.realEstateService.evaluateAddress(data).then(resp => {
				if (resp.isValidAddress) {
					if (resp.address.length > 1 && resp.address.length <= 2) {
						this.showMultipleAddressMatches(resp.address)
					}

					if (resp.address.length === 1) {
						data.accountId = this.accountId
						this.realEstateService.editRealEstate(data).then(
							() => {
								this.setState({ showSpinner: false })
								this.props.onDelete(this.accountId)
								this.props.showNextView('RE_SUCCESS', {
									id: this.accountId,
									accountName: this.state.accountName
								})
							},
							err => {
								this.setState({
									showSpinner: false,
									showSpinnerMessage: false
								})
								console.log('Error while editing account', err)
								this.showApiErrors(err)
							}
						)
					}

					if (resp.address.length > 2) {
						this.setState({
							showSpinner: false,
							showSpinnerMessage: false,
							showErrorBanner: false,
							errorReason: 'REAL_ESTATE_ERROR_SEARCH_AGAIN'
						})
					}
				} else {
					this.setState({
						showSpinner: false,
						showSpinnerMessage: false,
						showErrorBanner: true,
						errorReason: 'REAL_ESTATE_ADDRESS_NOT_FOUND',
						errorStatus: 'REAL_ESTATE_ADDRESS_NOT_FOUND'
					})
				}
			})
		}
	}

	showMultipleAddressMatches(addresses) {
		this.setState({
			multiAddress: addresses,
			selectedAddressIndex: 0,
			showSpinner: false,
			showErrorBanner: false,
			showSpinnerMessage: false,
			errorReason: 'REAL_ESTATE_ERROR_MULTIPLE_MATCHES_FOUND'
		})
		this.keepOrEditAddress = false
	}

	evaluateAddress(callback) {
		let data = realEstateHelper.buildDataObj.bind(this)()
		this.realEstateService.evaluateAddress(data).then(
			resp => {
				if (resp.isValidAddress) {
					if (resp.address.length > 1 && resp.address.length <= 2) {
						this.showMultipleAddressMatches(resp.address)
					}

					if (resp.address.length === 1) {
						this.realEstateService.addRealEstate(data).then(
							resp => {
								resp.account[0].accountName = this.state.accountName
								if (this.state.editmode) {
									callback(resp.account[0])
								} else {
									this.setState({ showSpinner: false })
									this.accountId = resp.account[0].id
									this.props.showNextView('RE_SUCCESS', {
										id: this.accountId,
										accountName: this.state.accountName
									})
								}
							},
							err => {
								if (err) {
									this.setState({ showSpinner: false })
									console.log(
										'Error while adding account',
										err
									)
									this.showApiErrors(err)
								}
							}
						)
					}

					if (resp.address.length > 2) {
						this.setState({
							showSpinner: false,
							showErrorBanner: false,
							errorReason: 'REAL_ESTATE_ERROR_SEARCH_AGAIN'
						})
					}
				} else {
					this.setState({
						showSpinner: false,
						showErrorBanner: true,
						errorReason: 'REAL_ESTATE_ADDRESS_NOT_FOUND',
						errorStatus: 'REAL_ESTATE_ADDRESS_NOT_FOUND'
					})
				}
			},
			error => {}
		)
	}

	handleAdd(callback) {
		if (this.keepOrEditAddress) {
			this.setState({
				multiAddress: []
			})
		}
		if (this.state.valuationType === 'system') {
			this.evaluateAddress(callback)
		} else {
			let data = realEstateHelper.buildDataObj.bind(this)()
			this.realEstateService.addRealEstate(data).then(
				resp => {
					resp.account[0].accountName = this.state.accountName
					if (this.state.editmode) {
						callback(resp.account[0])
					} else {
						this.setState({ showSpinner: false })
						this.accountId = resp.account[0].id
						this.props.showNextView('RE_SUCCESS', {
							id: this.accountId,
							accountName: this.state.accountName
						})
					}
				},
				err => {
					if (err) {
						this.setState({
							showSpinner: false,
							showSpinnerMessage: false
						})
						console.log('Error while adding account', err)
						this.showApiErrors(err)
					}
				}
			)
		}
	}

	isFormValid() {
		return this.state.valuationType === 'manual'
			? realEstateHelper.validateManualAccountFields.bind(this)()
			: realEstateHelper.validateAutomaticFields.bind(this)()
	}
	/**
	 * In case of valuation type change on Edit accout, the API does not support that.
	 * So this function adds a new account and then deletes the previous account.
	 */
	addAccountForValuationChange() {
		this.handleAdd(accountData => {
			new AccountsService()
				.deleteAccount({ accountId: this.accountId })
				.then(
					() => {
						this.props.onDelete(this.accountId)
						this.props.showNextView('RE_SUCCESS', {
							id: accountData.id,
							accountName: accountData.accountName
						})
					},
					() => {
						this.setState({ showSpinner: false })
					}
				)
		})
	}

	handleEdit() {
		if (this.keepOrEditAddress) {
			this.setState({
				multiAddress: []
			})
		}
		if (
			this.state.valuationType !==
			this.editAccount.valuationType.toLowerCase()
		) {
			if (this.state.valuationType === 'system') {
				let data = {}
				data.address = {
					street: this.state.addressLine1,
					zip: this.state.zip ? this.state.zip : undefined,
					city: this.state.city ? this.state.city : undefined,
					state: this.state.stateName
						? this.state.stateName
						: undefined
				}
				this.realEstateService.evaluateAddress(data).then(
					resp => {
						if (resp.isValidAddress) {
							this.addAccountForValuationChange()
						} else {
							this.setState({
								showSpinner: false,
								showSpinnerMessage: false,
								showErrorBanner: true,
								errorReason: 'REAL_ESTATE_ADDRESS_NOT_FOUND',
								errorStatus: 'REAL_ESTATE_ADDRESS_NOT_FOUND'
							})
						}
					},
					() => {
						this.setState({
							showSpinner: false,
							showSpinnerMessage: false,
							showErrorBanner: true,
							errorReason: '',
							errorStatus: ''
						})
					}
				)
			} else {
				this.addAccountForValuationChange()
			}
		} else {
			this.submitEdit()
		}
	}

	handleSubmit() {
		if (this.isFormValid()) {
			this.setState({ errors: {} })
			this.setState({ showSpinner: true })
			if (this.state.valuationType === 'system') {
				this.setState({ showSpinnerMessage: true })
			}
			if (!this.state.editmode) {
				this.handleAdd()
			} else {
				this.handleEdit()
			}
		} else {
			realEstateHelper.displayErrors.bind(this)()
		}
	}

	handleDelete(e) {
		new AccountsService().deleteAccount({ accountId: this.accountId }).then(
			() => {
				this.setState({ showDeleteCnfPopup: false })
				this.props.onDelete(this.accountId)
				if (this.isDeeplink) {
					this.props.handleCloseAppHandler(e)
				} else {
					this.props.navigate(CONSTANTS.ROUTE_LANDING_MODULE)
				}
			},
			error => {
				console.log('error occured while deleting', error)
				this.setState({
					showDeleteCnfPopup: false,
					errorReason: 'REAL_ESTATE_UNABLE_TO_DELETE',
					errorStatus: 'REAL_ESTATE_UNABLE_TO_DELETE',
					showErrorBanner: true
				})
			}
		)
	}

	showHideSmartzipPopup = flag => {
		this.setState({ showSmartZipPopup: flag })
	}

	handleAddressSelect(e, index) {
		if (index === undefined) {
			this.keepOrEditAddress = true
		} else {
			this.setState({ selectedAddressIndex: index })
			this.keepOrEditAddress = false
		}
	}

	render() {
		return (
			<div className="section-container">
				{this.state.showSmartZipPopup && (
					<SmartzipModal
						showHideSmartzipPopup={flag => {
							this.showHideSmartzipPopup(flag)
						}}
					/>
				)}
				{this.state.showDeleteCnfPopup && (
					<DeleteModal
						showHidePopUp={flag => {
							this.setState({ showDeleteCnfPopup: flag })
						}}
						handleDelete={this.handleDelete.bind(this)}
						accountName={this.state.accountName}
					/>
				)}
				{this.state.showSpinner ? (
					<Spinner id="largeSpinner" size="lg">
						{this.state.valuationType == 'system' &&
							this.state.showSpinnerMessage && (
								<div className="real-estate-refresh-label">
									{getString(
										AppStrings.REAL_ESTATE_SPINNER_MESSAGE_TEXT
									)}
								</div>
							)}
					</Spinner>
				) : (
					<div>
						<div className="realEstateWrapper section-header">
							{!this.state.editmode ? (
								<div className="title">
									{getString(
										AppStrings.REAL_ESTATE_ADD_ACCOUNT_TITLE
									)}
								</div>
							) : (
								<div className="title">
									{getString(
										AppStrings.REAL_ESTATE_EDIT_ACCOUNT_TITLE
									)}
								</div>
							)}
						</div>
						{this.state.showErrorBanner && !this.state.showSpinner && (
							<React.Fragment>
								<ErrorBanner
									errorCode={this.state.errorStatus}
								/>
								{/* <ErrorContent
									errorCode={this.state.errorStatus}
								/> */}
							</React.Fragment>
						)}
						{this.state.errorReason && (
							<React.Fragment>
								<ErrorContent
									errorCode={this.state.errorReason}
								/>
							</React.Fragment>
						)}

						<div className="form-content">
							{this.state.multiAddress &&
								this.state.multiAddress.map(
									(addressOb, index) => {
										let address = `${addressOb.street}, ${addressOb.city}, ${addressOb.state}, ${addressOb.zip}`
										return (
											<Radio
												name="multi-match-addresses"
												id={'option-address' + index}
												key={'option-address-' + index}
												label={address}
												checked={
													index ==
													this.state
														.selectedAddressIndex
														? true
														: false
												}
												value={addressOb.street}
												onChange={e => {
													this.handleAddressSelect(
														e,
														index
													)
												}}
											/>
										)
									}
								)}
							{this.state.multiAddress.length > 0 && (
								<Radio
									id="keep-address"
									name="multi-match-addresses"
									checked={false}
									onChange={e => {
										this.handleAddressSelect(e)
									}}
									label={
										'Keep or edit previously entered address'
									}
								/>
							)}
							<TextField
								id="accountname-input"
								name="account-name-input"
								placeholder={getString(
									AppStrings.REAL_ESTATE_REAL_ESTATE_NAME
								)}
								value={this.state.accountName}
								maxLength={50}
								onChange={this.updateAccountName.bind(this)}
								label={
									this.state.editmode &&
									getString(
										AppStrings.REAL_ESTATE_REAL_ESTATE_NAME
									)
								}
								error={
									this.state.errors.accountName ? true : false
								}
								errorMessage={this.state.errors.accountName}
							/>
							{!this.disableManual && !this.disableSystem && (
								<div>
									<Radio
										id="option-system"
										name="calculation-type"
										value="system"
										label={getString(
											AppStrings.REAL_ESTATE_CALCULATE_AUTO
										)}
										secondaryLabel={getString(
											AppStrings.REAL_ESTATE_CALCULATE_AUTO_DESC
										)}
										onChange={this.handleCaluclationTypeChange.bind(
											this
										)}
										checked={
											this.state.valuationType ===
											'system'
												? true
												: false
										}
									/>
									<Radio
										id="option-manual"
										name="calculation-type"
										value="manual"
										label={getString(
											AppStrings.REAL_ESTATE_ENTER_MANUALLY
										)}
										secondaryLabel={getString(
											AppStrings.REAL_ESTATE_ENTER_MANUALLY_DESC
										)}
										onChange={this.handleCaluclationTypeChange.bind(
											this
										)}
										checked={
											this.state.valuationType ===
											'manual'
												? true
												: false
										}
									/>
								</div>
							)}

							{((this.disableManual &&
								!this.disableSystem &&
								this.state.valuationType === 'system') ||
								(!this.disableManual &&
									!this.disableSystem &&
									this.state.valuationType === 'system')) && (
								<div>
									<TextField
										id="street-input"
										placeholder={getString(
											AppStrings.REAL_ESTATE_STREET_ADDRESS_LABEL
										)}
										value={this.state.addressLine1}
										onChange={this.updateAddressLine1.bind(
											this
										)}
										name="street-address-input"
										label={
											this.state.editmode &&
											getString(
												AppStrings.REAL_ESTATE_STREET_ADDRESS_LABEL
											)
										}
										error={
											this.state.errors.addressLine1
												? true
												: false
										}
										errorMessage={
											this.state.errors.addressLine1
										}
									/>

									<TextField
										id="city-input"
										name="city-input"
										placeholder={getString(
											AppStrings.REAL_ESTATE_CITY_LABEL
										)}
										value={this.state.city}
										onChange={e => {
											this.setState({
												city: e.target.value
											})
										}}
										label={
											this.state.editmode &&
											getString(
												AppStrings.REAL_ESTATE_CITY_LABEL
											)
										}
										error={
											this.state.errors.city
												? true
												: false
										}
										errorMessage={this.state.errors.city}
									/>
									<TextField
										id="state-input"
										name="state-input"
										placeholder={getString(
											AppStrings.REAL_ESTATE_STATE_LABEL
										)}
										value={this.state.stateName}
										onChange={e => {
											this.setState({
												stateName: e.target.value
											})
										}}
										label={
											this.state.editmode &&
											getString(
												AppStrings.REAL_ESTATE_STATE_LABEL
											)
										}
										error={
											this.state.errors.stateName
												? true
												: false
										}
										errorMessage={
											this.state.errors.stateName
										}
									/>
									<TextField
										id="zip-input"
										name="zip-input"
										placeholder={getString(
											AppStrings.REAL_ESTATE_ZIP_LABEL
										)}
										value={this.state.zip}
										onChange={e => {
											this.setState({
												zip: e.target.value
											})
										}}
										label={
											this.state.editmode &&
											getString(
												AppStrings.REAL_ESTATE_ZIP_LABEL
											)
										}
										error={
											this.state.errors.zip ? true : false
										}
										errorMessage={this.state.errors.zip}
									/>
								</div>
							)}
							{((this.disableSystem &&
								!this.disableManual &&
								this.state.valuationType === 'manual') ||
								(!this.disableSystem &&
									!this.disableManual &&
									this.state.valuationType === 'manual')) && (
								<div>
									<Dropdown
										name="currency-dropdown"
										options={this.state.currencyOptions}
										showSelectedMark={true}
										labelText={getString(
											AppStrings.CURRENCY_LABEL
										)}
										htmlId="test-dropdown"
										onChange={this.handleCurrencyChange.bind(
											this
										)}
									/>

									<TextField
										id="value-input"
										name="value-input"
										placeholder={getString(
											AppStrings.REAL_ESTATE_ESTIMATED_VALUE_LABEL
										)}
										label={
											this.state.editmode &&
											getString(
												AppStrings.REAL_ESTATE_ESTIMATED_VALUE_LABEL
											)
										}
										value={this.state.amount.toString()}
										onChange={this.updateAmount.bind(this)}
										error={
											this.state.errors.amount
												? true
												: false
										}
										errorMessage={this.state.errors.amount}
									/>
								</div>
							)}

							<Toggle
								name="toggle-button"
								id="toggle-button"
								label={getString(
									AppStrings.REAL_ESTATE_INCLUDE_NET_WORTH_LABEL
								)}
								disabled={false}
								checked={this.state.includeInNetWorth}
								onChange={e => {
									this.setState({
										includeInNetWorth: e.target.checked
									})
								}}
							/>

							<div className="btn-wrapper">
								<Button
									variant="primary"
									label={this.state.submitButonText}
									fullWidth
									onClick={this.handleSubmit.bind(this)}
								/>

								{this.state.editmode && (
									<div>
										<Button
											variant="danger"
											reversed={true}
											label={getString(
												AppStrings.REAL_ESTATE_DELETE_ACCOUNT_BUTTON_TEXT
											)}
											fullWidth
											onClick={() =>
												this.setState({
													showDeleteCnfPopup: true
												})
											}
										/>
									</div>
								)}
							</div>
						</div>
						{!this.disableSystem && (
							<div className="info-txt txt-center footer-pad">
								{getString(AppStrings.REAL_ESTATE_FOOTER_TEXT)}{' '}
								<a
									onClick={this.showHideSmartzipPopup.bind(
										true
									)}
									className="info-link"
								>
									{getString(
										AppStrings.REAL_ESTATE_SMARTZIP_FOOTER_TEXT
									)}
								</a>
							</div>
						)}
					</div>
				)}
			</div>
		)
	}
}

const mapStateToProps = state => {
	return {
		deeplinkData: state.deeplink
	}
}

const mapDispatchToProps = dispatch => {
	return {
		onDelete: accountID =>
			dispatch({
				type: 'REMOVE_REAL_ESTATE_ACCOUNT',
				payload: { accountID }
			})
	}
}

export default connect(mapStateToProps, mapDispatchToProps)(LandingView)
