import React, { Suspense } from 'react'
import { Provider } from 'react-redux'
import CDVBaseView from './../../views/CDVBaseView'
import Utility from './../../utils/Utility'
import { AppParams, getParam } from './../../../../conf'
import ProviderData from './../__mocks__/provider'
import configureStore from 'redux-mock-store'
import VerificationService from './../../../../services/cdv/VerificationService'

jest.mock('./../../utils/Utility')
jest.mock('./../../../../conf')
jest.mock('./../../../../../../framework/react/components/Modal')
jest.mock('./../../../../services/cdv/VerificationService')

const mockStore = configureStore([])

describe.only('CDV Base View', () => {
	let container = null
	beforeEach(() => {
		container = null

		Utility.isCDVEnabled.mockImplementation(() => {
			return true
		})

		getParam.mockImplementation(_key => {
			if (_key == AppParams.CDV_INITIATE_ACCOUNTTYPE_SELECTION) {
				return AppConstants.CDV_INITIATE_ACC_TYPE_CHECKING
			} else if (_key == AppParams.ERROR_DISCRIPTION_TOOLTIP) {
				return ['INCORRECT_CREDENTIALS']
			} else if (
				_key == AppParams.CDV_PRE_VERIFICATION_INVOKE_ENABLED_ERRORS
			) {
				return [
					'INCORRECT_CREDENTIALS',
					'ACCOUNT_LOCKED',
					'BETA_SITE_DEV_IN_PROGRESS',
					'SITE_BLOCKING_ERROR',
					'UNEXPECTED_SITE_ERROR',
					'SITE_UNAVAILABLE',
					'TECH_ERROR',
					'GENERIC',
					'DATASET_NOT_SUPPORTED',
					'VERIFICATION_FAILED'
				]
			} else if (
				_key == AppParams.CDV_POST_VERIFICATION_INVOKE_ENABLED_ERRORS
			) {
				return []
			} else if (_key == AppParams.ENABLE_CDV) {
				return true
			}
		})
	})

	let renderComponent = props => {
		VerificationService.mockImplementation(() => {
			return {
				getVerificationInfo: (_options, _callback) => {
					_callback(null, {
						verification: [
							{
								accountId: 12481712,
								verificationType: 'CHALLENGE_DEPOSIT',
								account: {
									accountNumber: '21320918309221321',
									accountType: 'SAVINGS',
									bankTransferCode: {
										id: '999999989',
										type: 'ROUTING_NUMBER'
									}
								},
								verificationStatus: 'DEPOSITED',
								providerAccountId: 11329462,
								verificationId: 10041437
							}
						]
					})
				}
			}
		})

		let deeplinkData = {
			isDeeplink: false,
			deeplinkData: null
		}

		let store = mockStore({
			currentProvider: ProviderData.provider,
			cdv: {
				verificationInfo: {}
			},
			deeplink: deeplinkData
		})
		container = mount(
			<Provider store={store}>
				<CDVBaseView
					{...props}
					currentProvider={ProviderData.provider}
					handleTechDiff={function() {}}
				/>
			</Provider>
		)
	}

	it('Check whether CDV Base View is rendered for Invoke flow', () => {
		act(() => {
			renderComponent({ path: 'INVOKE' })
		})
		expect(container.find('div.cdv-invoke-wrapper')).toHaveLength(1)
	})

	it('Check whether CDV Base View is rendered for Initiate flow', () => {
		act(() => {
			renderComponent({ path: 'INITIATE' })
		})
		expect(container.find('div.cdv-wrapper')).toHaveLength(1)
	})

	it('Check whether CDV Base View is rendered for Complete Flow', () => {
		act(() => {
			renderComponent({
				path: 'COMPLETE'
			})
		})
		expect(container.find('div.cdv-complete-wrapper')).toHaveLength(1)
	})

	it('Check whether CDV Base View renders error if CDV is not enabled', () => {
		let _hasError = false
		act(() => {
			Utility.isCDVEnabled.mockImplementation(() => {
				return false
			})
			renderComponent({ path: 'INVOKE' })
		})
		expect(container.find('div.cdv-error-section')).toHaveLength(1)
	})

	it('Check whether CDV Base View renders error for invalid flow', () => {
		act(() => {
			renderComponent({ path: 'SOMETHING' })
		})
		expect(container.find('div.cdv-error-section')).toHaveLength(1)
	})
})
