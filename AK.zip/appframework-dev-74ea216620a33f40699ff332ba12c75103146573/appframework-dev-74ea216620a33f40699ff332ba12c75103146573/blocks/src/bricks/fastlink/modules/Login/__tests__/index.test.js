
import React from 'react'


import { createStore, combineReducers, applyMiddleware, compose } from "redux";




import { getParam } from "../../../conf";
import LiginModule from "./../../Login";

import providerInfo from "./../../../store/reducers/providerInfo";


const mockPlaySoundFile = jest.fn(() => {
    return Promise.resolve({siteId:10});
});
jest.mock('./../../../services/provider/ProviderDetailsServices', () => {
  return jest.fn().mockImplementation(() => {
    return {getProvidersDetails: mockPlaySoundFile};
  });
});


describe('Login Module Component', () => {
    let container;
    let store = null
   

    const rootReducer = combineReducers({
        curentProvider: providerInfo,
    })

    beforeEach(() => {
        container = null

        store = createStore(
            rootReducer
        )
    })

   
    it('Check login index is rendered', () => {
        act(() => {
            container = mount(<LiginModule providerId={10} store={store} />);
            expect(container.state.subViewType).toBe(undefined);
        })
    })

   
})
