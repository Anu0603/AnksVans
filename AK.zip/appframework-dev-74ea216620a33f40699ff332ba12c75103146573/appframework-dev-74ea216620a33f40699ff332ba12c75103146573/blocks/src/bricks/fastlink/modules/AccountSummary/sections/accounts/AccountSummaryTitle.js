import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../conf'
import React, { useState } from 'react'

import { Modal } from '../../../../../../framework/react/components/Modal'
import {
	Icon,
	IconNameMap
} from '../../../../../../framework/react/components/Icon'
import DeeplinkConstants from '@fastlinkRoot/filters/deeplink/DeeplinkConstants'

const AccountSelectInfo = props => {
	const isSingleAccount = props.isSingleAccount

	const isSingleSelect =
		AppConstants.VERIFICATION_SINGLE_ACCOUNT_SELECTION ===
		getParam(AppParams.SUCCESS_ACCOUNT_SELECTION_TYPE)

	const inlineStyle = {
		color: props.currentProvider.hexCode1
	}

	const isDeeplink = props.deeplinkData
		? props.deeplinkData.isDeeplink
		: false
	const deeplinkType = isDeeplink ? props.deeplinkData.deeplinkType : null

	const isEditRefreshDeeplink =
		isDeeplink &&
		(deeplinkType == DeeplinkConstants.FLOW_TYPES['REFRESH'] ||
			deeplinkType == DeeplinkConstants.FLOW_TYPES['EDIT_CREDENTIALS'])

	/* Description: getMessageContent() returns the markup for the header title, which is rendered without Icon.
	 */
	let getMessageContent = keyName => {
		return (
			<div className="account-summary-title" style={inlineStyle}>
				{getString(keyName)}
			</div>
		)
	}
	/* Description: getMessageContentWithIcon() returns the markup for the header title, which is rendered with Icon.
	 */
	let getMessageContentWithIcon = keyName => {
		return (
			<div className="account-summary-title" style={inlineStyle}>
				{getString(keyName)}
				<Icon
					type="fal"
					iconClass={'fa-info-circle'}
					onClick={showHidePopUp.bind(this, true)}
				/>
			</div>
		)
	}

	/* Description: getVerificationMessageString() determines and returns the header title string based on the various
	 * conditions, like the param key for multi-select or single-select and the number of accounts.
	 */
	let getVerificationMessageString = () => {
		let keyName
		if (isSingleAccount) {
			keyName = AppStrings.ACCOUNTS_SUMMARY_SINGLE_ACCOUNT_MESSAGE_TEXT
		} else {
			keyName = AppStrings.ACCOUNT_SUMMARY_SELECTION_MESSAGE_TEXT
			if (isSingleSelect) {
				keyName =
					AppStrings.ACCOUNT_SUMMARY_SINGLE_ACCOUNT_SELECTION_MESSAGE_TEXT
			}
		}
		return keyName
	}

	/* Description: getAccountSummaryMsg() determines and return the header content
	 */
	let getAccountSummaryMsg = () => {
		let viewContent = null,
			keyName
		switch (getParam(AppParams.PRODUCT_TYPE)) {
			case AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME:
				if (props.appflow === AppConstants.APP_FLOW_VERIFICATION) {
					keyName = getVerificationMessageString()
				} else {
					keyName = AppStrings.ACCOUNTS_SUMMARY_TITLE_TEXT
				}
				viewContent = getMessageContentWithIcon(keyName)
				break
			case AppConstants.VERIFICATION_FLOW_NAME:
				keyName = getVerificationMessageString()
				viewContent = getMessageContentWithIcon(keyName)
				break
			default:
				viewContent = getMessageContent(
					AppStrings.ACCOUNTS_SUMMARY_TITLE_TEXT
				)
				break
		}
		return viewContent
	}

	let [cnfPopupState, cnfPopupStateSetState] = useState({
		showPopup: false
	})

	const showHidePopUp = flag => {
		cnfPopupStateSetState({
			showPopup: flag
		})
		console.log(cnfPopupState.showPopup)
	}

	/* Description: getSummaryModalContent() determines and generate the Modal content for the popup which opens on click of
	 * header title help icon.
	 */
	const getSummaryModalContent = () => {
		let modalContent
		switch (getParam(AppParams.PRODUCT_TYPE)) {
			case AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME:
				if (props.appflow === AppConstants.APP_FLOW_VERIFICATION) {
					modalContent = getString(
						AppStrings.ACCOUNT_SUMMARY_SELECTION_MESSAGE_MODAL_TEXT
					)
				} else {
					modalContent = getString(
						AppStrings.ACCOUNT_SUMMARY_AGGREGATION_MESSAGE_MODAL_TEXT
					)
				}

				break
			case AppConstants.VERIFICATION_FLOW_NAME:
				modalContent = getString(
					AppStrings.ACCOUNT_SUMMARY_SELECTION_MESSAGE_MODAL_TEXT
				)
				break
			default:
				break
		}
		return modalContent
	}

	return (
		<React.Fragment>
			{!isEditRefreshDeeplink && getAccountSummaryMsg()}
			{cnfPopupState.showPopup && (
				<Modal
					backDropEnabled={true}
					onBackDropClick={() => showHidePopUp(false)}
					crossIconEnabled={true}
					show={cnfPopupState.showPopup}
					className="small"
					onCrossIconClick={() => showHidePopUp(false)}
				>
					<div>{getSummaryModalContent()}</div>
				</Modal>
			)}
		</React.Fragment>
	)
}

export default AccountSelectInfo
