const landingViewProps = {
	data: {
		isEdit: true,
		editAccount: [
			{
				CONTAINER: 'bank',
				providerAccountId: 11306769,
				accountName: 'test',
				id: 12411774,
				providerName: '',
				accountType: 'SAVINGS',
				isManual: true,
				includeInNetWorth: true,
				amountDue: { amount: 4127, currency: 'AUD' },
				balance: { amount: 123, currency: 'AUD' },
				valuationType: 'MANUAL'
			}
		]
	},
	currencyOptions: []
}

const successViewProps = {
	data: { id: 123, container: 'bank' },
	showNextView: () => {}
}

export default {
	landingViewProps,
	successViewProps
}
