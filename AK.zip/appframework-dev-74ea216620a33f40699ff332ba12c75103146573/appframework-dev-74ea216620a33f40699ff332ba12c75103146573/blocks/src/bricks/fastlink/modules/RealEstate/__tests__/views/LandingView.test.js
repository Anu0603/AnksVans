import React from 'react'
import { Provider } from 'react-redux'
import realEstateHelper from '../../helper/RealEstateHelper'
import LandingView from '../../views/LandingView'
import { createStore, combineReducers } from 'redux'
import configureStore from 'redux-mock-store'
import realEstateReducer from './../../../../store/reducers/realEstate'
import { AppStrings, getString, AppParams } from '../../../../../fastlink/conf'
import { getParam } from '../../../../conf/utilities/Utilities'
import propsMock from '../__mocks__/props'
import RealEstateService from '../../../../services/account/RealEstateService'
import AccountsService from '../../../../services/account/AccountsService'

const mockStore = configureStore([])
const showNextViewMock = jest.fn()
const handleDeleteMock = jest.fn()
const handleTechDiffMock = jest.fn()
jest.mock('../../views/DeleteModal', () => {
	return {
		__esModule: true,
		default: props => {
			return (
				<div className="modal-content">
					<button
						id="cancel-modal"
						onClick={() => {
							props.showHidePopUp(false)
						}}
					></button>
					<button
						id="delete-button"
						onClick={() => {
							props.handleDelete()
						}}
					></button>
				</div>
			)
		}
	}
})

jest.mock('../../views/SmartzipModal', () => {
	return {
		__esModule: true,
		default: props => {
			return (
				<div className="modal-content">
					<button
						id="cancel-modal"
						onClick={() => {
							props.showHideSmartzipPopup(false)
						}}
					></button>
				</div>
			)
		}
	}
})
jest.mock('./../../../../components/Error/ErrorBanner', () => {
	return {
		__esModule: true,
		default: () => <div className="alert-error"></div>
	}
})
jest.mock('./../../../../components/Error/ErrorContent', () => {
	return {
		__esModule: true,
		default: () => <div className="alert-detail"></div>
	}
})
jest.mock('../../../../../fastlink/conf')
jest.mock('../../../../conf/utilities/Utilities')

realEstateHelper.getCurrencyDropdownOptions = jest.fn().mockReturnValue([
	{
		displayText: 'USD',
		optionValue: 'USD'
	},
	{
		displayText: 'AUD',
		optionValue: 'AUD'
	}
])

getString.mockImplementation(_key => {
	switch (_key) {
		case AppStrings.REAL_ESTATE_ADD_ACCOUNT_TITLE:
			return 'Add Real Estate Account'
		case AppStrings.REAL_ESTATE_EDIT_ACCOUNT_TITLE:
			return 'Edit Real Estate Account'
		case AppStrings.REAL_ESTATE_SUBMIT_BUTTON_TEXT:
			return 'Submit'
		case AppStrings.NEXT_BUTTON_TEXT:
			return 'Next'
		case AppStrings.ERROR_CANCEL_BUTTON_TEXT:
			return 'Cancel'
		default:
			break
	}
})

describe('Real Estate landing view For Add mode', () => {
	let container = null
	let landingViewInstance = null
	let store = null
	let props = null
	let appParam = {
		disable_realestate_manual: false,
		disable_realestate_system: false
	}

	// const rootReducer = combineReducers({
	// 	realEstate: realEstateReducer
	// })

	beforeEach(() => {
		getParam.mockImplementation(key => {
			if (key === AppParams.DISABLE_REALESTATE_MANUAL) {
				return appParam.disable_realestate_manual
			}
			if (key === AppParams.DISABLE_REALESTATE_SYSTEM) {
				return appParam.disable_realestate_system
			}
		})
		props = propsMock.landingViewProps.addMode
		container = null
		landingViewInstance = null
		// store = createStore(rootReducer)
	})

	const setAppParam = paramValue => {
		appParam = { ...appParam, ...paramValue }
	}

	let renderComponent = (
		isDeeplink = false,
		deeplinkType = 'EDIT_REAL_ESTATE'
	) => {
		store = mockStore({
			realEstate: { accounts: [] },
			deeplink: {
				isDeeplink: isDeeplink,
				deeplinkType: deeplinkType
			}
		})
		container = mount(
			<Provider store={store}>
				<LandingView
					{...props}
					showNextView={showNextViewMock}
					handleTechDiff={handleTechDiffMock}
				/>
			</Provider>
		)
		landingViewInstance = container
			.childAt(0)
			.childAt(0)
			.instance()
	}

	it('Check whether landing view is rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('.section-container')).toHaveLength(1)
	})

	it('Check header name for Add account', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		expect(container.find('.section-header .title').text()).toEqual(
			'Add Real Estate Account'
		)
	})
	it('Submit button text should be Next', () => {
		act(() => {
			renderComponent()
		})

		container.update()
		expect(container.find('.btn-primary').text()).toEqual('Next')
	})

	it('Check default initial values', () => {
		setAppParam({
			disable_realestate_manual: false,
			disable_realestate_system: false
		})
		act(() => {
			renderComponent()
		})
		expect(landingViewInstance.state.valuationType).toEqual('system')

		expect(landingViewInstance.state.currency).toEqual('USD')

		expect(landingViewInstance.state.includeInNetWorth).toEqual(true)
	})

	it('Radio buttons should not render when disable_realestate_manual is true', () => {
		setAppParam({
			disable_realestate_manual: true,
			disable_realestate_system: false
		})
		act(() => {
			renderComponent()
		})
		expect(container.find('.option-manual')).toHaveLength(0)
		expect(container.find('.option-system')).toHaveLength(0)
	})

	it('Radio buttons should not render when disable_realestate_system is true', () => {
		setAppParam({
			disable_realestate_manual: false,
			disable_realestate_system: true
		})
		act(() => {
			renderComponent()
		})
		expect(container.find('.option-manual')).toHaveLength(0)
		expect(container.find('.option-system')).toHaveLength(0)
	})

	it('Manual account components should not render initially', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('[name="value-input"]')).toHaveLength(0)
		expect(container.find('#test-dropdown')).toHaveLength(0)
	})

	it('Check if updateAccountName is called on value change', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		const event = { target: { name: 'xyz', value: 'xyz' } }
		container
			.find({ name: 'account-name-input' })
			.hostNodes()
			.simulate('change', event)
		expect(landingViewInstance.state.accountName).toEqual(
			event.target.value
		)
	})
	it('Check if onChange is called on street address change', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		const event = { target: { name: 'amount', value: '123' } }
		container
			.find({ name: 'street-address-input' })
			.hostNodes()
			.simulate('change', event)
		expect(landingViewInstance.state.addressLine1).toEqual(
			event.target.value
		)
	})

	it('Check if onChange is called on city change', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		const event = { target: { name: 'city', value: 'test_city' } }
		container
			.find({ name: 'city-input' })
			.hostNodes()
			.simulate('change', event)
		expect(landingViewInstance.state.city).toEqual(event.target.value)
	})

	it('Check if onChange is called on state change', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		const event = { target: { name: 'state', value: 'state' } }
		container
			.find({ name: 'state-input' })
			.hostNodes()
			.simulate('change', event)
		expect(landingViewInstance.state.stateName).toEqual(event.target.value)
	})

	it('Check if onChange is called on zip change', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		const event = { target: { name: 'zip', value: '213' } }
		container
			.find({ name: 'zip-input' })
			.hostNodes()
			.simulate('change', event)
		expect(landingViewInstance.state.zip).toEqual(event.target.value)
	})

	it('Check if handleCaluclationTypeChange is called on valuation change', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		const event = { target: { name: 'manual', value: 'manual' } }
		container
			.find('#option-manual')
			.hostNodes()
			.simulate('change', event)
		expect(landingViewInstance.state.valuationType).toEqual(
			event.target.value
		)
	})

	it('Check if updateAmount is called on value change', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		let event = { target: { name: 'manual', value: 'manual' } }
		container
			.find('#option-manual')
			.hostNodes()
			.simulate('change', event)
		event = { target: { name: 'value', value: '123' } }
		container
			.find({ name: 'value-input' })
			.hostNodes()
			.simulate('change', event)
		expect(landingViewInstance.state.amount).toEqual(event.target.value)
	})

	it('Check if handleCurrencyChange is called on currency change', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		let event = { target: { name: 'manual', value: 'manual' } }
		container
			.find('#option-manual')
			.hostNodes()
			.simulate('change', event)
		event = { target: { name: 'value', value: 'AUD' } }
		container
			.find('.dropdown-base')
			.hostNodes()
			.simulate('change', event)
		// expect(landingViewInstance.state.currency).toEqual(event.target.value)
	})

	it('Simulate Include net worth toggle button ', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		let event = { target: { name: 'manual', checked: false } }
		container
			.find('#toggle-button')
			.hostNodes()
			.simulate('change', event)
		expect(landingViewInstance.state.includeInNetWorth).toEqual(
			event.target.checked
		)
	})

	it('Check if Handle Submit is called with valid value for Manual account', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'addRealEstate')
		mock.mockReturnValue(
			new Promise(resolve => {
				resolve({
					account: [{ id: 12442376, accountName: 'qdw' }]
				})
			})
		)

		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.setState({
				valuationType: 'manual',
				currency: 'USD',
				currency: '1234.12'
			})
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')

		mock.mockRestore()
	})

	it('Check if Handle Submit is called with valid value for System Account', () => {
		const mockEval = jest.spyOn(
			RealEstateService.prototype,
			'evaluateAddress'
		)
		mockEval.mockReturnValue(
			Promise.resolve({
				isValidAddress: true,
				address: [
					{
						street: 'street',
						city: 'city',
						state: 'state',
						zip: 'zip'
					}
				]
			})
		)

		const mock = jest.spyOn(RealEstateService.prototype, 'addRealEstate')
		mock.mockReturnValue(
			new Promise(resolve => {
				resolve({
					account: [{ id: 12442376, accountName: 'qdw' }]
				})
			})
		)

		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.setState({
				city: 'asd',
				stateName: 'ca',
				street: 'abc',
				zip: '123',
				accountName: 'Test account'
			})
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')

		// mock.mockRestore()
	})
	it('Simulate adrees select on Two matches', () => {
		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.setState({
				selectedAddressIndex: 0,
				multiAddress: [
					{
						street: 'street1',
						city: 'city1',
						state: 'state1',
						zip: 'zip1'
					},
					{
						street: 'street2',
						city: 'city2',
						state: 'state2',
						zip: 'zip2'
					}
				]
			})

		container
			.find('#option-address1')
			.hostNodes()
			.simulate('change')
		expect(landingViewInstance.state.selectedAddressIndex).toEqual(1)

		container
			.find('#keep-address')
			.hostNodes()
			.simulate('change')
		expect(landingViewInstance.keepOrEditAddress).toEqual(true)
	})

	it('Check if form is invalid with invalid values for Manual', () => {
		const mock = jest.spyOn(realEstateHelper, 'validateManualAccountFields')
		mock.mockReturnValue(false)
		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.setState({
				valuationType: 'manual',
				currency: 'USD',
				currency: ''
			})
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')

		mock.mockRestore()
	})

	it('Check if ErrorBanner and ErrorContent is rendered for Y862 error code ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'addRealEstate')
		mock.mockReturnValue(Promise.reject({ details: { errorCode: 'Y862' } }))

		const mockEval = jest.spyOn(
			RealEstateService.prototype,
			'evaluateAddress'
		)
		mockEval.mockReturnValue(
			Promise.resolve({
				isValidAddress: true,
				address: [
					{
						street: 'street',
						city: 'city',
						state: 'state',
						zip: 'zip'
					}
				]
			})
		)
		act(() => {
			renderComponent()
		})
		container.update()
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')

		container
			.childAt(0)
			.childAt(0)
			.setState({
				showSpinner: false,
				errorReason: 'REAL_ESTATE_ADDRESS_NOT_FOUND',
				errorStatus: '',
				showErrorBanner: true
			})
		expect(container.find('.alert-error').hostNodes()).toHaveLength(1)
		expect(container.find('.alert-detail').hostNodes()).toHaveLength(1)
	})

	it('Muliple addresses are returned by evaluateAddress api', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'evaluateAddress')
		mock.mockReturnValue(
			Promise.resolve({
				isValidAddress: true,
				address: [
					{
						street: 'street',
						city: 'city',
						state: 'state',
						zip: 'zip'
					},
					{
						street: 'street',
						city: 'city',
						state: 'state',
						zip: 'zip'
					}
				]
			})
		)

		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.setState({
				valuationType: 'system'
			})
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})

	it('Deeplink is true with flow=addRealEstate', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'getRealEstate')
		mock.mockReturnValue(
			Promise.resolve({
				account: [
					{
						CONTAINER: 'realEstate',
						providerAccountId: 11306769,
						accountName: 'qwe',
						id: 12411774,
						providerName: 'Custom Real Estate',
						accountType: 'REAL_ESTATE',
						isManual: true,
						includeInNetWorth: true,
						homeValue: { amount: 123, currency: 'AUD' },
						valuationType: 'MANUAL',
						address: { street: '', city: '', state: '', zip: '' }
					}
				]
			})
		)
		act(() => {
			renderComponent(true)
		})

		container.update()
	})
	it('deeplink true and getRealEstate returns error ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'getRealEstate')
		mock.mockReturnValue(Promise.reject('error'))
		act(() => {
			renderComponent(true)
		})

		container.update()
		expect(handleTechDiffMock).toBeCalled
	})
})
describe('Real Estate landing view For Edit mode', () => {
	let container = null
	let store = null
	let props = null
	let appParam = {
		disable_realestate_manual: false,
		disable_realestate_system: false
	}

	const rootReducer = combineReducers({
		realEstate: realEstateReducer
	})

	beforeEach(() => {
		getParam.mockImplementation(key => {
			if (key === AppParams.DISABLE_REALESTATE_MANUAL) {
				return appParam.disable_realestate_manual
			}
			if (key === AppParams.DISABLE_REALESTATE_SYSTEM) {
				return appParam.disable_realestate_system
			}
		})
		props = propsMock.landingViewProps.editMode
		container = null
		// store = createStore(rootReducer)
	})

	const setAppParam = paramValue => {
		appParam = { appParam, ...paramValue }
	}

	let renderComponent = (
		isDeeplink = false,
		deeplinkType = 'EDIT_REAL_ESTATE'
	) => {
		store = mockStore({
			realEstate: { accounts: [] },
			deeplink: {
				isDeeplink: isDeeplink,
				deeplinkType: deeplinkType
			}
		})
		container = mount(
			<Provider store={store}>
				<LandingView {...props} handleDelete={handleDeleteMock} />
			</Provider>
		)
	}

	it('Check header name for Edit account', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		expect(container.find('.section-header .title').text()).toEqual(
			'Edit Real Estate Account'
		)
	})

	it('Submit button text should be Submit For Edit', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		expect(container.find('.btn-primary').text()).toEqual('Submit')
	})

	it('Check if Handle Submit is called for Manual for Edit ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'editRealEstate')
		mock.mockReturnValue(Promise.resolve({}))
		act(() => {
			renderComponent()
		})
		container.update()
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})

	it('Check if Error is displayed for System account for Edit for two addresses Match ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'editRealEstate')
		mock.mockReturnValue(Promise.resolve({}))

		const mock2 = jest.spyOn(RealEstateService.prototype, 'evaluateAddress')
		mock2.mockReturnValue(
			Promise.resolve({ isValidAddress: true, address: ['', ''] })
		)
		props = {
			...props,
			data: {
				editAccount: {
					...props.data.editAccount,
					valuationType: 'SYSTEM'
				},
				isEdit: true
			}
		}
		act(() => {
			renderComponent()
		})
		container.update()

		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})

	it('Check if Error is displayed for System account for Edit for two addresses Match ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'editRealEstate')
		mock.mockReturnValue(Promise.resolve({}))

		const mock2 = jest.spyOn(RealEstateService.prototype, 'evaluateAddress')
		mock2.mockReturnValue(
			Promise.resolve({ isValidAddress: true, address: ['', '', ''] })
		)
		props = {
			...props,
			data: {
				editAccount: {
					...props.data.editAccount,
					valuationType: 'SYSTEM'
				},
				isEdit: true
			}
		}
		act(() => {
			renderComponent()
		})
		container.update()

		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})

	it('Check if Handle Submit is called for System account for Edit for Single addresses ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'editRealEstate')
		mock.mockReturnValue(Promise.resolve({}))

		const mock2 = jest.spyOn(RealEstateService.prototype, 'evaluateAddress')
		mock2.mockReturnValue(
			Promise.resolve({
				isValidAddress: true,
				address: [
					{
						street: 'street',
						city: 'city',
						state: 'state',
						zip: 'zip'
					}
				]
			})
		)
		props = {
			...props,
			data: {
				editAccount: {
					...props.data.editAccount,
					valuationType: 'SYSTEM'
				},
				isEdit: true
			}
		}
		act(() => {
			renderComponent()
		})
		container.update()

		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})

	it('Check if Handle Submit is called for System account for Single addresses and EditAccount returns error', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'editRealEstate')
		mock.mockReturnValue(Promise.reject({}))

		const mock2 = jest.spyOn(RealEstateService.prototype, 'evaluateAddress')
		mock2.mockReturnValue(
			Promise.resolve({
				isValidAddress: true,
				address: [
					{
						street: 'street',
						city: 'city',
						state: 'state',
						zip: 'zip'
					}
				]
			})
		)
		props = {
			...props,
			data: {
				editAccount: {
					...props.data.editAccount,
					valuationType: 'SYSTEM'
				},
				isEdit: true
			}
		}
		act(() => {
			renderComponent()
		})
		container.update()

		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})

	it('Click Submit for  valuation change from manual to system for Edit ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'editRealEstate')
		mock.mockReturnValue(Promise.resolve({}))

		const mock2 = jest.spyOn(RealEstateService.prototype, 'evaluateAddress')
		mock2.mockReturnValue(
			Promise.resolve({
				isValidAddress: true,
				address: [
					{
						street: 'street',
						city: 'city',
						state: 'state',
						zip: 'zip'
					}
				]
			})
		)
		// props.data.valuationType = 'SYSTEM'
		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.setState({
				valuationType: 'system'
			})
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})
	it('Click Submit for after valuation change from system to manual for Edit ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'addRealEstate')
		mock.mockReturnValue(
			Promise.resolve({ account: [{ id: '', accountName: '' }] })
		)

		const mock2 = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		mock2.mockReturnValue(Promise.resolve({}))

		props = {
			...props,
			data: {
				editAccount: {
					...props.data.editAccount,
					valuationType: 'SYSTEM'
				},
				isEdit: true
			}
		}
		act(() => {
			renderComponent()
		})

		container
			.childAt(0)
			.childAt(0)
			.setState({
				valuationType: 'manual',
				zip: 123,
				stateName: 'CA',
				city: 'xyz',
				accountName: 'test'
			})
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})

	it('Simulate Submit for after valuation change from system to manual With Error ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'addRealEstate')
		mock.mockReturnValue(Promise.reject({}))

		const mock2 = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		mock2.mockReturnValue(Promise.resolve({}))

		props = {
			...props,
			data: {
				editAccount: {
					...props.data.editAccount,
					valuationType: 'SYSTEM'
				},
				isEdit: true
			}
		}
		act(() => {
			renderComponent()
		})
		container
			.childAt(0)
			.childAt(0)
			.setState({
				valuationType: 'manual',
				zip: 123,
				stateName: 'CA',
				city: 'xyz',
				accountName: 'test'
			})
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})

	it('Evaluate address returns false ', () => {
		setAppParam({
			disable_realestate_manual: false,
			disable_realestate_system: false
		})
		const mock = jest.spyOn(RealEstateService.prototype, 'editRealEstate')
		mock.mockReturnValue(Promise.resolve({}))

		const mock2 = jest.spyOn(RealEstateService.prototype, 'evaluateAddress')
		mock2.mockReturnValue(Promise.resolve({ isValidAddress: false }))
		// props = { ...props }
		// props.valuationType = 'SYSTEM'
		act(() => {
			renderComponent()
		})
		container
			.childAt(0)
			.childAt(0)
			.setState({
				valuationType: 'system',
				zip: 123,
				stateName: 'CA',
				city: 'xyz'
			})
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})

	it('Evaluate address returns error ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'editRealEstate')
		mock.mockReturnValue(Promise.resolve({}))

		const mock2 = jest.spyOn(RealEstateService.prototype, 'evaluateAddress')
		mock2.mockReturnValue(Promise.reject({}))
		props = {
			...props,
			data: {
				editAccount: {
					...props.data.editAccount,
					valuationType: 'SYSTEM'
				},
				isEdit: true
			}
		}
		act(() => {
			renderComponent()
		})
		container
			.childAt(0)
			.childAt(0)
			.setState({
				valuationType: 'system',
				zip: 123,
				stateName: 'CA',
				city: 'xyz'
			})
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')
	})

	it('Check if ErrorBanner and ErrorContent is rendered for Y811 error code on Edit ', () => {
		const mock = jest.spyOn(RealEstateService.prototype, 'editRealEstate')
		mock.mockReturnValue(Promise.reject({ details: { errorCode: 'Y811' } }))
		act(() => {
			renderComponent()
		})
		container.update()
		container
			.find('.btn-primary')
			.hostNodes()
			.simulate('click')

		container
			.childAt(0)
			.childAt(0)
			.setState({
				showSpinner: false,
				errorReason: 'REAL_ESTATE_VALUE_ALREADY_ADDED',
				errorStatus: '',
				showErrorBanner: true
			})
		expect(container.find('.alert-error').hostNodes()).toHaveLength(1)
		expect(container.find('.alert-detail').hostNodes()).toHaveLength(1)
	})

	it('Check if delete modal is rendered on button click', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		expect(container.find('.btn-danger-reversed')).toHaveLength(1)
		container.find('.btn-danger-reversed').simulate('click')
		expect(
			container
				.childAt(0)
				.childAt(0)
				.instance().state.showDeleteCnfPopup
		).toEqual(true)
		container.find('#cancel-modal').simulate('click')
	})

	it('Simulate Delete Error on delete click', () => {
		const mock = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		mock.mockReturnValue(
			new Promise((resolve, reject) => {
				reject({})
			})
		)
		renderComponent()
		container.update()
		expect(container.find('.btn-danger-reversed')).toHaveLength(1)
		container.find('.btn-danger-reversed').simulate('click')
		expect(
			container
				.childAt(0)
				.childAt(0)
				.instance().state.showDeleteCnfPopup
		).toEqual(true)
		expect(container.find('.modal-content')).toHaveLength(1)
		container.find('#delete-button').simulate('click')
	})

	it('Simulate successful Delete on delete click', () => {
		const mock = jest.spyOn(AccountsService.prototype, 'deleteAccount')
		mock.mockReturnValue(
			new Promise((resolve, reject) => {
				resolve({})
			})
		)
		renderComponent()
		container.update()
		expect(container.find('.btn-danger-reversed')).toHaveLength(1)
		container.find('.btn-danger-reversed').simulate('click')
		expect(
			container
				.childAt(0)
				.childAt(0)
				.instance().state.showDeleteCnfPopup
		).toEqual(true)
		expect(container.find('.modal-content')).toHaveLength(1)
		container.find('#delete-button').simulate('click')
	})

	it('Check if smartzip modal is rendered on button click', () => {
		act(() => {
			renderComponent()
		})
		container.update()
		expect(container.find('.btn-danger-reversed')).toHaveLength(1)
		container.find('.info-txt .info-link').simulate('click')
		expect(container.find('.modal-content')).toHaveLength(1)
		container.find('#cancel-modal').simulate('click')
	})

	it('Check if delete modal is rendered and handleDelete is called on delete click', () => {
		act(() => {
			renderComponent(true)
		})
		container.update()
		expect(container.find('.btn-danger-reversed')).toHaveLength(1)
		container.find('.btn-danger-reversed').simulate('click')
		expect(
			container
				.childAt(0)
				.childAt(0)
				.instance().state.showDeleteCnfPopup
		).toEqual(true)
		container.find('#delete-button').simulate('click')
		expect(handleTechDiffMock).toBeCalled
	})
})
