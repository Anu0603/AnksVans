import React from 'react'
import {
	AutoIds,
	AppParams,
	getParam,
	AppStrings,
	getString,
} from '../../../../conf'

import PopularSectionCard from './../../components/PopularSectionCard'
import Constants from './../../../../router/Constant'

const PopularSitesView = props => {
	return (
		<ul className="card-list row">
			{props.providers ? (
				<React.Fragment>
					{props.providers.map((site, index) => {
						return (
							<li key={index} className="col-6 col-md-3">
								<PopularSectionCard
									onClick={props.navigateToSite.bind(
										this,
										site
									)}
									data={site}
								/>
							</li>
						)
					})}

					{getParam(AppParams.ENABLE_REAL_ESTATE) &&
					(!getParam(AppParams.DISABLE_REALESTATE_MANUAL) ||
						!getParam(AppParams.DISABLE_REALESTATE_SYSTEM)) ? (
						<li key="realestate" className="col-6 col-md-3">
							<PopularSectionCard
								classes={'real-estate-card'}
								cardType="other-account-card"
								data={{
									text: getString(AppStrings.REAL_ESTATE),
								}}
								onClick={props.navigateToRealEstate.bind()}
							/>
						</li>
					) : null}

					{getParam(AppParams.ENABLE_MANUAL_ACCOUNT) ? (
						<li key="manual" className="col-6 col-md-3">
							<PopularSectionCard
								classes={'manual-card'}
								cardType="other-account-card"
								data={{ text: getString(AppStrings.MANUAL) }}
								onClick={props.navigateToManualAccounts.bind()}
							/>
						</li>
					) : null}
				</React.Fragment>
			) : null}
		</ul>
	)
}

PopularSitesView.defaultProps = {
	navigateToSite: function() {},
	navigate: function() {},
}

export default PopularSitesView
