import React from 'react'
import { createStore } from 'redux'
import { Provider } from 'react-redux'
import ActSummaryHelpText from '../../sections/ActSummaryHelpText'
import configureStore from 'redux-mock-store'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../../fastlink/conf/index'
import { debug } from 'webpack'
import currentProviderMock from './../__mocks__/currentProvider'
import providerReducer from '../../../../store/reducers/providerInfo'

jest.mock('./../../../../conf')

describe('Account summary help text', () => {
	let container
	let disableBottomText
	let institutionName
	let containerList
	let primaryColor
	let appflow
	let store
	let renderComponent

	beforeEach(() => {
		container = null
		containerList = ['bank']
		disableBottomText = false
		institutionName = 'My bank'
		primaryColor = '404040'
		appflow = 'VERIFICATION'

		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'AGGR'
			}
		})

		getString.mockImplementation(_key => {
			if (_key == AppStrings.ACCOUNT_SUMMARY_BOTTOM_TEXT_START) {
				return 'summary text start'
			} else if (_key == AppStrings.ACCOUNT_SUMMARY_BOTTOM_TEXT_END) {
				return 'summary text end'
			}
		})

		store = createStore(providerReducer, {
			currentProvider: currentProviderMock
		})

		renderComponent = props => {
			container = mount(
				<div>
					<Provider store={store}>
						<ActSummaryHelpText
							disableBottomText={props.disableBottomText}
							institutionName={props.institutionName}
							containerList={props.containerList}
							primaryColor={props.primaryColor}
							appflow={props.appflow}
						/>
					</Provider>
				</div>
			)
		}
	})

	it('Test if the AccountSummaryText is not rendered when disableBottomText is true', () => {
		disableBottomText = true

		let props = {
			disableBottomText: disableBottomText,
			institutionName: institutionName,
			containerList: containerList,
			primaryColor: primaryColor
		}

		act(() => {
			renderComponent(props)
		})
		expect(container.find('div div')).toHaveLength(0)
	})
	it('Test if the AccountSummaryText is not rendered when containerList  is empty', () => {
		containerList = []

		let props = {
			disableBottomText: disableBottomText,
			institutionName: institutionName,
			containerList: containerList,
			primaryColor: primaryColor
		}

		act(() => {
			renderComponent(props)
		})
		expect(container.find('div div')).toHaveLength(0)
	})
	it('Test if the AccountSummaryText is rendered when disableBottomText is false', () => {
		let props = {
			disableBottomText: disableBottomText,
			institutionName: institutionName,
			containerList: containerList,
			primaryColor: primaryColor
		}
		act(() => {
			renderComponent(props)
		})
		expect(
			container.find('div div').hasClass('info-message footer-pad')
		).toBe(true)
	})
	it('Test if the AccountSummaryText is rendered correct', () => {
		let props = {
			disableBottomText: disableBottomText,
			institutionName: institutionName,
			containerList: containerList,
			primaryColor: primaryColor
		}
		act(() => {
			renderComponent(props)
		})
		debugger
		expect(
			container
				.find('div div')
				.childAt(0)
				.html()
		).toBe('summary text startMy banksummary text end')
	})
	it('Agg - Test if the AccountSummaryText is rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'AGGR'
			}
		})
		let props = {
			disableBottomText: disableBottomText,
			institutionName: institutionName,
			containerList: containerList,
			primaryColor: primaryColor
		}
		act(() => {
			renderComponent(props)
		})
		expect(
			container.find('div div').hasClass('info-message footer-pad')
		).toBe(true)
	})
	it('IAV - Test if the AccountSummaryText is not rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATION'
			}
		})
		let props = {
			disableBottomText: disableBottomText,
			institutionName: institutionName,
			containerList: containerList,
			primaryColor: primaryColor
		}
		act(() => {
			renderComponent(props)
		})
		expect(container.find('div div')).toHaveLength(0)
	})
	it('IAV+AGG - IAV - Test if the AccountSummaryText is not rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			}
		})
		let props = {
			disableBottomText: disableBottomText,
			institutionName: institutionName,
			containerList: containerList,
			primaryColor: primaryColor,
			appflow: appflow
		}
		act(() => {
			renderComponent(props)
		})
		expect(container.find('div div')).toHaveLength(0)
	})
	it('IAV+AGG - AGG - Test if the AccountSummaryText is rendered', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.PRODUCT_TYPE) {
				return 'VERIFICATIONPLUSAGGR'
			}
		})
		appflow = 'AGGREGATION'

		let props = {
			disableBottomText: disableBottomText,
			institutionName: institutionName,
			containerList: containerList,
			primaryColor: primaryColor,
			appflow: appflow
		}
		act(() => {
			renderComponent(props)
		})
		expect(
			container.find('div div').hasClass('info-message footer-pad')
		).toBe(true)
	})
})
