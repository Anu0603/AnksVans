export default {
	state: {
		multiAddress: [],
		valuationType: 'manual',
		accountName: 'qwe',
		addressLine1: 'xyz',
		city: 'xyz',
		stateName: 'xyz',
		zip: '123',
		amount: '123',
		currency: 'USD',
		includeInNetWorth: true,
		errorReason: '',
		errorStatus: '',
		errors: {
			addressLine1: '',
			city: '',
			stateName: '',
			zip: '',
			amount: '',
			accountName: ''
		}
	},
	keepOrEditAddress: true
}
