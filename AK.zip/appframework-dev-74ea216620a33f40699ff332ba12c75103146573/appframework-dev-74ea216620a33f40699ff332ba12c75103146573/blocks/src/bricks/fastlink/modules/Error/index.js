import React, { Component } from 'react'

import TechnicalErrorPage from '@fastlinkRoot/components/Error/TechnicalError/'
import { ErrorPage } from '@fastlinkRoot/components/Error/'

class ErrorModule extends Component {
	constructor(props) {
		super(props)
	}

	static propTypes = {}

	static defaultProps = {}

	componentDidMount() {}

	render() {
		return (
			<div>
				{this.props.isTechDiff ? (
					<TechnicalErrorPage
						code={this.props.code}
						message={this.props.message}
					/>
				) : (
					<ErrorPage {...this.props} />
				)}
			</div>
		)
	}
}

export default ErrorModule
