import React, { useState } from 'react'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../conf'
import AppConstants from '../../../conf/constants/AppConstants'

const ActSummaryHelpText = props => {
	let productType = getParam(AppParams.PRODUCT_TYPE)
	const containerLength =
		props.containerList && Object.keys(props.containerList).length
	if (containerLength == 0 || !containerLength) {
		return <React.Fragment></React.Fragment>
	}

	/* Description: showBottomText() determines when to enable or to disable the help text on the bottom.
	 */
	let showBottomText = () => {
		if (!props.disableBottomText) {
			if (productType === AppConstants.AGGREGATION_FLOW_NAME) {
				return true
			} else if (
				productType ===
					AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME &&
				props.appflow === AppConstants.APP_FLOW_AGGREGATION
			) {
				return true
			} else {
				return false
			}
		} else {
			return false
		}
	}

	return (
		<React.Fragment>
			{showBottomText() && (
				<div
					autoid={AutoIds.ACCOUNT_SUMMARY_LABEL_FOOTERHELPTEXT}
					className="info-message footer-pad"
					style={{ color: props.primaryColor }}
				>
					{getString(AppStrings.ACCOUNT_SUMMARY_BOTTOM_TEXT_START) +
						props.institutionName +
						getString(AppStrings.ACCOUNT_SUMMARY_BOTTOM_TEXT_END)}
				</div>
			)}
		</React.Fragment>
	)
}

export default ActSummaryHelpText
