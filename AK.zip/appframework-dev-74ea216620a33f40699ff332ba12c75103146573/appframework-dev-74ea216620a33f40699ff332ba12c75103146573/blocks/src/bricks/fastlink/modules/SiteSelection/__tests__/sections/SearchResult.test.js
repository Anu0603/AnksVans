import React from 'react'

import SearchResultSection from '../../sections/SearchResult'

import ProviderData from './../__mocks__/provider'
import { getParam } from '../../../../conf'
jest.mock('../../../../conf')

describe('Search Results Section', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check whether search result section rendered', () => {
		act(() => {
			container = shallow(<SearchResultSection searchResult={[]} />)
		})
		expect(container.find('div.search-list-wrapper')).toHaveLength(1)
	})

	it('Check whether spinner showed when searching in progress prop passed', () => {
		act(() => {
			container = mount(<SearchResultSection isSearching={true} />)
		})
		expect(container.find('div .spinner-wrapper')).toHaveLength(1)
	})

	it('Check whether search result cards are rendered', () => {
		act(() => {
			container = mount(
				<SearchResultSection searchResult={ProviderData.provider} />
			)
		})
		container
			.find('ul .site-search-row-cnr a')
			.first()
			.simulate('click')
		expect(container.find('ul .site-search-row-cnr')).toHaveLength(
			ProviderData.provider.length
		)
	})

	it('Check whether base url shown when the key is enabled', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'show_providers_base_url') {
					return true
				}
			})

			container = mount(
				<SearchResultSection searchResult={ProviderData.provider} />
			)
		})
		expect(container.find('.base-url-cnr')).toHaveLength(
			ProviderData.provider.length
		)
	})

	it('Check whether already added icon shown when show_providers_already_added_icon key is enabled', () => {
		let _count = ProviderData.provider.reduce(
			(accumulator, currentValue) => {
				if (currentValue.isAddedByUser !== 'false') {
					accumulator++
				}
				return accumulator
			},
			0
		)

		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == 'show_providers_already_added_icon') {
					return true
				}
			})

			container = mount(
				<SearchResultSection searchResult={ProviderData.provider} />
			)
		})
		expect(
			container.find('ul .site-search-row-cnr .fa-check-circle')
		).toHaveLength(_count)
	})
})
