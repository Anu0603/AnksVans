import React, { Component } from 'react';

import "./style/index.scss";

import VerificationView from './views/VerificationView';
import SiteBgColor from "./../../hoc/SiteBgColor";
import WithState from "./../../hoc/WithState";

class VerificationModule extends Component {
    constructor(props) {
        super(props);
    }

    static propTypes = {}

    static defaultProps = {}

    componentDidMount() {}

    render() {
        return (
            <VerificationView {...this.props} />
        )
    }
}

export default WithState("currentProvider",(VerificationModule));