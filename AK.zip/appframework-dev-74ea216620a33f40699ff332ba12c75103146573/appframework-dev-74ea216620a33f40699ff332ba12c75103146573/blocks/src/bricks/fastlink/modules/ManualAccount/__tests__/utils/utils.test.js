import utils from '../../utils/utils'
import data from '../__mocks__/landingViewState'
import { getString } from '../../../../../fastlink/conf'

jest.mock('../../../../../fastlink/conf')

getString.mockImplementation(_key => {
	switch (_key) {
		case 'currency_usd':
			return 'United States Dollar(USD)'

			break
	}
})

describe('Manual Account utils module', () => {
	let stateData

	beforeEach(() => {
		stateData = { state: { ...data.state } }
	})

	it('Should get fields', () => {
		const fields = [
			{
				id: 'account-name',
				name: 'accountName',
				type: 'text',
				properties: {
					value: '',
					error: false,
					errorMessage: '',
					required: true,
					placeholder: 'Account Name',
					default: '',
					maxLength: 50
				}
			},
			{
				id: 'nickname',
				name: 'nickname',
				type: 'text',
				properties: {
					value: '',
					error: false,
					errorMessage: '',
					required: false,
					placeholder: 'Nickname (optional)',
					default: '',
					maxLength: 50
				}
			},
			{
				id: 'account-number',
				name: 'accountNumber',
				type: 'text',
				properties: {
					value: '',
					error: false,
					errorMessage: '',
					required: false,
					placeholder: 'Account Number (optional)',
					default: ''
				}
			},
			{
				id: 'balance',
				name: 'balance',
				type: 'text',
				properties: {
					value: '',
					error: false,
					errorMessage: '',
					required: false,
					placeholder: 'Balance (optional)',
					default: ''
				}
			},
			{
				id: 'currency',
				name: 'currency',
				type: 'dropdown',
				properties: {
					value: '',
					options: undefined,
					default: 'USD',
					placeholder: 'Currency',
					required: false
				}
			},
			{
				id: 'include-in-net-worth',
				name: 'includeInNetWorth',
				type: 'toggle',
				properties: {
					value: false,
					options: [
						{
							checked: true,
							id: 'option-asset',
							name: 'include-in-net-worth',
							value: true
						},
						{
							checked: false,
							id: 'option-liability',
							name: 'include-in-net-worth',
							value: false
						}
					],
					required: false
				}
			},
			{
				id: 'memo',
				name: 'memo',
				type: 'text',
				properties: {
					value: '',
					error: false,
					errorMessage: '',
					required: false,
					placeholder: 'Memo (optional)',
					default: ''
				}
			}
		]

		utils.getAccountTypeOptions('accountName')
		utils.getAccountTypeContainer('BANK')
		const results = utils.getFields('SAVINGS')

		expect(results).toStrictEqual(fields)
	})

	it('Should get currency options', () => {
		const currencyOptions = utils.getCurrencyDropdownOptions(['USD'])

		expect(currencyOptions).toMatchObject([
			{
				displayText: 'United States Dollar(USD)',
				optionValue: 'USD'
			}
		])
	})
})
