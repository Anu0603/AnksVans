export default {
	providerAccount: [
		{
			id: 11314765,
			aggregationSource: 'USER',
			providerId: 13164,
			isManual: false,
			createdDate: '2020-04-16T11:00:57Z',
			status: 'LOGIN_IN_PROGRESS',
			code: 801,
			requestId: 'T5H9KC8TYxye0VZ/9mlEWGxlvpo=',
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					additionalStatus: 'LOGIN_IN_PROGRESS',
					updateEligibility: 'DISALLOW_UPDATE'
				}
			]
		}
	]
}
