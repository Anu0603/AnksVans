export default {
	params: [
		{
			id: 1316,
			value: 2
		},
		{
			id: 3130,
			value: 1
		}
	]
}
