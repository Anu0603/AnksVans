import React from 'react'
import { Provider } from 'react-redux'
import ProviderData from './../../../__mocks__/provider'
import CDVCompleteSuccessView from './../../../../components/complete/success'
import { AppStrings, getString } from './../../../../../../conf'
import configureStore from 'redux-mock-store'

jest.mock('./../../../../../../conf')
const mockStore = configureStore([])

describe('CDV Complete View - Success View', () => {
	let container = null
	beforeEach(() => {
		container = null

		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.CDV_COMPLETE_SUCCESS_TITLE:
					return 'SUCCESS'
					break
				case AppStrings.CDV_COMPLETE_SUCCESS_BUTTON_TEXT:
					return 'Save & Finish'
					break
				default:
					break
			}
		})
	})

	let renderComponent = props => {
		let store = mockStore({
			currentProvider: ProviderData.provider,
			cdv: {
				verificationInfo: {}
			}
		})
		container = mount(
			<Provider store={store}>
				<CDVCompleteSuccessView
					{...props}
					currentProvider={ProviderData.provider}
				/>
			</Provider>
		)
	}

	it('Check whether success section is rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('div.complete-success-wrapper')).toHaveLength(1)
		expect(
			container.find(
				'div.complete-success-wrapper #complete-success-label'
			)
		).toHaveLength(1)
		expect(
			container.find('div.complete-success-wrapper .complete-success-btn')
		).toHaveLength(1)
		expect(
			container.find(
				'div.complete-success-wrapper .complete-success-icon'
			)
		).toHaveLength(1)

		expect(
			container
				.find('div.complete-success-wrapper #complete-success-label')
				.text()
		).toEqual('SUCCESS')
		expect(
			container
				.find('div.complete-success-wrapper .complete-success-btn')
				.text()
		).toEqual('Save & Finish')
	})

	it('Check whether onClose CallBack is being called on clicking Close Button', () => {
		let onCloseCalled = false
		act(() => {
			renderComponent({
				onClose: function() {
					onCloseCalled = true
				}
			})
		})
		expect(onCloseCalled).toEqual(false)
		container
			.find('div.complete-success-wrapper .complete-success-btn')
			.simulate('click')
		expect(onCloseCalled).toEqual(true)
	})
})
