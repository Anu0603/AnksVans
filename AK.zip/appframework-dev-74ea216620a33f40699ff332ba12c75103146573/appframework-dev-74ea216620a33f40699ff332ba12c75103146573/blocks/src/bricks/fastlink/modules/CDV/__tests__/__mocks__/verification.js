export default {
	verificationMap: {
		NEW: {},
		INITIATED: {
			status: 'INITIATED'
		},
		ALREADY_INITIATED: {
			status: 'FAILED',
			reason: 'ALREADY_INITIATED'
		},
		ALREADY_COMPLETED: {
			status: 'FAILED',
			reason: 'ALREADY_COMPLETED'
		},
		FAILED: {
			status: 'FAILED',
			reason: 'DATA_MISMATCH'
		},
		SOMETHING: {
			status: 'SOMETHING'
		},
		DEPOSITED: {
			status: 'DEPOSITED',
			accountNumber: '98765432101234',
			routingNumber: '999999989',
			accountType: 'Checking',
			providerAccountId: '325662272'
		},
		SUCCESS: {
			status: 'SUCCESS',
			accountNumber: '98765432101234',
			routingNumber: '999999989',
			accountType: 'Checking',
			providerAccountId: '325662272'
		},
		ALREADY_SUCCESS: {
			status: 'ALREADY_SUCCESS',
			accountNumber: '98765432101234',
			routingNumber: '999999989',
			accountType: 'Checking',
			providerAccountId: '325662272'
		},
		ALREADY_FAILED: {
			status: 'ALREADY_FAILED',
			accountNumber: '98765432101234',
			routingNumber: '999999989',
			accountType: 'Checking',
			providerAccountId: '325662272'
		},
		TECH_ERROR: {
			status: 'TECH_ERROR'
		},
		INVALID_ACCOUNT_ID: {
			status: 'TECH_ERROR'
		},
		TOO_MANY_ATTEMPTS: {
			status: 'FAILED',
			reason: 'TOO_MANY_ATTEMPTS',
			accountNumber: '98765432101234',
			routingNumber: '999999989',
			accountType: 'Checking',
			providerAccountId: '325662272'
		},
		DATA_MISMATCH: {
			status: 'FAILED',
			reason: 'DATA_MISMATCH',
			accountNumber: '98765432101234',
			routingNumber: '999999989',
			accountType: 'Checking',
			providerAccountId: '325662272'
		},
		UNKNOWN_FAILED: {
			status: 'FAILED',
			reason: 'UNKNOWN',
			accountNumber: '98765432101234',
			routingNumber: '999999989',
			accountType: 'Checking',
			providerAccountId: '325662272'
		}
	}
}
