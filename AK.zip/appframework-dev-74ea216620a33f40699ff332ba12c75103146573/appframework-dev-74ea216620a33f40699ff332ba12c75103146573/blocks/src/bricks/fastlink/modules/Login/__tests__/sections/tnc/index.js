import React from 'react'
import { configure, shallow, mount } from 'enzyme';
import Adapter from 'enzyme-adapter-react-16';
import { act } from 'react-dom/test-utils'

configure({ adapter: new Adapter() });

import TNCSection from './../../../sections/tnc'
import { getParam } from "../../../../../conf"
jest.mock("../../../../../conf")

describe('TNCSection Section', () => {

    let container = null

    beforeEach(() => {
        container = null
    })


    it('Check whether tnc setion rendered', () => {
        act(() => {
            container = shallow(<TNCSection showPolicyView={true} tncCheckBox={{checkBoxId:"test"}} />)
        })
        expect(container.find('div.text')).toHaveLength(1)
    })

    it('Check whether external tnc text  rendered or not', () => {
        act(() => {
            getParam.mockImplementation((_key) => {
                if (_key == 'login_tnc_type') {
                    return "external"
                }
            })
            container = mount(<TNCSection showPolicyView={true} tncCheckBox={{checkBoxId:"test"}} />)
        })
        expect(container.find('.external').length).toBeGreaterThan(0)
    })
    it('Check whether pop up tnc text  rendered or not', () => {
        act(() => {
            getParam.mockImplementation((_key) => {
                if (_key == 'login_tnc_type') {
                    return "popup"
                }
            })
            container = mount(<TNCSection showPolicyView={true} tncCheckBox={{checkBoxId:"test"}} />)
        })
        expect(container.find('.tnc-link').length).toBeGreaterThan(0)
    })
})