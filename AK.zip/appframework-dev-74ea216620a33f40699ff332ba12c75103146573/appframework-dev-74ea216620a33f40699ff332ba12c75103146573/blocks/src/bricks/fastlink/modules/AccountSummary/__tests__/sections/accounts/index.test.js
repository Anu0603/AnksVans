import React from 'react'
import { Provider } from 'react-redux'
import configureStore from 'redux-mock-store'
import ContainerList from '../../../sections/accounts'
import { configure, shallow, mount } from 'enzyme'
import { test } from '../../../../../conf'
import { currentProvider } from '../../__mocks__/currentProvider'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../../../fastlink/conf/index'

const mockStore = configureStore([])

jest.mock('../../../../../../fastlink/conf/index')
jest.mock('../../../sections/accounts/AccountSummaryTitle', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="account-summary-title-view"></div>
		}
	}
})
jest.mock('../../../sections/accounts/AccountList', () => {
	return {
		__esModule: true,
		AccountList: () => {
			return <div className="account-list-view"></div>
		}
	}
})
jest.mock('../../../sections/accounts/EnableAllAccounts', () => {
	return {
		__esModule: true,
		default: () => {
			return <div className="enable-all-accounts-view"></div>
		}
	}
})
describe('Container list view', () => {
	let container = null
	let navigate = false
	let appflow = 'VERIFICATION'
	let currentProvider = currentProvider
	let selectedAccounts = []
	let accountsContainerList = ['bank']
	let containerAccountList = {
		bank: [
			{
				accountType: 'Savings',
				accountNumber: '12345',
				accountName: 'Test account3',
				amount: 12.34,
				currency: 'USD',
				negativeCurrency: true,
				id: 1
			},
			{
				accountType: 'Savings',
				accountNumber: '123456',
				accountName: 'Test account1',
				amount: 22.34,
				currency: 'USD',
				negativeCurrency: true,
				checked: true,
				id: 2
			},
			{
				accountType: 'Savings',
				accountNumber: '1234567',
				accountName: 'Test account2',
				amount: 2.34,
				currency: 'USD',
				negativeCurrency: true,
				id: 3
			}
		]
	}
	let verifiedAccounts = [
		{
			accountType: 'Savings',
			accountNumber: '12345',
			accountName: 'Test account3',
			amount: 12.34,
			currency: 'USD',
			negativeCurrency: true,
			id: 1
		},
		{
			accountType: 'Savings',
			accountNumber: '123456',
			accountName: 'Test account1',
			amount: 22.34,
			currency: 'USD',
			negativeCurrency: true,
			checked: true,
			id: 2
		}
	]
	let selectionOnChange = function() {}
	let allSelectionOnChange = function() {}
	let deleteCallback = function() {}
	beforeEach(() => {
		container = null
		container = null
		navigate = false
		appflow = 'VERIFICATION'
		currentProvider = currentProvider
		selectedAccounts = []
		accountsContainerList = ['bank']
		containerAccountList = {
			bank: [
				{
					accountType: 'Savings',
					accountNumber: '12345',
					accountName: 'Test account3',
					amount: 12.34,
					currency: 'USD',
					negativeCurrency: true,
					id: 1
				},
				{
					accountType: 'Savings',
					accountNumber: '123456',
					accountName: 'Test account1',
					amount: 22.34,
					currency: 'USD',
					negativeCurrency: true,
					checked: true,
					id: 2
				},
				{
					accountType: 'Savings',
					accountNumber: '1234567',
					accountName: 'Test account2',
					amount: 2.34,
					currency: 'USD',
					negativeCurrency: true
				}
			]
		}
		verifiedAccounts = [
			{
				accountType: 'Savings',
				accountNumber: '12345',
				accountName: 'Test account3',
				amount: 12.34,
				currency: 'USD',
				negativeCurrency: true,
				id: 1,
				status: true
			},
			{
				accountType: 'Savings',
				accountNumber: '123456',
				accountName: 'Test account1',
				amount: 22.34,
				currency: 'USD',
				negativeCurrency: true,
				checked: true,
				id: 2,
				status: true
			}
		]
		selectionOnChange = function() {}
		allSelectionOnChange = function() {}
		deleteCallback = function() {}
	})

	it('Check if container list view is loaded', () => {
		navigate = false
		selectedAccounts = []
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<ContainerList
						containerList={accountsContainerList}
						selectedAccounts={selectedAccounts}
						verifiedAccounts={verifiedAccounts}
						currentProvider={currentProvider}
						containerAccountList={containerAccountList}
						selectionOnChange={selectionOnChange.bind(this)}
						allSelectionOnChange={allSelectionOnChange.bind(this)}
						deleteCallback={deleteCallback.bind(this)}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				}
				if (_key === AppParams.PRODUCT_TYPE) {
					return 'VERIFICATIONPLUSAGGR'
				}
			})
			renderComponent()
		})
		expect(container.find('div.account-list-view')).toHaveLength(1)
		expect(container.find('div.account-summary-title-view')).toHaveLength(1)
		expect(container.find('div.enable-all-accounts-view')).toHaveLength(0)
	})
	it('Check if container list view is loaded with no accounts', () => {
		navigate = false
		selectedAccounts = []
		containerAccountList = {}
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<ContainerList
						containerList={accountsContainerList}
						selectedAccounts={selectedAccounts}
						currentProvider={currentProvider}
						containerAccountList={containerAccountList}
						selectionOnChange={selectionOnChange.bind(this)}
						allSelectionOnChange={allSelectionOnChange.bind(this)}
						deleteCallback={deleteCallback.bind(this)}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				}
				if (_key === AppParams.PRODUCT_TYPE) {
					return 'VERIFICATIONPLUSAGGR'
				}
			})
			renderComponent()
		})
		expect(container.find('div.account-list-view')).toHaveLength(0)
		expect(container.find('div.account-summary-title-view')).toHaveLength(1)
		expect(container.find('div.enable-all-accounts-view')).toHaveLength(0)
	})

	it('Check if container list view is loaded with no accounts having appflow aggr', () => {
		navigate = false
		selectedAccounts = []
		verifiedAccounts = []
		containerAccountList = {}
		appflow = 'AGGR'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<ContainerList
						containerList={accountsContainerList}
						selectedAccounts={selectedAccounts}
						verifiedAccounts={verifiedAccounts}
						currentProvider={currentProvider}
						containerAccountList={containerAccountList}
						selectionOnChange={selectionOnChange.bind(this)}
						allSelectionOnChange={allSelectionOnChange.bind(this)}
						deleteCallback={deleteCallback.bind(this)}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				}
				if (_key === AppParams.PRODUCT_TYPE) {
					return 'VERIFICATIONPLUSAGGR'
				}
			})
			renderComponent()
		})
		expect(container.find('div.account-list-view')).toHaveLength(0)
		expect(container.find('div.account-summary-title-view')).toHaveLength(1)
		expect(container.find('div.enable-all-accounts-view')).toHaveLength(0)
	})

	it('Check if container list view is loaded with accounts having appflow verification with no verified accounts', () => {
		navigate = false
		selectedAccounts = []
		verifiedAccounts = []
		appflow = 'VERIFICATION'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<ContainerList
						containerList={accountsContainerList}
						selectedAccounts={selectedAccounts}
						verifiedAccounts={verifiedAccounts}
						currentProvider={currentProvider}
						containerAccountList={containerAccountList}
						selectionOnChange={selectionOnChange.bind(this)}
						allSelectionOnChange={allSelectionOnChange.bind(this)}
						deleteCallback={deleteCallback.bind(this)}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return []
				}
				if (_key === AppParams.PRODUCT_TYPE) {
					return 'VERIFICATIONPLUSAGGR'
				}
			})
			renderComponent()
		})
		expect(container.find('div.account-list-view')).toHaveLength(1)
		expect(container.find('div.account-summary-title-view')).toHaveLength(1)
		expect(container.find('div.enable-all-accounts-view')).toHaveLength(0)
	})

	it('Check if container list view is loaded with accounts having appflow and product type aggr', () => {
		navigate = false
		selectedAccounts = []
		verifiedAccounts = []
		appflow = 'AGGR'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<ContainerList
						containerList={accountsContainerList}
						selectedAccounts={selectedAccounts}
						verifiedAccounts={verifiedAccounts}
						currentProvider={currentProvider}
						containerAccountList={containerAccountList}
						selectionOnChange={selectionOnChange.bind(this)}
						allSelectionOnChange={allSelectionOnChange.bind(this)}
						deleteCallback={deleteCallback.bind(this)}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				}
				if (_key === AppParams.PRODUCT_TYPE) {
					return 'AGGR'
				}
			})
			renderComponent()
		})
		expect(container.find('div.account-list-view')).toHaveLength(1)
		expect(container.find('div.account-summary-title-view')).toHaveLength(1)
		expect(container.find('div.enable-all-accounts-view')).toHaveLength(0)
	})

	it('Check if container list view is loaded with app flow verification and vrrified accounts', () => {
		navigate = false
		selectedAccounts = []
		verifiedAccounts = []
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<ContainerList
						containerList={accountsContainerList}
						selectedAccounts={selectedAccounts}
						verifiedAccounts={verifiedAccounts}
						currentProvider={currentProvider}
						containerAccountList={containerAccountList}
						selectionOnChange={selectionOnChange.bind(this)}
						allSelectionOnChange={allSelectionOnChange.bind(this)}
						deleteCallback={deleteCallback.bind(this)}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				}
				if (_key === AppParams.PRODUCT_TYPE) {
					return 'VERIFICATION'
				}
			})
			renderComponent()
		})
		expect(container.find('div.account-list-view')).toHaveLength(1)
		expect(container.find('div.account-summary-title-view')).toHaveLength(1)
		expect(container.find('div.enable-all-accounts-view')).toHaveLength(0)
	})

	it('Check if container list view is loaded with one account', () => {
		navigate = false
		selectedAccounts = []
		containerAccountList = {
			bank: [
				{
					accountType: 'Savings',
					accountNumber: '12345',
					accountName: 'Test account3',
					amount: 12.34,
					currency: 'USD',
					negativeCurrency: true,
					id: 1
				}
			]
		}
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<ContainerList
						containerList={accountsContainerList}
						selectedAccounts={selectedAccounts}
						currentProvider={currentProvider}
						containerAccountList={containerAccountList}
						selectionOnChange={selectionOnChange.bind(this)}
						allSelectionOnChange={allSelectionOnChange.bind(this)}
						deleteCallback={deleteCallback.bind(this)}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				}
				if (_key === AppParams.PRODUCT_TYPE) {
					return 'VERIFICATIONPLUSAGGR'
				}
			})
			renderComponent()
		})
		expect(container.find('div.account-list-view')).toHaveLength(1)
		expect(container.find('div.account-summary-title-view')).toHaveLength(1)
		expect(container.find('div.enable-all-accounts-view')).toHaveLength(0)
	})

	it('Check if container list view is loaded with accounts having appflow verification with muti account select', () => {
		navigate = false
		selectedAccounts = []
		verifiedAccounts = []
		appflow = 'VERIFICATION'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<ContainerList
						containerList={accountsContainerList}
						selectedAccounts={selectedAccounts}
						verifiedAccounts={verifiedAccounts}
						currentProvider={currentProvider}
						containerAccountList={containerAccountList}
						selectionOnChange={selectionOnChange.bind(this)}
						allSelectionOnChange={allSelectionOnChange.bind(this)}
						deleteCallback={deleteCallback.bind(this)}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				}
				if (_key === AppParams.PRODUCT_TYPE) {
					return 'VERIFICATIONPLUSAGGR'
				}
				if (_key === AppParams.SUCCESS_ACCOUNT_SELECTION_TYPE) {
					return AppConstants.VERIFICATION_MULTI_ACCOUNT_SELECTION
				}
			})
			renderComponent()
		})
		expect(container.find('div.account-list-view')).toHaveLength(1)
		expect(container.find('div.account-summary-title-view')).toHaveLength(1)
		expect(container.find('div.enable-all-accounts-view')).toHaveLength(1)
	})
	it('Check if container list view is loaded with accounts having appflow aggregation with muti account select', () => {
		navigate = false
		selectedAccounts = []
		verifiedAccounts = []
		appflow = 'AGGR'
		let renderComponent = () => {
			let store = mockStore({
				search: { providers: [] }
			})
			container = mount(
				<Provider store={store}>
					<ContainerList
						containerList={accountsContainerList}
						selectedAccounts={selectedAccounts}
						verifiedAccounts={verifiedAccounts}
						currentProvider={currentProvider}
						containerAccountList={containerAccountList}
						selectionOnChange={selectionOnChange.bind(this)}
						allSelectionOnChange={allSelectionOnChange.bind(this)}
						deleteCallback={deleteCallback.bind(this)}
						appflow={appflow}
					/>
				</Provider>
			)
		}
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key === AppParams.VERIFICATION_ELIGBLE_CONTAINERS) {
					return ['bank']
				}
				if (_key === AppParams.PRODUCT_TYPE) {
					return 'VERIFICATIONPLUSAGGR'
				}
				if (_key === AppParams.SUCCESS_ACCOUNT_SELECTION_TYPE) {
					return AppConstants.VERIFICATION_MULTI_ACCOUNT_SELECTION
				}
			})
			renderComponent()
		})
		expect(container.find('div.account-list-view')).toHaveLength(1)
		expect(container.find('div.account-summary-title-view')).toHaveLength(1)
		expect(container.find('div.enable-all-accounts-view')).toHaveLength(0)
	})
})
