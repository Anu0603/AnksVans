import React from 'react'
import { Provider } from 'react-redux'
import configureStore from 'redux-mock-store'
import Account from '../../../sections/accounts/Account'

const mockStore = configureStore([])

describe('spinning message view', () => {
	let container = null
	let props = {}
	beforeEach(() => {
		container = null
	})

	let renderComponent = () => {
		let store = mockStore({})
		container = mount(
			<Provider store={store}>
				<Account {...props} />
			</Provider>
		)
	}

	it('Check if account is loaded with account type', () => {
		props.currentProvider = {}
		props.currentProvider.hexCode1 = '404040'
		props.accountType = 'Savings'
		props.accountNumber = '1234'
		props.accountName = 'Test account'
		props.amount = 2.34
		props.currency = 'USD'
		props.negativeCurrency = true

		act(() => {
			renderComponent()
		})
		expect(container.find('div.list-title').text()).toEqual('Test account')
		expect(container.find('div.list-sub-title').text()).toEqual(
			'savings | 1234'
		)
	})
	it('Check if account is loaded without account type', () => {
		props.currentProvider = {}
		props.currentProvider.hexCode1 = '404040'
		props.accountType = ''
		props.accountNumber = '1234'
		props.accountName = 'Test account'
		props.amount = 2.34
		props.currency = 'USD'
		props.negativeCurrency = true

		act(() => {
			renderComponent()
		})
		expect(container.find('div.list-title').text()).toEqual('Test account')
		expect(
			container
				.find('div.list-sub-title')
				.text()
				.trim()
		).toEqual('1234')
	})
})
