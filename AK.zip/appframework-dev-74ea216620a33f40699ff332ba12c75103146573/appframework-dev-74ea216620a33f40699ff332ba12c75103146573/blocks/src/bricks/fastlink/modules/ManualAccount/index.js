import React, { Component } from 'react'
import PropTypes from 'prop-types'
import LandingView from './views/LandingView'
import SuccessView from './views/SuccessView'

class ManualAccountModule extends Component {
	constructor(props) {
		super(props)
		this.state = {
			currentView: this.props.currentView,
			data: this.props.data
		}
	}

	static propTypes = {
		currentView: PropTypes.string,
		data: PropTypes.object
	}

	static defaultProps = {
		currentView: 'MA_LANDING_VIEW', // MA_LANDING_VIEW | MA_SUCCESS,
		data: {}
	}

	componentDidMount() {}

	onShowNextView(_viewName, _options) {
		console.log(_viewName, _options)
		this.setState({
			currentView: _viewName,
			data: _options
		})
	}

	renderManualAccountView() {
		let View = null

		switch (this.state.currentView) {
			case 'MA_SUCCESS':
				View = SuccessView
				break

			case 'MA_LANDING_VIEW':
			default:
				View = LandingView
		}

		return (
			<View
				navigate={this.props.navigate}
				data={this.state.data}
				showNextView={this.onShowNextView.bind(this)}
			/>
		)
	}

	render() {
		return (
			<div id={'manual-account-container'} className="manual-acct">
				{this.renderManualAccountView()}
			</div>
		)
	}
}

export default ManualAccountModule
