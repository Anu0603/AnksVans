/**
 * This file is the Entry point for the FastLink Container
 */
import React, { Component, Suspense } from 'react'
import Navigator from './router/Navigator'
import CONSTANTS from './router/Constant'
import { connect } from 'react-redux'

import { Icon, IconNameMap } from '@framework/react/components/Icon'
import SiteLogo from './components/SiteLogo'
import { Spinner } from '@framework/react/components/Spinner'
import { Modal } from '../../../../blocks/src/framework/react/components/Modal'
import { Button } from '@framework/react/components/Button'
import { Link } from '@framework/react/components/Link'
import ProviderAccountService from '../../../src/bricks/fastlink/services/provider/ProviderAccountService'
import { AppStrings, getString } from '../../bricks/fastlink/conf'
import Postmessage from '@fastlinkRoot/components/ExternalNotification'
import './utils/Utilities'
import './style/fastlink.scss'
import Filter from '@fastlinkRoot/filters/Filter'
import ErrorBoundary from '@fastlinkRoot/components/Error/ErrorBoundary'

const defaultState = {
	routeName: CONSTANTS.ROUTE_LANDING_MODULE,
	data: null,
	showHeader: true
}

class FastLinkContainer extends Component {
	constructor(props) {
		super(props)
		this.backIconRef = React.createRef()
		this.event = null
		this.state = Filter.doFilter(defaultState)
	}

	handleNavigatePress(routeName, data) {
		switch (routeName) {
			case CONSTANTS.ROUTE_LANDING_MODULE:
				this.props.resetProviderdetails()
				this.props.resetRefreshdetails()
				this.props.resetAcountshdetails()
				break

			case CONSTANTS.ROUTE_LOGIN_MODULE:
				this.props.resetRefreshdetails()
				break

			case CONSTANTS.ROUTE_CDV_MODULE:
				this.props.resetProviderdetails()
				this.props.resetRefreshdetails()
				this.props.resetAcountshdetails()
				this.props.resetCDVerificationInfodetails()
				break

			case CONSTANTS.ROUTE_ERROR_MODULE:
				this.props.resetRefreshdetails()
				break

			case CONSTANTS.ROUTE_ACCOUNT_SUMMARY_MODULE:
				data.backIcon = this.backIconRef
				break
		}
		this.setState({
			routeName: routeName,
			data: data,
			popUpVisible: false
		})
	}

	handleCloseAppHandler(event) {
		this.event = event

		if (
			Application.Wrapper.closeAplication(
				Postmessage.getNotificationData(),
				this.event
			)
		) {
			//alert("Ji");
		}
	}

	handleToggleheader(isShow) {
		this.setState({
			showHeader: isShow ? true : false
		})
	}

	componentDidMount() {
		this.backIconRef = React.createRef()
	}
	componentDidUpdate() {
		this.backIconRef = React.createRef()
	}

	displayHeader() {
		let header = null
		if (this.state.showHeader) {
			header = (
				<div
					id={'fastlink-header-wrap'}
					className="header-action-wrapper"
				>
					<div
						id={'header-back-btn-container'}
						className="icon-button"
					>
						{this.displybackIcon()}
					</div>
					<div
						id={'header-close-btn-container'}
						className="icon-button"
					>
						{this.displayCloseIcon()}
					</div>
				</div>
			)
		}
		return header
	}

	displybackIcon() {
		let backIcon = null
		switch (this.state.routeName) {
			case CONSTANTS.ROUTE_LOGIN_MODULE:
			case CONSTANTS.ROUTE_CDV_MODULE:
			case CONSTANTS.ROUTE_REAL_ESTATE_MODULE:
			case CONSTANTS.ROUTE_MANUAL_ACCOUNT_MODULE:
			case CONSTANTS.ROUTE_MFA_MODULE:
				backIcon = (
					<Icon
						type="fal"
						iconClass={IconNameMap['chevron-left']}
						onClick={this.navigateToLandingPage.bind(this)}
					/>
				)
				break
			case CONSTANTS.ROUTE_ACCOUNT_SUMMARY_MODULE:
				backIcon = (
					<Icon
						iconRef={this.backIconRef}
						type="fal"
						iconClass={IconNameMap['chevron-left']}
					/>
				)
				break
		}
		return backIcon
	}

	displayCloseIcon() {
		let closeIcon = null
		switch (this.state.routeName) {
			case CONSTANTS.ROUTE_ACCOUNT_SUMMARY_MODULE:
				closeIcon = ''
				break
			default:
				closeIcon = (
					<Link
						onClick={this.crossIconhandler}
						lable={
							<Icon type="fal" iconClass={IconNameMap.close} />
						}
					></Link>
				)
		}
		return closeIcon
	}

	displayModalPopUpOnClose = () => {
		if (
			this.state.popUpVisible &&
			this.state.routeName === CONSTANTS.ROUTE_VERIFICATION_MODULE
		) {
			return (
				<Modal
					backDropEnabled={true}
					onBackDropClick={this.popUpCloseHandler}
					show={
						this.state.popUpVisible &&
						this.state.routeName ===
							CONSTANTS.ROUTE_VERIFICATION_MODULE
					}
					crossIconEnabled={true}
					className="small"
					onCrossIconClick={this.popUpCloseHandler}
				>
					<div
						className="txt-center"
						style={{
							color: this.props.currentProvider.hexCode1
						}}
					>
						<div>
							{' '}
							{getString(AppStrings.POPUP_ACCOUNT_NOT_LINK)}{' '}
							{getString(AppStrings.POPUP_EXIT_CONFIRMTION)}{' '}
						</div>
					</div>
					<div className="modal-button-wrapper">
						<Button
							classes="continue__ButtonPopUp"
							size="md"
							variant="primary"
							fullWidth={true}
							onClick={this.backToApplication}
							label={getString(AppStrings.POPUP_CONTINUE)}
						></Button>
						<Button
							classes="exit__ButtonPopUp"
							size="md"
							variant="danger"
							reversed={true}
							fullWidth={true}
							onClick={this.closeApplication}
							label={getString(AppStrings.POPUP_EXIT)}
						></Button>
					</div>
				</Modal>
			)
		}
	}

	crossIconhandler = event => {
		this.event = event
		if (this.state.routeName === CONSTANTS.ROUTE_VERIFICATION_MODULE) {
			this.setState({
				popUpVisible: true
			})
		} else {
			this.closeApplication(event)
		}
	}

	popUpCloseHandler = () => {
		this.setState({
			popUpVisible: false
		})
	}

	hnadleDeleteCallback = (error, res) => {}

	closeApplication = event => {
		this.event = event
		if (
			this.props.refresh.providerAccountId >= 0 &&
			!this.props.refresh.successRefreshView
		) {
			const providerAccountService = new ProviderAccountService()
			providerAccountService.deleteProviderAccount(
				{
					providerAccountId: this.props.refresh.providerAccountId
				},
				this.hnadleDeleteCallback.bind(this)
			)
			Postmessage.addUpdateProviderAccountsData({
				status: 'DELETED',
				reason:
					'User canceled the linking process confirming account deletion.',
				requestId: this.props.refresh.requestId,
				// additionalStatus: "DELETED",
				providerAccountId: this.props.refresh.providerAccountId
			})
		}
		this.handleCloseAppHandler(this.event)
	}

	backToApplication = () => {
		this.setState({
			popUpVisible: false
		})
	}
	navigateToLandingPage() {
		this.handleNavigatePress(CONSTANTS.ROUTE_LANDING_MODULE, {})
	}

	displaySiteLogo() {
		if (
			this.props.currentProvider.id > 0 ||
			this.props.currentProvider.name
		) {
			return <SiteLogo {...this.props.currentProvider} />
		}
	}

	getBGColor() {
		let bgColor = null
		switch (this.state.routeName) {
			case CONSTANTS.ROUTE_LOGIN_MODULE:
			case CONSTANTS.ROUTE_VERIFICATION_MODULE:
			case CONSTANTS.ROUTE_MFA_MODULE:
			case CONSTANTS.ROUTE_ERROR_MODULE:
				if (this.props.currentProvider.id > 0) {
					bgColor = {
						backgroundColor: this.props.currentProvider.hexCode1
					}
				}
				break
		}
		return bgColor
	}

	getSpinnerColor() {
		let spinnerColor = null
		switch (this.state.routeName) {
			case CONSTANTS.ROUTE_LOGIN_MODULE:
			case CONSTANTS.ROUTE_VERIFICATION_MODULE:
			case CONSTANTS.ROUTE_MFA_MODULE:
			case CONSTANTS.ROUTE_ERROR_MODULE:
				if (this.props.currentProvider.id > 0) {
					spinnerColor = this.props.currentProvider.hexCode2
				}
				break
		}
		return spinnerColor
	}

	getSpinnerChildren() {
		let children
		switch (this.state.routeName) {
			case CONSTANTS.ROUTE_VERIFICATION_MODULE:
				children = (
					<div
						id="login-refresh-label"
						className="login-refresh-label"
					>
						{getString(AppStrings.VERIFICATION_LOGIN_STEPPER_TEXT)}
					</div>
				)
				break
		}
		return children
	}

	techDiffHandler(error) {
		this.handleNavigatePress(CONSTANTS.ROUTE_ERROR_MODULE, {
			...error,
			isTechDiff: true
		})
	}

	render() {
		return (
			<ErrorBoundary {...this.state.data}>
				<div id={'fastlink-container'}>
					{this.displayModalPopUpOnClose()}
					{this.displayHeader()}
					{this.displaySiteLogo()}
					<div
						id={'fastlink-modules-container'}
						className="flex-pane"
						style={this.getBGColor()}
					>
						<Suspense
							fallback={
								<Spinner
									id="largeSpinner"
									name="someButtonName"
									color={this.getSpinnerColor()}
									classes="aaa"
									size="lg"
									children={this.getSpinnerChildren()}
								/>
							}
						>
							<Navigator
								routeName={this.state.routeName}
								{...this.state.data}
								handleCloseAppHandler={this.handleCloseAppHandler.bind(
									this
								)}
								navigate={this.handleNavigatePress.bind(this)}
								toggleHeader={this.handleToggleheader.bind(
									this
								)}
								handleTechDiff={this.techDiffHandler.bind(this)}
							/>
						</Suspense>
					</div>
				</div>
			</ErrorBoundary>
		)
	}
}

const mapStateToProps = state => {
	return {
		currentProvider: state.currentProvider,
		refresh: state.refresh,
		deeplinkData: state.deeplink
	}
}

const mapDispatchToProps = dispatch => {
	return {
		resetProviderdetails: () =>
			dispatch({
				type: 'RESET_PROVIDER_DATA',
				payload: {}
			}),
		resetRefreshdetails: () =>
			dispatch({
				type: 'RESET_REFESH_DATA',
				payload: {}
			}),
		resetAcountshdetails: () =>
			dispatch({
				type: 'RESET_ACCOUNTS_DATA',
				payload: {}
			}),
		resetCDVerificationInfodetails: () =>
			dispatch({
				type: 'RESET_CDV_VERIFICATION_INFO',
				payload: {}
			})
	}
}
export default connect(mapStateToProps, mapDispatchToProps)(FastLinkContainer)
