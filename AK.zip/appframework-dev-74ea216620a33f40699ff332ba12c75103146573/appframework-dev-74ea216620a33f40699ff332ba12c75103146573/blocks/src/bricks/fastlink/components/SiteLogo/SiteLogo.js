import React, { useState } from 'react'
import './SiteLogo.scss'

const SiteLogo = props => {
	const [logoLoaded, setLogoLoaded] = useState(1)

	let handleImageErrored = () => {
		setLogoLoaded(0)
	}
	return (
		<div className="logo-wrapper" autoid="fl-container-sitelogo">
			<div className="provider-logo-container">
				{props.logo && logoLoaded ? (
					<img
						src={Application.Utilities.getSiteLogoResourceServiceURL(
							{
								siteId: props.id,
								url: props.logo
							}
						)}
						className="site-logo"
						onError={handleImageErrored.bind(this)}
						alt={props.name}
					/>
				) : props.name ? (
					<span className="provider-name text-capitalize">
						{props.name}
					</span>
				) : null}
			</div>
		</div>
	)
}
export default SiteLogo
