import React, { useState } from 'react'
import FormField from './FormFields'
import { Radio } from './../../../../framework/react/components/RadioButton'
import { AppStrings } from '../../conf'
import RadioGroup from './RadioGroup'

let ChoiceField = props => {
	let choiceFieldsRef = React.createRef(this)
	let hexCode1 = props.currentProvider.hexCode1
	let hexCode2 = props.currentProvider.hexCode2

	let displayChoiceFields = () => {
		return props.fieldList.map(element => {
			return displayField(element)
		})
	}

	const hideFieldStyle = {
		display: 'none'
	}

	const displayFieldStyle = {
		display: 'flex'
	}

	let showRadioOptionField = (event, data) => {
		let value = null
		if (data) {
			value = data.value
		}
		let refName = 'container-' + value
		if (choiceFieldsRef.current) {
			let radioWrapper = choiceFieldsRef.current.querySelectorAll(
				'.radio'
			)
			for (let i = 0; i <= radioWrapper.length - 1; i++) {
				hideDisplayElements(
					'container-' + radioWrapper[i].value,
					'display:none'
				)
			}
			hideDisplayElements(refName, 'display:flex')
		}
	}

	const hideDisplayElements = (refName, style) => {
		let enableFieldsRef = choiceFieldsRef.current.querySelector(
			'.' + refName
		)
		enableFieldsRef.style = style
	}

	let displayChoiceLabels = () => {
		let viewElement = (
			<RadioGroup
				stateChangeCallbackHandler={showRadioOptionField.bind(this)}
				option={props.labelList}
				fieldId={'choice-group'}
				name={props.name}
				label={FLUtil.getString(AppStrings.LOGIN_CHOOSE_ONE)}
				hexCode1={hexCode1}
				hexCode2={hexCode2}
			/>
		)
		return viewElement
	}

	let displayField = element => {
		return (
			<FormField
				key={element.id}
				fieldElement={element}
				currentProvider={props.currentProvider}
				inlineStyle={
					element.display ? displayFieldStyle : hideFieldStyle
				}
				stateChangeCallbackHandler={props.stateChangeCallbackHandler}
			/>
		)
	}

	return (
		<div ref={choiceFieldsRef} className="choice-field-wrapper">
			{displayChoiceLabels()}
			{displayChoiceFields()}
		</div>
	)
}
export default ChoiceField
