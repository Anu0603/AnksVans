import React from 'react'
import { Provider } from 'react-redux'

import TechnicalError from './../../TechnicalError/'
import configureStore from 'redux-mock-store'
import { getParam, AppParams } from '../../../../conf/'
const mockStore = configureStore([])

jest.mock('../../../../conf')

jest.mock('./../../ErrorPage', props => {
	return {
		__esModule: true,
		default: () => {
			return <div className="error-page"></div>
		}
	}
})

describe('TechnicalError Component', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	let renderComponent = props => {
		let store = mockStore({
			deeplink: props.deeplinkData
		})

		container = mount(
			<Provider store={store}>
				<TechnicalError />
			</Provider>
		)
	}

	it('Check whether Technical Error module is rendered in case of non deeplink flow', () => {
		act(() => {
			renderComponent({ deeplinkData: { isDeeplink: false } })
		})
		expect(container.find('div.tech-error-section')).toHaveLength(1)
		expect(container.find('div.error-page')).toHaveLength(1)
	})

	it('Check whether Technical Error module is rendered in case of deeplink flow', () => {
		act(() => {
			renderComponent({ deeplinkData: { isDeeplink: true } })
		})
		expect(container.find('div.tech-error-section')).toHaveLength(1)
		expect(container.find('div.error-page')).toHaveLength(1)
	})

	it('Check whether Spinner is shown if tech diff page is not enabled', () => {
		act(() => {
			getParam.mockImplementation(_key => {
				if (_key == AppParams.ENABLE_TECHDIFF_PAGE) {
					return false
				}
			})

			global.Application = {
				Wrapper: {
					getRequestParameter: _param => {
						switch (_param) {
							case 'callback':
								return 'http://wwww.google.com'
								break
						}
					},

					closeAplication: () => {}
				}
			}
			renderComponent({ deeplinkData: { isDeeplink: true } })
		})
		expect(container.find('div.tech-error-section')).toHaveLength(1)
		expect(container.find('div.tech-error-spinner')).toHaveLength(1)
	})
})
