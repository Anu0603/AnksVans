/*********
	As file name predicts, this JS file beign used for parsing YSL login form field
	and construct generic JSON, so template will use the render the HTMl code in UI side.
*/
var SiteLoginFormParser = function(options) {
	var loginForm = null
	var formatedFormFields = []
	var rows = null
	let formType = options.formType.toLowerCase()
	/**
	THis is main method to get formatted JSOn field and 
	receive the list of optins value along with YSL login form.
	*/
	var _getParserFormFieldsToDisplay = function() {
		loginForm = options.formComponents
		formatedFormFields = []
		_getLoginFormFields()
		return formatedFormFields
	}
	/****
	List through  the rows and construct generic JSON format.
	1. If field not choice field, add row as single row
	2. If field(s) are choice, group them using "fieldRowChoice" value of YSL response. 
		We are grouping choice label in one colleection and respective choice label 
		fields in another collection
	**/

	function checkValue(value, arr) {
		var status = false
		for (var i = 0; i < arr.length; i++) {
			var name = arr[i]
			if (name == value) {
				status = true
				break
			}
		}
		return status
	}

	var _getLoginFormFields = function() {
		var choiceGroupList = []
		if (typeof loginForm == 'undefined' || loginForm == '') {
			Logger.debug('YSL form is empty :')
			return choiceGroupList
		}
		rows = loginForm
		for (let index in rows) {
			var row = rows[index]
			if (row.fieldRowChoice.toLowerCase().indexOf('choice') == -1) {
				var rowJSON = _constructRow(row, false)
				formatedFormFields.push(rowJSON)
			} else if (!checkValue(row.fieldRowChoice, choiceGroupList)) {
				_constructChoiceFields(index, row.fieldRowChoice)
				choiceGroupList.push(row.fieldRowChoice)
			} else {
				continue
			}
		}
	}

	let _addLabel = (rowJSON, row) => {
		switch (formType) {
			case 'token':
			case 'questionandanswer':
			case 'image':
				rowJSON.label = row.label
				break
		}
	}

	let _changeFiledType = field => {
		switch (formType) {
			case 'token':
			case 'questionandanswer':
			case 'image':
				if (field.type == 'text') {
					field.type = 'password'
				}
				break
		}
	}

	let _addGhostText = (field, source) => {
		switch (formType) {
			case 'token':
				field.placeHolder = source.label
				if (field.type == 'password') {
					field.placeHolder = FLUtil.getString(
						AppStrings.SITE_LOGIN_FORM_PASSCODE_LABEL
					)
				}
				break
			case 'questionandanswer':
				field.placeHolder = source.label
				if (field.type == 'password') {
					field.placeHolder = FLUtil.getString(
						AppStrings.SITE_LOGIN_FORM_QA_LABEL
					)
				}
				break

			case 'image':
				field.placeHolder = FLUtil.getString(
					AppStrings.MFA_CAPTCHA_PLACEHOLDER
				)
				break

			case 'login':
				field.placeHolder = source.label
				break
		}
	}

	let _addOptionalText = (field, isChoice) => {
		if (field.isOptional && !isChoice) {
			field.placeHolder =
				field.placeHolder +
				' ' +
				FLUtil.getString(AppStrings.LOGIN_OPTIONAL_TEXT)
		}
	}

	var _constructRow = function(row, isChoice) {
		var rowJSON = {}
		rowJSON.type = 'singleField'
		rowJSON.gridColumn = 'col-' + 12 / row.field.length

		_addLabel(rowJSON, row)

		rowJSON.field = row.field
		var values = []
		var end = rowJSON.field.length - 1
		for (let fieldIndex in rowJSON.field) {
			values.push(rowJSON.field[fieldIndex].id)
			_changeFiledType(rowJSON.field[fieldIndex])
			if (fieldIndex == 0) {
				_addGhostText(rowJSON.field[fieldIndex], row)
				_addOptionalText(rowJSON.field[fieldIndex], isChoice)
			}
			if (end >= 1 && fieldIndex != end) {
				rowJSON.field[fieldIndex].separator = true
			}
			if (isChoice) {
				rowJSON.field[fieldIndex].isOptional = true
				rowJSON.field[fieldIndex].className = 'choiceFields'
			}

			if (rowJSON.isSelected) {
				rowJSON.selected = rowJSON.isSelected == 'true'
				delete rowJSON.isSelected
			}

			_updateOptions(rowJSON, fieldIndex)
			// remove the value for questionandanswer MFA type //
			if (formType == 'questionandanswer') {
				rowJSON.field[fieldIndex].value = null
			}
		}
		rowJSON.id = row.id
		return rowJSON
	}

	//Format the options as per component accepted format - Dropdown component
	function _updateOptions(rowJSON, fieldIndex) {
		let _rowOptions = rowJSON.field[fieldIndex].option

		if (_rowOptions) {
			let _options = [
				{
					optionValue: '',
					displayText: rowJSON.field[fieldIndex].placeHolder
				}
			]
			if (
				rowJSON.field[fieldIndex].type == 'radio' ||
				formType != 'login'
			) {
				_options.pop()
			}
			let _selected = false

			for (let index in _rowOptions) {
				_rowOptions[index].selected =
					_rowOptions[index].isSelected == 'true'
				delete _rowOptions[index].isSelected
				if (!_selected && _rowOptions[index].selected) {
					_selected = _rowOptions[index].selected
				}
				_options.push(_rowOptions[index])
			}

			if (!_selected) {
				_options[0].selected = true
			}
			delete rowJSON.field[fieldIndex].option
			rowJSON.field[fieldIndex].options = _options
		}
	}

	var _constructChoiceLabel = function(row) {
		var rowJSON = {}
		rowJSON.label = row.label
		rowJSON.id = row.id
		rowJSON.checked = false
		rowJSON.name = 'radio_'
		rowJSON.displayText = row.label
		rowJSON.optionValue = row.id
		for (let fieldIndex in row.field) {
			var field = row.field[fieldIndex]
			if (field.hasOwnProperty('value') && field.value) {
				rowJSON.selected = true
			}
		}
		rowJSON.name =
			rowJSON.name + row.fieldRowChoice.replace(/ /g, '_').toLowerCase()
		return rowJSON
	}
	/**
		Grouping choice form fields
			- sub grpoup: labels - one row
			- Sub group: respective fields - one row
	**/
	var _constructChoiceFields = function(index, choiceGroup) {
		let choiceLabelList = []
		let choiceLabelListObj = {}
		let choiceFieldList = []
		let isOptionFieldChcked = false
		for (let i = index; i < rows.length; i++) {
			let row = rows[i]
			if (row.fieldRowChoice == choiceGroup) {
				let choiceLabel = _constructChoiceLabel(row)
				choiceLabelList.push(choiceLabel)
				let rowJSON = _constructRow(row, true)
				rowJSON.display = choiceLabel.selected
				choiceFieldList.push(rowJSON)
				if (choiceLabel.selected) {
					isOptionFieldChcked = choiceLabel.selected
				}
			}
		}
		// None of field is selected, make first element and correspanding element visisble to  user.
		if (!isOptionFieldChcked && choiceLabelList[0] && choiceFieldList[0]) {
			choiceLabelList[0].selected = true
			choiceFieldList[0].display = true
		}
		choiceLabelListObj.type = 'choiceLabel'
		choiceLabelListObj.name = choiceLabelList[0].name
		choiceLabelListObj.labelList = choiceLabelList
		choiceLabelListObj.fieldList = choiceFieldList
		formatedFormFields.push(choiceLabelListObj)
	}
	return {
		getParserFormFieldsToDisplay: _getParserFormFieldsToDisplay
	}
}

export default SiteLoginFormParser
