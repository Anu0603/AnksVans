import React from 'react'
import ChoiceFormField from '../ChoiceFormField'

import ChoiceFieldData from './__mocks__/ChoiceFieldData.json'

describe('Choice field Module', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	let renderComponent = () => {
		container = mount(
			<ChoiceFormField
				{...ChoiceFieldData}
				stateChangeCallbackHandler={function() {}}
			/>
		)
	}

	it('Check whether Choice field module rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('div.choice-field-wrapper')).toHaveLength(1)
	})

	it('Count number of radio elements', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('input')).toHaveLength(5)
	})

	it('Check if onChange prop is called', () => {
		const onChangeMock = jest.fn()
		const event = { preventDefault() {}, target: { value: 'test' } }
		act(() => {
			container = mount(
				<ChoiceFormField {...ChoiceFieldData} onChange={onChangeMock} />
			)
		})
		container
			.find('input')
			.at(0)
			.simulate('change', event)
		// To be fixed: Read the value from lock data
		expect(
			container
				.find('.container-' + ChoiceFieldData.labelList[0].id)
				.prop('style')
		).toHaveProperty('display', 'flex')
	})
})
