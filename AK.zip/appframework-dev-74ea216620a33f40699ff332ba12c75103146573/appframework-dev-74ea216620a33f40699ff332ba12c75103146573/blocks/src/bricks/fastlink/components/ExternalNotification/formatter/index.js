import Version1 from './V1'
//import Version2 from './V2'

const Formatter = store => {
	let version = new Version1(store)
	let notification_version = BrandUtils.getParam(
		'postmessage_notification',
		'fastlink'
	)
	if (notification_version == 'V2') {
		//version = new Version2(store)
	}
	let formatData = data => {
		return version.formatData(data)
	}

	let getNotificationData = () => {
		return version.getNotificationData()
	}

	let sendInstantNotification = data => {
		return version.sendInstantNotification(data)
	}

	return {
		getNotificationData,
		formatData,
		sendInstantNotification
	}
}

export default Formatter
