import React from 'react'
import {
	TextField,
	PasswordField
} from './../../../../framework/react/components/InputField'
import DropDown from './../../../../framework/react/components/Dropdown'
import { Radio } from './../../../../framework/react/components/RadioButton'
import {
	getString,
	AppStrings,
	AutoIds,
	getParam,
	AppParams
} from './../../conf'
import RadioGroup from './RadioGroup'
import classNames from 'classnames'

let FormField = props => {
	let hexCode1 = props.currentProvider.hexCode1
	let hexCode2 = props.currentProvider.hexCode2
	const getFiledsProps = (props, element) => {
		let fieldRefClsName = 'fieldId-' + props.fieldElement.id

		let _inputClass = classNames(
			props.classNames && props.classNames,
			element.className && element.className,
			fieldRefClsName
		)

		let inputProps = {
			value: element.value,
			large: true,
			placeholder: element.placeHolder,
			inputclass: _inputClass,
			name: element.name,
			'data-id': element.id,
			id: 'fieldid-' + element.id,
			key: element.id,
			// allowCopyPaste: getParam(AppParams.LOGIN_ALLOW_COPY_PASTE),
			onChange: props.stateChangeCallbackHandler,
			onFocus: onSiteElementsFocus.bind(this),
			onBlur: onSiteElementsBlur.bind(this)
		}
		if (element.maxLength) {
			inputProps.maxLength = element.maxLength
		}

		if (element.value) {
			props.stateChangeCallbackHandler(null, {
				'data-id': element.id,
				value: element.value
			})
		}

		if (props.fieldElement.label) {
			inputProps.label = props.fieldElement.label
		}

		if (element.error) {
			inputProps.error = true
			inputProps.errorMessage = getString('field_inline_error_message')
		}

		return inputProps
	}

	const onSiteElementsFocus = event => {
		if (event.target instanceof HTMLAnchorElement) {
			event.target.style.outlineColor = hexCode2
		} else {
			event.target.style.borderColor = hexCode2
		}
	}

	const onSiteElementsBlur = event => {
		if (event.target instanceof HTMLAnchorElement) {
			event.target.style.outlineColor = 'inherit'
		} else {
			event.target.style.borderColor = 'inherit'
		}
	}

	const getMfaCaptcha = element => {
		if (element.id == 'image') {
			let captcha = 'data:image/jpeg;base64,' + element.image
			return (
				<div className="col-12 mfa-captch-wrapper">
					<img src={captcha} alt={'Captcha'} />
				</div>
			)
		}
	}

	const getSeparator = displaySeparator => {
		if (displaySeparator) {
			// return <span>-</span>;
		}
	}

	let handleDropDownSelection = (event, selectedOption) => {
		let selectedData = {
			'data-id': selectedOption['data-id'],
			value: selectedOption.value.optionValue
		}
		props.stateChangeCallbackHandler(null, selectedData)
	}

	let displayField = () => {
		let inlineStyle = props.inlineStyle
		let containerClass = 'container-' + props.fieldElement.id
		let temp
		let fieldViewList = props.fieldElement.field.map((element, index) => {
			if (element.placeHolder) {
				temp = element.placeHolder
			} else {
				element.placeHolder = temp
			}
			const inputProps = getFiledsProps(props, element)
			let viewElement = null

			switch (element.type) {
				case 'text':
					viewElement = <TextField {...inputProps} />
					break

				case 'password':
					viewElement = (
						<PasswordField
							showPassword={true}
							allowCopyPaste={getParam(
								AppParams.LOGIN_ALLOW_COPY_PASTE
							)}
							{...inputProps}
						/>
					)
					break

				case 'option':
				case 'options':
					element['data-id'] = element.id
					element.onChange = handleDropDownSelection.bind(this)
					for (let keyname in element.options) {
						if (element.options[keyname].selected) {
							props.stateChangeCallbackHandler(null, {
								'data-id': element.id,
								value: element.options[keyname].optionValue
							})
							break
						}
					}
					viewElement = (
						<DropDown
							key="text"
							{...element}
							key={element.id}
							htmlId={element.id + ''}
							labelText={props.fieldElement.label}
							onFocus={onSiteElementsFocus.bind(this)}
							onBlur={onSiteElementsBlur.bind(this)}
						/>
					)
					break

				case 'radio':
					viewElement = (
						<RadioGroup
							stateChangeCallbackHandler={
								props.stateChangeCallbackHandler
							}
							option={element.options}
							fieldId={element.id}
							name={element.name}
							label={props.fieldElement.label}
							hexCode1={hexCode1}
							hexCode2={hexCode2}
						/>
					)
			}

			return (
				<React.Fragment key={element.id}>
					{getMfaCaptcha(element)}
					<div className={props.fieldElement.gridColumn}>
						{viewElement}
						{getSeparator(element.separator)}
					</div>
				</React.Fragment>
			)
		})

		return (
			<div className={containerClass} style={inlineStyle}>
				{fieldViewList}
			</div>
		)
	}

	return <React.Fragment key={props.id}>{displayField()}</React.Fragment>
}
export default FormField
