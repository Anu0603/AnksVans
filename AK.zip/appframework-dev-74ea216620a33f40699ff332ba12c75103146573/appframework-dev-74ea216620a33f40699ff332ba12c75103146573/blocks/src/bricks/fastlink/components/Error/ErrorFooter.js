import React from 'react'
import CDVModule from './../../../fastlink/modules/CDV'
import AppConstants from '../../../fastlink/conf/constants/AppConstants'
import { AppParams, getParam } from '../../../fastlink/conf'

const ErrorFooter = props => {
	let cdvEnabled = getParam(AppParams.ENABLE_CDV),
		isCDVPreVerificationInvokeError = getParam(
			AppParams.CDV_PRE_VERIFICATION_INVOKE_ENABLED_ERRORS
		).includes(props.errorCode),
		isCDVPostVerificationInvokeError = getParam(
			AppParams.CDV_POST_VERIFICATION_INVOKE_ENABLED_ERRORS
		).includes(props.errorCode)
	let showCDVForError =
		cdvEnabled &&
		(isCDVPreVerificationInvokeError || isCDVPostVerificationInvokeError)

	return showCDVForError ? (
		<div className="cdv-error-container">
			<CDVModule
				navigate={props.navigate}
				provider={props.site}
				path={AppConstants.CDV_PATH_INVOKE}
				subPath={
					isCDVPreVerificationInvokeError
						? AppConstants.CDV_SUB_PATH_INVOKE_PRE_VERIFICATION
						: AppConstants.CDV_SUB_PATH_INVOKE_POST_VERIFICATION
				}
			/>
		</div>
	) : null
}

export default ErrorFooter
