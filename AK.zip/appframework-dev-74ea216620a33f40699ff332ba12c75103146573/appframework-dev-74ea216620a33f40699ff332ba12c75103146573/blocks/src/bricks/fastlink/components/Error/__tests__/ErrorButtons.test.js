import React from 'react'
import ErrorButtons from '../ErrorButtons'
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import ProviderData from '../__mocks__/provider'
import { AppStrings, getString, getParam, AppParams } from './../../../conf'

jest.mock('./../../../conf')
const mockStore = configureStore([])

describe('Error Page Section', () => {
	window.open = jest.fn()
	let container = null
	beforeEach(() => {
		container = null

		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.ERROR_INCORRECT_CREDENTIALS_TITLE:
					return 'Incorrect Credentials'
					break
				case AppStrings.ERROR_USER_ACTION_NEEDED_AT_SITE_TITLE:
					return 'Action Required at _SITE_NAME_'
					break
				case AppStrings.ERROR_DATA_NOT_AVAILABLE_TITLE:
					return 'Data is Unavailable'
					break
				case AppStrings.ERROR_SITE_NOT_SUPPORTED_TITLE:
				case AppStrings.ERROR_SITE_NOT_SUPPORTED_MANUAL_ACCOUNT_DISABLED_TITLE:
					return 'Site Unavailable'
					break
				case AppStrings.ERROR_EDIT_CRED_BUTTON_TEXT:
					return 'Edit Credentials'
					break
				case AppStrings.ERROR_CANCEL_BUTTON_TEXT:
					return 'Cancel'
					break
				case AppStrings.ERROR_LAA_BUTTON_TEXT:
					return 'Link Another Account'
					break
				case AppStrings.ERROR_TA_BUTTON_TEXT:
					return 'Try Again'
					break
				case AppStrings.ERROR_TECH_ERROR_TITLE:
					return 'Site Unavailable'
					break
				case AppStrings.ERROR_NEW_AUTHENTICATION_REQUIRED_TITLE:
					return 'New Authentication Required'
					break
				case AppStrings.ERROR_GENERIC_TITLE:
					break
					return 'Technical Error'
				default:
					break
			}
		})

		getParam.mockImplementation(_key => {
			switch (_key) {
				case AppParams.ERROR_INCORRECT_CREDENTIALS_BUTTONS:
					return 'EDIT_CRED,CANCEL'
					break
				case AppParams.ERROR_GENERIC_BUTTONS:
					return 'LAA'
					break
				case AppParams.ERROR_DATA_NOT_AVAILABLE_BUTTONS:
					return 'TA,LAA,CANCEL'
					break
				case AppParams.ERROR_SITE_NOT_SUPPORTED_BUTTONS:
					return 'MAA,LAA'
					break
				case AppParams.ERROR_SITE_NOT_SUPPORTED_MANUAL_ACCOUNT_DISABLED_BUTTONS:
					return 'LAA'
					break
				case AppParams.ERROR_TECH_ERROR_BUTTONS:
					return 'VS,SDS,CLOSE'
					break
				case AppParams.ERROR_NEW_AUTHENTICATION_REQUIRED_BUTTONS:
					return 'EC'
					break
				case AppParams.ERROR_DEEPLINK_TECH_DIFF_BUTTONS:
					return 'TECH_DIFF_CLOSE'
					break
				case AppParams.ERROR_TECH_DIFF_BUTTONS:
					return 'TECH_DIFF_CLOSE'
					break

				default:
					break
			}
		})
	})

	let renderComponent = props => {
		let store = mockStore({
			currentProvider: ProviderData.provider
		})
		container = mount(
			<Provider store={store}>
				<ErrorButtons
					{...props}
					currentProvider={ProviderData.provider}
					handleCloseAppHandler={() => {}}
				/>
			</Provider>
		)
	}

	it('Check whether error button component is rendered', () => {
		let props = { errorCode: 'INCORRECT_CREDENTIALS' }
		act(() => {
			renderComponent(props)
		})
		expect(container.find('.buttons-wrapper')).toHaveLength(1)
	})

	it('Check if <button> is rendered', () => {
		let props = { errorCode: 'INCORRECT_CREDENTIALS' }
		act(() => {
			renderComponent(props)
		})
		expect(container.find('button')).toHaveLength(2)
	})

	it('Check if generic buttons are rendered', () => {
		let props = { errorCode: 'GENERIC' }
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.btn-base').text()).toEqual(
			'Link Another Account'
		)
	})

	it('Check if button label is rendered', () => {
		let props = { errorCode: 'INCORRECT_CREDENTIALS' }
		act(() => {
			renderComponent(props)
		})
		expect(container.find('.err-primary').text()).toEqual(
			'Edit Credentials'
		)
		expect(container.find('.err-secondary').text()).toEqual('Cancel')
	})

	it('Check if tertiary button is rendered', () => {
		let props = { errorCode: 'DATA_NOT_AVAILABLE' }
		act(() => {
			renderComponent(props)
		})
		expect(container.find('button')).toHaveLength(3)
		expect(container.find('.err-tertiary')).toHaveLength(1)
	})

	it('Check if tertiary button label is rendered', () => {
		let props = { errorCode: 'DATA_NOT_AVAILABLE' }
		act(() => {
			renderComponent(props)
		})
		expect(container.find('.err-primary').text()).toEqual('Try Again')
		expect(container.find('.err-secondary').text()).toEqual(
			'Link Another Account'
		)
		expect(container.find('.err-tertiary').text()).toEqual('Cancel')
	})

	it('Check if SITE_NOT_SUPPORTED error status button action handlers are triggered correctly when manual account is disabled', () => {
		const onClickMock = jest.fn()

		getParam.mockImplementation(_key => {
			switch (_key) {
				case AppParams.ENABLE_MANUAL_ACCOUNT:
					return false
				case AppParams.ERROR_SITE_NOT_SUPPORTED_MANUAL_ACCOUNT_DISABLED_BUTTONS:
					return 'LAA'
				default:
					break
			}
		})

		let props = {
			errorCode: 'SITE_NOT_SUPPORTED',
			onClick: onClickMock,
			navigate: () => {}
		}
		act(() => {
			renderComponent(props)
		})

		container.find('.err-primary').simulate('click')
		// expect(onClickMock).toHaveBeenCalled()
	})

	it('Check if SITE_NOT_SUPPORTED error status button action handlers are triggered correctly when manual account is enabled', () => {
		const onClickMock = jest.fn()

		getParam.mockImplementation(_key => {
			switch (_key) {
				case AppParams.ENABLE_MANUAL_ACCOUNT:
					return true
				case AppParams.ERROR_SITE_NOT_SUPPORTED_BUTTONS:
					return 'MAA,LAA'
				default:
					break
			}
		})

		let props = {
			errorCode: 'SITE_NOT_SUPPORTED',
			onClick: onClickMock,
			navigate: () => {}
		}
		act(() => {
			renderComponent(props)
		})

		container.find('.err-primary').simulate('click')
		container.find('.err-secondary').simulate('click')
		// expect(onClickMock).toHaveBeenCalled()
	})

	it('Check if DATA_NOT_AVAILABLE error status button action handlers are triggered correctly', () => {
		const onClickMock = jest.fn()
		let props = {
			errorCode: 'DATA_NOT_AVAILABLE',
			onClick: onClickMock,
			navigate: () => {}
		}
		act(() => {
			renderComponent(props)
		})

		container.find('.err-primary').simulate('click')
		container.find('.err-secondary').simulate('click')
		container.find('.err-tertiary').simulate('click')
		// expect(onClickMock).toHaveBeenCalled()
	})

	it('Check if TECH_ERROR error status button action handlers are triggered correctly', () => {
		const onClickMock = jest.fn()
		let props = {
			errorCode: 'TECH_ERROR',
			onClick: onClickMock,
			navigate: () => {}
		}
		act(() => {
			renderComponent(props)
		})

		container.find('.err-primary').simulate('click')
		container.find('.err-secondary').simulate('click')
		container.find('.err-tertiary').simulate('click')
		// expect(onClickMock).toHaveBeenCalled()
	})

	it('Check if NEW_AUTHENTICATION_REQUIRED error status button action handlers are triggered correctly', () => {
		debugger
		const onClickMock = jest.fn()
		let props = {
			errorCode: 'NEW_AUTHENTICATION_REQUIRED',
			onClick: onClickMock,
			navigate: () => {}
		}
		act(() => {
			renderComponent(props)
		})

		container.find('.err-primary').simulate('click')

		// expect(onClickMock).toHaveBeenCalled()
	})

	it('Check if TECH_DIFF error status button action handlers are triggered correctly', () => {
		const onClickMock = jest.fn()
		let props = {
			errorCode: 'TECH_DIFF',
			onClick: onClickMock,
			navigate: () => {}
		}
		act(() => {
			renderComponent(props)
		})

		container.find('.err-primary').simulate('click')
	})

	it('Check if DEEPLINK_TECH_DIFF error status button action handlers are triggered correctly', () => {
		const onClickMock = jest.fn()
		let props = {
			errorCode: 'DEEPLINK_TECH_DIFF',
			onClick: onClickMock,
			navigate: () => {}
		}
		act(() => {
			renderComponent(props)
		})

		container.find('.err-primary').simulate('click')
	})
})
