import React, { Component } from 'react'
import TechnicalError from '@fastlinkRoot/components/Error/TechnicalError'
import TechErrorConstants from '../TechnicalError/TechErrorConstants'

class ErrorBoundary extends Component {
	constructor(props) {
		super(props)
		this.state = { errorCode: null }
	}

	static getDerivedStateFromError(error) {
		return { hasError: true }
	}

	componentDidCatch(error, errorInfo) {
		this.errorCode = error
		console.error(error)
	}

	render() {
		if (this.state.hasError) {
			return (
				<div>
					<TechnicalError
						{...this.props}
						code={TechErrorConstants.TECH_ERROR.code}
						message={TechErrorConstants.TECH_ERROR.message}
					/>
				</div>
			)
		}
		return this.props.children
	}
}

export default ErrorBoundary
