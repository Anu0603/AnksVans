export default {
	provider: {
		id: 9565,
		hexCode1: '#3E0046',
		hexCode2: '#40B8BD',
		name: 'Ally Bank',
		loginUrl: 'https://secure.ally.com/',
		favicon: 'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_9565.SVG',
		logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_9565_1_2.SVG',
		authType: 'MFA_CREDENTIALS',
		countryISOCode: 'US',
		formType: 'login',
		loginForm: [
			{
				id: 30879,
				label: 'Username',
				form: '0001',
				fieldRowChoice: '0001',
				field: [
					{
						id: 20687,
						name: 'LOGIN',
						size: 30,
						maxLength: 28,
						type: 'text',
						value: '',
						isOptional: false,
						valueEditable: true,
						placeHolder: 'Username'
					}
				]
			},
			{
				id: 23120,
				label: 'Security Password',
				form: '0001',
				fieldRowChoice: '0002',
				field: [
					{
						id: 20686,
						name: 'PASSWORD',
						size: 20,
						maxLength: 50,
						type: 'password',
						value: '',
						isOptional: false,
						valueEditable: true,
						placeHolder: 'Security Password'
					}
				]
			}
		],
		tncValue: 1,
		showTnc: true
	}
}
