const TechErrorConstants = {
	// GENERIC TECH ERROR
	TECH_ERROR: { code: 'E100', message: 'Internal Server Error.' },

	// DEEPLINK ERRORS
	DEEPLINK_INVALID_FLOW: {
		code: 'E700',
		message: 'Invalid value for flow'
	},
	DEEPLINK_INVALID_PROVIDER_ID: {
		code: 'E701',
		message: 'Invalid value for providerId'
	},
	DEEPLINK_INVALID_PROVIDER_ACCOUNT_ID: {
		code: 'E702',
		message: 'Invalid value for providerAccountId'
	},
	DEEPLINK_INVALID_ACCOUNT_ID: {
		code: 'E703',
		message: 'Invalid value for accountId'
	},
	DEEPLINK_INVALID_CONTAINER: {
		code: 'E704',
		message: 'Invalid value for container'
	},
	DEEPLINK_INVALID_BANK_TRANSFER_CODE: {
		code: 'E705',
		message: 'Invalid value for bankTransferCode'
	},

	// API FUNCTIONAL ERRORS
	GENERIC_API_ERROR: {
		code: 'E800',
		message: 'Generic API Error'
	},
	PROVIDER_NOT_SUPPORTED: {
		code: 'E801',
		message: 'Provider not supported'
	},
	INVALID_PROVIDER_ACCOUNT_ID: {
		code: 'E802',
		message: 'Invalid value for providerAccountId'
	},
	INVALID_OPERATION_PROVIDER_ACCOUNT_ID: {
		code: 'E803',
		message: 'Operation not allowed for providerAccountId'
	},
	INVALID_ACCOUNT_ID: {
		code: 'E804',
		message: 'Invalid value for accountId'
	},

	// SUPSCRIPTION ERRORS
	CDV_NOT_ENABLED: {
		code: 'E900',
		message: 'CDV feature is not enabled'
	},
	REAL_ESTATE_NOT_ENABLED: {
		code: 'E901',
		message: 'Real Estate feature is not enabled'
	},
	MANUAL_ACCOUNTS_NOT_ENABLED: {
		code: 'E902',
		message: 'Manual Accounts feature is not enabled'
	},

	API_TYPE: {
		PROVIDER_DETAILS: 'PROVIDER_DETAILS',
		PROVIDER_ACCOUNT_DETAILS: 'PROVIDER_ACCOUNT_DETAILS',
		VERIFICATION_INFO: 'VERIFICATION_INFO'
	},

	getAPIError(errorResponse, apiType) {
		let code =
			errorResponse && errorResponse.errorCode
				? errorResponse.errorCode
				: null

		switch (code) {
			case 'Y821':
				return this.PROVIDER_NOT_SUPPORTED

			case 'Y807':
				return this.INVALID_PROVIDER_ACCOUNT_ID

			case 'Y800':
				if (apiType == this.API_TYPE.VERIFICATION_INFO) {
					return this.INVALID_ACCOUNT_ID
				} else {
					return this.INVALID_PROVIDER_ACCOUNT_ID
				}

			default:
				return this.GENERIC_API_ERROR
		}
	},

	getErrorType(code) {
		let numCode = code.substring(1)
		if (numCode) {
			if ((numCode >= 900) & (numCode < 999)) {
				return 'PARAMETER_VALUE_INELIGIBLE'
			} else if ((numCode >= 700) & (numCode < 900)) {
				return 'INVALID_PARAMETER_OR_VALUE'
			} else {
				return 'TECH_ERROR'
			}
		}
	}
}

export default TechErrorConstants
