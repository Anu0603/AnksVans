import TechErrorConstants from '../../../../components/Error/TechnicalError/TechErrorConstants'

describe('TechErrorConstants Test Case', () => {
	beforeEach(() => {})

	it('Check if getAPIError returns proper API Errors based on error code', () => {
		expect(TechErrorConstants.getAPIError({ errorCode: 'Y821' })).toEqual(
			TechErrorConstants.PROVIDER_NOT_SUPPORTED
		)
		expect(TechErrorConstants.getAPIError({ errorCode: 'Y807' })).toEqual(
			TechErrorConstants.INVALID_PROVIDER_ACCOUNT_ID
		)
		expect(TechErrorConstants.getAPIError({ errorCode: 'Y800' })).toEqual(
			TechErrorConstants.INVALID_PROVIDER_ACCOUNT_ID
		)
		expect(
			TechErrorConstants.getAPIError(
				{ errorCode: 'Y800' },
				TechErrorConstants.API_TYPE.VERIFICATION_INFO
			)
		).toEqual(TechErrorConstants.INVALID_ACCOUNT_ID)
		expect(TechErrorConstants.getAPIError({ errorCode: 'Y100' })).toEqual(
			TechErrorConstants.GENERIC_API_ERROR
		)

		expect(TechErrorConstants.getErrorType('E100')).toEqual('TECH_ERROR')
		expect(TechErrorConstants.getErrorType('E700')).toEqual(
			'INVALID_PARAMETER_OR_VALUE'
		)
		expect(TechErrorConstants.getErrorType('E800')).toEqual(
			'INVALID_PARAMETER_OR_VALUE'
		)
		expect(TechErrorConstants.getErrorType('E900')).toEqual(
			'PARAMETER_VALUE_INELIGIBLE'
		)
	})
})
