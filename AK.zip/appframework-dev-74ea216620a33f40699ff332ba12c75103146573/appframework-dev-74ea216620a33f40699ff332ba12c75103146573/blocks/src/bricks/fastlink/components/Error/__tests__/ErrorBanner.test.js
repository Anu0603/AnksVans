import React from 'react'
import ErrorBanner from '../ErrorBanner'
import { AppStrings, AppParams, getString, getParam } from './../../../conf'

jest.mock('./../../../conf')

describe('Error Banner Section', () => {
	let container = null

	beforeEach(() => {
		container = null

		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.ERROR_INCORRECT_CREDENTIALS_TITLE:
					return 'Incorrect Credentials'
				case AppStrings.ERROR_USER_ACTION_NEEDED_AT_SITE_TITLE:
					return 'Action Required at _SITE_NAME_'
				case AppStrings.ERROR_SITE_NOT_SUPPORTED_TITLE:
				case AppStrings.ERROR_SITE_NOT_SUPPORTED_MANUAL_ACCOUNT_DISABLED_TITLE:
					return 'Site Not Supported'
				default:
					break
			}
		})

		getParam.mockImplementation(_key => {
			switch (_key) {
				case AppParams.ENABLE_MANUAL_ACCOUNT:
					return true
				default:
					break
			}
		})
	})

	it('Check if error banner rendered', () => {
		act(() => {
			container = mount(<ErrorBanner />)
		})
		expect(container.find('.alert-error')).toHaveLength(1)
	})

	it('Check if <p> is rendered', () => {
		act(() => {
			container = mount(<ErrorBanner errorCode="INCORRECT_CREDENTIALS" />)
		})
		expect(container.find('.alert-error-msg')).toHaveLength(1)
	})

	it('Check if error message is rendered', () => {
		act(() => {
			container = mount(<ErrorBanner errorCode="INCORRECT_CREDENTIALS" />)
		})

		expect(container.find('.alert-error-msg').text()).toEqual(
			'Incorrect Credentials'
		)
	})

	it('Check if error code contains SITE_NAME & it is rendered', () => {
		let props = {
			errorCode: 'USER_ACTION_NEEDED_AT_SITE',
			site: { name: 'ICICI' }
		}
		act(() => {
			container = mount(<ErrorBanner {...props} />)
		})
		expect(container.find('.alert-error-msg').text()).toEqual(
			'Action Required at ICICI'
		)
	})

	it('Check if error message for SITE_NOT_SUPPORTED error status is rendered correctly when manual account is enabled', () => {
		act(() => {
			container = mount(<ErrorBanner errorCode="SITE_NOT_SUPPORTED" />)
		})

		expect(container.find('.alert-error-msg').text()).toEqual(
			'Site Not Supported'
		)
	})

	it('Check if error message for SITE_NOT_SUPPORTED error status is rendered correctly when manual account is disabled', () => {
		getParam.mockImplementation(_key => {
			switch (_key) {
				case AppParams.ENABLE_MANUAL_ACCOUNT:
					return false
					break
				default:
					break
			}
		})

		act(() => {
			container = mount(<ErrorBanner errorCode="SITE_NOT_SUPPORTED" />)
		})

		expect(container.find('.alert-error-msg').text()).toEqual(
			'Site Not Supported'
		)
	})
})
