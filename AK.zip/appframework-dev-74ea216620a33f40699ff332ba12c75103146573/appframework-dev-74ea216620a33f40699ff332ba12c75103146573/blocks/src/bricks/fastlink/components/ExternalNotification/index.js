import DataFormater from './formatter'
import { store } from '@framework/react/store/store'
import * as actionTypes from '@fastlinkRoot/store/actions/actionTypes'
import { AppStrings, getString, AppParams, getParam } from '@fastlinkRoot/conf'

const Notifier = () => {
	var dataFormaterObj = DataFormater(store)
	let instantPostmessage = []
	let getNotificationData = () => {
		return dataFormaterObj.getNotificationData()
	}

	/*
        Takes care of adding post message to store
    */
	let getRedirectionStatusList = () => {
		let redirectionAddStatusList = [
			'AVAILABLE_DATA_RETRIEVED',
			'ACCT_SUMMARY_RECEIVED'
		]
		if (
			getParam(AppParams.PRODUCT_TYPE) ==
				AppConstants.VERIFICATION_FLOW_NAME ||
			getParam(AppParams.PRODUCT_TYPE) ==
				AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME
		) {
			redirectionAddStatusList.pop()
		}
		return redirectionAddStatusList
	}
	let redirectionStatusList = getRedirectionStatusList()

	let getStatus = data => {
		if (
			(data.status == 'IN_PROGRESS' &&
				redirectionStatusList.indexOf(data.statusCode) != -1) ||
			data.status == 'SUCCESS' ||
			data.status == 'PARTIAL_SUCCESS'
		) {
			if (
				(getParam(AppParams.PRODUCT_TYPE) ==
					AppConstants.VERIFICATION_FLOW_NAME ||
					getParam(AppParams.PRODUCT_TYPE) ==
						AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME) &&
				data.selectedAccounts &&
				Object.keys(data.selectedAccounts).length == 0
			) {
				return 'ACTION_ABANDON'
			}

			return 'SUCCESS'
		} else if (data.status == 'FAILED') {
			return 'FAILED'
		} else {
			return 'ACTION_ABANDON'
		}
	}

	let sendPostMessage = postMessageData => {
		let key = postMessageData.providerAccountId + postMessageData.status
		if (
			postMessageData &&
			(postMessageData.status == 'SUCCESS' ||
				postMessageData.status == 'FAILED') &&
			!instantPostmessage[key]
		) {
			dataFormaterObj.sendInstantNotification(postMessageData)
			instantPostmessage[key] = true
		}
	}

	let getPostMessageData = (data, currentProvider) => {
		let statusCode = data.additionalStatus
		delete data.additionalStatus
		data.statusCode = statusCode

		let _data = {
			poviderId: currentProvider.id,
			bankName: currentProvider.name,
			...data,
			status: getStatus(data)
		}
		if (
			currentProvider.authType == 'MFA_CREDENTIALS' &&
			_data.status == 'FAILED'
		) {
			_data.isMFAError = true
		}
		addErrorReason(_data, data, currentProvider)
		return _data
	}

	let addUpdateProviderAccountsData = data => {
		//console.log("PostMessage data" + JSON.stringify(store.getState().currentProvider))
		let currentProvider = store.getState().currentProvider
		let postMessageData = getPostMessageData(data, currentProvider)
		store.dispatch({
			type: actionTypes.ADD_UPDATE_USED_ADDED_ACCOUNTS_DATA,
			payload: {
				key: data.providerAccountId,
				data: postMessageData
			}
		})
		sendPostMessage(postMessageData)
		console.log('PostMessage data' + JSON.stringify(postMessageData))
	}

	let addErrorReason = (_data, data, currentProvider) => {
		let errorMessage = null
		if (_data.status == 'FAILED') {
			errorMessage = getString(
				AppStrings['ERROR_' + data.statusCode + '_DESC']
			)
			_data.reason = errorMessage
		}
		if (errorMessage && errorMessage.includes('_SITE_NAME_')) {
			let siteLink =
				'<a href="' +
				currentProvider.loginUrl +
				'" target="blank">' +
				currentProvider.name +
				'</a>'
			errorMessage = errorMessage.replace('_SITE_NAME_', siteLink)
			_data.reason = errorMessage
		}
	}
	let sendInstantNotification = data => {
		dataFormaterObj.sendInstantNotification(data)
	}
	return {
		addUpdateProviderAccountsData,
		getNotificationData,
		sendInstantNotification
	}
}

export default new Notifier()
