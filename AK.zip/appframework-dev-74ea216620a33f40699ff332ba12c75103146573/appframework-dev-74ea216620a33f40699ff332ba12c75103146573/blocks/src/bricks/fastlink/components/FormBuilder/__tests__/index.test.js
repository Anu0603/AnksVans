import React from 'react'
import FormBuilder from '../index'
import { AppStrings, AppParams, getString, getParam } from './../../../conf'
import currentProviderData from './__mocks__/currentProvider.json'
import choiceErrorData from './__mocks__/choiceError.json'
import { createStore } from 'redux'
import { Provider } from 'react-redux'
import providerReducer from '../../../store/reducers/providerInfo'
import Button from '@framework/react/components/Button/Button'

jest.mock('./../../../conf')

describe('Choice field Module', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	let renderComponent = props => {
		let store = createStore(providerReducer, {
			currentProvider: currentProviderData
		})

		container = mount(
			<Provider store={store}>
				<FormBuilder {...currentProviderData} {...props} />
			</Provider>
		)
	}

	it('Check if form builder index is rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('.form-field-wrapper')).toHaveLength(1)
	})

	it('Check if input fields are rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('input')).toHaveLength(2)
	})

	it('Check if child component is rendered', () => {
		let props = { children: <Button classes="next-action-btn" /> }
		act(() => {
			renderComponent(props)
		})
		expect(container.find('input')).toHaveLength(2)
	})

	it('Check if shouldcomponentUpdate is trigered', () => {
		let store = createStore(providerReducer, {
			currentProvider: currentProviderData
		})
		container = mount(
			shallow(
				<Provider store={store}>
					<FormBuilder {...currentProviderData} />
				</Provider>
			).get(0)
		)
		container.setProps({ form: 'error' })
		// expect(container.find('input')).toHaveLength(2)
	})

	it('Check if child component onClick prop is called', () => {
		let onClickMock = jest.fn()
		const event = { preventDefault() {}, target: { value: 'test' } }
		let props = {
			children: <Button classes="next-action-btn" onClick={onClickMock} />
		}
		act(() => {
			renderComponent(props)
		})
		// container.find('.next-action-btn').prop('onClick')()
		container
			.find('input')
			.at(0)
			.simulate('change', event)
		container
			.find('input')
			.at(1)
			.simulate('change', event)
		container.find('.next-action-btn').simulate('click')
		expect(onClickMock).toHaveBeenCalled()
	})
})
