import React from 'react'
import ErrorPage from '../ErrorPage'
import { createStore } from 'redux'
import { Provider } from 'react-redux'
import { AppStrings, AppParams, getString, getParam } from './../../../conf'
import provider from './../__mocks__/provider'
import providerReducer from '../../../store/reducers/providerInfo'

jest.mock('./../../../conf')

describe('Error Content Section', () => {
	const modalRoot = global.document.createElement('div')
	modalRoot.setAttribute('id', 'modal-root')
	const body = global.document.querySelector('body')
	body.appendChild(modalRoot)

	let container = null

	beforeEach(() => {
		container = null

		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.ERROR_INCORRECT_CREDENTIALS_DESC:
					return 'Incorrect Credentials'
				case AppStrings.ERROR_INCORRECT_CREDENTIALS_TOOLTIP_CONTENT:
					return 'Incorrect Credentials'
				case AppStrings.ERROR_USER_ACTION_NEEDED_AT_SITE_DESC:
					return 'Action Required at _SITE_NAME_'
				case AppStrings.ERROR_SITE_NOT_SUPPORTED_MANUAL_ACCOUNT_DISABLED_DESC:
					return 'Site Not Supported'
				case AppStrings.ERROR_GENERIC_DESC:
					return

				default:
					break
			}
		})

		getParam.mockImplementation(_key => {
			switch (_key) {
				case AppParams.ENABLE_CDV:
					return true
				case AppParams.CDV_PRE_VERIFICATION_INVOKE_ENABLED_ERRORS:
					return [
						'INCORRECT_CREDENTIALS',
						'ACCOUNT_LOCKED',
						'BETA_SITE_DEV_IN_PROGRESS',
						'SITE_BLOCKING_ERROR',
						'UNEXPECTED_SITE_ERROR',
						'SITE_UNAVAILABLE',
						'TECH_ERROR',
						'GENERIC',
						'DATASET_NOT_SUPPORTED',
						'VERIFICATION_FAILED'
					]
				case AppParams.CDV_POST_VERIFICATION_INVOKE_ENABLED_ERRORS:
					return [
						'INCORRECT_CREDENTIALS',
						'ACCOUNT_LOCKED',
						'BETA_SITE_DEV_IN_PROGRESS',
						'SITE_BLOCKING_ERROR',
						'UNEXPECTED_SITE_ERROR',
						'SITE_UNAVAILABLE',
						'TECH_ERROR',
						'GENERIC',
						'DATASET_NOT_SUPPORTED',
						'VERIFICATION_FAILED'
					]
				case AppParams.ENABLE_MANUAL_ACCOUNT:
					return true
				case AppParams.ERROR_DISCRIPTION_TOOLTIP:
					return '["INCORRECT_CREDENTIALS"]'
				default:
					break
			}
		})
	})

	let renderComponent = props => {
		let store = createStore(providerReducer, {
			currentProvider: provider
		})

		container = mount(
			<Provider store={store}>
				<ErrorPage {...props} />
			</Provider>
		)
	}

	it('Check if error page is rendered', () => {
		let props = {
			errorCode: 'INCORRECT_CREDENTIALS'
		}
		act(() => {
			renderComponent(props)
		})
		expect(container.find('.alert-detail')).toHaveLength(1)
	})

	it('Check if error banner is rendered inside parent', () => {
		let props = {
			errorCode: 'INCORRECT_CREDENTIALS'
		}
		act(() => {
			renderComponent(props)
		})
		expect(container.find('.alert-error')).toHaveLength(1)
	})

	it('Check if error content is rendered inside parent', () => {
		let props = {
			errorCode: 'INCORRECT_CREDENTIALS'
		}
		act(() => {
			renderComponent(props)
		})
		expect(container.find('.alert-detail')).toHaveLength(1)
	})

	it('Check if error buttons is rendered inside parent', () => {
		let props = {
			errorCode: 'INCORRECT_CREDENTIALS'
		}
		act(() => {
			renderComponent(props)
		})
		expect(container.find('.buttons-wrapper')).toHaveLength(1)
	})

	it('Check if error footer is rendered inside parent', () => {
		let props = {
			errorCode: 'GENERIC'
		}
		act(() => {
			renderComponent(props)
		})
		expect(container.find('.cdv-error-container')).toHaveLength(1)
	})
})
