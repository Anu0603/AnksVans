import React from 'react'
import RadioGroup from '../RadioGroup'
import RadioGroupData from "./__mocks__/RadioGroupData.json";

describe('Radio Group Module', () => {
    let container = null

    beforeEach(() => {
        container = null
    })

    let renderComponent = () => {
        container = mount(
            <RadioGroup {...RadioGroupData} stateChangeCallbackHandler={function () { }} />
        )
    }

    it('Check whether Radio Group  module rendered', () => {
        act(() => {
            renderComponent()
        })
        expect(container.find('div.radio-group')).toHaveLength(1)
    })

    it('Count number of radio elements', () => {
        act(() => {
            renderComponent()
        })
        expect(container.find("input")).toHaveLength(3)
    })


})
