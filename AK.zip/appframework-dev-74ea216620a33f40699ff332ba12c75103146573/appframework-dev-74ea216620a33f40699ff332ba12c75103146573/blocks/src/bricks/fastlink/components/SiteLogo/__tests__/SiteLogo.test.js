import React from 'react'
import SiteLogo from '../SiteLogo'

describe('SiteLogo Component', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	it('Check if SiteLogo is rendered', () => {
		act(() => {
			container = mount(<SiteLogo />)
		})
		expect(container.find('.logo-wrapper')).toHaveLength(1)
		expect(container).toMatchSnapshot()
	})

	it('Check if Img is rendered', () => {
		let props = { logo: '../../../../../../jest/100.png' }
		act(() => {
			container = mount(<SiteLogo {...props} />)
		})
		expect(container.find('.site-logo')).toHaveLength(1)
		expect(container).toMatchSnapshot()
	})

	it('Check if name is rendered', () => {
		let props = { name: 'site logo' }
		act(() => {
			container = mount(<SiteLogo {...props} />)
		})
		expect(container.find('.provider-name')).toHaveLength(1)
		expect(container.find('.provider-name').text()).toBe('site logo')
	})
})
