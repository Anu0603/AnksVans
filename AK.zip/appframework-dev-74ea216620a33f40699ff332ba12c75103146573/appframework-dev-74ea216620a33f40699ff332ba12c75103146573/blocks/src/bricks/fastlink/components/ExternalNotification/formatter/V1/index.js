import { AppStrings, getString, AppParams, getParam } from '@fastlinkRoot/conf'

const Ver1 = store => {
	let formtedPostmessageData = []

	let getPostMessagaData = () => {
		formtedPostmessageData = []
		let postMessageData = store.getState().userAddedAccountData
		var keys = Object.keys(postMessageData)
		for (var key in keys) {
			let temp = Object.assign({}, postMessageData[keys[key]])
			addAccountId(formatData(temp), temp)
		}
		return formtedPostmessageData
	}

	let addAccountId = (formatedData, temp) => {
		if (
			(getParam(AppParams.PRODUCT_TYPE) ==
				AppConstants.VERIFICATION_FLOW_NAME ||
				getParam(AppParams.PRODUCT_TYPE) ==
					AppConstants.VERIFICATION_THEN_AGGREGATION_FLOW_NAME) &&
			temp.selectedAccounts &&
			Object.keys(temp.selectedAccounts).length >= 1
		) {
			var selectedAccountsIds = Object.keys(temp.selectedAccounts)
			for (var index in selectedAccountsIds) {
				let formateDataClone = Object.assign({}, formatedData)
				formateDataClone.accountId = selectedAccountsIds[index]
				formtedPostmessageData.push(formateDataClone)
			}
		} else {
			formtedPostmessageData.push(formatedData)
		}
	}

	let formatData = temp => {
		var postMesssageObj = {}
		postMesssageObj.poviderId = temp.poviderId
		postMesssageObj.bankName = temp.bankName
		postMesssageObj.requestId = temp.requestId
		if (temp.isMFAError) {
			postMesssageObj.isMFAError = temp.isMFAError
		}
		if (temp.reason) {
			postMesssageObj.reason = temp.reason
		}
		postMesssageObj.status = temp.status
		if (temp.statusCode) {
			postMesssageObj.statusCode = temp.statusCode
		}
		postMesssageObj.providerAccountId = temp.providerAccountId
		return postMesssageObj
	}

	let getNotificationData = () => {
		var notificationData = getPostMessagaData()
		var callbackData =
			'JSONcallBackStatus=' +
			encodeURIComponent(JSON.stringify(notificationData))
		let postMessageData = {
			action: 'exit',
			fnToCall: 'accountStatus',
			sites: notificationData
		}
		return { callbackData, postMessageData }
	}

	let sendInstantNotification = postMessageData => {
		var formatedData = formatData(postMessageData)
		formatedData.fnToCall = 'accountStatus'
		Application.Wrapper.sendPostMessage({
			...formatedData
		})
	}
	return {
		getNotificationData,
		sendInstantNotification
	}
}

export default Ver1
