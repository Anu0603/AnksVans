import ErrorBanner from './ErrorBanner'
import ErrorContent from './ErrorContent'
import ErrorButtons from './ErrorButtons'
import ErrorPage from './ErrorPage'

import './Error.scss'

export { ErrorBanner, ErrorContent, ErrorButtons, ErrorPage }
