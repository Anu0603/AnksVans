import React from 'react'
import { Provider } from 'react-redux'

import ErrorBoundary from './../../ErrorBoundary/'
import configureStore from 'redux-mock-store'
const mockStore = configureStore([])

jest.mock('./../../ErrorPage', props => {
	return {
		__esModule: true,
		default: () => {
			return <div className="error-page"></div>
		}
	}
})

const Something = () => null

describe('ErrorBoundary Component', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	let renderComponent = props => {
		let store = mockStore({
			deeplink: props.deeplinkData
		})

		container = mount(
			<Provider store={store}>
				<ErrorBoundary>
					<Something />
				</ErrorBoundary>
			</Provider>
		)
	}

	it('Check whether Technical Error module is rendered in case of any uncaught error', () => {
		act(() => {
			renderComponent({ deeplinkData: { isDeeplink: false } })
		})

		container.find(Something).simulateError(new Error('someError'))
		console.log(container.html())
		expect(container.find('div.tech-error-section')).toHaveLength(1)
		expect(container.find('div.error-page')).toHaveLength(1)
	})
})
