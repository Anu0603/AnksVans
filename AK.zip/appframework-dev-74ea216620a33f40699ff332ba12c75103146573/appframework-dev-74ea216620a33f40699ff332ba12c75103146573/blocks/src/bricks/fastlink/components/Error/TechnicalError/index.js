import React, { Component } from 'react'
import { connect } from 'react-redux'
import AppConstants from '@fastlinkRoot/conf/constants/AppConstants'
import { ErrorPage } from '@fastlinkRoot/components/Error/'
import Postmessage from './../../../components/ExternalNotification'
import TechErrorConstants from './TechErrorConstants'
import { getParam, AppParams } from '../../../conf'
import { Spinner } from '../../../../../framework/react/components/Spinner'

class TechnicalError extends Component {
	constructor(props) {
		super(props)
		this.state = {
			showTechDiffPage: this.showTechDiff(),
			code: this.props.code
				? this.props.code
				: TechErrorConstants.TECH_ERROR.code,
			message: this.props.message
				? this.props.message
				: TechErrorConstants.TECH_ERROR.message
		}
	}

	showTechDiff() {
		if (
			Application.Wrapper.getRequestParameter('callback') != null &&
			!getParam(AppParams.ENABLE_TECHDIFF_PAGE)
		) {
			return false
		} else {
			return true
		}
	}

	componentDidMount() {
		if (!this.state.showTechDiffPage) {
			this.handleTechErrorExit()
		}
	}

	formatPostMessageData(data) {
		let postMessageData = {}
		if (data.code) {
			postMessageData.code = data.code
			postMessageData.title = TechErrorConstants.getErrorType(data.code)
			postMessageData.message = data.message
			postMessageData.action = 'exit'
			postMessageData.fnToCall = 'errorHandler'
		}
		return postMessageData
	}

	getCallBackData(data) {
		let callbackData =
			'JSONcallBackStatus=' +
			encodeURIComponent(
				JSON.stringify({
					acton: data.action,
					code: data.code
				})
			)
		return callbackData
	}

	handleTechErrorExit() {
		let postMessageData = this.formatPostMessageData(this.state)
		Application.Wrapper.closeAplication({
			postMessageData: postMessageData,
			callbackData: this.getCallBackData(postMessageData)
		})
	}

	render() {
		return (
			<div className="tech-error-section">
				{this.state.showTechDiffPage ? (
					this.props.deeplinkData &&
					this.props.deeplinkData.isDeeplink ? (
						<ErrorPage
							{...this.props}
							errorCode={AppConstants.ERROR_DEEPLINK_TECH_DIFF}
							handleTechErrorExit={this.handleTechErrorExit.bind(
								this
							)}
						/>
					) : (
						<ErrorPage
							{...this.props}
							errorCode={AppConstants.ERROR_TECH_DIFF}
							handleTechErrorExit={this.handleTechErrorExit.bind(
								this
							)}
						/>
					)
				) : (
					<Spinner
						id="tech-error-spinner"
						name="someButtonName"
						classes="tech-error-spinner"
						size="lg"
						children={<div className="empty-string"></div>}
					/>
				)}
			</div>
		)
	}
}

const mapStateToProps = state => {
	return {
		deeplinkData: state.deeplink
	}
}
export default connect(mapStateToProps, null)(TechnicalError)
