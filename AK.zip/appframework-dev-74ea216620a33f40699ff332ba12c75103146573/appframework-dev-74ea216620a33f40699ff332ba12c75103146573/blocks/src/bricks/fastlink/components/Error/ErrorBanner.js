import React from 'react'
import { AppStrings, AppParams, getString, getParam } from '../../conf'
import AppConstants from '../../conf/constants/AppConstants'

const ErrorBanner = props => {
	let errorCode = props.errorCode
	let site = props.site

	if (
		!getParam(AppParams.ENABLE_MANUAL_ACCOUNT) &&
		errorCode == AppConstants.SITE_NOT_SUPPORTED
	) {
		errorCode =
			errorCode + AppConstants.MANUAL_ACCOUNT_DISABLED_ERROR_EXTENSION
	}

	let errorMessage = getString(AppStrings['ERROR_' + errorCode + '_TITLE'])

	if (!errorMessage) {
		errorMessage = getString(AppStrings['ERROR_GENERIC_TITLE'])
	}

	if (errorMessage && errorMessage.includes('_SITE_NAME_')) {
		// let siteLink =
		//   '<a href="' + site.loginUrl + '" target="blank">' + site.name + "</a>";
		errorMessage = errorMessage.replace('_SITE_NAME_', site.name)
	} else {
		errorMessage = errorMessage
	}

	return (
		<div className="alert-error">
			<p
				className="alert-error-msg"
				dangerouslySetInnerHTML={{ __html: errorMessage }}
			></p>
		</div>
	)
}

export default ErrorBanner
