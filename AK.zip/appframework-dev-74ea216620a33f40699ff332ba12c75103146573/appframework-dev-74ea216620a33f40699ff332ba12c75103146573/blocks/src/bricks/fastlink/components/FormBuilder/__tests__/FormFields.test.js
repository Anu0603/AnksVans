import React from 'react'
import FormField from '../FormFields'
import { AppStrings, AppParams, getString, getParam } from './../../../conf'
import formFieldsData from './__mocks__/formFields.json'
import radioFieldData from './__mocks__/radio.json'
import choiceFieldData from './__mocks__/choice.json'
import choiceErrorData from './__mocks__/choiceError.json'

jest.mock('./../../../conf')

describe('Choice field Module', () => {
	let container = null

	beforeEach(() => {
		container = null
	})

	let renderComponent = props => {
		container = mount(
			<FormField
				{...formFieldsData}
				{...props}
				stateChangeCallbackHandler={function() {}}
			/>
		)
	}

	it('Check if form field is rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(
			container.find('.container-' + formFieldsData.fieldElement.id)
		).toHaveLength(1)
	})

	it('Check if input field is rendered', () => {
		act(() => {
			renderComponent()
		})
		expect(container.find('input')).toHaveLength(2)
	})

	it('Check if radios are rendered', () => {
		act(() => {
			container = mount(
				<FormField
					{...radioFieldData}
					stateChangeCallbackHandler={function() {}}
				/>
			)
		})
		expect(
			container
				.find('input')
				.at(0)
				.prop('className')
		).toBe('radio')
		expect(container.find('.input-radio')).toHaveLength(3)
	})

	it('Check if dropdown choice fields are rendered', () => {
		act(() => {
			container = mount(
				<FormField
					{...choiceFieldData}
					stateChangeCallbackHandler={function() {}}
				/>
			)
		})
		expect(container.find('.dropdown-component')).toHaveLength(1)
	})

	it('Check for error', () => {
		act(() => {
			container = mount(
				<FormField
					{...choiceErrorData}
					stateChangeCallbackHandler={function() {}}
				/>
			)
		})
		expect(container.find('input')).not.toHaveLength(1)
	})

	it('Check for onChange', () => {
		let onFocusMock = jest.fn()
		act(() => {
			container = mount(
				<FormField
					{...choiceFieldData}
					stateChangeCallbackHandler={function() {}}
					onSiteElementsFocus={onFocusMock}
					// onFocus={onFocusMock}
				/>
			)
		})
		const input = container.find('input')
		input.simulate('change', { target: { value: 'Test Two' } })

		// expect(container.find("input").props().defaultValue).toEqual("Test Two");
	})

	it('Check if focus event is called', () => {
		const onFocusMock = jest.fn()
		const event = { preventDefault() {}, target: { value: 'test' } }
		act(() => {
			container = mount(
				<FormField
					{...choiceFieldData}
					stateChangeCallbackHandler={function() {}}
					onSiteElementsFocus={onFocusMock}
				/>
			)
		})
		container
			.find('input')
			.at(0)
			.simulate('change', event)
		expect(container.find('input').props().defaultValue).toEqual(
			'Log on with one time verification code to phone number'
		)
	})

	it.skip('Check if onBlur events is called', () => {
		const onFocusMock = jest.fn()
		const event = { preventDefault() {}, target: { value: 'test' } }
		const styleEvent = {
			preventDefault() {},
			target: { value: 'test' }
		}
		act(() => {
			container = mount(
				<FormField
					{...choiceFieldData}
					stateChangeCallbackHandler={function() {}}
					onSiteElementsFocus={onFocusMock}
				/>
			)
		})
		container.find('input').simulate('focus', styleEvent)
		container
			.find('input')
			.at(0)
			.simulate('blur', event)
	})
})
