/**
 *  This Ccomponent take care babout following items
 *   1. Display form fields
 *   2. Validatio the fields.
 *   3. Attach en event to  primart button
 */
import React, { Component } from 'react'
import ChoiceFormFields from './ChoiceFormField'
import FormField from './FormFields'
import WithState from './../../hoc/WithState'

class FormBuilder extends Component {
	constructor(props) {
		super(props)
		this.state = {
			form: props.form
		}
		this.btnRef = React.createRef()
		this.formRef = React.createRef()
		this.tempForm = null
		this.isSubmitForm = false
		this.isError = false
		this.fieldVlaue = []
	}

	displayFormFields() {
		return this.state.form.map((element, index) => {
			switch (element.type) {
				case 'choiceLabel':
					return (
						<ChoiceFormFields
							key={'choice-row-' + index}
							labelList={element.labelList}
							fieldList={element.fieldList}
							name={element.name}
							currentProvider={this.props.currentProvider}
							stateChangeCallbackHandler={this.stateChangeCallbackHandler.bind(
								this
							)}
						/>
					)
					break
				default:
					return (
						<FormField
							key={'form-row-' + index}
							fieldElement={element}
							currentProvider={this.props.currentProvider}
							stateChangeCallbackHandler={this.stateChangeCallbackHandler.bind(
								this
							)}
						/>
					)
					break
			}
		})
	}

	shouldComponentUpdate(nextProps, nextState) {
		if (JSON.stringify(nextState.form) == JSON.stringify(this.state.form)) {
			console.log('Component should not be updated...')
			return false
		}
		console.log('Component should be updated...')
		return true
	}

	componentDidUpdate() {
		this.isSubmitForm = false
	}

	stateChangeCallbackHandler(event, elementData) {
		let value = null
		let fieldId = null
		if (event) {
			value = event.currentTarget.value
			fieldId = event.currentTarget.dataset.id
		} else if (elementData) {
			value = elementData['value']
			fieldId = elementData['data-id']
		}
		var tempValue = Object.assign({}, this.fieldVlaue)
		tempValue[fieldId] = value
		this.fieldVlaue = tempValue
	}

	getCheckedRadioValue() {
		let allRadioFields = document.querySelectorAll('.radio')
		let isChecked = 0
		for (let element in allRadioFields) {
			if (allRadioFields[element].checked) {
				isChecked = allRadioFields[element].value
			}
		}
		return isChecked
	}
	getEnabledFieldIds(enabledRadioRef) {
		let enabledRef = this.formRef.current.querySelectorAll(
			'.fieldId-' + enabledRadioRef
		)
		let ids = []
		for (let i = 0; i < enabledRef.length; i++) {
			ids.push(parseInt(enabledRef[i].getAttribute('data-id')))
		}
		return ids
	}

	choiceFieldValidation(choiceList) {
		let checkedValue = this.getCheckedRadioValue()
		if (checkedValue > 0) {
			let enabledFieldsIds = this.getEnabledFieldIds(checkedValue)
			choiceList.map((element, index) => {
				element.field.map((row, index) => {
					if (
						enabledFieldsIds.indexOf(row.id) >= 0 &&
						!this.fieldVlaue[row.id]
					) {
						row.error = true
						this.isError = true
					}
				})
			})
		} else {
			this.isError = true
			// Todo Display  error message for radio button.
		}
	}

	/**
	 * Loop throgh the all the fileds  - Single and Choice fields
	 * mark a files as error if field is required and usre not enterd the values.
	 */
	validateLoginForm() {
		this.isError = false //reset the error field
		// To be fixed
		var tempForm = JSON.parse(JSON.stringify(this.props.form))
		tempForm.map((element, index) => {
			if (!element.isOptional && element.field) {
				this.updateError(element)
			} else if (element.fieldList) {
				this.choiceFieldValidation(element.fieldList)
			}
		})
		this.tempForm = tempForm

		let checkBoxParentRef = this.btnRef.current.querySelector(
			'.checkbox-wrapper'
		)
		let checkBoxRef =
			checkBoxParentRef &&
			checkBoxParentRef.querySelector('.checkbox-base')
		checkBoxParentRef && checkBoxParentRef.classList.remove('error')
		if (
			checkBoxRef &&
			checkBoxRef.className.indexOf('checkbox-checked') <= -1
		) {
			this.isError = true
			checkBoxParentRef.classList.add('error')
		}
	}

	updateError(element) {
		element.field.map((row, index) => {
			if (!row.isOptional) {
				if (!this.fieldVlaue[row.id]) {
					row.error = true
					this.isError = true
				}
			}
		})
	}

	/**
	 * Hnadle Submit btn of form, that is primary button
	 */
	handleSubmitBtn() {
		this.validateLoginForm()
		this.setState({ form: this.tempForm })
		if (!this.isError && !this.isSubmitForm) {
			this.props.btnClickCallback(this.fieldVlaue)
			this.isSubmitForm = true
			console.log('Validation is done::::::::')
		}
	}

	/**
	 * attach an event to  primary btn
	 */
	componentDidMount() {
		let btnPrimary = this.btnRef.current.querySelector('.next-action-btn')
		if (btnPrimary) {
			btnPrimary.addEventListener(
				'click',
				this.handleSubmitBtn.bind(this)
			)
		}
	}

	render() {
		return (
			<React.Fragment>
				<div
					className={'form-field-wrapper'}
					ref={this.formRef}
					autoid={this.props.autoId}
				>
					{this.displayFormFields()}
				</div>
				<div ref={this.btnRef}>{this.props.children}</div>
			</React.Fragment>
		)
	}
}

export default WithState('currentProvider', FormBuilder)
