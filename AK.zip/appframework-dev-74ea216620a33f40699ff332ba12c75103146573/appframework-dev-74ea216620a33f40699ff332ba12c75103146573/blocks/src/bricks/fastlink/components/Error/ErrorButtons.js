import React, { Component } from 'react'
import { connect } from 'react-redux'
import { AppParams, AppStrings, getParam, getString } from '../../conf'

import { Button } from './../../../../framework/react/components/Button'
import Constants from './../../router/Constant'
import AppConstants from '../../conf/constants/AppConstants'
import DeeplinkConstants from './../../filters/deeplink/DeeplinkConstants'

class ErrorButtons extends Component {
	constructor(props) {
		super(props)
		this.state = {}
		this.site = this.props.site
		this.errorButtons = ''
		this.errorCode = this.props.errorCode
		this.loginUrl = this.props.loginUrl
		this.providerAccountId = this.props.providerAccountId

		if (
			!getParam(AppParams.ENABLE_MANUAL_ACCOUNT) &&
			this.errorCode == AppConstants.SITE_NOT_SUPPORTED
		) {
			this.errorCode =
				this.errorCode +
				AppConstants.MANUAL_ACCOUNT_DISABLED_ERROR_EXTENSION
		}

		this.constructButtons()
	}

	errorButtonHandler(actionType) {
		switch (actionType) {
			case 'CLOSE':
				this.closeAction()
				break
			case 'CANCEL':
				this.closeAction()
				break
			case 'SDS':
			case 'LMA':
			case 'LAA':
				this.addAnotherAccount()
				break
			case 'MAA':
				this.addManualAccount()
				break
			case 'TA':
				this.refreshSite()
				break
			case 'VS':
			case 'GTS':
				this.openBaseUrlWindow()
				break
			case 'EC':
				this.editCredentials()
				break
			case 'TECH_DIFF_CLOSE':
				this.closeTechError()
		}
	}

	closeTechError() {
		this.props.handleTechErrorExit()
	}

	closeAction() {
		this.props.handleCloseAppHandler()
	}

	refreshSite() {
		this.props.navigate(Constants.ROUTE_VERIFICATION_MODULE, {
			providerAccountId: this.providerAccountId
		})
	}
	editCredentials() {
		this.props.navigate(Constants.ROUTE_LOGIN_MODULE, {
			providerAccountId: this.providerAccountId
		})
	}
	addManualAccount() {
		this.props.navigate(Constants.ROUTE_MANUAL_ACCOUNT_MODULE, {})
		console.log('Add Manual Account')
	}
	openBaseUrlWindow() {
		window.open(this.loginUrl, '_blank')
	}
	addAnotherAccount() {
		this.props.navigate(Constants.ROUTE_LANDING_MODULE, {})
	}

	constructButtons() {
		let errorCode = this.errorCode

		let errorMessage = getString(
			AppStrings['ERROR_' + errorCode + '_TITLE']
		)

		let buttonParams = getParam(
			AppParams['ERROR_' + errorCode + '_BUTTONS']
		)

		if (!errorMessage) {
			buttonParams = getParam(AppParams['ERROR_GENERIC_BUTTONS'])
		}

		if (!buttonParams) {
			return
		}
		let buttonTypes = buttonParams.split(',')
		buttonTypes = this.applyDeeplink(buttonTypes)

		let buttonsConfg = []
		if (buttonTypes.length > 1) {
			buttonTypes.forEach((item, index) => {
				let conf = {}
				conf.id = 'error_button_' + item
				conf.label = getString(
					AppStrings['ERROR_' + item + '_BUTTON_TEXT']
				)
				conf.onClick = this.errorButtonHandler.bind(this, item)
				conf.key = 'error_button' + index
				conf.reversed = true
				conf.fullWidth = true
				if (index === 0) {
					conf.variant = 'primary'
					conf.classes = 'err-primary'
					if (this.props.site.hexCode1) {
						conf.btnStyle = { color: this.props.site.hexCode1 }
					}
				} else if (index === 1) {
					conf.btnStyle = {}
					conf.variant = 'secondary'
					conf.classes = 'err-secondary'
				} else if (index === 2) {
					conf.btnStyle = {}
					conf.variant = 'tertiary'
					conf.classes = 'err-tertiary'
				}
				buttonsConfg.push(conf)
			})
		} else {
			let conf = {}
			conf.id = 'error_button_' + buttonTypes[0]
			conf.reversed = true
			conf.classes = 'err-primary'
			conf.label = getString(
				AppStrings['ERROR_' + buttonTypes[0] + '_BUTTON_TEXT']
			)
			if (this.props.site.hexCode1) {
				conf.btnStyle = { color: this.props.site.hexCode1 }
			}
			conf.onClick = this.errorButtonHandler.bind(this, buttonTypes[0])
			conf.fullWidth = true
			buttonsConfg.push(conf)
		}

		this.errorButtons = buttonsConfg.map((item, index) => {
			let { btnStyle, id, ...itemm } = item
			return <Button style={btnStyle} key={id} {...itemm} />
		})
	}

	applyDeeplink(buttonTypes) {
		if (
			this.props.deeplinkData &&
			this.props.deeplinkData.isDeeplink &&
			this.props.deeplinkData.deeplinkType !=
				DeeplinkConstants.FLOW_TYPES.ACCOUNT_ADDITION
		) {
			if (buttonTypes.length > 1) {
				buttonTypes = buttonTypes.filter(
					actionType => actionType !== 'LAA'
				)
			} else {
				if (buttonTypes[0] === 'LAA') {
					buttonTypes[0] = 'CLOSE'
				}
			}
		}
		return buttonTypes
	}

	render() {
		return <div className="buttons-wrapper">{this.errorButtons}</div>
	}
}

const mapStateToProps = state => {
	return {
		site: state.currentProvider
	}
}

export default connect(mapStateToProps)(ErrorButtons)
