import React from 'react'
import ErrorContent from '../ErrorContent'
import { createStore } from 'redux'
import { Provider } from 'react-redux'
import { AppStrings, AppParams, getString, getParam } from './../../../conf'
import provider from './../__mocks__/provider'
import providerReducer from '../../../store/reducers/providerInfo'

jest.mock('./../../../conf')

describe('Error Content Section', () => {
	const modalRoot = global.document.createElement('div')
	modalRoot.setAttribute('id', 'modal-root')
	const body = global.document.querySelector('body')
	body.appendChild(modalRoot)

	let container = null

	beforeEach(() => {
		container = null

		getString.mockImplementation(_key => {
			switch (_key) {
				case AppStrings.ERROR_INCORRECT_CREDENTIALS_DESC:
					return 'Incorrect Credentials'
					break
				case AppStrings.ERROR_INCORRECT_CREDENTIALS_TOOLTIP_CONTENT:
					return 'Incorrect Credentials'
					break
				case AppStrings.ERROR_USER_ACTION_NEEDED_AT_SITE_DESC:
					return 'Action Required at _SITE_NAME_'
					break
				case AppStrings.ERROR_SITE_NOT_SUPPORTED_DESC:
					return "We're unable to support this site, but you can add your account details manually."
					break
				case AppStrings.ERROR_SITE_NOT_SUPPORTED_MANUAL_ACCOUNT_DISABLED_DESC:
					return "We're unable to support this site."
					break
				case AppStrings.ERROR_TECH_ERROR_DESC:
					return "We're unable to link your account at this time. Please try again later and contact _COBRANDNAME_ support team if the issue persists."
					break
				case AppStrings.ERROR_GENERIC_DESC:
					return
					break
				case AppStrings.COBRAND_NAME:
					return 'Yodlee'
					break
				default:
					break
			}
		})

		getParam.mockImplementation(_key => {
			switch (_key) {
				case AppParams.ENABLE_MANUAL_ACCOUNT:
					return true
				case AppParams.ERROR_DISCRIPTION_TOOLTIP:
					return '["INCORRECT_CREDENTIALS"]'
				default:
					break
			}
		})
	})

	let renderComponent = props => {
		let store = createStore(providerReducer, {
			currentProvider: provider
		})

		container = mount(
			<Provider store={store}>
				<ErrorContent {...props} />
			</Provider>
		)
	}

	it('Check if error banner rendered', () => {
		let props = {
			errorCode: 'INCORRECT_CREDENTIALS'
		}
		act(() => {
			renderComponent(props)
		})
		expect(container.find('.alert-detail')).toHaveLength(1)
	})

	it('Check if <Modal> is rendered when tooltip is true', () => {
		let props = {
			errorCode: 'INCORRECT_CREDENTIALS'
		}
		act(() => {
			renderComponent(props)
		})
		expect(container.find('Modal')).toHaveLength(1)
	})

	it('Check if error code contains SITE_NAME & it is rendered', () => {
		let props = {
			errorCode: 'USER_ACTION_NEEDED_AT_SITE'
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.tooltip-spacer')).toHaveLength(0)
	})

	it('Check if GENERIC error is rendered', () => {
		let props = {
			errorCode: 'GENERIC'
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.alert-detail').text()).toEqual(
			"We're unable to link your account at this time. Please try again later and contact Yodlee support team if the issue persists."
		)
	})

	it('Check if GENERIC error is rendered when the error code is not defined', () => {
		let props = {
			errorCode: ''
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.alert-detail').text()).toEqual(
			"We're unable to link your account at this time. Please try again later and contact Yodlee support team if the issue persists."
		)
	})

	it('Check if SITE_NOT_SUPPORTED error message is rendered correctly when manual account is disabled', () => {
		const onClickMock = jest.fn()

		getParam.mockImplementation(_key => {
			switch (_key) {
				case AppParams.ENABLE_MANUAL_ACCOUNT:
					return false
				case AppParams.ERROR_DISCRIPTION_TOOLTIP:
					return '["INCORRECT_CREDENTIALS"]'
				default:
					break
			}
		})
		debugger
		let props = {
			errorCode: 'SITE_NOT_SUPPORTED'
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.alert-detail').text()).toEqual(
			"We're unable to support this site."
		)
	})

	it('Check if SITE_NOT_SUPPORTED error is rendered correctly when manual account is enabled', () => {
		const onClickMock = jest.fn()

		getParam.mockImplementation(_key => {
			switch (_key) {
				case AppParams.ENABLE_MANUAL_ACCOUNT:
					return true
				case AppParams.ERROR_DISCRIPTION_TOOLTIP:
					return '["INCORRECT_CREDENTIALS"]'
				default:
					break
			}
		})

		let props = {
			errorCode: 'SITE_NOT_SUPPORTED'
		}

		act(() => {
			renderComponent(props)
		})

		expect(container.find('.alert-detail').text()).toEqual(
			"We're unable to support this site, but you can add your account details manually."
		)
	})

	it('Check if _COBRANDNAME_ is rendered correct in Message', () => {
		let props = {
			errorCode: 'TECH_ERROR'
		}
		act(() => {
			renderComponent(props)
		})

		expect(container.find('.alert-detail').text()).toEqual(
			"We're unable to link your account at this time. Please try again later and contact Yodlee support team if the issue persists."
		)
	})

	it('Check if onClick prop is called', () => {
		const onClickMock = jest.fn()
		let props = {
			errorCode: 'INCORRECT_CREDENTIALS',
			onClick: onClickMock
		}
		act(() => {
			renderComponent(props)
		})
		container
			.find('.fa-info-circle')
			.at(0)
			.prop('onClick')()
		container.update()
		expect(container.find('Modal')).toHaveLength(1)
	})

	it('Check if Modal Close is called', () => {
		const onClickMock = jest.fn()
		let props = {
			errorCode: 'INCORRECT_CREDENTIALS',
			onCrossIconClick: onClickMock
		}
		act(() => {
			renderComponent(props)
		})
		container
			.find('.fa-info-circle')
			.at(0)
			.prop('onClick')()
		container.update()
		container.find('.modalCrossIcon .fa-times').simulate('click')
		container.update()
		expect(container.find('.modal-inner-container')).toHaveLength(0)
	})
})
