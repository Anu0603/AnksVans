import React from 'react'
import { connect } from 'react-redux'
import ErrorBanner from './ErrorBanner'
import ErrorContent from './ErrorContent'
import ErrorButtons from './ErrorButtons'
import ErrorFooter from './ErrorFooter'
import classNames from 'classnames'

const ErrorPage = props => {
	let module = 'fastlink'
	let _classNames = classNames(
		'alert-wrapper',
		('error-' + props.errorCode).toLowerCase().replace(/_/gi, '-')
	)

	return (
		<div className={_classNames}>
			<ErrorBanner {...props} />
			<ErrorContent {...props} />
			<ErrorButtons {...props} />
			<ErrorFooter {...props} />
		</div>
	)
}

const mapStateToProps = state => {
	return {
		site: state.currentProvider,
		deeplinkData: state.deeplink
	}
}

export default connect(mapStateToProps)(ErrorPage)
