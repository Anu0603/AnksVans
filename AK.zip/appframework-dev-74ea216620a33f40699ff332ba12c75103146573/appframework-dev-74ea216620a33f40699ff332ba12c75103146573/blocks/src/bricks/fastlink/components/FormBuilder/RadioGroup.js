import React, { useState } from 'react'
import { Radio } from './../../../../framework/react/components/RadioButton'

const RadioGroup = ({
	stateChangeCallbackHandler,
	option,
	fieldId,
	label,
	hexCode1,
	hexCode2,
	name,
	...props
}) => {
	let [selectedRadio, setSelectedRadio] = useState('0')

	let radioChangeHandler = (event, value) => {
		setSelectedRadio(value)
	}

	let isSelected = fieldElement => {
		if (selectedRadio != '0') {
			return selectedRadio == fieldElement.optionValue
		} else {
			return fieldElement.selected
		}
	}

	let viewRadio = option.map((radioElement, index) => {
		let radioProps = {
			value: radioElement.optionValue + '',
			'data-id': fieldId,
			id: index + name,
			name: name,
			key: 'radio' + index,
			label: radioElement.displayText,
			hexCode1: hexCode1,
			hexCode2: hexCode2,
			className: 'radio',
			checked: isSelected(radioElement),
			onChange: radioChangeHandler.bind(this)
		}
		if (radioProps.checked) {
			stateChangeCallbackHandler(null, {
				'data-id': fieldId,
				value: radioElement.optionValue
			})
		}
		return <Radio {...radioProps} />
	})
	return (
		<div className="radio-group" key={'radio' + fieldId}>
			{label && <div className=" label text">{label}</div>}
			{viewRadio}
		</div>
	)
}

export default RadioGroup
