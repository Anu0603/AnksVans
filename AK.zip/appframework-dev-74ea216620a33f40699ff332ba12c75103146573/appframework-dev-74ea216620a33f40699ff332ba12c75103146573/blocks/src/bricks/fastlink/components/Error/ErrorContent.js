import React, { Component } from 'react'
import { connect } from 'react-redux'

import { AppStrings, getString, AppParams, getParam } from '../../conf'
import AppConstants from '../../conf/constants/AppConstants'
import { IconLink, Link } from './../../../../framework/react/components/Link'
import Modal from '../../../../framework/react/components/Modal/Modal'
import { Icon, IconNameMap } from '../../../../framework/react/components/Icon'

class ErrorContent extends Component {
	constructor(props) {
		super(props)
		this.state = {
			showPopup: false
		}
		this.site = this.props.site
		this.errorCode = this.props.errorCode
		this.errormsg = ''
	}

	processErrorMessage() {
		if (
			!getParam(AppParams.ENABLE_MANUAL_ACCOUNT) &&
			this.errorCode == AppConstants.SITE_NOT_SUPPORTED
		) {
			this.errorCode =
				this.errorCode +
				AppConstants.MANUAL_ACCOUNT_DISABLED_ERROR_EXTENSION
		}

		this.showTooltip = false
		if (
			getParam(AppParams.ERROR_DISCRIPTION_TOOLTIP).includes(
				this.errorCode
			)
		) {
			this.showTooltip = true
			this.tooltipContent = getString(
				AppStrings['ERROR_' + this.errorCode + '_TOOLTIP_CONTENT']
			)
		}
		this.constructErrorDescription()
	}

	constructErrorDescription() {
		let errorMessage = getString(
			AppStrings['ERROR_' + this.errorCode + '_DESC']
		)
		if (!errorMessage) {
			errorMessage = getString(AppStrings['ERROR_GENERIC_DESC'])
		}

		if (errorMessage && errorMessage.includes('_COBRANDNAME_')) {
			let cobrandName = getString(AppStrings.COBRAND_NAME)
			errorMessage = errorMessage.replace('_COBRANDNAME_', cobrandName)
		}

		if (errorMessage && errorMessage.includes('_SITE_NAME_')) {
			let siteLink =
				'<a href="' +
				this.site.loginUrl +
				'" target="blank">' +
				this.site.name +
				'</a>'
			this.errormsg = errorMessage.replace('_SITE_NAME_', siteLink)
		} else {
			this.errormsg = errorMessage
		}
	}

	showTooltipPopup() {
		this.setState({
			showPopup: true
		})
	}

	closeTooltipPopup() {
		this.setState({
			showPopup: false
		})
	}

	render() {
		this.errorCode = this.props.errorCode
		this.processErrorMessage()
		return (
			<React.Fragment>
				<div className="alert-detail">
					<span
						dangerouslySetInnerHTML={{ __html: this.errormsg }}
					></span>
					{this.showTooltip ? (
						<span className="tooltip-spacer">
							<Icon
								type="fal"
								iconClass={IconNameMap['info-circle']}
								onClick={this.showTooltipPopup.bind(this)}
							/>
						</span>
					) : null}
				</div>
				{this.showTooltip ? (
					<Modal
						show={this.state.showPopup}
						backDropEnabled={true}
						onBackDropClick={this.closeTooltipPopup.bind(this)}
						crossIconEnabled={true}
						onCrossIconClick={this.closeTooltipPopup.bind(this)}
						className="small"
					>
						<div
							className="alert-tooltip"
							dangerouslySetInnerHTML={{
								__html: this.tooltipContent
							}}
						></div>
					</Modal>
				) : null}
			</React.Fragment>
		)
	}
}

const mapStateToProps = state => {
	return {
		site: state.currentProvider
	}
}

export default connect(mapStateToProps)(ErrorContent)
