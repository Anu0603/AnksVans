import AccountsService from './../../../services/account/AccountsService'
import actionTypes from './../../../store/actions/actionTypes'

class AccountsPolling {
	constructor(providerAccountId, status) {
		this.accountsService = new AccountsService()
		this.providerAccountId = providerAccountId
		this.status = status
		this.isPolling = false
		this.timer = null
	}

	startPolling(dispatch) {
		if (!this.isPolling) {
			this.isPolling = true
			this.doPolling(dispatch)
		}
	}

	doPolling(dispatch) {
		this.accountsService.getAccounts(
			{
				providerAccountId: this.providerAccountId,
				status: this.status
			},
			this.setAccounts.bind(this, dispatch)
		)
	}

	setAccounts(dispatch, _error, _response) {
		dispatch({
			type: 'FETCH_ACCOUNTS',
			payload: {
				response: _response
			}
		})
		if (this.isPolling) {
			this.timer = setTimeout(() => this.doPolling(dispatch), 1500)
		}
	}

	endPolling() {
		if (this.isPolling) {
			clearTimeout(this.timer)
			this.isPolling = false
		}
	}
}

export default AccountsPolling
