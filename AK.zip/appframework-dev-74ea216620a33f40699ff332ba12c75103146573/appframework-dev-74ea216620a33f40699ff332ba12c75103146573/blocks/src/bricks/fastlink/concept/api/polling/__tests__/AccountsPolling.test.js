import AccountsPolling from './../AccountsPolling'
import AccountsService from './../../../../services/account/AccountsService'

jest.mock('./../../../../services/account/AccountsService')

describe('AccountsPolling Test Case', () => {
	beforeEach(() => {
		AccountsService.mockImplementation(() => {
			return {
				getAccounts: (_options, _callback) => {
					_callback(null, {})
				}
			}
		})
	})

	it('Check if AccountsPolling is properly initialized with props', () => {
		let accountsPolling = new AccountsPolling(26712829, 'IN_PROGRESS')
		expect(accountsPolling.providerAccountId).toEqual(26712829)
		expect(accountsPolling.status).toEqual('IN_PROGRESS')
		expect(accountsPolling.isPolling).toEqual(false)
		expect(accountsPolling.timer).toEqual(null)
	})

	it('Check if AccountsPolling gets started', () => {
		let isDispatchedCalled = false
		let accountsPolling = new AccountsPolling(26712829, 'IN_PROGRESS')
		expect(accountsPolling.isPolling).toEqual(false)
		expect(accountsPolling.timer).toEqual(null)
		expect(isDispatchedCalled).toEqual(false)

		accountsPolling.startPolling(function() {
			isDispatchedCalled = true
		})
		expect(accountsPolling.isPolling).toEqual(true)
	})

	it('Check if AccountsPolling gets ended', () => {
		let isDispatchedCalled = false
		let accountsPolling = new AccountsPolling(26712829, 'IN_PROGRESS')
		accountsPolling.startPolling(function() {
			isDispatchedCalled = true
		})
		expect(accountsPolling.isPolling).toEqual(true)
		accountsPolling.endPolling()
		expect(accountsPolling.isPolling).toEqual(false)
	})
})
