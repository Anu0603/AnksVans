import ProviderAccountService from './../../../services/provider/ProviderAccountService'
import { AppParams, getParam } from './../../../conf'

class ProviderAccountPolling {
	constructor(providerId, providerAccountId, requestId) {
		this.providerAccountService = new ProviderAccountService()
		this.providerId = providerId
		this.providerAccountId = providerAccountId
		this.requestId = requestId
		this.isPolling = false
		this.timer = null
	}

	startPolling(dispatch) {
		if (!this.isPolling) {
			this.isPolling = true
			this.doPolling(dispatch)
		}
	}

	// TODO Catch for error
	doPolling(dispatch) {
		this.providerAccountService
			.getProviderAccountDetails({
				providerId: this.providerId,
				providerAccountId: this.providerAccountId,
				requestId: this.requestId
			})
			.then(response => {
				if (response.requestId) {
					this.requestId = response.requestId
				}
				dispatch({
					type: 'FETCH_PROVIDER_ACCOUNTS',
					payload: {
						status: response.status,
						additionalStatus: response.additionalStatus,
						mfaLoginForm: response.mfaLoginForm,
						requestId: response.requestId,
						providerAccountId: response.providerAccountId
					}
				})
				if (this.isPolling) {
					this.timer = setTimeout(
						() => this.doPolling(dispatch),
						getParam(AppParams.PROVIDER_ACCOUNT_POLLING_INTERVAL)
					)
				}
			})
	}

	endPolling() {
		if (this.isPolling) {
			clearTimeout(this.timer)
			this.isPolling = false
		}
	}
}

export default ProviderAccountPolling
