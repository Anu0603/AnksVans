import ProviderAccountPolling from './../ProviderAccountPolling'
import ProviderAccountService from './../../../../services/provider/ProviderAccountService'

jest.mock('./../../../../services/provider/ProviderAccountService')

describe('ProviderAccountPolling Test Case', () => {
	beforeEach(() => {
		ProviderAccountService.mockImplementation(() => {
			return {
				getProviderAccountDetails: (_options, _callback) => {
					return Promise.resolve({
						status: 'IN_PROGRESS',
						additionalStatus: 'ACCT_SUMMARY_RECEIVED'
					})
				}
			}
		})
	})

	it('Check if ProviderAccountPolling is properly initialized with props', () => {
		let providerAccountPollingService = new ProviderAccountPolling(
			16441,
			26712829,
			'_abc'
		)
		expect(providerAccountPollingService.providerId).toEqual(16441)
		expect(providerAccountPollingService.providerAccountId).toEqual(
			26712829
		)
		expect(providerAccountPollingService.requestId).toEqual('_abc')
		expect(providerAccountPollingService.isPolling).toEqual(false)
		expect(providerAccountPollingService.timer).toEqual(null)
	})

	it('Check if ProviderAccountPolling gets started', () => {
		let isDispatchedCalled = false
		let providerAccountPollingService = new ProviderAccountPolling(
			16441,
			26712829,
			'_abc'
		)
		expect(providerAccountPollingService.isPolling).toEqual(false)
		expect(providerAccountPollingService.timer).toEqual(null)
		expect(isDispatchedCalled).toEqual(false)

		providerAccountPollingService.startPolling(function() {
			isDispatchedCalled = true
		})
		expect(providerAccountPollingService.isPolling).toEqual(true)
	})

	it('Check if ProviderAccountPolling gets ended', () => {
		let isDispatchedCalled = false
		let providerAccountPollingService = new ProviderAccountPolling(
			16441,
			26712829,
			'_abc'
		)
		providerAccountPollingService.startPolling(function() {
			isDispatchedCalled = true
		})
		expect(providerAccountPollingService.isPolling).toEqual(true)
		providerAccountPollingService.endPolling()
		expect(providerAccountPollingService.isPolling).toEqual(false)
	})
})
