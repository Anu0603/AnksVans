import React from 'react'
import CONSTANTS from './Constant'

const SiteSelectionModule = React.lazy(() => import('../modules/SiteSelection'))
const LoginModule = React.lazy(() => import('../modules/Login'))
const AccountSummaryModule = React.lazy(() =>
	import('../modules/AccountSummary')
)
const RealEstateModule = React.lazy(() => import('../modules/RealEstate'))
const ManualAccountModule = React.lazy(() => import('../modules/ManualAccount'))

const VerificationModule = React.lazy(() => import('../modules/Verification'))
const CDVModule = React.lazy(() => import('../modules/CDV'))
const ErrorModule = React.lazy(() => import('../modules/Error'))
const MFAModule = React.lazy(() => import('../modules/MFA'))

const Navigator = ({ routeName, ...props }) => {
	let Route = null
	switch (routeName) {
		case CONSTANTS.ROUTE_LOGIN_MODULE:
			Route = LoginModule
			break

		case CONSTANTS.ROUTE_VERIFICATION_MODULE:
			Route = VerificationModule
			break

		case CONSTANTS.ROUTE_ACCOUNT_SUMMARY_MODULE:
			Route = AccountSummaryModule
			break

		case CONSTANTS.ROUTE_ERROR_MODULE:
			Route = ErrorModule
			break

		case CONSTANTS.ROUTE_REAL_ESTATE_MODULE:
			Route = RealEstateModule
			break

		case CONSTANTS.ROUTE_MANUAL_ACCOUNT_MODULE:
			Route = ManualAccountModule
			break

		case CONSTANTS.ROUTE_MFA_MODULE:
			Route = MFAModule
			break

		case CONSTANTS.ROUTE_CDV_MODULE:
			Route = CDVModule
			break

		case CONSTANTS.ROUTE_LANDING_MODULE:
		default:
			Route = SiteSelectionModule
			break
	}

	return <Route {...props} />
}

export default Navigator
