export const getString = (stringName) => BrandUtils.getString(stringName, 'fastlink')
export const getParam = (paramName) => BrandUtils.getParam(paramName, 'fastlink');

