const AutoIds = {
	//Landing Module
	LANDING_SEARCHFIELD_CONTAINER: 'landing-searchfield-container',
	LANDING_SEARCH_RESULTS_CONTAINER: 'landing-search-results-container',
	LANDING_SITES_CONTAINER: 'landing-sites-container',
	LANDING_FOOTER: 'landing-footer',

	//Login Module

	// Verification Module
	VERIFICATION_LOGIN_STEPPER_CONTAINER:
		'verification-login-stepper-container',
	VERIFICATION_DATA_STEPPER_CONTAINER: 'verification-data-stepper-container',
	VERIFICATION_SUCCESS_CONTAINER: 'verification-success-container',

	//MFA Module

	//Error Module

	//Account Summary Module
	ACCOUNT_SUMMARY_LABEL_PARTIAL: 'accoun-summary-label-',
	ACCOUNT_SUMMARY_BUTTON_SAVENFINISH:
		'account-summary-button-save-and-finish',
	ACCOUNT_SUMMARY_BUTTON_SAVENLINKMOREACCOUNTS:
		'account-summary-button-save-and-link-more-accounts',
	ACCOUNT_SUMMARY_BUTTON_CANCEL: 'account-summary-button-cancel',
	ACCOUNT_SUMMARY_BUTTON_CLOSE: 'account-summary-button-close',
	ACCOUNT_SUMMARY_LABEL_FOOTERHELPTEXT:
		'account-summary-label-footer-help-text',
	ACCOUNT_SUMMARY_LABEL_MOREACCOUNTSTEXT:
		'account-summary-label-more-accounts-text',
	ACCOUNT_SUMMARY_BUTTON_LINK_MORE_ACCOUNTS:
		'account-summary-button-link-more-accounts',

	//Real Estate Module

	//Manual Account Module

	//CDV Module
	CDV_COMMON_AUTOID: 'CDV_COMMON_AUTOID',
	CDV_INVOKE_CONTAINER: 'CDV_INVOKE_CONTAINER',
	CDV_INITIATE_CONTAINER: 'CDV_INITIATE_CONTAINER',
	CDV_COMPLETE_CONTAINER: 'CDV_COMPLETE_CONTAINER',
	CDV_ERROR_CONTAINER: 'CDV_ERROR_CONTAINER'
}

export default AutoIds
