const params = {
	POPULAR_PROVIDERS_COUNT: 'popular_providers_count',
	POPULAR_PROVIDERS_COUNT_MOBILE: 'popular_providers_count_mobile',
	PROVIDERS_SEARCH_COUNT: 'providers_search_count',
	PROVIDERS_SEARCH_COUNT_MOBILE: 'providers_search_count_mobile',
	ENABLE_REAL_ESTATE: 'enable_real_estate',
	ENABLE_MANUAL_ACCOUNT: 'enable_manual_account',
	SHOW_LANDING_SCREEN_FOOTER: 'show_landing_screen_footer',
	SHOW_PRIVACY_POLICY: 'show_privacy_policy',
	SHOW_SECURITY_POLICY: 'show_security_policy',
	SHOW_PROVIDERS_ALREADY_ADDED_ICON: 'show_providers_already_added_icon',
	SHOW_PROVIDERS_BASE_URL: 'show_providers_base_url',
	SHOW_PROVIDERS_FAVICON: 'show_providers_favicon',
	SHOW_SITE_NAME_IN_CARD: 'show_popular_site_name',
	TNC_VERSION: 'login_tnc_version',
	TNC_TYPE: 'login_tnc_type',
	LOGIN_SHOW_ONETIME_TNC: 'login_onetime_show_tnc',
	LOGIN_ALLOW_COPY_PASTE: 'login_allow_copy_paste',
	LOGIN_EXTERNAL_TNC_URL: 'login_external_tnc_url',
	LOGIN_SHOW_TNC_ALWAYS: 'login_show_tnc_always',
	PRODUCT_TYPE: 'product_type',
	SUCCESS_ACCOUNT_SELECTION_TYPE: 'success_account_selection_type',
	ENABLE_VERIFICATION_MS_FLOW: 'enable_verification_ms_flow',
	// SUCCESS SCREEN
	DISABLE_TRASH_ICON: 'disable_trash_icon',
	CONTAINER_LIST: 'container_list',
	DISABLE_BOTTOM_TEXT: 'disable_bottom_text',
	DISABLE_POPUP_ON_DELETE: 'disable_popup_on_delete',
	DISABLE_POPUP_ON_CANCEL: 'disable_popup_on_cancel',
	POLLING_INTERVAL: 'polling_interval',
	DISABLE_LINK_MORE_FOR_ADD: 'disable_link_more_for_add',
	DISABLE_LINK_MORE_FOR_EDIT: 'disable_link_more_for_edit',
	DISABLE_LINK_MORE_FOR_REFRESH: 'disable_link_more_for_refresh',
	DISABLE_LINK_MORE_FOR_STANDARD: 'disable_link_more_for_standard',
	DISABLE_LINK_MORE_BTN_FOR_VERIFICATION:
		'disable_link_more_btn_for_verification',

	// VERIFICATION MODULE
	VERIFICATION_ELIGBLE_CONTAINERS: 'verification_eligble_containers',
	DISABLE_VERIFICATION_SUCCESS_PAGE: 'disable_verification_success_page',
	PROVIDER_ACCOUNT_POLLING_INTERVAL: 'provider_account_polling_interval',
	SUCCESS_PAGE_STAY_TIME: 'success_page_stay_time',

	// TOOLTIP ERRORS  ARRAY
	ERROR_DISCRIPTION_TOOLTIP: 'error_discription_tooltip',

	//ERROR SCREEN BUTTONS
	ERROR_ACCOUNT_LOCKED_BUTTONS: 'error_account_locked_buttons',
	ERROR_INCORRECT_CREDENTIALS_BUTTONS: 'error_incorrect_credentials_buttons',
	ERROR_ADDL_AUTHENTICATION_REQUIRED_BUTTONS:
		'error_invalid_addl_info_provided_buttons',
	ERROR_INVALID_ADDL_INFO_PROVIDED_BUTTONS:
		'error_invalid_addl_info_provided_buttons',
	ERROR_USER_ACTION_NEEDED_AT_SITE_BUTTONS:
		'error_user_action_needed_at_site_buttons',
	ERROR_CREDENTIALS_UPDATE_NEEDED_BUTTONS:
		'error_credentials_update_needed_buttons',
	ERROR_SITE_SESSION_INVALIDATED_BUTTONS:
		'error_site_session_invalidated_buttons',
	ERROR_UNEXPECTED_SITE_ERROR_BUTTONS: 'error_unexpected_site_error_buttons',
	ERROR_TECH_ERROR_BUTTONS: 'error_tech_error_buttons',
	ERROR_DATA_RETRIEVAL_FAILED_BUTTONS: 'error_data_retrieval_failed_buttons',
	ERROR_REQUEST_TIME_OUT_BUTTONS: 'error_request_time_out_buttons',
	ERROR_DATASET_NOT_SUPPORTED_BUTTONS: 'error_dataset_not_supported_buttons',
	ERROR_ENROLLMENT_REQUIRED_FOR_DATASET_BUTTONS:
		'error_enrollment_required_for_dataset_buttons',
	ERROR_GENERIC_BUTTONS: 'error_generic_buttons',
	ERROR_SITE_UNAVAILABLE_BUTTONS: 'error_site_unavailable_buttons',
	ERROR_SITE_BLOCKING_ERROR_BUTTONS: 'error_site_blocking_error_buttons',
	ERROR_SITE_NOT_SUPPORTED_BUTTONS: 'error_site_not_supported_buttons',
	ERROR_SITE_NOT_SUPPORTED_MANUAL_ACCOUNT_DISABLED_BUTTONS:
		'error_site_not_supported_manual_account_disabled_buttons',
	ERROR_DATA_NOT_AVAILABLE_BUTTONS: 'error_data_not_available_buttons',
	ERROR_NEW_AUTHENTICATION_REQUIRED_BUTTONS:
		'error_new_authentication_required_buttons',
	ERROR_BETA_SITE_DEV_IN_PROGRESS_BUTTONS:
		'error_beta_site_dev_in_progress_buttons',

	ERROR_MFA_INFO_NOT_PROVIDED_IN_REAL_TIME_BY_USER_VIA_APP_BUTTONS:
		'error_mfa_info_not_provided_in_real_time_by_user_via_app_buttons',
	ERROR_VERIFICATION_FAILED_BUTTONS: 'error_verification_failed_buttons',
	ERROR_NO_ACCOUNTS_FOR_VERIFICATION_BUTTONS:
		'error_no_accounts_for_verification_buttons',
	ERROR_UPDATE_NOT_ALLOWED_BUTTONS: 'error_update_not_allowed_buttons',
	ERROR_REFRESH_TOO_SOON_BUTTONS: 'error_refresh_too_soon_buttons',
	ERROR_REFRESH_ALREADY_IN_PROCESS_BUTTONS:
		'error_refresh_already_in_process_buttons',

	// Callback
	CLIENT_CALLBACK_DOMAINS: 'client_callback_domains',
	CLIENT_CALLBACK_URL_VALIDATION: 'client_callback_url_validation',

	// Tech Diff Page
	ENABLE_TECHDIFF_PAGE: 'enable_techdiff_page',

	// CDV MODULE
	ENABLE_CDV: 'enable_cdv',
	SHOW_CDV_ON_SEARCH: 'show_cdv_on_search',
	SHOW_CDV_ON_LOGIN: 'show_cdv_on_login',
	CDV_INITIATE_ACCOUNTTYPE_SELECTION: 'cdv_initiate_accountType_selection',
	ERROR_CUSTOM_INVALID_FLOW_BUTTONS: 'error_custom_invalid_flow_buttons',

	// DEELINK ERROR
	ERROR_TECH_DIFF_BUTTONS: 'error_tech_diff_buttons',
	ERROR_DEEPLINK_TECH_DIFF_BUTTONS: 'error_deeplink_tech_diff_buttons',

	// ERROR CDV SECTION CONFIG
	CDV_PRE_VERIFICATION_INVOKE_ENABLED_ERRORS:
		'cdv_pre_verification_invoke_enabled_errors',
	CDV_POST_VERIFICATION_INVOKE_ENABLED_ERRORS:
		'cdv_post_verification_invoke_enabled_errors',
	ERROR_CDV_INVALID_FLOW_BUTTONS: 'error_cdv_invalid_flow_buttons',
	ERROR_CDV_INITIATE_VERIFICATION_ALREADY_INITIATED_BUTTONS:
		'error_cdv_initiate_verification_already_initiated_buttons',
	ERROR_CDV_INITIATE_VERIFICATION_ALREADY_COMPLETED_BUTTONS:
		'error_cdv_initiate_verification_already_completed_buttons',
	ERROR_CDV_INITIATE_VERIFICATION_UNKNOWN_BUTTONS:
		'error_cdv_initiate_verification_unknown_buttons',
	ERROR_CDV_COMPLETE_ALREADY_SUCCESS_BUTTONS:
		'error_cdv_complete_already_success_buttons',
	ERROR_CDV_COMPLETE_ALREADY_FAILED_BUTTONS:
		'error_cdv_complete_already_failed_buttons',
	ERROR_CDV_COMPLETE_FAILED_BUTTONS: 'error_cdv_complete_failed_buttons',
	//REAL ESTATE

	DISABLE_REALESTATE_MANUAL: 'disable_realestate_manual',
	DISABLE_REALESTATE_SYSTEM: 'disable_realestate_system',
	SUPPORTED_CURRENCY: 'supported_currency',
	DISABLE_REALESTATE_EDIT: 'disable_realestate_edit',

	// MANUAL ACCOUNT
	MANUAL_ACCOUNT_ADD_ACCOUNT_TITLE: 'manual_account_add_account_title',
	MANUAL_ACCOUNT_VIEW_ACCOUNT_TITLE: 'manual_account_view_account_title',
	MANUAL_ACCOUNT_EDIT_ACCOUNT_TITLE: 'manual_account_edit_account_title',
	MANUAL_ACCOUNT_DELETE_ACCOUNT_POPUP_HEADER:
		'manual_account_delete_account_popup_header',
	MANUAL_ACCOUNT_DELETE_CONFIRM_TEXT: 'manual_account_delete_confirm_text',
	MANUAL_ACCOUNT_DELETE_ACCOUNT_WARNING_TEXT:
		'manual_account_delete_account_warning_text',
	MANUAL_ACCOUNT_DELETE_ACCOUNT_BUTTON_TEXT:
		'manual_account_delete_account_button_text'
}

export default params
