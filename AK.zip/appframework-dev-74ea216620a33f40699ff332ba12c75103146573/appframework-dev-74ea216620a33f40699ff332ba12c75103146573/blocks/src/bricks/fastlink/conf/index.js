import _AppStrings from './constants/locale'
import _AppParams from './constants/param'
import _AutoIds from './constants/autoids'
import _AppConstants from './constants/AppConstants'

import {
	getString as _getString,
	getParam as _getParam
} from './utilities/Utilities'

export const AppStrings = _AppStrings
export const AppParams = _AppParams
export const AutoIds = _AutoIds
export const getString = _getString
export const getParam = _getParam

window.AppStrings = _AppStrings
window.AppParams = _AppParams
window.AutoIds = _AutoIds
window.AppConstants = _AppConstants

const FLUtil = () => {
	let getParam = paramName => {
		return BrandUtils.getParam(paramName, 'fastlink')
	}
	let getString = stringName => {
		return BrandUtils.getString(stringName, 'fastlink')
	}

	let getFlowName = () => {
		return getParam(AppParams.PRODUCT_TYPE)
	}
	const isMSFlowEnabled = () => {
		return BrandUtils.getParam(
			AppParams.ENABLE_VERIFICATION_MS_FLOW,
			'fastlink'
		)
	}

	return {
		getParam,
		getString,
		getFlowName,
		isMSFlowEnabled
	}
}
window.FLUtil = FLUtil()
