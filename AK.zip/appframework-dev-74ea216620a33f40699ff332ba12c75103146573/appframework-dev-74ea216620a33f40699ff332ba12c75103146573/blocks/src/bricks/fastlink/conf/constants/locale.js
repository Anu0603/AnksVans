const locale = {
	FL_MODULE_NAME: 'fl_module_name',
	SITE_SORT_ORDER: 'site_sort_order',
	SECURITY_POLICY: 'security_policy',
	PRIVACY_POLICY: 'privacy_policy',
	NO_SEARCH_RESULT_LINE_ONE: 'no_search_result_line_one',
	NO_SEARCH_RESULT_LINE_TWO: 'no_search_result_line_two',
	REAL_ESTATE: 'real_estate',
	MANUAL: 'manual',
	SEARCH: 'search',
	SEARCH_DIFFERENT_FI: 'search_different_fi',
	SITE_LOGIN_FORM_QA_LABEL: 'mfa_qa_label',
	SITE_LOGIN_FORM_PASSCODE_LABEL: 'mfa_token_label',
	MFA_INFO_TEXT: 'mfa_info_text',
	MFA_TIMER_TEXT: 'mfa_timer_msg',
	MFA_CAPTCHA_PLACEHOLDER: 'mfa_captcha_placeholder',
	POPUP_ACCOUNT_NOT_LINK: 'popup_account_not_link',
	POPUP_EXIT_CONFIRMTION: 'popup_exit_confirmation',
	POPUP_CONTINUE: 'popup_continue',
	POPUP_EXIT: 'popup_exit',
	LOGIN_OPTIONAL_TEXT: 'login_optional_text',
	LOGIN_CHOOSE_ONE: 'login_choose_one',
	NEXT_BUTTON_TEXT: 'next_button_text',
	DELETE_BUTTON_TEXT: 'delete_button_text',
	COBRAND_NAME: 'cobrand_name',
	ACCOUNT_NUMBER_MASK_CHARACTER: 'account_number_mask_character',
	LOGIN_SUBMIT_BUTTON_TEXT: 'login_submit_button_text',
	LOGIN_UPDATE_BUTTON_TEXT: 'login_update_button_text',
	LOGIN_EDIT_CREDENTIALS_LABEL: 'login_edit_credentials_label',

	// VERIFICATION MODULE
	VERIFICATION_LOGIN_STEPPER_TEXT: 'verification_login_stepper_text',
	VERIFICATION_DATA_STEPPER_TEXT: 'verification_data_stepper_text',
	VERIFICATION_SUCCESS_TEXT: 'verification_success_text',

	//SUCCESS SCREEN
	ACCOUNTS_SUMMARY_TITLE_TEXT: 'accounts_summary_title_text',
	ACCOUNT_SUMMARY_SELECTION_MESSAGE_TEXT: 'account_summary_selection_message',
	ACCOUNT_SUMMARY_SINGLE_ACCOUNT_SELECTION_MESSAGE_TEXT:
		'account_summary_single_account_selection_message',
	ACCOUNTS_SUMMARY_SINGLE_ACCOUNT_MESSAGE_TEXT:
		'accounts_summary_single_account_message_text',
	ACCOUNT_SUMMARY_ALL_ACCOUNTS_DELETED_TEXT:
		'account_summary_all_accounts_deleted_text',
	ACCOUNT_SUMMARY_LINKING_MORE_ACCOUNTS_LOADING_TEXT:
		'account_summary_linking_more_accounts_loading_text',
	ACCOUNT_SUMMARY_LINK_MORE_ACCOUNTS_BUTTON_TEXT:
		'account_summary_link_more_accounts_button_text',
	ACCOUNT_SUMMARY_SAVE_AND_FINISH_BUTTON_TEXT:
		'account_summary_save_and_finish_button_text',
	ACCOUNT_SUMMARY_SAVE_AND_LINK_MORE_ACCOUNTS_BUTTON_TEXT:
		'account_summary_save_and_link_more_accounts_button_text',
	ACCOUNT_SUMMARY_CANCEL_BUTTON_TEXT: 'account_summary_cancel_button_text',
	ACCOUNT_SUMMARY_CLOSE_BUTTON_TEXT: 'account_summary_close_button_text',
	ACCOUNT_SUMMARY_BOTTOM_TEXT_START: 'account_summary_bottom_text_start',
	ACCOUNT_SUMMARY_BOTTOM_TEXT_END: 'account_summary_bottom_text_end',
	ACCOUNT_SUMMARY_DELETE_POPUP_CONFIRMATION_TEXT:
		'account_summary_delete_popup_confirmation_text',
	ACCOUNT_SUMMARY_CANCEL_POPUP_CONFIRMATION_TEXT_1:
		'account_summary_cancel_popup_confirmation_text_1',
	ACCOUNT_SUMMARY_CANCEL_POPUP_CONFIRMATION_TEXT_2:
		'account_summary_cancel_popup_confirmation_text_2',
	ACCOUNT_SUMMARY_DELETE_POPUP_KEEP_ACCOUNT_BUTTON_TEXT:
		'account_summary_delete_popup_keep_account_button_text',
	ACCOUNT_SUMMARY_DELETE_POPUP_DELETE_ACCOUNT_BUTTON_TEXT:
		'account_summary_delete_popup_delete_account_button_text',
	ACCOUNT_SUMMARY_CANCEL_POPUP_CONTINUE_LINKING_ACCOUNTS_BUTTON_TEXT:
		'account_summary_cancel_popup_continue_linking_accounts_button_text',
	ACCOUNT_SUMMARY_DELETE_POPUP_EXIT_BUTTON_TEXT:
		'account_summary_delete_popup_exit_button_text',
	ACCOUNT_SUMMARY_TITLE_CONTAINER_PARTIAL: 'account_summary_title_container_',
	ACCOUNT_SUMMARY_SELECTION_MESSAGE_MODAL_TEXT:
		'account_summary_selection_message_modal_text',
	ACCOUNT_SUMMARY_AGGREGATION_MESSAGE_MODAL_TEXT:
		'account_summary_aggregation_message_modal_text',

	//ACTION BUTTON TEXT
	ERROR_TA_BUTTON_TEXT: 'try_again_button_text',
	ERROR_EC_BUTTON_TEXT: 'edit_credentials_button_text',
	ERROR_CANCEL_BUTTON_TEXT: 'cancel_button_text',

	// ERROR TITLES, DESCRIPTIONS and TOOLTIP CONTENT
	ERROR_ACCOUNT_LOCKED_TITLE: 'error_account_locked_title',
	ERROR_ACCOUNT_LOCKED_DESC: 'error_account_locked_desc',
	ERROR_INCORRECT_CREDENTIALS_TITLE: 'error_incorrect_credentials_title',
	ERROR_INCORRECT_CREDENTIALS_DESC: 'error_incorrect_credentials_desc',
	ERROR_INCORRECT_CREDENTIALS_TOOLTIP_CONTENT:
		'error_incorrect_credentials_tooltip_content',
	ERROR_ADDL_AUTHENTICATION_REQUIRED_TITLE:
		'error_addl_authentication_required_title',
	ERROR_ADDL_AUTHENTICATION_REQUIRED_DESC:
		'error_addl_authentication_required_desc',
	ERROR_INVALID_ADDL_INFO_PROVIDED_TITLE:
		'error_invalid_addl_info_provided_title',
	ERROR_INVALID_ADDL_INFO_PROVIDED_DESC:
		'error_invalid_addl_info_provided_desc',
	ERROR_PROPERTY_VALUE_NOT_AVAILABLE_TITLE:
		'error_property_value_not_available_title',
	ERROR_PROPERTY_VALUE_NOT_AVAILABLE_DESC:
		'error_property_value_not_available_desc',
	ERROR_SITE_SESSION_INVALIDATED_TITLE:
		'error_site_session_invalidated_title',
	ERROR_SITE_SESSION_INVALIDATED_DESC: 'error_site_session_invalidated_desc',

	ERROR_SITE_NOT_SUPPORTED_TITLE: 'error_site_not_supported_title',
	ERROR_SITE_NOT_SUPPORTED_DESC: 'error_site_not_supported_desc',
	ERROR_SITE_NOT_SUPPORTED_MANUAL_ACCOUNT_DISABLED_TITLE:
		'error_site_not_supported_manual_account_disabled_title',
	ERROR_SITE_NOT_SUPPORTED_MANUAL_ACCOUNT_DISABLED_DESC:
		'error_site_not_supported_manual_account_disabled_desc',
	ERROR_MFA_INFO_NOT_PROVIDED_IN_REAL_TIME_BY_USER_VIA_APP_TITLE:
		'error_mfa_info_not_provided_in_real_time_by_user_via_app_title',
	ERROR_MFA_INFO_NOT_PROVIDED_IN_REAL_TIME_BY_USER_VIA_APP_DESC:
		'error_mfa_info_not_provided_in_real_time_by_user_via_app_desc',
	ERROR_DATA_NOT_AVAILABLE_TITLE: 'error_data_not_available_title',
	ERROR_DATA_NOT_AVAILABLE_DESC: 'error_data_not_available_desc',
	ERROR_USER_ACTION_NEEDED_AT_SITE_TITLE:
		'error_action_required_at_site_title',
	ERROR_USER_ACTION_NEEDED_AT_SITE_DESC: 'error_action_required_at_site_desc',
	ERROR_CREDENTIALS_UPDATE_NEEDED_TITLE:
		'error_action_required_at_site_title',
	ERROR_CREDENTIALS_UPDATE_NEEDED_DESC: 'error_action_required_at_site_desc',

	ERROR_UNEXPECTED_SITE_ERROR_TITLE: 'error_technical_error_title',
	ERROR_UNEXPECTED_SITE_ERROR_DESC: 'error_technical_error_desc',
	ERROR_TECH_ERROR_TITLE: 'error_technical_error_title',
	ERROR_TECH_ERROR_DESC: 'error_technical_error_desc',
	ERROR_DATA_RETRIEVAL_FAILED_TITLE: 'error_technical_error_title',
	ERROR_DATA_RETRIEVAL_FAILED_DESC: 'error_technical_error_desc',
	ERROR_REQUEST_TIME_OUT_TITLE: 'error_technical_error_title',
	ERROR_REQUEST_TIME_OUT_DESC: 'error_technical_error_desc',
	ERROR_DATASET_NOT_SUPPORTED_TITLE: 'error_technical_error_title',
	ERROR_DATASET_NOT_SUPPORTED_DESC: 'error_technical_error_desc',
	ERROR_ENROLLMENT_REQUIRED_FOR_DATASET_TITLE: 'error_technical_error_title',
	ERROR_ENROLLMENT_REQUIRED_FOR_DATASET_DESC: 'error_technical_error_desc',
	ERROR_GENERIC_TITLE: 'error_technical_error_title',
	ERROR_GENERIC_DESC: 'error_technical_error_desc',

	ERROR_SITE_UNAVAILABLE_TITLE: 'error_site_unavailable_title',
	ERROR_SITE_UNAVAILABLE_DESC: 'error_site_unavailable_desc',

	ERROR_SITE_BLOCKING_ERROR_TITLE: 'error_site_blocking_error_title',
	ERROR_SITE_BLOCKING_ERROR_DESC: 'error_site_blocking_error_desc',

	ERROR_NEW_AUTHENTICATION_REQUIRED_TITLE:
		'error_new_authentication_required_title',
	ERROR_NEW_AUTHENTICATION_REQUIRED_DESC:
		'error_new_authentication_required_desc',

	ERROR_BETA_SITE_DEV_IN_PROGRESS_TITLE:
		'error_beta_site_dev_in_progress_title',
	ERROR_BETA_SITE_DEV_IN_PROGRESS_DESC:
		'error_beta_site_dev_in_progress_desc',

	ERROR_VERIFICATION_FAILED_TITLE: 'error_verification_failed_title',
	ERROR_VERIFICATION_FAILED_DESC: 'error_verification_failed_desc',
	ERROR_NO_ACCOUNTS_FOR_VERIFICATION_TITLE:
		'error_no_accounts_for_verification_title',
	ERROR_NO_ACCOUNTS_FOR_VERIFICATION_DESC:
		'error_no_accounts_for_verification_desc',

	ERROR_UPDATE_NOT_ALLOWED_TITLE: 'error_update_not_allowed_title',
	ERROR_UPDATE_NOT_ALLOWED_DESC: 'error_update_not_allowed_desc',
	ERROR_REFRESH_TOO_SOON_TITLE: 'error_refresh_too_soon_title',
	ERROR_REFRESH_TOO_SOON_DESC: 'error_refresh_too_soon_desc',
	ERROR_REFRESH_ALREADY_IN_PROCESS_TITLE:
		'error_refresh_already_in_process_title',
	ERROR_REFRESH_ALREADY_IN_PROCESS_DESC:
		'error_refresh_already_in_process_desc',

	// ERROR SCREEN BUTTONS
	ERROR_TA_BUTTON_TEXT: 'error_ta_button_text',
	ERROR_VS_BUTTON_TEXT: 'error_vs_button_text',
	ERROR_GTS_BUTTON_TEXT: 'error_gts_button_text',
	ERROR_LAA_BUTTON_TEXT: 'error_laa_button_text',
	ERROR_LMA_BUTTON_TEXT: 'error_lma_button_text',
	ERROR_MAA_BUTTON_TEXT: 'error_maa_button_text',
	ERROR_CLOSE_BUTTON_TEXT: 'error_close_button_text',
	ERROR_SDS_BUTTON_TEXT: 'error_sds_button_text',
	ERROR_CANCEL_BUTTON_TEXT: 'error_cancel_button_text',

	ERROR_TECH_DIFF_TITLE: 'error_tech_diff_title',
	ERROR_TECH_DIFF_DESC: 'error_tech_diff_desc',
	ERROR_DEEPLINK_TECH_DIFF_TITLE: 'error_deeplink_tech_diff_title',
	ERROR_DEEPLINK_TECH_DIFF_DESC: 'error_deeplink_tech_diff_desc',
	ERROR_TECH_DIFF_CLOSE_BUTTON_TEXT: 'error_tech_diff_close_button_text',

	// CDV MODULE
	CDV_ERROR_ACCOUNT_TYPE_NOT_SELECTED: 'cdv_error_account_type_not_selected',
	CDV_ERROR_ROUTING_NUMBER_NOT_VALID: 'cdv_error_routing_number_not_valid',
	CDV_ERROR_ROUTING_NUMBER_NOT_FOUND: 'cdv_error_routing_number_not_found',
	CDV_ERROR_ACCOUNT_NUMBER_NOT_VALID: 'cdv_error_account_number_not_valid',
	CDV_ERROR_AMOUNT_NOT_VALID: 'cdv_error_amount_not_valid',
	CDV_INVOKE_VERIFICATION_INFO_TEXT: 'cdv_invoke_verification_info_text',
	CDV_INVOKE_PRE_VERIFICATION_DEMARCATION_TEXT:
		'cdv_invoke_pre_verification_demarcation_text',
	CDV_INVOKE_PRE_VERIFICATION_TITLE: 'cdv_invoke_pre_verification_title',
	CDV_INVOKE_PRE_VERIFICATION_TEXT_1: 'cdv_invoke_pre_verification_text_1',
	CDV_INVOKE_PRE_VERIFICATION_TEXT_2: 'cdv_invoke_pre_verification_text_2',
	CDV_INVOKE_PRE_VERIFICATION_BUTTON_TEXT:
		'cdv_invoke_pre_verification_button_text',
	CDV_INVOKE_POST_VERIFICATION_DEMARCATION_TEXT:
		'cdv_invoke_post_verification_demarcation_text',
	CDV_INVOKE_POST_VERIFICATION_TITLE: 'cdv_invoke_post_verification_title',
	CDV_INVOKE_POST_VERIFICATION_TEXT: 'cdv_invoke_post_verification_text',
	CDV_INVOKE_POST_VERIFICATION_BUTTON_TEXT:
		'cdv_invoke_post_verification_button_text',
	CDV_INITIATE_VERIFICATION_INFO_TITLE:
		'cdv_initiate_verification_info_title',
	CDV_INITIATE_VERIFICATION_FORM_ACCOUNT_TYPE_TEXT:
		'cdv_initiate_verification_form_account_type_text',
	CDV_INITIATE_VERIFICATION_FORM_ACCOUNT_TYPE_CHECKING_TEXT:
		'cdv_initiate_verification_form_account_type_checking_text',
	CDV_INITIATE_VERIFICATION_FORM_ACCOUNT_TYPE_SAVINGS_TEXT:
		'cdv_initiate_verification_form_account_type_savings_text',
	CDV_INITIATE_VERIFICATION_FORM_ROUTING_NUMBER_TEXT:
		'cdv_initiate_verification_form_routing_number_text',
	CDV_INITIATE_VERIFICATION_FORM_ACCOUNT_NUMBER_TEXT:
		'cdv_initiate_verification_form_account_number_text',
	CDV_INITIATE_VERIFICATION_FORM_HELP_TEXT:
		'cdv_initiate_verification_form_help_text',
	CDV_INITIATE_VERIFICATION_FORM_DETAIL_INFO_TEXT:
		'cdv_initiate_verification_form_detail_info_text',
	CDV_INITIATE_VERIFICATION_FORM_SUBMIT_BUTTON_TEXT:
		'cdv_initiate_verification_form_submit_button_text',
	CDV_INITIATE_VERIFICATION_FORM_HELP_POPUP_TITLE_TEXT:
		'cdv_initiate_verification_form_help_popup_title_text',
	CDV_INITIATE_VERIFICATION_SUCCESS_TITLE:
		'cdv_initiate_verification_success_title',
	CDV_INITIATE_VERIFICATION_SUCCESS_TEXT:
		'cdv_initiate_verification_success_text',
	CDV_INITIATE_VERIFICATION_SUCCESS_BUTTON_TEXT:
		'cdv_initiate_verification_success_button_text',
	CDV_INITIATE_VERIFICATION_INPROGRESS_TITLE:
		'cdv_initiate_verification_inprogress_title',
	CDV_INITIATE_VERIFICATION_INPROGRESS_TEXT:
		'cdv_initiate_verification_inprogress_text',
	CDV_INITIATE_VERIFICATION_INPROGRESS_BUTTON_TEXT:
		'cdv_initiate_verification_inprogress_button_text',
	CDV_COMPLETE_VERIFICATION_INFO_TITLE:
		'cdv_complete_verification_info_title',
	CDV_COMPLETE_VERIFICATION_INFO_TEXT: 'cdv_complete_verification_info_text',
	CDV_COMPLETE_VERIFICATION_ACCOUNT_INFO_ACCOUNT_NUMBER_TEXT:
		'cdv_complete_verification_account_info_account_number_text',
	CDV_COMPLETE_VERIFICATION_ACCOUNT_INFO_ROUTING_NUMBER_TEXT:
		'cdv_complete_verification_account_info_routing_number_text',
	CDV_COMPLETE_VERIFICATION_ACCOUNT_INFO_ACCOUNT_TYPE_TEXT:
		'cdv_complete_verification_account_info_account_type_text',
	CDV_COMPLETE_VERIFICATION_FORM_DEPOSIT_PREFIX:
		'cdv_complete_verification_form_deposit_',
	CDV_COMPLETE_VERIFICATION_FORM_DEPOSIT_POSTFIX: '_text',
	CDV_COMPLETE_VERIFICATION_FORM_WITHDRAWAL_TEXT:
		'cdv_complete_verification_form_withdrawal_text',
	CDV_COMPLETE_VERIFICATION_FORM_SUBMIT_BUTTON_TEXT:
		'cdv_complete_verification_form_submit_button_text',
	CDV_COMPLETE_SUCCESS_TITLE: 'cdv_complete_success_title',
	CDV_COMPLETE_SUCCESS_BUTTON_TEXT: 'cdv_complete_success_button_text',
	CDV_COMPLETE_SUCCESS_BUTTON_DEEPLINK_TEXT:
		'cdv_complete_success_button_deeplink_text',
	ERROR_CDV_INVALID_FLOW_TITLE: 'error_cdv_invalid_flow_title',
	ERROR_CDV_INVALID_FLOW_DESC: 'error_cdv_invalid_flow_desc',
	ERROR_CDV_INITIATE_VERIFICATION_ALREADY_INITIATED_TITLE:
		'error_cdv_initiate_verification_already_initiated_title',
	ERROR_CDV_INITIATE_VERIFICATION_ALREADY_INITIATED_DESC:
		'error_cdv_initiate_verification_already_initiated_desc',
	ERROR_CDV_INITIATE_VERIFICATION_ALREADY_COMPLETED_TITLE:
		'error_cdv_initiate_verification_already_completed_title',
	ERROR_CDV_INITIATE_VERIFICATION_ALREADY_COMPLETED_DESC:
		'error_cdv_initiate_verification_already_completed_desc',
	ERROR_CDV_INITIATE_VERIFICATION_UNKNOWN_TITLE:
		'error_cdv_initiate_verification_unknown_title',
	ERROR_CDV_INITIATE_VERIFICATION_UNKNOWN_DESC:
		'error_cdv_initiate_verification_unknown_desc',
	ERROR_CDV_COMPLETE_ALREADY_SUCCESS_TITLE:
		'error_cdv_complete_already_success_title',
	ERROR_CDV_COMPLETE_ALREADY_SUCCESS_DESC:
		'error_cdv_complete_already_success_desc',
	ERROR_CDV_COMPLETE_ALREADY_FAILED_TITLE:
		'error_cdv_complete_already_failed_title',
	ERROR_CDV_COMPLETE_ALREADY_FAILED_DESC:
		'error_cdv_complete_already_failed_desc',
	ERROR_CDV_COMPLETE_FAILED_TITLE: 'error_cdv_complete_failed_title',
	ERROR_CDV_COMPLETE_FAILED_DESC: 'error_cdv_complete_failed_desc',
	ERROR_CDV_COMPLETE_INCORRECT_AMOUNT_TITLE:
		'error_cdv_complete_incorrect_amount_title',

	ERROR_TECH_DIFF_TITLE: 'error_tech_diff_title',
	ERROR_TECH_DIFF_DESC: 'error_tech_diff_desc',
	ERROR_REAL_ESTATE_ADDRESS_NOT_FOUND_TITLE:
		'error_real_estate_address_not_found_title',
	ERROR_REAL_ESTATE_VALUE_ALREADY_ADDED_TITLE:
		'error_real_estate_value_already_added_title',
	ERROR_REAL_ESTATE_VALUE_ALREADY_ADDED_DESC:
		'error_real_estate_value_already_added_desc',
	ERROR_REAL_ESTATE_ADDRESS_NOT_FOUND_DESC:
		'error_real_estate_address_not_found_desc',
	ERROR_REAL_ESTATE_ERROR_SEARCH_AGAIN_DESC:
		'error_real_estate_error_search_again_desc',
	ERROR_REAL_ESTATE_ERROR_MULTIPLE_MATCHES_FOUND_DESC:
		'error_real_estate_error_multiple_matches_found_desc',
	ERROR_REAL_ESTATE_UNABLE_TO_DELETE_TITLE:
		'error_real_estate_unable_to_delete_title',
	ERROR_REAL_ESTATE_UNABLE_TO_DELETE_DESC:
		'error_real_estate_unable_to_delete_desc',
	REAL_ESTATE_ADD_ACCOUNT_TITLE: 'real_estate_add_account_title',
	REAL_ESTATE_EDIT_ACCOUNT_TITLE: 'real_estate_edit_account_title',
	REAL_ESTATE_INCLUDE_NET_WORTH_LABEL: 'real_estate_include_net_worth_label',
	REAL_ESTATE_ESTIMATED_VALUE_LABEL: 'real_estate_estimated_value_label',
	CURRENCY_LABEL: 'currency_label',
	REAL_ESTATE_REAL_ESTATE_NAME: 'real_estate_real_estate_name',
	REAL_ESTATE_STREET_ADDRESS_LABEL: 'real_estate_street_address_label',
	REAL_ESTATE_CITY_STATE_ZIP_LABEL: 'real_estate_city_state_zip_label',
	REAL_ESTATE_CALCULATE_AUTO: 'real_estate_calculate_auto',
	REAL_ESTATE_CALCULATE_AUTO_DESC: 'real_estate_calculate_auto_desc',
	REAL_ESTATE_ENTER_MANUALLY: 'real_estate_enter_manually',
	REAL_ESTATE_ENTER_MANUALLY_DESC: 'real_estate_enter_manually_desc',
	REAL_ESTATE_DELETE_CONFIRM_TEXT: 'real_estate_delete_confirm_text',
	REAL_ESTATE_FOOTER_TEXT: 'real_estate_footer_text',
	REAL_ESTATE_SMARTZIP_FOOTER_TEXT: 'real_estate_smartzip_footer_text',
	REAL_ESTATE_VIEW_ACCOUNT_TITLE: 'real_estate_view_account_title',
	REAL_ESTATE_MAIN_HOME_TEXT: 'real_estate_main_home_text',
	REAL_ESTATE_SEE_MORE_DETAILS_TEXT: 'real_estate_see_more_details_text',
	REAL_ESTATE_SMARTZIP: 'real_estate_smartzip',
	REAL_ESTATE_SAVE_FINISH_BUTTON_LABEL:
		'real_estate_save_finish_button_label',
	REAL_ESTATE_SAVE_AND_LINK_MORE_BUTTON_LABEL:
		'real_estate_save_and_link_more_button_label',
	REAL_ESTATE_DELETE_ACCOUNT_WARNING_TEXT:
		'real_estate_delete_account_warning_text',
	REAL_ESTATE_CITY_LABEL: 'real_estate_city_label',
	REAL_ESTATE_STATE_LABEL: 'real_estate_state_label',
	REAL_ESTATE_ZIP_LABEL: 'real_estate_zip_label',
	REAL_ESTATE_DELETE_ACCOUNT_BUTTON_TEXT:
		'real_estate_delete_account_button_text',
	REAL_ESTATE_SUBMIT_BUTTON_TEXT: 'real_estate_submit_button_text',
	REAL_ESTATE_DELETE_ACCOUNT_POPUP_HEADER:
		'real_estate_delete_account_popup_header',
	REAL_ESTATE_SPINNER_MESSAGE_TEXT: 'real_estate_spinner_message_text',
	CURRENCY_AUD: 'currency_aud',
	CURRENCY_BRL: 'currency_brl',
	CURRENCY_GBP: 'currency_gbp',
	CURRENCY_CAD: 'currency_cad',
	CURRENCY_CNY: 'currency_cny',
	CURRENCY_EUR: 'currency_eur',
	CURRENCY_HKD: 'currency_hkd',
	CURRENCY_INR: 'currency_inr',
	CURRENCY_IDR: 'currency_idr',
	CURRENCY_JPY: 'currency_jpy',
	CURRENCY_MXN: 'currency_mxn',
	CURRENCY_NZD: 'currency_nzd',
	CURRENCY_RUR: 'currency_rur',
	CURRENCY_SGD: 'currency_sgd',
	CURRENCY_ZAR: 'currency_zar',
	CURRENCY_CHF: 'currency_chf',
	CURRENCY_USD: 'currency_usd',
	CURRENCY_VND: 'currency_vnd',

	SMARTZIP_POPUP_HEADING: 'smartzip_popup_heading',
	SMARTZIP_POPUP_TEXT_LINE1: 'smartzip_popup_text_line1',
	SMARTZIP_POPUP_TEXT_LINE2: 'smartzip_popup_text_line2',
	POPUP_CANCEL_BUTTON: 'popup_cancel_button',
	SMARTZIP_POPUP_HEADER: 'smartzip_popup_header',
	POPUP_CONTINUE_BUTTON: 'popup_continue_button',

	ERROR_REQUIRED_FIELD: 'error_required_field',
	REAL_ESTATE_ERROR_INVALID_VALUE: 'real_estate_error_invalid_value',
	REAL_ESTATE_ERROR_NO_SPECIAL_CHAR: 'real_estate_error_no_special_char',

	// MANUAL ACCOUNT MODULE
	MANUAL_ACCOUNT_ADD_ACCOUNT_TITLE: 'manual_account_add_account_title',
	MANUAL_ACCOUNT_VIEW_ACCOUNT_TITLE: 'manual_account_view_account_title',
	MANUAL_ACCOUNT_EDIT_ACCOUNT_TITLE: 'manual_account_edit_account_title',
	MANUAL_ACCOUNT_DELETE_ACCOUNT_POPUP_HEADER:
		'manual_account_delete_account_popup_header',
	MANUAL_ACCOUNT_DELETE_CONFIRM_TEXT: 'manual_account_delete_confirm_text',
	MANUAL_ACCOUNT_DELETE_ACCOUNT_WARNING_TEXT:
		'manual_account_delete_account_warning_text',
	MANUAL_ACCOUNT_DELETE_ACCOUNT_BUTTON_TEXT:
		'manual_account_delete_account_button_text'
}

export default locale
