import { AppStrings, AppParams, AutoIds, getParam, getString } from '../conf'
const FastlinkUtil = () => {
	let product = getParam(AppParams.PRODUCT_TYPE)
	if (product) {
		product = product.toUpperCase()
	}
	const prodcutToDatasetMaping = []
	prodcutToDatasetMaping['AGGR'] = ['BASIC_AGG_DATA']
	prodcutToDatasetMaping['VERIFICATION'] = ['ACCT_PROFILE']
	prodcutToDatasetMaping['VERIFICATIONPLUSAGGR'] = [
		'BASIC_AGG_DATA',
		'ACCT_PROFILE'
	]

	let getProductMappingDataset = () => {
		if (!product) {
			return ''
		}
		return prodcutToDatasetMaping[product]
	}

	let getProviderAPIDataset = () => {
		if (!product) {
			return ''
		}
		let datsetArray = getProductMappingDataset()
		let dataset = ''
		for (let index in datsetArray) {
			dataset = dataset + datsetArray[index]
			if (datsetArray.length - 1 != index) {
				dataset = dataset + ' OR '
			}
		}
		return dataset
	}

	return {
		getProductMappingDataset,
		getProviderAPIDataset
	}
}
export default FastlinkUtil()
