import ParamKeyService from '../../services/common/ParamKeyService'
import Constants from '../../conf/constants/AppConstants'

class PKILibrary {
	constructor() {
		this.paramKeyService = new ParamKeyService()
	}
	initializePKI = () => {
		if (typeof PKI == 'undefined') {
			this.paramKeyService.getParamKeyValue(
				{ paramKeyString: Constants.PKI_ENABLE_PARAM_KEY_ID },
				this._getPublickey.bind(this)
			)
		}
	}

	_getPublickey(_error, _response) {
		if (!_error && _response[0].value === 'TRUE') {
			this.paramKeyService.getCoBrandPublicKey(
				{},
				this.setPublicKey.bind(this)
			)
		}
	}

	setPublicKey(key) {
		const PKILibraryPath = () => {
			return import('../../../../ext/PKI/library/PKI_Library')
		}
		if (key) {
			PKILibraryPath()
				.then(cmp => {
					PKI.setKey(key)
				})
				.catch(error => {
					console.log('Erorr loading PKI library' + error)
				})
		}
	}
}

export default PKILibrary
