import React from 'react'
import PKILibrary from './../index'

describe('Sample Test Case', () => {
	let container = null
	it('Check if PKI initialized', () => {
		container = new PKILibrary()
		container.initializePKI()
		expect(container.hasOwnProperty.length).toEqual(1)
	})

	it('Check if PKI initialized', () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve({})
		})
		container = new PKILibrary()
		container._getPublickey(null, [{ value: 'TRUE' }])
		expect(container.hasOwnProperty.length).toEqual(1)
	})
	it('Check if PKI initialized', () => {
		container = new PKILibrary()
		container.setPublicKey('test')
		expect(container.hasOwnProperty.length).toEqual(1)
	})
})
