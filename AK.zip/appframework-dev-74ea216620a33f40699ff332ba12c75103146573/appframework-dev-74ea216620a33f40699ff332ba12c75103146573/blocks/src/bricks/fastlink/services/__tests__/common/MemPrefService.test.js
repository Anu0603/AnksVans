import MemPrefService from '../../common/MemPrefService'

describe('MemPerf Service', () => {
	beforeEach(() => {
		Application.BaseService.makecall = function() {}
	})

	it('Check whether the getMemPref returns the data', done => {
		let memPref = {
			preference: [{ key: 'externalAccTncRevision', value: ['1'] }]
		}
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve(memPref)
		})

		act(() => {
			new MemPrefService().getMemPrefValue(
				{ prefKey: 'externalTnc' },
				function(_err, _res) {
					expect(memPref.preference[0].key).toBe(
						_res.preference[0].key
					)
					done()
				},
				() => {}
			)
		})
	})

	it('Check whether the getMemPref returns the exception', done => {
		let memPref = {
			errorCode: 'Y807',
			errorMessage: 'Resource not found',
			referenceCode: 'o1588506616291q21A179F'
		}
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.reject(memPref)
		})

		act(() => {
			new MemPrefService().getMemPrefValue(
				{ prefKey: 'externalTnc' },
				function(_err, _res) {
					expect(memPref.errorCode).toBe(_err.errorCode)
					done()
				}
			)
		})
	})

	it('Check whether the setMemPref returns the data', done => {
		let memPref = {}
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve(memPref)
		})

		act(() => {
			new MemPrefService().setMemPrefValue(
				{ prefKey: 'externalTnc', perfValue: [1] },
				function(_err, _res) {
					expect(memPref).toBe(_res)
					done()
				},
				() => {}
			)
		})
	})

	it('Check whether the setMemPref returns the failure message', done => {
		let memPref = {
			errorCode: 'Y807',
			errorMessage: 'Resource not found',
			referenceCode: 'o1588506616291q21A179F'
		}
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.reject(memPref)
		})

		act(() => {
			new MemPrefService().setMemPrefValue(
				{ prefKey: 'externalTnc', perfValue: [1] },
				function(_err, _res) {
					expect(memPref.errorCode).toBe(_err.errorCode)
					done()
				}
			)
		})
	})

	it('Check whether the setMemPref without callback', done => {
		let memPref = {
			errorCode: 'Y807',
			errorMessage: 'Resource not found',
			referenceCode: 'o1588506616291q21A179F'
		}
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.reject(memPref)
		})

		act(() => {
			new MemPrefService().setMemPrefValue({
				prefKey: 'externalTnc',
				perfValue: [1]
			})
			done()
		})
	})
})
