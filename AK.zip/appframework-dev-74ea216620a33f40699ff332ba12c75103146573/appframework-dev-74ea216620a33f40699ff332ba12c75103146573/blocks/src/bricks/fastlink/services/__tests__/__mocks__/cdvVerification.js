export default {
	initVerificationMap: {
		UNKNOWN: {
			unknown: 'unknown'
		},
		INITIATED: {
			verification: [
				{
					accountId: 12295258,
					verificationType: 'CHALLENGE_DEPOSIT',
					verificationStatus: 'INITIATED',
					providerAccountId: 11269520,
					verificationId: 10039289
				}
			]
		},
		ERROR_Y840: {
			errorOccurred: true,
			details: {
				errorCode: 'Y840'
			}
		},
		ERROR_Y837: {
			errorOccurred: true,
			details: {
				errorCode: 'Y837'
			}
		}
	},
	getVerificationInfoMap: {
		TECH_ERROR: {
			unknown: 'unknown'
		},
		DEPOSITED: {
			verification: [
				{
					accountId: 12481712,
					verificationType: 'CHALLENGE_DEPOSIT',
					account: {
						accountNumber: '21320918309221321',
						accountType: 'SAVINGS',
						bankTransferCode: {
							id: '999999989',
							type: 'ROUTING_NUMBER'
						}
					},
					verificationStatus: 'DEPOSITED',
					providerAccountId: 11329462,
					verificationId: 10041437
				}
			]
		},
		ERROR_Y842: {
			errorOccurred: true,
			details: {
				errorCode: 'Y842'
			}
		},
		ERROR_Y800: {
			errorOccurred: true,
			details: {
				errorCode: 'Y800'
			}
		}
	},
	submitVerificationMap: {
		TECH_ERROR: {
			unknown: 'unknown'
		},
		SUCCESS: {
			verification: [
				{
					accountId: 12488874,
					verificationDate: '2020-05-03T20:18:20Z',
					verificationType: 'CHALLENGE_DEPOSIT',
					verificationStatus: 'SUCCESS',
					providerAccountId: 11331324,
					verificationId: 10041449
				}
			]
		},
		MISMATCH: {
			verification: [
				{
					accountId: 12481723,
					verificationDate: '2020-05-03T20:12:16Z',
					reason: 'DATA_MISMATCH',
					verificationType: 'CHALLENGE_DEPOSIT',
					verificationStatus: 'FAILED',
					providerAccountId: 11331323,
					verificationId: 10041448
				}
			]
		},
		FAILED: {
			details: {
				errorCode: 'Y842'
			},
			errorOccurred: true
		}
	}
}
