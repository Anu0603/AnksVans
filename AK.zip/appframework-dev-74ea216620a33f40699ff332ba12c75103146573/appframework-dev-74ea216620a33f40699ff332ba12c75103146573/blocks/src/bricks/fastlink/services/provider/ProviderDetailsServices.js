import { getParam, AppParams } from '../../conf'

class ProviderDetailsServices {
	constructor(data) {
		if (data) {
			this.show_tnc_always = data.show_tnc_always
			this.tnc_version = data.tnc_version
			this.one_time_tnc = data.one_time_tnc
		}
	}

	getLoginForm = _response => {
		let provideDetails =
			_response['providerDetails'].provider ||
			_response['providerDetails']['providerAccount']
		let provider = provideDetails[0]
		let data = {
			id: provider.id,
			providerId: provider.providerId,
			hexCode1: provider.backgroundColor,
			hexCode2: provider.highlightColor,
			name: provider.name,
			loginUrl: provider.loginUrl,
			favicon: provider.favicon,
			logo: provider.logo,
			authType: provider.authType,
			countryISOCode: provider.countryISOCode,
			helpText: provider.loginForm[0].loginHelp || provider.help,
			formType: provider.loginForm[0].formType,
			loginForm: provider.loginForm[0].row,
			providerAccount: {
				aggregationSource: provider.aggregationSource
			}
		}
		if (!data.hexCode1) {
			data.hexCode1 = '#747474'
		}
		if (!data.hexCode2) {
			data.hexCode2 = '#0096D6'
		}

		if (_response['tnc']) {
			let tnv = _response['tnc']['preference']
			for (let prefIndex in tnv) {
				let pref = tnv[prefIndex]

				if (pref.value[0]) {
					data.tncValue = parseInt(pref.value[0])
				}
			}
		}

		if (
			this.one_time_tnc == true &&
			data.tncValue &&
			data.tncValue == this.tnc_version
		) {
			data.showTnc = false
		} else if (this.one_time_tnc || this.show_tnc_always) {
			data.showTnc = true
		}
		return data
	}

	getProvidersDetails = (_options, _callback) => {
		let providerDetails = {
			serviceType: 'ysl',
			url: _options.providerId
				? '/1.1/providers'
				: '/1.1/providerAccounts',
			method: 'GET',
			identifier: 'providerDetails'
		}
		// Get a login form for provider ID else get for provider Acocunt Id for edit flow
		if (_options.providerId) {
			providerDetails.url =
				providerDetails.url + '/' + _options.providerId
		} else if (_options.providerAccountId) {
			providerDetails.url =
				providerDetails.url + '/' + _options.providerAccountId
			providerDetails.data = {
				include: 'credentials'
			}
		}

		_options.data = { graphData: [providerDetails] }

		// To be fixed AppParams.LOGIN_SHOW_ONETIME_TNC
		if (this.one_time_tnc == true || this.show_tnc_always == true) {
			let tncMem = {
				serviceType: 'ysl',
				url: '/v1.1/user/preferences?key=externalAccTncRevision',
				method: 'GET',
				identifier: 'tnc'
			}
			_options.data.graphData.push(tncMem)
		}

		var self = this
		return new Promise(function(resolve, reject) {
			Application.BaseService.graphCall(_options)
				.then(_response => {
					resolve(self.getLoginForm(_response))
				})
				.catch(_error => {
					if (self.checkErrorHappend(_error)) {
						reject(_error)
					} else {
						resolve(self.getLoginForm(_error))
					}
				})
		})
	}

	//Temporary fix untill error handing is taken care
	//To be fixed
	checkErrorHappend(_error) {
		let isError = true
		if (_error.providerDetails && !_error.providerDetails.errorOccurred) {
			isError = false
		}
		return isError
	}

	// TBD Error Handling
	getProviderDetailsByRTN = (_options, _callback) => {
		let self = this
		_options.data = {
			url: '/1.1/providers',
			method: 'GET',
			data: {
				capability: 'CHALLENGE_DEPOSIT_VERIFICATION',
				name: _options.name
			}
		}
		Application.BaseService.makecall(_options)
			.then(_response => {
				_callback(null, self.parseProviderDetailsByRTN(_response))
			})
			.catch(_error => {
				_callback(_error)
			})
	}

	// Parsers
	parseProviderDetailsByRTN(_response) {
		let parsedRTNResponse = {
			fiName: null,
			providerId: null
		}
		if (_response && _response.provider && _response.provider[0]) {
			let parsedResponse = _response.provider[0]

			parsedRTNResponse.name = parsedResponse.name
				? parsedResponse.name
				: parsedResponse.displayName
			parsedRTNResponse.id = parsedResponse.id
			parsedRTNResponse.hexCode1 = parsedResponse.backgroundColor
				? parsedResponse.backgroundColor
				: '#747474'
			parsedRTNResponse.hexCode2 = parsedResponse.highlightColor
				? parsedResponse.highlightColor
				: '#0096D6'
			parsedRTNResponse.logo = parsedResponse.logo
		}
		return parsedRTNResponse
	}
}

export default ProviderDetailsServices
