import param from '../../conf/constants/param'

const PfileService = {
	getPfileContent: (_options, _callback) => {
		_options.data = {
			method: 'GET',
			data: {}
		}

		Application.BaseService.getPfileResourceCall(_options)
			.then(_response => {
				_callback(null, _response)
			})
			.catch(_error => {
				_callback(_error)
			})
	}
}

export default PfileService
