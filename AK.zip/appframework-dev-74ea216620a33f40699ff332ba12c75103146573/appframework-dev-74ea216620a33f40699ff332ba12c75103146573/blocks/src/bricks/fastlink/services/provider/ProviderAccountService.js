import FastlinkUtil from './../../utils/Utilities'
class ProviderAccountService {
	getFormatAddUpdateAPIRequestData(_options) {
		let postObj = { loginForm: { row: [] } }
		let field = { field: [] }
		let mfaForm = _options.mfaForm
		let mfaLabelList = []
		for (let index in mfaForm) {
			mfaLabelList[mfaForm[index].field[0].id] = mfaForm[index].label
		}
		let isEncrypt = false

		if (
			_options.formType.toLowerCase() == 'login' ||
			_options.formType.toLowerCase() == 'questionandanswer'
		) {
			isEncrypt = true
		}

		let fieldVlaues = _options.fieldVlaues
		if (fieldVlaues) {
			for (let i in fieldVlaues) {
				var fieldObj = {
					id: i,
					value: this.encryptData(fieldVlaues[i], isEncrypt)
				}
				if (mfaLabelList[i]) {
					fieldObj.label = mfaLabelList[i]
				}
				field.field.push(fieldObj)
			}
		}
		postObj.loginForm.row.push(field)
		return field
	}

	encryptData(data, isEncrypt) {
		if (!isEncrypt || typeof PKI == 'undefined') {
			return data
		}
		return PKI.encrypt(data)
	}

	parseResponse(_response) {
		let response = _response.providerAccount[0]
		var refreshDetails = {
			providerAccountId: response.id,
			providerId: response.providerId,
			status: response.status,
			requestId: response.requestId,
			mfaLoginForm: response.loginForm
		}
		let additionalStatus = null
		for (let i in response.dataset) {
			let eachDataset = response.dataset[i]
			if (
				eachDataset.additionalStatus &&
				eachDataset.name == 'BASIC_AGG_DATA'
			) {
				additionalStatus = eachDataset.additionalStatus
			}
		}
		refreshDetails.additionalStatus = additionalStatus
		return refreshDetails
	}

	getProviderAccountDetails = _inputParams => {
		let _options = {}
		_options.data = {
			url: '/1.1/providerAccounts',
			method: 'GET'
		}

		if (_inputParams.providerAccountId && _inputParams.requestId) {
			_options.data.url =
				_options.data.url +
				'/' +
				_inputParams.providerAccountId +
				'?requestId=' +
				_inputParams.requestId
		}
		if (!_inputParams.requestId && _inputParams.providerAccountId) {
			_options.data.method = 'PUT'
			_options.data.data = {}
			_options.data.url =
				_options.data.url +
				'?providerAccountIds=' +
				_inputParams.providerAccountId
		}
		var self = this
		return new Promise(function(resolve, reject) {
			Application.BaseService.makecall(_options)
				.then(_response => {
					return resolve(self.parseResponse(_response))
				})
				.catch(_error => {
					return reject(_error)
				})
		})
	}

	addAccount = (_options, _callback) => {
		_options.data = {
			url: '/1.1/providerAccounts',
			method: 'POST'
		}

		if (_options.providerId) {
			_options.data.url =
				_options.data.url + '?providerId=' + _options.providerId
		}
		_options.data.data = this.getFormatAddUpdateAPIRequestData(_options)
		if (_options.providerAccountId) {
			_options.data.url =
				_options.data.url +
				'?providerAccountIds=' +
				_options.providerAccountId
			_options.data.method = 'PUT'
		}
		_options.data.data.datasetName = FastlinkUtil.getProductMappingDataset()
		var self = this
		return new Promise(function(resolve, reject) {
			Application.BaseService.makecall(_options)
				.then(_response => {
					return resolve(self.parseResponse(_response))
				})
				.catch(_error => {
					return reject(_error)
				})
		})
	}

	deleteProviderAccount(_options, _callback) {
		_options.data = {
			url: '/1.1/providerAccounts/' + _options.providerAccountId,
			method: 'DELETE'
		}
		_options.callback = (_error, _response) => {
			_callback(_error, _response)
		}

		Application.BaseService.makecall(_options)
	}
}

export default ProviderAccountService
