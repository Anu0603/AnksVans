import VerificationService from '../../provider/VerificationService'

describe('Sample Test Case', () => {
	it('Sample Test Case', () => {
		expect(1 + 1).toBe(2)
	})
})
