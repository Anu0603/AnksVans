export default {
	providerAccount: [
		{
			id: 11325903,
			providerId: 5,
			aggregationSource: 'USER',
			status: 'LOGIN_IN_PROGRESS',
			requestId: 'aqvM2fg4WXy4gPuvyOl2S9+KHRU=',
			code: 801,
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					additionalStatus: 'LOGIN_IN_PROGRESS',
					updateEligibility: 'DISALLOW_UPDATE',
					lastUpdated: '2020-05-02T20:16:44Z',
					lastUpdateAttempt: '2020-05-04T04:33:48Z',
					nextUpdateScheduled: '2020-04-27T01:14:25Z'
				}
			]
		}
	]
}
