export default {
	providerDetails: {
		providerAccount: [
			{
				id: 11331215,
				aggregationSource: 'USER',
				providerId: 16441,
				isManual: false,
				createdDate: '2020-05-03T07:53:21Z',
				status: 'FAILED',
				dataset: [
					{
						name: 'BASIC_AGG_DATA',
						additionalStatus: 'INCORRECT_CREDENTIALS',
						updateEligibility: 'ALLOW_UPDATE_WITH_CREDENTIALS'
					}
				],
				loginForm: [
					{
						id: 16103,
						forgetPasswordURL: 'http://64.14.28.129/dag/index.do',
						formType: 'login',
						row: [
							{
								id: 150862,
								label: 'Username',
								form: '0001',
								fieldRowChoice: '0001',
								field: [
									{
										id: 65499,
										name: 'LOGIN',
										type: 'text',
										value: '',
										isOptional: false,
										valueEditable: true
									}
								]
							},
							{
								id: 150863,
								label: 'Password',
								form: '0001',
								fieldRowChoice: '0002',
								field: [
									{
										id: 65500,
										name: 'PASSWORD',
										type: 'password',
										value: '',
										isOptional: false,
										valueEditable: true
									}
								]
							}
						]
					}
				]
			}
		]
	},
	tnc: {
		preference: [
			{
				key: 'externalAccTncRevision',
				value: ['1']
			}
		]
	}
}
