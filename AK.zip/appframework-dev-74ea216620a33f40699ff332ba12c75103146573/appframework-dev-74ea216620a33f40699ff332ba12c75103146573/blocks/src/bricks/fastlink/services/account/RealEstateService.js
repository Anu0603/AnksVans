export default class RealEstateService {
	getRealEstate(_inputParams) {
		let _options = {}
		_options.data = {
			url: `/1.1/accounts/${_inputParams.id}?container=realEstate`,
			method: 'GET'
		}

		return Application.BaseService.makecall(_options)
	}

	addRealEstate(_options) {
		let data = {
			account: {
				accountType: 'REAL_ESTATE',
				accountName: _options.accountName,
				valuationType: _options.valuationType,
				includeInNetWorth: _options.includeInNetWorth
			}
		}
		delete _options.includeInNetWorth
		if (_options.valuationType === 'MANUAL') {
			data.account.homeValue = _options.homeValue
		} else {
			data.account.address = _options.address
		}
		_options.data = {
			url: '/1.1/accounts',
			method: 'POST',
			data: data
		}

		return Application.BaseService.makecall(_options)
	}

	editRealEstate(_options) {
		let data = {
			account: {
				accountName: _options.accountName,
				valuationType: _options.valuationType,
				includeInNetWorth: _options.includeInNetWorth
			}
		}

		delete _options.includeInNetWorth
		if (_options.valuationType === 'MANUAL') {
			data.account.homeValue = _options.homeValue
		} else {
			data.account.address = _options.address
		}
		_options.data = {
			url: `/1.1/accounts/${_options.accountId}`,
			method: 'PUT',
			data: data
		}
		return Application.BaseService.makecall(_options)
	}

	evaluateAddress(_options = {}) {
		_options.data = {
			url: `/1.1/evaluateAddress`,
			method: 'POST',
			data: { address: _options.address }
		}
		return Application.BaseService.makecall(_options)
	}
}
