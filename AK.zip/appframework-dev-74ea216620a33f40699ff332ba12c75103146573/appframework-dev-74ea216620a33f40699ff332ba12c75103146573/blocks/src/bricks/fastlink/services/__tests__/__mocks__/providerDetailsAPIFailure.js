export default {
	providerDetails: {
		errorCode: 'Y821',
		errorMessage: 'Provider not supported',
		referenceCode: 'U1588491936704t21b179o',
		errorOccurred: true
	},
	tnc: {
		errorCode: 'Y807',
		errorMessage: 'Resource not found',
		referenceCode: 'g1588491936659v21L179G',
		errorOccurred: true
	}
}
