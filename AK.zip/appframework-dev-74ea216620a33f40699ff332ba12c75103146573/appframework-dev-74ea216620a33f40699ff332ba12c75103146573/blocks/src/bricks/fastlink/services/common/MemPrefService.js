class CommonService {
	getMemPrefValue = (_options, _callback) => {
		_options.data = {
			url: '/v1.1/user/preferences',
			method: 'GET',
			data: {
				key: _options.prefKey
			}
		}
		if (!_callback) {
			_callback = () => {}
		}
		Application.BaseService.makecall(_options)
			.then(_response => {
				_callback(null, _response)
			})
			.catch(_error => {
				_callback(_error)
			})
	}

	setMemPrefValue = (_options, _callback) => {
		_options.data = {
			url: '/v1.1/user/preferences',
			method: 'POST'
		}

		let _preference = { preference: [] }
		var eachParam = { key: _options.prefKey, value: _options.perfValue }
		_preference.preference.push(eachParam)
		_options.data.data = _preference
		if (!_callback) {
			_callback = () => {}
		}

		Application.BaseService.makecall(_options)
			.then(_response => {
				_callback(null, _response)
			})
			.catch(_error => {
				_callback(_error)
			})
	}
}

export default CommonService
