import ProviderDetailsServices from '../../provider/ProviderDetailsServices'

import ProvidersData from './../__mocks__/providerDetails'
import providerDetailsFailure from './../__mocks__/providerDetailsFailure'
import providerDetailsAPIFailure from './../__mocks__/providerDetailsAPIFailure'
import ProviderAccountDetails from './../__mocks__/ProviderAccountDetails'

describe('Provider Detail Service', () => {
	beforeEach(() => {
		Application.BaseService.makecall = function() {}
	})

	it('Check whether the providerDetails returns the data for first time user with TNc failure', done => {
		Application.BaseService.graphCall = jest.fn(_options => {
			return Promise.resolve(providerDetailsFailure)
		})
		act(() => {
			let providrId =
				providerDetailsFailure.providerDetails.provider[0].id
			let providerDetailsPromises = new ProviderDetailsServices({
				one_time_tnc: true,
				tnc_version: 1
			}).getProvidersDetails({
				providerId: providrId
			})

			providerDetailsPromises.then(
				function(response) {
					expect(response.id).toBe(providrId)
					done()
				},
				response => {
					done()
				}
			)
		})
	})

	it('Check whether the providerDetails returns the data for second time user', done => {
		Application.BaseService.graphCall = jest.fn(_options => {
			return Promise.resolve(ProvidersData)
		})
		act(() => {
			let providrId = ProvidersData.providerDetails.provider[0].id
			let providerDetailsPromises = new ProviderDetailsServices({
				show_tnc_always: true
			}).getProvidersDetails({
				providerId: providrId,
				tnc_version: 1
			})
			providerDetailsPromises.then(
				function(response) {
					expect(response.id).toBe(providrId)
					done()
				},
				() => {}
			)
		})
	})

	it('Check whether the providerDetails returns the API failure', done => {
		Application.BaseService.graphCall = jest.fn(_options => {
			return Promise.reject(providerDetailsAPIFailure)
		})
		act(() => {
			let providerDetailsPromises = new ProviderDetailsServices({
				show_tnc_always: true
			}).getProvidersDetails({
				providerId: 10,
				tnc_version: 1
			})
			providerDetailsPromises.then(
				function(response) {
					done()
				},
				e => {
					done()
				}
			)
		})
	})

	it('Check whether the providerDetails returns the Edit provider Accounts details', done => {
		Application.BaseService.graphCall = jest.fn(_options => {
			return Promise.resolve(ProviderAccountDetails)
		})
		act(() => {
			let providrAccountId =
				ProviderAccountDetails.providerDetails.providerAccount[0].id

			let providerId =
				ProviderAccountDetails.providerDetails.providerAccount[0]
					.providerId
			let providerDetailsPromises = new ProviderDetailsServices({
				show_tnc_always: true
			}).getProvidersDetails({
				providerAccountId: providrAccountId,
				tnc_version: 1
			})
			providerDetailsPromises.then(
				function(response) {
					expect(response.id).toBe(providrAccountId)
					done()
				},
				e => {
					done()
				}
			)
		})
	})
})
