import ManualAccountService from './../../account/ManualAccountService'

describe('Manual Account service', () => {
	const manualAccountService = new ManualAccountService()
	beforeEach(() => {
		Application.BaseService.makecall = function() {}
	})
	it('Should get manual account data ', () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve({ accountId: 123 })
		})

		manualAccountService.getManualAccount({ id: 1 }).then(res => {
			expect(res).toMatchObject({ accountId: 123 })
		})
	})
	it('Should add manual account data', () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve({})
		})

		manualAccountService.addManualAccount({}).then(res => {
			expect(res).toMatchObject({})
		})
	})
	it('Should edit manual account data', () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve({})
		})

		manualAccountService.editManualAccount({}).then(res => {
			expect(res).toMatchObject({})
		})
	})
})
