class VerificationService {
	/** API HANDLERS */
	/**
	 * Starts the CDV Verification Flow
	 */
	initiateVerification = (_options, _callback) => {
		var self = this
		_options.data = {
			url: '/1.1/verification',
			method: 'POST'
		}
		_options.data.data = this.getInitiateVerificationRequestData(_options)
		Application.BaseService.makecall(_options)
			.then(_response => {
				_callback(
					null,
					self.parseInitiateVerificationResponse(_response)
				)
			})
			.catch(_error => {
				_callback(null, self.parseInitiateVerificationResponse(_error))
			})
	}

	/**
	 * Gets the CDV Verification Status for the account Id being passed
	 */
	getVerificationInfo = (_options, _callback) => {
		var self = this
		_options.data = {
			url: '/1.1/verification',
			method: 'GET',
			data: {
				accountId: _options.accountId
			}
		}
		Application.BaseService.makecall(_options)
			.then(_response => {
				_callback(null, self.parseVerificationInfoResponse(_response))
			})
			.catch(_error => {
				_callback(null, self.parseVerificationInfoResponse(_error))
			})
	}

	/**
	 * Submit the CDV Verification
	 */
	submitVerificationDetails = (_options, _callback) => {
		var self = this
		_options.data = {
			url: '/1.1/verification',
			method: 'PUT'
		}
		_options.data.data = this.getSubmitVerificationRequestData(_options)
		Application.BaseService.makecall(_options)
			.then(_response => {
				_callback(null, self.parseSubmitVerificationResponse(_response))
			})
			.catch(_error => {
				_callback(null, self.parseSubmitVerificationResponse(_error))
			})
	}

	/** PARSERS */

	/**
	 * Parses the initiate verification response
	 */
	// TBD ACH Expired
	parseInitiateVerificationResponse(_response) {
		let initVerificationResponse = {}
		if (_response && _response.verification) {
			let verificationResponse = _response.verification[0]
			if (verificationResponse) {
				initVerificationResponse.status =
					verificationResponse.verificationStatus
				initVerificationResponse.reason = verificationResponse.reason
					? response.reason
					: null
			}
		} else if (_response && _response.errorOccurred && _response.details) {
			// Verification has been initiated already
			if (
				_response.details.code == 'Y840' ||
				_response.details.errorCode == 'Y840'
			) {
				initVerificationResponse.status = 'FAILED'
				initVerificationResponse.reason = 'ALREADY_INITIATED'

				// This account has already completed the verification process
			} else if (
				_response.details.code == 'Y837' ||
				_response.details.errorCode == 'Y837'
			) {
				initVerificationResponse.status = 'FAILED'
				initVerificationResponse.reason = 'ALREADY_COMPLETED'
			}
		}
		initVerificationResponse.status = !initVerificationResponse.status
			? 'FAILED'
			: initVerificationResponse.status
		initVerificationResponse.reason = !initVerificationResponse.reason
			? 'UNKNOWN'
			: initVerificationResponse.reason
		return initVerificationResponse
	}

	/**
	 * Parses the get verification response
	 */
	// TBD any value if is null, verificationId
	parseVerificationInfoResponse(_response) {
		let verificationResponse = {}
		if (_response && _response.verification) {
			let response = _response.verification[0]
			verificationResponse.accountNumber = response.account.accountNumber
			verificationResponse.routingNumber =
				response.account.bankTransferCode.id
			verificationResponse.accountType = response.account.accountType
			verificationResponse.status = response.verificationStatus
			verificationResponse.providerAccountId = response.providerAccountId
			verificationResponse.reason = response.reason
		} else if (_response && _response.errorOccurred && _response.details) {
			if (
				_response.details.code == 'Y842' ||
				_response.details.errorCode == 'Y842'
			) {
				verificationResponse.status = 'FAILED'
			} else {
				verificationResponse.status = _response.details.errorCode
					? _response.details.errorCode
					: _response.details.code
			}
		}

		verificationResponse.status = !verificationResponse.status
			? 'TECH_ERROR'
			: verificationResponse.status
		verificationResponse.reason = !verificationResponse.reason
			? 'UNKNOWN'
			: verificationResponse.reason

		return verificationResponse
	}

	/**
	 * Parses the complete verification response
	 */
	parseSubmitVerificationResponse(_response) {
		let verificationResponse = {}
		if (_response && _response.verification) {
			let response = _response.verification[0]
			verificationResponse.status = response.verificationStatus
			verificationResponse.reason = response.reason
				? response.reason
				: null
		} else if (
			_response &&
			_response.errorOccurred &&
			_response.details &&
			(_response.details.code == 'Y842' ||
				_response.details.errorCode == 'Y842')
		) {
			verificationResponse.status = 'FAILED'
			verificationResponse.reason = 'TOO_MANY_ATTEMPTS'
		} else {
			verificationResponse.status = 'TECH_ERROR'
		}
		return verificationResponse
	}

	/** HELPERS */
	/**
	 * Get the request object for initiate verification call
	 */
	getInitiateVerificationRequestData(_options) {
		let requestObject = {
			verification: {
				account: {
					accountNumber: _options.accountNumber,
					accountType: _options.accountType,
					bankTransferCode: {
						id: _options.routingNumber,
						type: 'ROUTING_NUMBER'
					}
				},
				verificationType: 'CHALLENGE_DEPOSIT'
			}
		}
		return requestObject
	}

	/**
	 * Get the request object for submit verification call
	 */
	getSubmitVerificationRequestData(_options) {
		let requestObject = {
			verification: {
				transaction: [],
				verificationType: 'CHALLENGE_DEPOSIT',
				accountId: _options.accountId,
				providerAccountId: _options.providerAccountId
			}
		}

		for (let creditDetail of _options.creditDetails) {
			requestObject.verification.transaction.push(
				this.getTransactionDetailsObject(creditDetail, 'CREDIT')
			)
		}

		for (let debitDetail of _options.debitDetails) {
			requestObject.verification.transaction.push(
				this.getTransactionDetailsObject(debitDetail, 'DEBIT')
			)
		}
		return requestObject
	}

	/**
	 * Get the transaction request object for the submit verification call
	 */
	getTransactionDetailsObject(_transactionAmount, _baseType) {
		let transactionObject = {
			baseType: _baseType,
			amount: {
				amount: '',
				currency: 'USD'
			}
		}
		transactionObject.amount.amount = _transactionAmount
		return transactionObject
	}
}
export default VerificationService
