export default {
	bill: [
		{
			id: 12490439,
			accountName: 'DAG BILLING',
			accountType: 'BILLS',
			providerAccountId: 11326300,
			accountNumber: 'x-5555',
			currency: 'USD',
			amount: 1200,
			negativeCurrency: false,
			checked: false
		}
	],
	investment: [
		{
			id: 12490438,
			accountName: 'Dag IRA',
			accountType: 'INDIVIDUAL RETIREMENT ACCOUNT IRA',
			providerAccountId: 11326300,
			accountNumber: 'x-2345',
			currency: 'USD',
			amount: 609447.65,
			negativeCurrency: false,
			checked: false
		}
	],
	creditCard: [
		{
			id: 12490435,
			accountName: 'Dag Credit Card',
			accountType: 'CREDIT',
			providerAccountId: 11326300,
			accountNumber: 'x-9806',
			currency: 'USD',
			amount: 20022.86,
			negativeCurrency: false,
			checked: false
		}
	],
	bank: [
		{
			id: 12490433,
			accountName: 'Dag Saving Plus',
			accountType: 'SAVINGS',
			providerAccountId: 11326300,
			accountNumber: 'x-4197',
			currency: 'USD',
			amount: 305,
			negativeCurrency: false,
			checked: false
		}
	],
	reward: [
		{
			id: 12470172,
			accountName: 'Robin',
			accountType: 'REWARD POINTS',
			providerAccountId: 11326300,
			accountNumber: 'x-3456',
			currency: 'miles',
			amount: 34567.98,
			negativeCurrency: false,
			checked: false
		}
	],
	insurance: [
		{
			id: 12470171,
			accountName: 'Auto Property Bill',
			accountType: 'INSURANCE',
			providerAccountId: 11326300,
			accountNumber: 'x-4395',
			checked: false
		}
	],
	loan: [
		{
			id: 12470169,
			accountName: 'Dag Student Loan',
			accountType: 'OTHER',
			providerAccountId: 11326300,
			accountNumber: 'x-6789',
			currency: 'USD',
			amount: 2316.36,
			negativeCurrency: false,
			checked: false
		}
	]
}
