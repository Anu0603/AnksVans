import ProviderAccountService from '../../provider/ProviderAccountService'

import providerAccountAPiResposne from './../__mocks__/addEditProviderAccountsAPI'

describe('Provider Account Details Test suite', () => {
	it('Check add account API ', done => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve(providerAccountAPiResposne)
		})
		act(() => {
			let providrId =
				providerAccountAPiResposne.providerAccount[0].providerId
			let providerDetailsPromises = new ProviderAccountService().addAccount(
				{
					providerId: 5,
					formType: 'LOGIN',
					fieldVlaues: { '12': 'r', '13': 'r' }
				}
			)

			providerDetailsPromises.then(
				function(response) {
					debugger
					expect(response.providerId).toBe(providrId)
					done()
				},
				response => {
					done()
				}
			)
		})
	})

	it('Check Edit account API ', done => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve(providerAccountAPiResposne)
		})
		act(() => {
			let providerAccountId =
				providerAccountAPiResposne.providerAccount[0].id
			let providerDetailsPromises = new ProviderAccountService().addAccount(
				{
					providerAccountId: providerAccountId,
					formType: 'LOGIN',
					fieldVlaues: { '12': 'r', '13': 'r' }
				}
			)

			providerDetailsPromises.then(
				function(response) {
					expect(response.providerAccountId).toBe(providerAccountId)
					done()
				},
				response => {
					done()
				}
			)
		})
	})
})
