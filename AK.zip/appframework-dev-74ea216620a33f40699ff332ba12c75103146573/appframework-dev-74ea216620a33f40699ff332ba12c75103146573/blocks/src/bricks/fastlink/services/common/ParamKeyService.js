class ParamKeyService {
	getCoBrandPublicKey = (_options, _callback) => {
		var self = this
		_options.data = {
			url: '/1.1/cobrand/publicKey',
			method: 'GET',
			cache: true
		}

		Application.BaseService.makecall(_options)
			.then(_response => {
				_callback(self.parsePublickeyResponse(_response))
			})
			.catch(_error => {
				_callback(_error)
			})
	}

	parsePublickeyResponse(_response) {
		if (_response.details && _response.details.errorCode == 'Y901') {
			return null
		}
		return _response
	}

	/** API HANDLERS */
	/**
	 * Get the param key values for the key string passed (comma delimited)
	 */
	getParamKeyValue = (_options, _callback) => {
		var self = this
		_options.data = {
			url: '/1.1/cobrand/config/paramKey',
			method: 'GET',
			cache: true,
			data: {
				paramKey: _options.paramKeyString
			}
		}
		_options.callback = (_error, _response) => {
			_callback(_error, self.parseParamKeyResponse(_response, _error))
		}
		Application.BaseService.makecall(_options)
	}

	/** PARSERS */
	/**
	 * Parses the param key values in form of array of param key id and value
	 */
	parseParamKeyResponse(_response, _error) {
		let response = _response.paramKey
		let paramKeyResponse = {}
		for (let index in response) {
			let paramKeyObj = response[index]
			paramKeyResponse[index] = {
				id: paramKeyObj.paramKeyId,
				value: paramKeyObj.value
			}
		}
		return paramKeyResponse
	}
}
export default ParamKeyService
