import AccountsService from './../../account/AccountsService'
import AccountsData from './../__mocks__/AccountsData'
import ParsedAccountsData from './../__mocks__/ParsedAccountsData'
import {
	AppStrings,
	AppParams,
	AutoIds,
	getParam,
	getString
} from '../../../../fastlink/conf/index'
jest.mock('../../../../fastlink/conf')

describe('Account service ', () => {
	const accountsService = new AccountsService()

	beforeEach(() => {
		Application.BaseService.makecall = function() {}
		console.log = jest.fn()

		getParam.mockImplementation(_key => {
			if (_key == AppParams.CONTAINER_LIST) {
				return [
					'bank',
					'creditCard',
					'investment',
					'loan',
					'mortgage',
					'insurance',
					'bill',
					'reward'
				]
			}
		})
	})
	let mockAPICall = succss => {
		Application.BaseService.makecall = jest.fn(_options => {
			return succss
				? Promise.resolve(AccountsData['account'])
				: Promise.reject(AccountsData['account'])
		})
	}
	let mockDeleteAPICall = () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return {}
		})
	}

	it('getAccounts: Test whether it fetches Accounts Data', () => {
		mockAPICall(true)
		accountsService.getAccounts(
			{ providerAccountId: 1, status: 'SUCCESS' },
			(_error, _response) => {
				expect(res).toMatchObject({ accountId: 123 })
			}
		)
		accountsService.getAccounts({})
	})
	it('parseResponse: Test whether this method parse response correctly if container_list is defined correctly in params', () => {
		let parsedData = accountsService.parseResponse(AccountsData)
		expect(Object.keys(parsedData).length).toBe(7)
	})
	it('parseResponse: Test whether this method parse response correctly if container_list not is defined in params', () => {
		getParam.mockImplementation(_key => {
			if (_key == AppParams.CONTAINER_LIST) {
				return null
			}
		})
		let parsedData = accountsService.parseResponse(AccountsData)
		expect(Object.keys(parsedData).length).toBe(7)
	})
	it('parseResponse: Test whether this method parse response correctly if CONTAINER is not available in accounts object', () => {
		var tempAccountsData = JSON.parse(JSON.stringify(AccountsData))
		let accountZero = tempAccountsData.account[0]
		delete accountZero.CONTAINER
		tempAccountsData.account[0] = accountZero

		let parsedData = accountsService.parseResponse(tempAccountsData)
		expect(Object.keys(parsedData).length).toBe(6)
	})
	it('parseResponse: Test whether this method parse response correctly if multiple accounts with same CONTAINER are available in accounts object', () => {
		debugger
		let accountZero = AccountsData.account[0]
		AccountsData.account.push(accountZero)

		let parsedData = accountsService.parseResponse(AccountsData)
		expect(Object.keys(parsedData).length).toBe(7)
		expect(parsedData['bill'].length).toBe(2)
	})
	it('_parseAccount: Test whether this method parse account correctly', () => {
		let accountObj = AccountsData.account[0]
		let parsedAccountObj = accountsService._parseAccount(accountObj)

		expect(parsedAccountObj.id).toEqual(accountObj.id)
		expect(parsedAccountObj.accountName).toEqual(accountObj.accountName)
		expect(parsedAccountObj.accountType).toEqual(accountObj.accountType)
		expect(parsedAccountObj.providerAccountId).toEqual(
			accountObj.providerAccountId
		)
		expect(parsedAccountObj.currency).toEqual(accountObj.balance.currency)
		expect(parsedAccountObj.amount).toEqual(accountObj.balance.amount)
	})
	it('_parseAccount: Test whether this method parse account correctly when rewardBalance are available', () => {
		let accountObj = AccountsData.account[4]
		let parsedAccountObj = accountsService._parseAccount(accountObj)

		expect(parsedAccountObj.id).toEqual(accountObj.id)
		expect(parsedAccountObj.accountName).toEqual(accountObj.accountName)
		expect(parsedAccountObj.accountType).toEqual('REWARD POINTS')
		expect(parsedAccountObj.providerAccountId).toEqual(
			accountObj.providerAccountId
		)
		expect(parsedAccountObj.currency).toEqual('miles')
		expect(parsedAccountObj.amount).toEqual(34567.98)
	})
	it('_parseAccount: Test whether this method parse account correctly when faceAmount are available', () => {
		let accountObj = JSON.parse(JSON.stringify(AccountsData.account[0]))
		accountObj.faceAmount = {
			amount: 100,
			currency: 'USD'
		}
		let parsedAccountObj = accountsService._parseAccount(accountObj)

		expect(parsedAccountObj.id).toEqual(accountObj.id)
		expect(parsedAccountObj.accountName).toEqual(accountObj.accountName)
		expect(parsedAccountObj.accountType).toEqual(accountObj.accountType)
		expect(parsedAccountObj.providerAccountId).toEqual(
			accountObj.providerAccountId
		)
		expect(parsedAccountObj.currency).toEqual('USD')
		expect(parsedAccountObj.amount).toEqual(100)
	})
	it('_parseAccount: Test whether this method throws error when account is passed as null', () => {
		let accountObj = null
		let parsedAccountObj = accountsService._parseAccount(accountObj)

		expect(console.log).toBeCalledTimes(2)
	})
	it('_setRewardPointsBalance: Test whether this method calculate the reward points correctly', () => {
		let accountObj = AccountsData.account[4]
		let result = {}

		let parsedAccountObj = accountsService._setRewardPointsBalance(
			result,
			accountObj
		)
		expect(parsedAccountObj.currency).toEqual('miles')
		expect(parsedAccountObj.amount).toEqual(34567.98)
	})
	it('_setRewardPointsBalance: Test whether this method does not calculate the reward points when reward points are not available', () => {
		let accountObj = AccountsData.account[0]
		let result = {}

		let parsedAccountObj = accountsService._setRewardPointsBalance(
			result,
			accountObj
		)
		expect(parsedAccountObj.currency).toEqual(undefined)
		expect(parsedAccountObj.amount).toEqual(undefined)
	})
	it('_formatAccountNumber: Test whether this method format the account number correctly', () => {
		let formatedAccountNum = accountsService._formatAccountNumber(
			'xxxx-1234'
		)
		expect(formatedAccountNum).toEqual('x-1234')
	})
	it('_isNegativeNum: Test whether this method returns true for negative amount', () => {
		let isNegativeAmount = accountsService._isNegativeNum(-100)
		expect(isNegativeAmount).toBe(true)
	})
	it('_isNegativeNum: Test whether this method returns false for positive amount', () => {
		let isNegativeAmount = accountsService._isNegativeNum(100)
		expect(isNegativeAmount).toBe(false)
	})

	it('deleteAccount: Test whether this methid deletes account', () => {
		mockDeleteAPICall()
		accountsService.deleteAccount({ accountId: 1 }, (_error, _response) => {
			expect(res).toMatchObject({})
		})
	})
})
