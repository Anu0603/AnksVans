export default {
	account: [
		{
			CONTAINER: 'bill',
			providerAccountId: 11326300,
			accountName: 'DAG BILLING',
			accountStatus: 'ACTIVE',
			isAsset: false,
			aggregationSource: 'USER',
			id: 12490439,
			lastUpdated: '2020-05-05T05:33:02Z',
			providerId: '16441',
			providerName: 'Dag Site',
			accountType: 'BILLS',
			isManual: false,
			createdDate: '2020-05-04T10:38:31Z',
			dueDate: '2018-09-28',
			frequency: 'ANNUALLY',
			displayedName: 'Robin',
			minimumAmountDue: { amount: 100.0, currency: 'USD' },
			lastPaymentAmount: { amount: 5600.0, currency: 'USD' },
			balance: { amount: 1200.0, currency: 'USD' },
			accountNumber: 'xxxx5555',
			amountDue: { amount: 1200.0, currency: 'USD' },
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					additionalStatus: 'AVAILABLE_DATA_RETRIEVED',
					updateEligibility: 'DISALLOW_UPDATE',
					lastUpdated: '2020-05-05T05:33:03Z',
					lastUpdateAttempt: '2020-05-05T05:33:03Z',
					nextUpdateScheduled: '2020-05-09T05:21:48Z'
				}
			]
		},
		{
			CONTAINER: 'investment',
			providerAccountId: 11326300,
			accountName: 'Dag IRA',
			accountStatus: 'ACTIVE',
			isAsset: true,
			aggregationSource: 'USER',
			id: 12490438,
			lastUpdated: '2020-05-05T05:32:33Z',
			providerId: '16441',
			providerName: 'Dag Site',
			accountType: 'INDIVIDUAL_RETIREMENT_ACCOUNT_IRA',
			isManual: false,
			createdDate: '2020-05-04T10:38:29Z',
			includeInNetWorth: true,
			displayedName: 'Jacob',
			classification: 'PERSONAL',
			balance: { amount: 609447.65, currency: 'USD' },
			accountNumber: 'xxxx2345',
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					additionalStatus: 'AVAILABLE_DATA_RETRIEVED',
					updateEligibility: 'DISALLOW_UPDATE',
					lastUpdated: '2020-05-05T05:32:34Z',
					lastUpdateAttempt: '2020-05-05T05:32:34Z',
					nextUpdateScheduled: '2020-05-05T18:33:01Z'
				}
			]
		},
		{
			CONTAINER: 'creditCard',
			providerAccountId: 11326300,
			accountName: 'Dag Credit Card',
			accountStatus: 'ACTIVE',
			isAsset: false,
			aggregationSource: 'USER',
			id: 12490435,
			lastUpdated: '2020-05-05T05:32:32Z',
			providerId: '16441',
			providerName: 'Dag Site',
			accountType: 'CREDIT',
			isManual: false,
			createdDate: '2020-05-04T10:38:29Z',
			includeInNetWorth: true,
			apr: 19.99,
			classification: 'PERSONAL',
			balance: { amount: 20022.86, currency: 'USD' },
			runningBalance: { amount: 20022.86, currency: 'USD' },
			accountNumber: 'xxxx9806',
			availableCredit: { amount: 1927.14, currency: 'USD' },
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					additionalStatus: 'AVAILABLE_DATA_RETRIEVED',
					updateEligibility: 'DISALLOW_UPDATE',
					lastUpdated: '2020-05-05T05:32:33Z',
					lastUpdateAttempt: '2020-05-05T05:32:33Z',
					nextUpdateScheduled: '2020-05-05T18:23:22Z'
				}
			]
		},
		{
			CONTAINER: 'bank',
			providerAccountId: 11326300,
			accountName: 'Dag Saving Plus',
			accountStatus: 'ACTIVE',
			isAsset: true,
			aggregationSource: 'USER',
			id: 12490433,
			lastUpdated: '2020-05-05T05:32:26Z',
			providerId: '16441',
			providerName: 'Dag Site',
			accountType: 'SAVINGS',
			isManual: false,
			createdDate: '2020-05-04T10:38:29Z',
			includeInNetWorth: true,
			displayedName: 'Robin',
			classification: 'PERSONAL',
			currentBalance: { amount: 305.0, currency: 'USD' },
			balance: { amount: 305.0, currency: 'USD' },
			availableBalance: { amount: 105.0, currency: 'USD' },
			accountNumber: 'xxxx4197',
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					additionalStatus: 'AVAILABLE_DATA_RETRIEVED',
					updateEligibility: 'DISALLOW_UPDATE',
					lastUpdated: '2020-05-05T05:32:33Z',
					lastUpdateAttempt: '2020-05-05T05:32:33Z',
					nextUpdateScheduled: '2020-05-06T01:13:46Z'
				}
			]
		},
		{
			CONTAINER: 'reward',
			providerAccountId: 11326300,
			accountName: 'Robin',
			accountStatus: 'ACTIVE',
			isAsset: true,
			aggregationSource: 'USER',
			id: 12470172,
			lastUpdated: '2020-05-05T05:32:57Z',
			providerId: '16441',
			providerName: 'Dag Site',
			accountType: 'REWARD_POINTS',
			isManual: false,
			createdDate: '2020-04-27T08:57:30Z',
			enrollmentDate: '2012-08-25',
			displayedName: 'Robin',
			nextLevel: 'Elite',
			classification: 'PERSONAL',
			primaryRewardUnit: 'Rew Unit',
			rewardBalance: [
				{
					description: 'Last Year Points',
					balance: 12121.98,
					balanceType: 'BALANCE',
					units: 'miles',
					balanceToLevel: 'GOLD'
				},
				{
					description: 'Total Rewards',
					balance: 34567.98,
					balanceType: 'TOTAL_BALANCE',
					units: 'miles',
					balanceToLevel: 'GOLD'
				},
				{
					description: 'Expiring Points',
					balance: 1200,
					balanceType: 'EXPIRING_BALANCE',
					units: 'miles',
					expiryDate: '2018-12-31',
					balanceToLevel: 'GOLD'
				},
				{
					description: 'To Elite Balance',
					balance: 1400,
					balanceType: 'BALANCE_TO_LEVEL',
					units: 'miles',
					balanceToLevel: 'GOLD'
				},
				{
					description: 'To Business Reward',
					balance: 14560,
					balanceType: 'BALANCE_TO_REWARD',
					units: 'miles',
					expiryDate: '2018-10-25',
					balanceToLevel: 'GOLD'
				}
			],
			accountNumber: 'xxxx3456',
			currentLevel: 'Gold',
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					additionalStatus: 'AVAILABLE_DATA_RETRIEVED',
					updateEligibility: 'DISALLOW_UPDATE',
					lastUpdated: '2020-05-05T05:32:57Z',
					lastUpdateAttempt: '2020-05-05T05:32:57Z',
					nextUpdateScheduled: '2020-05-11T22:28:56Z'
				}
			]
		},
		{
			CONTAINER: 'insurance',
			providerAccountId: 11326300,
			accountName: 'Auto Property Bill',
			accountStatus: 'ACTIVE',
			isAsset: false,
			aggregationSource: 'USER',
			id: 12470171,
			lastUpdated: '2020-05-05T05:32:52Z',
			providerId: '16441',
			providerName: 'Dag Site',
			accountType: 'INSURANCE',
			isManual: false,
			createdDate: '2020-04-27T08:57:30Z',
			includeInNetWorth: true,
			displayedName: 'Lindsay',
			policyStatus: 'OTHER',
			accountNumber: 'xxxx4395',
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					additionalStatus: 'AVAILABLE_DATA_RETRIEVED',
					updateEligibility: 'DISALLOW_UPDATE',
					lastUpdated: '2020-05-05T05:32:53Z',
					lastUpdateAttempt: '2020-05-05T05:32:53Z',
					nextUpdateScheduled: '2020-05-11T19:23:06Z'
				}
			]
		},
		{
			CONTAINER: 'loan',
			providerAccountId: 11326300,
			accountName: 'Dag Student Loan',
			accountStatus: 'ACTIVE',
			isAsset: false,
			aggregationSource: 'USER',
			id: 12470169,
			lastUpdated: '2020-05-05T05:32:52Z',
			providerId: '16441',
			providerName: 'Dag Site',
			accountType: 'OTHER',
			isManual: false,
			createdDate: '2020-04-27T08:57:30Z',
			includeInNetWorth: true,
			principalBalance: { amount: 2316.36, currency: 'USD' },
			dueDate: '2018-11-14',
			frequency: 'OTHER',
			displayedName: 'Robin',
			originationDate: '2006-10-01',
			classification: 'PERSONAL',
			interestRateType: 'UNKNOWN',
			lastPaymentAmount: { amount: 36.7, currency: 'USD' },
			balance: { amount: 2316.36, currency: 'USD' },
			lastPaymentDate: '0018-10-14',
			accountNumber: 'xxxx6789',
			dataset: [
				{
					name: 'BASIC_AGG_DATA',
					additionalStatus: 'AVAILABLE_DATA_RETRIEVED',
					updateEligibility: 'DISALLOW_UPDATE',
					lastUpdated: '2020-05-05T05:32:53Z',
					lastUpdateAttempt: '2020-05-05T05:32:53Z',
					nextUpdateScheduled: '2020-05-11T20:07:00Z'
				}
			],
			originalLoanAmount: { amount: 3667.0, currency: 'USD' }
		}
	]
}
