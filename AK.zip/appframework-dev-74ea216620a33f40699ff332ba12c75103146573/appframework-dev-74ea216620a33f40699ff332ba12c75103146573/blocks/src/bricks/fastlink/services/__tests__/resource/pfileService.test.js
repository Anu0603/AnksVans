import pfileService from '../../resource/pfileService'

describe('pFile service ', () => {
	beforeEach(() => {
		Application.BaseService.getPfileResourceCall = function() {}
	})
	let mockAPICall = succss => {
		Application.BaseService.getPfileResourceCall = jest.fn(_options => {
			return succss
				? Promise.resolve({ accountId: 123 })
				: Promise.reject('Error')
		})
	}

	it('getPfileContent: Test whether it fetches the Data', () => {
		mockAPICall(true)
		pfileService.getPfileContent(
			{ fileName: 'testpfile' },
			(_error, _response) => {
				expect(res).toMatchObject({ accountId: 123 })
			}
		)
	})
})
