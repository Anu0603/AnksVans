export default class ManualAccountService {
	getManualAccount(_inputParams) {
		let _options = {}
		_options.data = {
			url: `/1.1/accounts/${_inputParams.id}?container=${_inputParams.container}`,
			method: 'GET'
		}

		return Application.BaseService.makecall(_options)
	}

	// parseResponse = (_response, _error) => {
	// 	if (_error) {

	// 	}
	// }

	addManualAccount(_options) {
		let data = {
			account: {
				..._options
			}
		}

		_options.data = {
			url: '/1.1/accounts',
			method: 'POST',
			data: data
		}

		return Application.BaseService.makecall(_options)
	}

	editManualAccount(_options) {
		let accountId = _options.accountId

		delete _options.accountId
		delete _options.accountType

		let data = {
			account: {
				..._options
			}
		}

		_options.data = {
			url: `/1.1/accounts/${accountId}`,
			method: 'PUT',
			data: data
		}

		return Application.BaseService.makecall(_options)
	}
}
