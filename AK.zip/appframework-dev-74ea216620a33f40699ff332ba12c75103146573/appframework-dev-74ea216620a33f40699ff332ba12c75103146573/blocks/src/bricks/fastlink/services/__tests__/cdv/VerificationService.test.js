import VerificationService from '../../../services/cdv/VerificationService'
import VerificationData from './../__mocks__/cdvVerification'

describe('VerificationService Test Case', () => {
	const verificationService = new VerificationService()

	beforeEach(() => {
		Application.BaseService.makecall = function() {}
	})

	let mockAPICall = (apiType, status, success) => {
		Application.BaseService.makecall = jest.fn(_options => {
			return success
				? Promise.resolve(VerificationData[apiType][status])
				: Promise.reject(VerificationData[apiType][status])
		})
	}

	it('Test initiateVerification for unknown response', () => {
		mockAPICall('initVerificationMap', 'UNKNOWN', true)
		let _expectedResponse = { reason: 'UNKNOWN', status: 'FAILED' }

		verificationService.initiateVerification(
			{
				routingNumber: 9999999989,
				accountNumber: 1234567890,
				accountType: 'SAVINGS'
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('Test initiateVerification for INITIATED response', () => {
		mockAPICall('initVerificationMap', 'INITIATED', true)
		let _expectedResponse = { status: 'INITIATED', reason: 'UNKNOWN' }

		verificationService.initiateVerification(
			{
				routingNumber: 9999999989,
				accountNumber: 1234567890,
				accountType: 'SAVINGS'
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('Test initiateVerification for ERROR Y840, ALREADY_INITIATED', () => {
		mockAPICall('initVerificationMap', 'ERROR_Y840', false)
		let _expectedResponse = {
			status: 'FAILED',
			reason: 'ALREADY_INITIATED'
		}

		verificationService.initiateVerification(
			{
				routingNumber: 9999999989,
				accountNumber: 1234567890,
				accountType: 'SAVINGS'
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('Test initiateVerification for ERROR Y837, ALREADY_COMPLETED', () => {
		mockAPICall('initVerificationMap', 'ERROR_Y837', false)
		let _expectedResponse = {
			status: 'FAILED',
			reason: 'ALREADY_COMPLETED'
		}

		verificationService.initiateVerification(
			{
				routingNumber: 9999999989,
				accountNumber: 1234567890,
				accountType: 'SAVINGS'
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('Test getVerificationInfo for invalid response', () => {
		mockAPICall('getVerificationInfoMap', 'TECH_ERROR', true)
		let _expectedResponse = { status: 'TECH_ERROR' }

		verificationService.getVerificationInfo(
			{
				accountId: 129002992
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('Test getVerificationInfo for DEPOSITED response', () => {
		mockAPICall('getVerificationInfoMap', 'DEPOSITED', true)
		let _expectedResponse = {
			accountNumber: '21320918309221321',
			routingNumber: '999999989',
			accountType: 'SAVINGS',
			status: 'DEPOSITED',
			providerAccountId: 11329462
		}

		verificationService.getVerificationInfo(
			{
				accountId: 129002992
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('Test getVerificationInfo for Y842, FAILED response', () => {
		mockAPICall('getVerificationInfoMap', 'ERROR_Y842', false)
		let _expectedResponse = { status: 'FAILED' }

		verificationService.getVerificationInfo(
			{
				accountId: 129002992
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('DEEPLINK: Test getVerificationInfo for Y800, Invalid Account ID response', () => {
		mockAPICall('getVerificationInfoMap', 'ERROR_Y800', false)
		let _expectedResponse = { status: 'INVALID_ACCOUNT_ID' }

		verificationService.getVerificationInfo(
			{
				accountId: 0
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('Test submitVerificationDetails for unknown response', () => {
		mockAPICall('submitVerificationMap', 'TECH_ERROR', false)
		let _expectedResponse = { status: 'TECH_ERROR' }

		verificationService.submitVerificationDetails(
			{
				accountId: '12481723',
				providerAccountId: 11331323,
				creditDetails: ['1', '2'],
				debitDetails: ['3']
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('Test submitVerificationDetails for SUCCESS response', () => {
		mockAPICall('submitVerificationMap', 'SUCCESS', true)
		let _expectedResponse = { status: 'SUCCESS', reason: null }

		verificationService.submitVerificationDetails(
			{
				accountId: '12481723',
				providerAccountId: 11331323,
				creditDetails: ['1', '2'],
				debitDetails: ['3']
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('Test submitVerificationDetails for MISMATCH response', () => {
		mockAPICall('submitVerificationMap', 'MISMATCH', false)
		let _expectedResponse = { status: 'FAILED', reason: 'DATA_MISMATCH' }

		verificationService.submitVerificationDetails(
			{
				accountId: '12481723',
				providerAccountId: 11331323,
				creditDetails: ['1', '2'],
				debitDetails: ['3']
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})

	it('Test submitVerificationDetails for FAILED response', () => {
		mockAPICall('submitVerificationMap', 'FAILED', false)
		let _expectedResponse = {
			status: 'FAILED',
			reason: 'TOO_MANY_ATTEMPTS'
		}

		verificationService.submitVerificationDetails(
			{
				accountId: '12481723',
				providerAccountId: 11331323,
				creditDetails: ['1', '2'],
				debitDetails: ['3']
			},
			(_error, _response) => {
				expect(_response).toEqual(_expectedResponse)
			}
		)
	})
})
