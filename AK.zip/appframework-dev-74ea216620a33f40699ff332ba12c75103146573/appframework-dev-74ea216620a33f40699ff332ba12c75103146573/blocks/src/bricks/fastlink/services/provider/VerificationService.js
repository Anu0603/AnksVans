class VerificationService {
	parseResponse(_response) {
		let response = _response.verification
		let verifiedAccounts = {}
		for (let i in response) {
			let status = true
			verifiedAccounts[response[i].accountId] = { status: status }
		}
		return verifiedAccounts
	}

	matchingVerification = (_options, _callback) => {
		_options.data = {
			url: '/1.1/verification',
			method: 'POST',
		}
		let verification = { verification: {} }
		if (_options.providerAccountId) {
			verification.verification.providerAccountId =
				_options.providerAccountId
		}
		verification.verification.verificationType = 'MATCHING'
		_options.data.data = verification
		var self = this
		return new Promise(function(resolve, reject) {
			_options.callback = (_error, _response) => {
				if (_error) {
					reject(_error)
				} else {
					resolve(self.parseResponse(_response))
				}
			}
			Application.BaseService.makecall(_options)
		})
	}
}

export default VerificationService
