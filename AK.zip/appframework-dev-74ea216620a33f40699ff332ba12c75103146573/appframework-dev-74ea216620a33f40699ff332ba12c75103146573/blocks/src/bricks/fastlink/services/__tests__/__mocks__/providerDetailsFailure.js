export default {
	providerDetails: {
		provider: [
			{
				id: 2852,
				name: 'Bank of America',
				loginUrl:
					'https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go',
				baseUrl: 'https://www.bankofamerica.com/',
				favicon:
					'https://yodlee-1.hs.llnwd.net/v1/FAVICON/FAV_2852.SVG',
				logo: 'https://yodlee-1.hs.llnwd.net/v1/LOGO/LOGO_2852_1_2.SVG',

				status: 'Supported',
				isConsentRequired: false,
				isAutoRefreshEnabled: true,
				authType: 'MFA_CREDENTIALS',
				lastModified: '2020-04-17T04:44:00Z',
				languageISOCode: 'EN',
				primaryLanguageISOCode: 'EN',
				countryISOCode: 'US',
				loginForm: [
					{
						id: 2152,
						forgetPasswordURL:
							'https://secure.bankofamerica.com/login/sign-in/signOnV2Screen.go',
						formType: 'login',
						row: [
							{
								id: 5371,
								label: 'Online ID',
								form: '0001',
								fieldRowChoice: '0001',
								field: [
									{
										id: 2863,
										name: 'LOGIN',
										type: 'text',
										value: '',
										isOptional: false,
										valueEditable: true
									}
								]
							},
							{
								id: 5372,
								label: 'Passcode',
								form: '0001',
								fieldRowChoice: '0002',
								field: [
									{
										id: 2864,
										name: 'PASSWORD',
										maxLength: 20,
										type: 'password',
										value: '',
										isOptional: false,
										valueEditable: true
									}
								]
							}
						]
					}
				],
				dataset: [
					{
						name: 'BASIC_AGG_DATA',
						attribute: [
							{
								name: 'ACCOUNT_DETAILS',
								container: ['loan', 'bank', 'creditCard']
							},
							{
								name: 'STATEMENTS',
								container: ['loan', 'creditCard']
							},
							{
								name: 'TRANSACTIONS',
								containerAttributes: {
									BANK: {
										numberOfTransactionDays: 90
									},
									LOAN: {
										numberOfTransactionDays: 90
									},
									CREDITCARD: {
										numberOfTransactionDays: 90
									}
								},
								container: ['bank', 'loan', 'creditCard']
							},
							{
								name: 'BASIC_ACCOUNT_INFO',
								container: ['loan', 'bank', 'creditCard']
							}
						]
					},
					{
						name: 'DOCUMENT',
						attribute: [
							{
								name: 'STATEMENTS',
								container: ['bank']
							}
						]
					}
				]
			}
		]
	},
	tnc: {
		errorCode: 'Y807',
		errorMessage: 'Resource not found',
		referenceCode: 'G1588491574702n21d179I',
		errorOccurred: true
	}
}
