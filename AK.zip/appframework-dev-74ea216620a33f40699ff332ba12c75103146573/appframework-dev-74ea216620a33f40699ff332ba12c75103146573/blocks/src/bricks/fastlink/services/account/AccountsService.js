import { AppParams, getParam } from '../../conf'

class AccountsService {
	getAccounts = (_options, _callback) => {
		_options.data = {
			url: '/1.1/accounts',
			method: 'GET'
		}

		if (_options.providerAccountId && _options.status) {
			_options.data.url =
				_options.data.url +
				'?' +
				'providerAccountId=' +
				_options.providerAccountId +
				'&' +
				'status=' +
				_options.status
		}

		Application.BaseService.makecall(_options)
			.then(_response => {
				_response = this.parseResponse(_response)
				_callback(null, _response)
			})
			.catch(_error => {
				_callback(_error)
			})
	}

	deleteAccount(_options) {
		_options.data = {
			url: '/1.1/accounts/' + _options.accountId,
			method: 'DELETE'
		}

		return Application.BaseService.makecall(_options)
	}

	parseResponse = _response => {
		let accounts = _response.account
		let containerSortList = getParam(AppParams.CONTAINER_LIST)
		let accountsResp = {}
		for (let i in accounts) {
			if (containerSortList && containerSortList.length > 0) {
				if (containerSortList.indexOf(accounts[i].CONTAINER) != -1) {
					this.pushToArray(accountsResp, accounts, i)
				}
			} else {
				this.pushToArray(accountsResp, accounts, i)
			}
		}
		console.log(accountsResp)
		return accountsResp
	}

	pushToArray(accountsResp, accounts, i) {
		if (accountsResp[accounts[i].CONTAINER]) {
			accountsResp[accounts[i].CONTAINER].push(
				this._parseAccount(accounts[i])
			)
		} else {
			accountsResp[accounts[i].CONTAINER] = [
				this._parseAccount(accounts[i])
			]
		}
	}

	_parseAccount = _account => {
		let account = {}
		try {
			account.id = _account.id
			account.accountName = _account.accountName
			account.accountType = _account.accountType.split('_').join(' ')
			account.providerAccountId = _account.providerAccountId
			account.accountNumber = this._formatAccountNumber(
				_account.accountNumber
			)
			if (_account.rewardBalance) {
				account = this._setRewardPointsBalance(account, _account)
			} else if (_account.faceAmount) {
				account.currency = _account.faceAmount.currency
				account.amount = _account.faceAmount.amount
			} else if (_account.balance) {
				account.currency = _account.balance.currency
				account.amount = _account.balance.amount
			}
			if (account.amount) {
				account.negativeCurrency = this._isNegativeNum(account.amount)
			}
		} catch (error) {
			console.log('parser failing for ' + error)
			console.log(_account)
		}
		return account
	}

	_setRewardPointsBalance = (result, response) => {
		if (response.rewardBalance) {
			let rewardBalance = response.rewardBalance
			let totalBalance = {}
			for (let i in rewardBalance) {
				if (rewardBalance[i].balanceType === 'TOTAL_BALANCE') {
					totalBalance.amount = rewardBalance[i].balance
					totalBalance.currency = rewardBalance[i].units
				} else if (rewardBalance[i].balanceType === 'BALANCE') {
					totalBalance.amount = rewardBalance[i].balance
					totalBalance.currency = rewardBalance[i].units
				}
			}

			if (
				Object.entries(totalBalance).length > 0 &&
				totalBalance.constructor === Object
			) {
				result.currency = totalBalance.currency
				result.amount = totalBalance.amount
			}
		}
		return result
	}

	_formatAccountNumber(accountNumber) {
		let accountNumberStr = accountNumber.toString()
		accountNumberStr = accountNumberStr.substring(
			accountNumberStr.length - 4
		)
		return 'x-' + accountNumberStr
	}

	_isNegativeNum(num) {
		if (Math.sign(num) === -1) {
			return true
		} else {
			return false
		}
	}
}

export default AccountsService
