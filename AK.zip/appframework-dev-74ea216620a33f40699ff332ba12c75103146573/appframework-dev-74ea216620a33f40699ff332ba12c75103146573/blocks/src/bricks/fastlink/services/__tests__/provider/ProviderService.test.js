import ProviderService from '../../provider/ProviderService'

import ProvidersData from './../__mocks__/provider'

describe('Provider Service', () => {
	beforeEach(() => {
		Application.BaseService.makecall = function() {}
	})

	it('Check whether the getPopularProviders returns the data', done => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve(ProvidersData)
		})

		act(() => {
			let providersCount = ProvidersData.provider.length
			ProviderService.getPopularProviders({}, function(_err, _res) {
				expect(_res.provider.length).toBe(providersCount)
				done()
			})
		})
	})

	it('Check whether the getSearchProviders returns the data', done => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve(ProvidersData)
		})

		act(() => {
			let providersCount = ProvidersData.provider.length
			ProviderService.getSearchProviders({}, function(_err, _res) {
				expect(_res.provider.length).toBe(providersCount)
				done()
			})
		})
	})

	it('Check whether the getSearchProviders returns error when error passed', done => {
		const sampleError = { error: 'sample Error' }
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.reject(sampleError)
		})

		act(() => {
			let providersCount = ProvidersData.provider.length
			ProviderService.getSearchProviders({}, function(_err, _res) {
				expect(_err).toBe(sampleError)
				done()
			})
		})
	})
})
