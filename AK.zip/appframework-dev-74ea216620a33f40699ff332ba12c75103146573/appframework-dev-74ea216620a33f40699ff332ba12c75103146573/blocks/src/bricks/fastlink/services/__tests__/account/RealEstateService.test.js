import RealEstateService from './../../account/RealEstateService'

describe('Real estate serice ', () => {
	const realEstateService = new RealEstateService()
	beforeEach(() => {
		Application.BaseService.makecall = function() {}
	})
	it('Should Get Real Estate Data ', () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve({ accountId: 123 })
		})

		realEstateService.getRealEstate({ id: 1 }).then(res => {
			expect(res).toMatchObject({ accountId: 123 })
		})
	})
	it('Should add Real Estate Data for System account', () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve({})
		})

		realEstateService.addRealEstate({}).then(res => {
			expect(res).toMatchObject({})
		})
	})

	it('Should add Real Estate Data for Manual ', () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve({})
		})

		realEstateService
			.addRealEstate({ valuationType: 'MANUAL' })
			.then(res => {
				expect(res).toMatchObject({})
			})
	})
	it('Should edit Real Estate Data for Manual account ', () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve({})
		})

		realEstateService
			.editRealEstate({ valuationType: 'MANUAL' })
			.then(res => {
				expect(res).toMatchObject({})
			})
	})

	it('Should edit Real Estate Data for system account ', () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve({})
		})

		realEstateService.editRealEstate({}).then(res => {
			expect(res).toMatchObject({})
		})
	})

	it('Should evaluate Address ', () => {
		Application.BaseService.makecall = jest.fn(_options => {
			return Promise.resolve({ isValidAddress: true })
		})

		realEstateService.evaluateAddress({ address: {} }).then(res => {
			expect(res).toMatchObject({ isValidAddress: true })
		})
	})
})
