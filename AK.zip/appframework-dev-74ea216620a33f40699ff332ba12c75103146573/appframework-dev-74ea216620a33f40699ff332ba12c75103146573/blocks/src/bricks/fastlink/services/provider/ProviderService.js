import FastlinkUtil from './../../utils/Utilities'
const ProviderService = {
	getSearchProviders: (_options, _callback) => {
		_options.data = {
			url: '/1.1/providers',
			method: 'GET',
			data: {
				top: _options.top,
				name: _options.name,
				dataset$filter: FastlinkUtil.getProviderAPIDataset(),
				classification: 'RETAIL',
				..._options
			}
		}

		Application.BaseService.cancelLastRequest()
		Application.BaseService.makecall(_options)
			.then(_response => {
				_callback(null, _response)
			})
			.catch(_error => {
				_callback(_error)
			})
	},

	getPopularProviders: (_options, _callback) => {
		_options.data = {
			url: '/1.1/providers',
			method: 'GET',
			data: {
				priority: 'popular',
				dataset$filter: FastlinkUtil.getProviderAPIDataset(),
				top: _options.top
			}
		}

		Application.BaseService.makecall(_options)
			.then(_response => {
				_callback(null, _response)
			})
			.catch(error => {
				_callback(error, null)
			})
	}
}

export default ProviderService
