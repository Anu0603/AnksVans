import DEEPLINK_CONSTANTS from './DeeplinkConstants'
import CONSTANTS from '@fastlinkRoot/router/Constant'
import { store } from '@framework/react/store/store'
import * as actionTypes from '@fastlinkRoot/store/actions/actionTypes'
import TechErrorConstants from './../../components/Error/TechnicalError/TechErrorConstants'
import { AppParams, getParam } from './../../conf'

export default {
	doFilter(defaultState) {
		let _state = defaultState,
			_flowValue = Application.Wrapper.getRequestParameter(
				DEEPLINK_CONSTANTS.FLOW_PARAM_NAME
			),
			_flowData = null,
			_isDeeplink = false,
			_isError = false,
			_errorCode = null,
			_deeplinkData = null

		if (_flowValue) {
			_flowData = DEEPLINK_CONSTANTS.FLOWS_METADATA[_flowValue]
			_isDeeplink = true
			if (_flowData) {
				if (this._isFeatureEnabled(_flowData)) {
					_deeplinkData = this._getDeeplinkData(_flowData.PARAMS)
					if (_deeplinkData.isValid) {
						_state.routeName = _flowData.ROUTE
						_state.data = {
							..._state.data,
							..._deeplinkData.data,
							..._flowData.DEFAULT_PROPS
						}
					} else {
						_state.routeName = CONSTANTS.ROUTE_ERROR_MODULE
						_state.data = {
							..._state.data,
							..._deeplinkData.errorCode,
							isTechDiff: true
						}
					}
				} else {
					_state.routeName = CONSTANTS.ROUTE_ERROR_MODULE
					_state.data = {
						..._state.data,
						...this._getFeatureErrorType(_flowData.SWITCH),
						isTechDiff: true
					}
				}
			} else {
				_state.routeName = CONSTANTS.ROUTE_ERROR_MODULE
				_state.data = {
					..._state.data,
					...this._getErrorType(DEEPLINK_CONSTANTS.FLOW_PARAM_NAME),
					isTechDiff: true
				}
			}
		}

		this._storeDeeplinkMetaData({
			isDeeplink: _isDeeplink,
			deeplinkType: _flowData ? _flowData.TYPE : null
		})
		return _state
	},

	_isFeatureEnabled(data) {
		if (data.SWITCH && !getParam(data.SWITCH)) {
			return false
		} else {
			return true
		}
	},

	_storeDeeplinkMetaData(deeplinkMetaData) {
		store.dispatch({
			type: actionTypes.ADD_DEEPLINK_DATA,
			payload: deeplinkMetaData
		})
	},

	_getDeeplinkData(_paramsData) {
		let self = this,
			_deeplinkData = { data: {}, isValid: true, errorCode: null },
			_parameterValue = null,
			_isParameterValid = false,
			paramData = null

		if (_paramsData) {
			for (let i = 0; i < _paramsData.length; i++) {
				paramData = _paramsData[i]

				_parameterValue = Application.Wrapper.getRequestParameter(
					paramData.NAME
				)
				_isParameterValid = self._validateDeeplinkData(
					_parameterValue,
					paramData
				)
				if (_isParameterValid) {
					if (_parameterValue) {
						_deeplinkData.data[
							paramData.PROPS ? paramData.PROPS : paramData.NAME
						] = self._formatDeeplinkData(_parameterValue, paramData)
					}
				} else {
					_deeplinkData.data = null
					_deeplinkData.errorCode = self._getErrorType(paramData.NAME)
					_deeplinkData.isValid = false
					break
				}
			}
		}

		return _deeplinkData
	},

	_validateDeeplinkData(data, metadata) {
		let _isValid = false
		if (data) {
			switch (metadata.TYPE) {
				case 'NUMBER':
					_isValid = !isNaN(parseInt(data)) && parseInt(data) > 0
					break

				case 'ENUM':
					_isValid = metadata['ENUM_RANGE'].includes(data)
					break
			}
		} else if (metadata.OPTIONAL) {
			_isValid = true
		} else {
			_isValid = false
		}
		return _isValid
	},

	_formatDeeplinkData(data, metadata) {
		let _formattedData = data
		if (data) {
			switch (metadata.TYPE) {
				case 'NUMBER':
					_formattedData = parseInt(data)
			}
		}
		return _formattedData
	},

	_getErrorType(paramName) {
		switch (paramName) {
			case 'providerId':
				return TechErrorConstants.DEEPLINK_INVALID_PROVIDER_ID

			case 'providerAccountId':
				return TechErrorConstants.DEEPLINK_INVALID_PROVIDER_ACCOUNT_ID

			case 'accountId':
				return TechErrorConstants.DEEPLINK_INVALID_ACCOUNT_ID

			case 'container':
				return TechErrorConstants.DEEPLINK_INVALID_CONTAINER

			case 'bankTransferCode':
				return TechErrorConstants.DEEPLINK_INVALID_BANK_TRANSFER_CODE

			default:
				return TechErrorConstants.DEEPLINK_INVALID_FLOW
		}
	},

	_getFeatureErrorType(featureKey) {
		switch (featureKey) {
			case AppParams.ENABLE_CDV:
				return TechErrorConstants.CDV_NOT_ENABLED
			case AppParams.ENABLE_REAL_ESTATE:
				return TechErrorConstants.REAL_ESTATE_NOT_ENABLED
			case AppParams.ENABLE_MANUAL_ACCOUNT:
				return TechErrorConstants.MANUAL_ACCOUNTS_NOT_ENABLED
		}
	}
}
