export default {
	doFilter(defaultState) {
		return defaultState
	}
}
