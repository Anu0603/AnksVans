import CONSTANTS from './../../router/Constant'
import AppConstants from '../../conf/constants/AppConstants'
import { AppParams } from '../../conf'

const DeeplinkConstants = {
	FLOW_PARAM_NAME: 'flow',

	FLOW_TYPES: {
		ACCOUNT_ADDITION: 'ACCOUNT_ADDITION',
		EDIT_CREDENTIALS: 'EDIT_CREDENTIALS',
		REFRESH: 'REFRESH',
		INITIATE_VERIFICATION: 'INITIATE_VERIFICATION',
		COMPLETE_VERIFICATION: 'COMPLETE_VERIFICATION',
		ADD_REAL_ESTATE: 'ADD_REAL_ESTATE',
		EDIT_REAL_ESTATE: 'EDIT_REAL_ESTATE',
		ADD_MANUAL: 'ADD_MANUAL',
		EDIT_MANUAL: 'EDIT_MANUAL'
	},

	FLOWS_METADATA: {
		add: {
			TYPE: 'ACCOUNT_ADDITION',
			ROUTE: CONSTANTS.ROUTE_LOGIN_MODULE,
			PARAMS: [
				{
					NAME: 'providerId',
					TYPE: 'NUMBER'
				}
			]
		},
		edit: {
			TYPE: 'EDIT_CREDENTIALS',
			ROUTE: CONSTANTS.ROUTE_LOGIN_MODULE,
			PARAMS: [
				{
					NAME: 'providerAccountId',
					TYPE: 'NUMBER'
				}
			]
		},

		refresh: {
			TYPE: 'REFRESH',
			ROUTE: CONSTANTS.ROUTE_VERIFICATION_MODULE,
			PARAMS: [
				{
					NAME: 'providerAccountId',
					TYPE: 'NUMBER'
				}
			]
		},

		initiateCDV: {
			TYPE: 'INITIATE_VERIFICATION',
			ROUTE: CONSTANTS.ROUTE_CDV_MODULE,
			DEFAULT_PROPS: {
				path: AppConstants.CDV_PATH_INITIATE
			},
			PARAMS: [
				{
					NAME: 'bankTransferCode',
					TYPE: 'NUMBER',
					PROPS: 'routingNumber',
					OPTIONAL: true
				},
				{
					NAME: 'providerId',
					TYPE: 'NUMBER',
					OPTIONAL: true
				}
			],
			SWITCH: AppParams.ENABLE_CDV
		},

		completeVerification: {
			TYPE: 'COMPLETE_VERIFICATION',
			ROUTE: CONSTANTS.ROUTE_CDV_MODULE,
			DEFAULT_PROPS: {
				path: AppConstants.CDV_PATH_COMPLETE
			},
			PARAMS: [
				{
					NAME: 'accountId',
					TYPE: 'NUMBER'
				}
			],
			SWITCH: AppParams.ENABLE_CDV
		},

		addRealEstate: {
			TYPE: 'ADD_REAL_ESTATE',
			ROUTE: CONSTANTS.ROUTE_REAL_ESTATE_MODULE,
			SWITCH: AppParams.ENABLE_REAL_ESTATE
		},

		editRealEstate: {
			TYPE: 'EDIT_REAL_ESTATE',
			ROUTE: CONSTANTS.ROUTE_REAL_ESTATE_MODULE,
			PARAMS: [
				{
					NAME: 'accountId',
					TYPE: 'NUMBER'
				}
			],
			SWITCH: AppParams.ENABLE_REAL_ESTATE
		},

		addManual: {
			TYPE: 'ADD_MANUAL',
			ROUTE: CONSTANTS.ROUTE_MANUAL_ACCOUNT_MODULE,
			SWITCH: AppParams.ENABLE_MANUAL_ACCOUNT
		},

		editManual: {
			TYPE: 'EDIT_MANUAL',
			ROUTE: CONSTANTS.ROUTE_MANUAL_ACCOUNT_MODULE,
			PARAMS: [
				{
					NAME: 'accountId',
					TYPE: 'NUMBER'
				},
				{
					NAME: 'container',
					TYPE: 'ENUM',
					ENUM_RANGE: [
						'bank',
						'creditCard',
						'investment',
						'insurance',
						'loan',
						'reward',
						'bill',
						'otherAssets',
						'otherLiabilities'
					]
				}
			],
			SWITCH: AppParams.ENABLE_MANUAL_ACCOUNT
		}
	}
}

export default DeeplinkConstants
