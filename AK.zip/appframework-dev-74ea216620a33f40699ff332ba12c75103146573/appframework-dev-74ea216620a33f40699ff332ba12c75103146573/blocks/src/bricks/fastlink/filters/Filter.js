import ConfigHandler from './configs/ConfigHandler'
import DeeplinkHandler from './deeplink/DeeplinkHandler'

export default {
	doFilter(defaultState, techDiffHandler) {
		let _state = ConfigHandler.doFilter(defaultState)
		_state = DeeplinkHandler.doFilter(_state)
		return _state
	}
}
