import DeeplinkHandler from './../DeeplinkHandler'
import DEEPLINK_CONSTANTS from './../DeeplinkConstants'
import CONSTANTS from './../../../router/Constant'
import AppConstants from './../../../conf/constants/AppConstants'
import DeeplinkConstants from './../DeeplinkConstants'
import TechErrorConstants from '../../../components/Error/TechnicalError/TechErrorConstants'
import { AppParams, getParam } from './../../../conf'

jest.mock('./../../../conf')

describe('DeeplinkHandler Test Case', () => {
	beforeEach(() => {})

	it('Check if state is not changed if flow is not there in request url', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					return null
				}
			}
		}
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		}

		let _actualState = DeeplinkHandler.doFilter(_expectedState)
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error if flow is not a supported flow', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					return 'something'
				}
			}
		}
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.DEEPLINK_INVALID_FLOW
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error if flow is add but supported parameters are not there', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					return 'add'
				}
			}
		}
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.DEEPLINK_INVALID_PROVIDER_ID
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Login Module if flow is add with supported parameters', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'add'
							break

						case 'providerId':
							return '16441'
							break
					}
				}
			}
		}
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_LOGIN_MODULE,
			data: {
				providerId: 16441
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error Module if flow is add with providerId as alphabet', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'add'
							break

						case 'providerId':
							return 'abc'
							break
					}
				}
			}
		}
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.DEEPLINK_INVALID_PROVIDER_ID
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error Module if flow is add with no providerId in request', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'add'
							break

						case 'providerId':
							return null
							break
					}
				}
			}
		}
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.DEEPLINK_INVALID_PROVIDER_ID
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to CDV Module if flow is initiateCDV with optional parameter', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'initiateCDV'
							break
					}
				}
			}
		}

		getParam.mockImplementation(_key => {
			if (_key == AppParams.ENABLE_CDV) {
				return true
			}
		})

		let _expectedState = {
			routeName: CONSTANTS.ROUTE_CDV_MODULE,
			data: {
				path: 'INITIATE'
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if props changes from bankTransferCode to routingNumber in case flow is initiateCDV', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'initiateCDV'
							break

						case 'bankTransferCode':
							return '999999989'
							break
					}
				}
			}
		}
		getParam.mockImplementation(_key => {
			if (_key == AppParams.ENABLE_CDV) {
				return true
			}
		})
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_CDV_MODULE,
			data: {
				path: 'INITIATE',
				routingNumber: 999999989
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Manual Module if flow is editManual with supported container', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'editManual'
							break

						case 'accountId':
							return '123123'
							break

						case 'container':
							return 'insurance'
							break
					}
				}
			}
		}

		getParam.mockImplementation(_key => {
			if (_key == AppParams.ENABLE_MANUAL_ACCOUNT) {
				return true
			}
		})

		let _expectedState = {
			routeName: CONSTANTS.ROUTE_MANUAL_ACCOUNT_MODULE,
			data: {
				accountId: 123123,
				container: 'insurance'
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error Module if flow is editManual with non supported container', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'editManual'
							break

						case 'accountId':
							return '123123'
							break

						case 'container':
							return 'junk'
							break
					}
				}
			}
		}
		getParam.mockImplementation(_key => {
			if (_key == AppParams.ENABLE_MANUAL_ACCOUNT) {
				return true
			}
		})
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.DEEPLINK_INVALID_CONTAINER
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error Module if flow is edit with no providerAccountId', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'edit'
							break

						case 'providerAccountId':
							return null
							break
					}
				}
			}
		}
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.DEEPLINK_INVALID_PROVIDER_ACCOUNT_ID
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error Module if flow is completeVerification with no accountId', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'completeVerification'
							break

						case 'accountId':
							return null
							break
					}
				}
			}
		}
		getParam.mockImplementation(_key => {
			if (_key == AppParams.ENABLE_CDV) {
				return true
			}
		})
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.DEEPLINK_INVALID_ACCOUNT_ID
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error Module if flow is initiateVerification with invalid bankTransferCode', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'initiateCDV'
							break

						case 'bankTransferCode':
							return 'Random'
							break
					}
				}
			}
		}
		getParam.mockImplementation(_key => {
			if (_key == AppParams.ENABLE_CDV) {
				return true
			}
		})
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.DEEPLINK_INVALID_BANK_TRANSFER_CODE
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error Module if CDV is not enabled', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'initiateCDV'
							break

						case 'bankTransferCode':
							return 'Random'
							break
					}
				}
			}
		}
		getParam.mockImplementation(_key => {
			if (_key == AppParams.ENABLE_CDV) {
				return false
			}
		})
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.CDV_NOT_ENABLED
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error Module if Manual Accounts is not enabled', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'addManual'
							break
					}
				}
			}
		}
		getParam.mockImplementation(_key => {
			if (_key == AppParams.ENABLE_MANUAL_ACCOUNT) {
				return false
			}
		})
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.MANUAL_ACCOUNTS_NOT_ENABLED
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})

	it('Check if router changes to Error Module if Real Estate is not enabled', () => {
		global.Application = {
			Wrapper: {
				getRequestParameter: _param => {
					switch (_param) {
						case DeeplinkConstants.FLOW_PARAM_NAME:
							return 'addRealEstate'
							break
					}
				}
			}
		}
		getParam.mockImplementation(_key => {
			if (_key == AppParams.ENABLE_REAL_ESTATE) {
				return false
			}
		})
		let _expectedState = {
			routeName: CONSTANTS.ROUTE_ERROR_MODULE,
			data: {
				isTechDiff: true,
				...TechErrorConstants.REAL_ESTATE_NOT_ENABLED
			}
		}

		let _actualState = DeeplinkHandler.doFilter({
			routeName: CONSTANTS.ROUTE_LANDING_MODULE
		})
		expect(_actualState).toEqual(_expectedState)
	})
})
