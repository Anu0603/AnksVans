import { ReactReduxContext } from 'react-redux'
import React from 'react'

const WithState = (stateName, WrappedComponent) => {
	return class extends React.Component {
		constructor(props) {
			super(props)
		}

		render() {
			return (
				<ReactReduxContext.Consumer>
					{({ store }) => {
						let props = Object.assign({}, this.props)
						props[stateName] = store.getState()[stateName]
						return <WrappedComponent {...props} />
					}}
				</ReactReduxContext.Consumer>
			)
		}
	}
}
export default WithState
