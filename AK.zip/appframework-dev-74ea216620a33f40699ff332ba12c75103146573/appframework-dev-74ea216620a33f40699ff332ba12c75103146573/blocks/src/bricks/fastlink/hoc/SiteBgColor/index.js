import React from 'react'

const SiteBgColor = WrappedComponent => {
	return class extends React.Component {
		constructor(props) {
			super(props)
			this.currentProvider = this.props.currentProvider
			this.state = {
				hexCode1: this.currentProvider.hexCode1
			}
		}

		render() {
			let bgColorInline = { backgroundColor: this.state.hexCode1 }
			return (
				<div style={bgColorInline}>
					<WrappedComponent {...this.props} />
				</div>
			)
		}
	}
}
export default SiteBgColor
