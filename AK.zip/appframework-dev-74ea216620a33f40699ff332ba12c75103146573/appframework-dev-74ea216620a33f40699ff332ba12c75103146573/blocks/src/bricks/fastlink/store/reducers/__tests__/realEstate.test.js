import reducer from '../realEstate'
import * as types from '../../actions/actionTypes'

describe('RealEstate reducer', () => {
	it('should return the initial state', () => {
		expect(
			reducer(
				{
					accounts: []
				},
				{}
			)
		).toEqual({
			accounts: []
		})
	})

	it('should handle ADD_REAL_ESTATE_ACCOUNT', () => {
		let data = {
			realEstate: {
				CONTAINER: 'realEstate',
				providerAccountId: 11313442,
				accountName: 'qwd',
				accountStatus: 'ACTIVE',
				isAsset: true,
				aggregationSource: 'USER',
				id: 12431635,
				lastUpdated: '2020-04-15T13:20:13Z',
				providerId: '7842',
				providerName: 'Custom Real Estate',
				accountType: 'REAL_ESTATE',
				isManual: true,
				createdDate: '2020-04-15T13:20:13Z',
				includeInNetWorth: true,
				homeValue: {
					amount: 123,
					currency: 'USD'
				},
				balance: {
					amount: 123,
					currency: 'USD'
				},
				estimatedDate: '2020-04-15',
				valuationType: 'MANUAL'
			}
		}

		expect(
			reducer(
				{
					accounts: []
				},
				{
					type: types.ADD_REAL_ESTATE_ACCOUNT,
					payload: data
				}
			)
		).toEqual({ accounts: [data.realEstate] })
	})

	it('should handle REMOVE_REAL_ESTATE_ACCOUNT  for account ID in added list', () => {
		let data = {
			realEstate: {
				CONTAINER: 'realEstate',
				providerAccountId: 11313442,
				accountName: 'qwd',
				accountStatus: 'ACTIVE',
				isAsset: true,
				aggregationSource: 'USER',
				id: 12431635,
				lastUpdated: '2020-04-15T13:20:13Z',
				providerId: '7842',
				providerName: 'Custom Real Estate',
				accountType: 'REAL_ESTATE',
				isManual: true,
				createdDate: '2020-04-15T13:20:13Z',
				includeInNetWorth: true,
				homeValue: {
					amount: 123,
					currency: 'USD'
				},
				balance: {
					amount: 123,
					currency: 'USD'
				},
				estimatedDate: '2020-04-15',
				valuationType: 'MANUAL'
			}
		}
		expect(
			reducer(
				{
					accounts: [data.realEstate]
				},
				{
					type: types.REMOVE_REAL_ESTATE_ACCOUNT,
					payload: { accountID: 12431635 }
				}
			)
		).toEqual({ accounts: [] })
	})

	it('should handle REMOVE_REAL_ESTATE_ACCOUNT for account ID not in added list', () => {
		let data = {
			realEstate: {
				CONTAINER: 'realEstate',
				providerAccountId: 11313442,
				accountName: 'qwd',
				accountStatus: 'ACTIVE',
				isAsset: true,
				aggregationSource: 'USER',
				id: 12431635,
				lastUpdated: '2020-04-15T13:20:13Z',
				providerId: '7842',
				providerName: 'Custom Real Estate',
				accountType: 'REAL_ESTATE',
				isManual: true,
				createdDate: '2020-04-15T13:20:13Z',
				includeInNetWorth: true,
				homeValue: {
					amount: 123,
					currency: 'USD'
				},
				balance: {
					amount: 123,
					currency: 'USD'
				},
				estimatedDate: '2020-04-15',
				valuationType: 'MANUAL'
			}
		}

		expect(
			reducer(
				{
					accounts: [data.realEstate]
				},
				{
					type: types.REMOVE_REAL_ESTATE_ACCOUNT,
					payload: { accountID: 10000000 }
				}
			)
		).toEqual({ accounts: [data.realEstate] })
	})
})
