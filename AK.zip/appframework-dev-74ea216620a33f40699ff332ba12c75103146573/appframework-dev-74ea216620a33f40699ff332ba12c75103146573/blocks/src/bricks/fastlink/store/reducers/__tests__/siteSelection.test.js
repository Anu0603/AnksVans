import reducer from '../siteSelection'
import * as types from '../../actions/actionTypes'

describe('Search reducer', () => {
	it('should return the initial state', () => {
		expect(reducer(undefined, {})).toEqual({
			providers: []
		})
	})

	it('should handle FETCH_PROVIDERS', () => {
		let data = {
			providers: [1, 2, 3]
		}
		expect(
			reducer(
				{},
				{
					type: types.FETCH_PROVIDERS,
					payload: data
				}
			)
		).toEqual(data)
	})
})
