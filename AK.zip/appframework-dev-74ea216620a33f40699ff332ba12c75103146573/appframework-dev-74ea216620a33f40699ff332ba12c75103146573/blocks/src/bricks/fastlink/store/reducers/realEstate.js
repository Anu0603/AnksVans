import * as actionTypes from '../actions/actionTypes'

const initialState = {
	accounts: []
}

const reducer = (state = initialState, action) => {
	switch (action.type) {
		case actionTypes.ADD_REAL_ESTATE_ACCOUNT:
			return {
				...state,
				accounts: state.accounts.concat(action.payload.realEstate)
			}
		case actionTypes.REMOVE_REAL_ESTATE_ACCOUNT:
			return {
				...state,
				accounts: state.accounts.filter(
					account => account.id !== action.payload.accountID
				)
			}
	}
	return state
}

export default reducer
