const initialState = {}
const ProviderInfo = (state = initialState, action) => {
	switch (action.type) {
		case 'SELECTED_PROVIDER_DATA':
			return Object.assign({}, state, action.payload)

		case 'RESET_PROVIDER_DATA':
			return {}

		default:
			return state
	}
}

export default ProviderInfo
