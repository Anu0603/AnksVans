import reducer from '../login'
import * as types from '../../actions/actionTypes'

describe('Login reducer', () => {
	it('should return the initial state', () => {
		expect(reducer(undefined, {})).toEqual({
			subViewType: '',
			form: 0,
			providerId: 0,
			loading: false
		})
	})

	it('should handle LOAD_LOGIN_FORM', () => {
		let data = {
			subViewType: 'abc',
			form: { some: 'some' },
			providerId: 10001000,
			loading: true
		}

		let expectedData = {
			subViewType: 'abc',
			form: { some: 'some' },
			providerId: 10001000,
			loading: false
		}

		expect(
			reducer(
				{},
				{
					type: types.LOAD_LOGIN_FORM,
					payload: data
				}
			)
		).toEqual(expectedData)
	})

	it('should handle LOAD_LOGIN_FORM_START', () => {
		let data = {
			loading: true
		}

		expect(
			reducer(
				{},
				{
					type: types.LOAD_LOGIN_FORM_START,
					payload: data
				}
			)
		).toEqual(data)
	})
})
