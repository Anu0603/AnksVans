import { combineReducers } from 'redux'

import siteSelectionReducer from './siteSelection'
import loginReducer from './login'
import refreshReducer from './refresh'
import accountsReducer from './accounts'
import providerInfo from './providerInfo'
import cdvReducer from './cdv'
import realEstateReducer from './realEstate'
import manualAccountReducer from './manualAccount'
import userAddedAccountData from './userAddedAccountData'
import deeplinkReducer from './deeplink'

const fastlinkRootReducer = combineReducers({
	siteSelection: siteSelectionReducer,
	login: loginReducer,
	refresh: refreshReducer,
	accounts: accountsReducer,
	currentProvider: providerInfo,
	cdv: cdvReducer,
	realEstate: realEstateReducer,
	manualAccount: manualAccountReducer,
	userAddedAccountData: userAddedAccountData,
	deeplink: deeplinkReducer
})

export default fastlinkRootReducer
