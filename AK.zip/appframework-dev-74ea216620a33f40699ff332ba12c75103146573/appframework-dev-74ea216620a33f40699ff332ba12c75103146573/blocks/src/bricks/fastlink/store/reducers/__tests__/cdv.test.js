import reducer from '../cdv'
import * as types from '../../actions/actionTypes'

describe('CDV reducer', () => {
	it('should return the initial state', () => {
		expect(reducer(undefined, {})).toEqual({
			verificationInfo: {},
			creditDebitInfo: {}
		})
	})

	it('should handle FETCH_CDV_VERIFICATION_INFO', () => {
		let data = {
			verificationInfo: {
				accountNumber: '2000',
				accountType: 'SAVINGS',
				routingNumber: 999999989,
				status: 'INITIATED',
				providerAccountId: 11272681
			}
		}

		expect(
			reducer(
				{},
				{
					type: types.FETCH_CDV_VERIFICATION_INFO,
					payload: data
				}
			)
		).toEqual(data)
	})

	it('should handle FETCH_CDV_CREDIT_DEBIT_INFO', () => {
		let data = {
			creditDebitInfo: {
				numberOfCredit: 2,
				isDebitEnabled: true
			}
		}

		expect(
			reducer(
				{},
				{
					type: types.FETCH_CDV_CREDIT_DEBIT_INFO,
					payload: data
				}
			)
		).toEqual(data)
	})

	it('should handle RESET_CDV_VERIFICATION_INFO', () => {
		expect(
			reducer(
				{},
				{
					type: 'RESET_CDV_VERIFICATION_INFO',
					payload: {}
				}
			)
		).toEqual({})
	})
})
