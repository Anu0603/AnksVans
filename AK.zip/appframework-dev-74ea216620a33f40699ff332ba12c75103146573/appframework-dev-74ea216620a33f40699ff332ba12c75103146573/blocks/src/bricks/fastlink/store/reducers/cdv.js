import * as actionTypes from '../actions/actionTypes'

const initialState = {
	verificationInfo: {},
	creditDebitInfo: {}
}

const reducer = (state = initialState, action) => {
	switch (action.type) {
		case actionTypes.FETCH_CDV_VERIFICATION_INFO:
			return {
				...state,
				verificationInfo: {
					...state.verificationInfo,
					...action.payload.verificationInfo
				}
			}

		case actionTypes.FETCH_CDV_CREDIT_DEBIT_INFO:
			return {
				...state,
				creditDebitInfo: action.payload.creditDebitInfo
			}

		case actionTypes.RESET_CDV_VERIFICATION_INFO:
			return {}
	}
	return state
}

export default reducer
