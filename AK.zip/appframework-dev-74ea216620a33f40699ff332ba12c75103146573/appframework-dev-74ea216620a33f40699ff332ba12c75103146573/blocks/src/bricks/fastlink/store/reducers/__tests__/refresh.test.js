import reducer from '../refresh'
import * as types from '../../actions/actionTypes'

describe('Refresh reducer', () => {
	it('should return the initial state', () => {
		expect(reducer(undefined, {})).toEqual({
			status: '',
			additionalStatus: '',
			mfaLoginForm: '',
			providerAccountId: -1,
			successRefreshView: false,
		})
	})

	it('should handle FETCH_PROVIDER_ACCOUNTS', () => {
		let data = {
			status: 'INPROGRESS',
			additionalStatus: 'ACCT_SUMMARY_RECEIVED',
			mfaLoginForm: null,
			requestId: 'QxqBoPC0iGkHtrDoDp/v5ZiviUQ=',
			providerAccountId: 23415276,
		}

		expect(
			reducer(
				{},
				{
					type: types.FETCH_PROVIDER_ACCOUNTS,
					payload: data,
				}
			)
		).toEqual(data)
	})

	it('should handle SUCCESS_REFRESH_VIEW', () => {
		let data = { successRefreshView: true }

		expect(
			reducer(
				{},
				{
					type: types.SUCCESS_REFRESH_VIEW,
					payload: data,
				}
			)
		).toEqual(data)
	})

	it('should handle RESET_REFESH_DATA', () => {
		expect(
			reducer(
				{},
				{
					type: 'RESET_REFESH_DATA',
					payload: {},
				}
			)
		).toEqual({})
	})
})
