import * as actionTypes from '../actions/actionTypes'

const initialState = {
	subViewType: '',
	form: 0,
	providerId: 0,
	loading: false
}

const reducer = (state = initialState, action) => {
	switch (action.type) {
		case actionTypes.LOAD_LOGIN_FORM:
			return {
				...state,
				loading: false,
				subViewType: action.payload.subViewType,
				form: action.payload.form,
				providerId: action.payload.providerId
			}
		case actionTypes.LOAD_LOGIN_FORM_START:
			return { ...state, loading: true }
	}
	return state
}

export default reducer
