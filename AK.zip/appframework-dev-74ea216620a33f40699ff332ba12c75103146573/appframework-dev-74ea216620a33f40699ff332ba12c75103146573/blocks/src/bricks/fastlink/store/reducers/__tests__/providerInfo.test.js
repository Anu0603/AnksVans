import reducer from '../providerInfo'
import * as types from '../../actions/actionTypes'

describe('ProviderInfo reducer', () => {
	it('should return the initial state', () => {
		expect(reducer(undefined, {})).toEqual({})
	})

	it('should handle SELECTED_PROVIDER_DATA', () => {
		let data = {
			name: 'Ally Bank',
			id: 9565,
			hexCode1: '#3E0046',
			hexCode2: '#40B8BD'
		}
		expect(
			reducer(
				{},
				{
					type: types.SELECTED_PROVIDER_DATA,
					payload: data
				}
			)
		).toEqual({})
	})

	it('should handle RESET_PROVIDER_DATA', () => {
		expect(
			reducer(
				{},
				{
					type: 'RESET_PROVIDER_DATA',
					payload: {}
				}
			)
		).toEqual({})
	})
})
