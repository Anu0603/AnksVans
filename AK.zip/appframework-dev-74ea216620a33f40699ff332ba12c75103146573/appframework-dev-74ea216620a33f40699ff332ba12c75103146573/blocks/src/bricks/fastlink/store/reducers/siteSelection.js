import * as actionTypes from '../actions/actionTypes'

const initialState = {
	providers: []
}

const reducer = (state = initialState, action) => {
	switch (action.type) {
		case actionTypes.FETCH_PROVIDERS:
			return {
				...state,
				providers: action.payload.providers
			}
	}
	return state
}

export default reducer
