import reducer from '../manualAccount'
import * as types from '../../actions/actionTypes'

describe('Manual Account reducer', () => {
	it('Returns initial state', () => {
		expect(
			reducer(
				{
					accounts: []
				},
				{}
			)
		).toEqual({
			accounts: []
		})
	})

	it('Has successful ADD_MANUAL_ACCOUNT', () => {
		let data = {
			manualAccount: {
				CONTAINER: 'bank',
				accountName: 'TEST',
				accountStatus: 'ACTIVE',
				aggregationSource: 'USER',
				id: 12345678,
				lastUpdated: '2020-05-25T00:00:00Z',
				accountType: 'SAVINGS',
				isManual: true,
				createdDate: '2020-05-25T00:00:00Z',
				includeInNetWorth: true,
				balance: {
					amount: 555,
					currency: 'USD'
				}
			}
		}

		expect(
			reducer(
				{
					accounts: []
				},
				{
					type: types.ADD_MANUAL_ACCOUNT,
					payload: data
				}
			)
		).toEqual({ accounts: [data.manualAccount] })
	})

	it('Should remove manual account based on id', () => {
		let data = {
			manualAccount: {
				CONTAINER: 'bank',
				accountName: 'TEST',
				accountStatus: 'ACTIVE',
				aggregationSource: 'USER',
				id: 12345678,
				lastUpdated: '2020-05-25T00:00:00Z',
				accountType: 'SAVINGS',
				isManual: true,
				createdDate: '2020-05-25T00:00:00Z',
				includeInNetWorth: true,
				balance: {
					amount: 555,
					currency: 'USD'
				}
			}
		}
		expect(
			reducer(
				{
					accounts: [data.manualAccount]
				},
				{
					type: types.REMOVE_MANUAL_ACCOUNT,
					payload: { accountID: 12345678 }
				}
			)
		).toEqual({ accounts: [] })
	})

	it('Should handle the action of remove for account ID not present', () => {
		let data = {
			manualAccount: {
				CONTAINER: 'bank',
				accountName: 'TEST',
				accountStatus: 'ACTIVE',
				aggregationSource: 'USER',
				id: 12345678,
				lastUpdated: '2020-05-25T00:00:00Z',
				accountType: 'SAVINGS',
				isManual: true,
				createdDate: '2020-05-25T00:00:00Z',
				includeInNetWorth: true,
				balance: {
					amount: 555,
					currency: 'USD'
				}
			}
		}

		expect(
			reducer(
				{
					accounts: [data.manualAccount]
				},
				{
					type: types.REMOVE_MANUAL_ACCOUNT,
					payload: { accountID: 4444444444 }
				}
			)
		).toEqual({ accounts: [data.manualAccount] })
	})
})
