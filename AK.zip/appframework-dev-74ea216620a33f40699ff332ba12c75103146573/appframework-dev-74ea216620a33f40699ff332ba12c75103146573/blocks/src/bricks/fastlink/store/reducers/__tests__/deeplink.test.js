import reducer from '../deeplink'
import * as types from '../../actions/actionTypes'

describe('Deeplink reducer', () => {
	it('should return the initial state', () => {
		expect(reducer(undefined, {})).toEqual({})
	})

	it('should handle ADD_DEEPLINK_DATA', () => {
		let data = {
			isDeeplink: true,
			deeplinkType: 'ACCOUNT_ADDITION'
		}

		expect(
			reducer(
				{},
				{
					type: types.ADD_DEEPLINK_DATA,
					payload: data
				}
			)
		).toEqual(data)
	})
})
