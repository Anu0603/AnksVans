import reducer from '../accounts'
import * as types from '../../actions/actionTypes'

describe('Accounts reducer', () => {
	it('should return the initial state', () => {
		expect(reducer(undefined, {})).toEqual({
			additionalStatus: '',
			status: ''
		})
	})

	it('should handle FETCH_ACCOUNTS', () => {
		let data = {
			additionalStatus: 'Testing',
			status: 'complete'
		}
		expect(
			reducer(
				{},
				{
					type: types.FETCH_ACCOUNTS,
					payload: {
						response: data
					}
				}
			)
		).toEqual({
			response: data
		})
	})

	it('should handle RESET_ACCOUNTS_DATA', () => {
		expect(
			reducer(
				{},
				{
					type: 'RESET_ACCOUNTS_DATA',
					payload: {}
				}
			)
		).toEqual({})
	})
})
