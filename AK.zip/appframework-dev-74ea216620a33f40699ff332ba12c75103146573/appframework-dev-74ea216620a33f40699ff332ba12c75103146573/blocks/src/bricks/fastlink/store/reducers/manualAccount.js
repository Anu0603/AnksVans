import * as actionTypes from "../actions/actionTypes";

const initialState = {
  accounts: [],
};

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case actionTypes.ADD_MANUAL_ACCOUNT:
      return {
        ...state,
        accounts: state.accounts.concat(action.payload.manualAccount),
      };
    case actionTypes.REMOVE_MANUAL_ACCOUNT:
      return {
        ...state,
        accounts: state.accounts.filter(
          (account) => account.id !== action.payload.accountID
        ),
      };
  }
  return state;
};

export default reducer;
