import * as actionTypes from '../actions/actionTypes'

const initialState = {}

const callbaclPostMessgae = (postMessageState = initialState, action) => {
	switch (action.type) {
		case actionTypes.ADD_UPDATE_USED_ADDED_ACCOUNTS_DATA:
			let tempPostMessageState = Object.assign({}, postMessageState)
			tempPostMessageState[action.payload.key] = action.payload.data
			return tempPostMessageState
	}
	return postMessageState
}

export default callbaclPostMessgae
