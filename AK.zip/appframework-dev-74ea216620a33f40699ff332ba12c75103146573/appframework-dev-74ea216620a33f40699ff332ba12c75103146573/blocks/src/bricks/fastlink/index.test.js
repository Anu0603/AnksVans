import React from 'react'
import FastLinkContainer from './index'

import { store } from './../../framework/react/store/store'

describe('Sample Test Case', () => {
	let container = null

	it('Sample Test Case', () => {
		act(() => {
			container = mount(<FastLinkContainer store={store} />)
		})
	})
})
