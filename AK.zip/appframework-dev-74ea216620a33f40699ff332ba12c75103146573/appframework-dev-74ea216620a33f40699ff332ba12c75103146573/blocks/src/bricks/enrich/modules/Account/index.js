import React, { Component } from 'react'
import FastLink from '../../../fastlink'
import { Button } from '../../../../framework/react/components/Button'
import { Modal } from '../../../../framework/react/components/Modal'

import AccountsService from '../../services/AccountsService'
import {Spinner} from '../../../../framework/react/components/Spinner'

class Accounts extends Component {

    state = {
        showFastLinkPopup: false,
        accounts: [],
        loading: true
    }

    handleLinkAccountClick(e) {
        this.setState({
            showFastLinkPopup: true,
        })
    }

    componentDidMount() {
        let _self = this
        this.setState({
            animatePage: true
        })

        AccountsService.getAccounts({}, (_error, _response) => {
            _self.setState({
                loading: false,
                accounts: _response.account
            })
        })

    }


    render() {
        return (
            <div>
                {this.state.loading ? (
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', paddingTop: 200 }}>
                        <Spinner style={{ flex: 1 }} />
                    </div>
                ) : (
                        <div>
                            <div style={{ borderBottom: '1px solid #ececec', height: 80 }}>
                                <div style={{ display: 'flex', padding: 16 }}>
                                    <div style={{ flex: 1, textAlign: 'left' }}>
                                        <span style={{ fontSize: 20, fontWeight: 'bold' }}>Accounts</span>
                                    </div>
                                    <div style={{ flex: 1, textAlign: "right" }}>
                                        <Button variant="primary" label="Link Account" onClick={this.handleLinkAccountClick.bind(this)}/>
                                    </div>
                                </div>
                            </div>
                            <div style={{ minHeight: 200, paddingTop: 50, textAlign: 'center' }}>
                                <ul style={{ padding: 0, margin: 0, borderTop: '1px solid #eee', textAlign: 'left' }}>
                                    {this.state.accounts.map((_account) => {
                                        let _accountName = ''

                                        if(_account.accountName){
                                            _accountName = _account.accountName
                                        } else if (_account.displayedName){
                                            _accountName = _account.displayedName 
                                        } else if (_account.providerName){
                                            _accountName = _account.providerName
                                        }

                                        return (
                                            <li style={{ listStyle: 'none', borderBottom: '1px solid #eee', padding: 16 }} key={_account.id}>
                                                <div className={'row'}>
                                                    <div className={'col-4'}> {_accountName}</div>
                                                    <div className={'col-4'}> {_account.CONTAINER}</div>
                                                    <div className={'col-4'}> {_account.accountNumber}</div>
                                                </div>
                                            </li>
                                        )
                                    })}
                                </ul>
                            </div>

                            <Modal isVisible={this.state.showFastLinkPopup}>
                                <FastLink />
                            </Modal>
                        </div>
                    )}
            </div>
        )
    }
}

export default Accounts