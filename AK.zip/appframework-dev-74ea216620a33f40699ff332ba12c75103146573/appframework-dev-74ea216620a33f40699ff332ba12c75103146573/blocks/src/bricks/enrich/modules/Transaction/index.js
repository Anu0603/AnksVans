import React, { Component } from 'react'
import FastLink from '../../../fastlink'
import { Button } from '../../../../framework/react/components/Button'
import { Modal } from '../../../../framework/react/components/Modal'

import TransactionsService from '../../services/TransactionsService'
import {Spinner} from '../../../../framework/react/components/Spinner'

class Accounts extends Component {

    state = {
        showFastLinkPopup: false,
        transactions: [],
        loading: true
    }

    handleLinkAccountClick(e) {
        this.setState({
            showFastLinkPopup: true,
        })
    }

    componentDidMount() {
        let _self = this
        this.setState({
            animatePage: true
        })

        TransactionsService.getTransactions({}, (_error, _response) => {
            console.log(_response)
            _self.setState({
                loading: false,
                transactions: _response.transaction
            })
        })
    }

    render() {
        return (
            <div>
                {this.state.loading ? (
                    <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', paddingTop: 200 }}>
                        <Spinner style={{ flex: 1 }} />
                    </div>
                ) : (
                        <div>
                            <div style={{ borderBottom: '1px solid #ececec', height: 80 }}>
                                <div style={{ display: 'flex', padding: 16 }}>
                                    <div style={{ flex: 1, textAlign: 'left' }}>
                                        <span style={{ fontSize: 20, fontWeight: 'bold' }}>Transactions</span>
                                    </div>
                                    <div style={{ flex: 1, textAlign: "right" }}>
                                        <Button variant="primary" label="Link Account" onClick={this.handleLinkAccountClick.bind(this)}/>
                                    </div>
                                </div>
                            </div>
                            <div style={{ minHeight: 200, paddingTop: 50, textAlign: 'center' }}>
                                <ul style={{ padding: 0, margin: 12, border: '1px solid #eee', textAlign: 'left' }}>
                                    {this.state.transactions.map((_transaction) => {
                                        let _descrption = ''

                                        if (_transaction.description) {
                                            if (_transaction.description.simple) {
                                                _descrption = _transaction.description.simple
                                            } else if (_transaction.description.consumer) {
                                                _descrption = _transaction.description.consumer
                                            } else if (_transaction.description.original) {
                                                _descrption = _transaction.description.original
                                            }
                                        }
                                        return (
                                            <li style={{ listStyle: 'none', borderBottom: '1px solid #eee', padding: 16 }} key={_transaction.id}>
                                                <div className={'row'}>
                                                    <div className={'col-4'}> {_descrption}</div>
                                                    <div className={'col-4'}> {_transaction.category}</div>
                                                    <div className={'col-4'}> {_transaction.amount.currency} {_transaction.amount.amount}</div>
                                                </div>
                                            </li>
                                        )
                                    })}
                                </ul>
                            </div>

                            <Modal isVisible={this.state.showFastLinkPopup}>
                                <FastLink />
                            </Modal>
                        </div>
                    )}
            </div>
        )
    }
}

export default Accounts