

/**
 * This file is the Entry point for the FastLink Container
 */
import React, { Component } from 'react'
import Navigator from './router/Navigator'
import './style/enrich.css'
import CONSTANTS from './router/Constant'

class EnrichContainer extends Component {

    state = {
        routeName: CONSTANTS.ROUTE_ACCOUNTS,
        data: null
    }

    handleNavigatePress(routeName, data) {
        this.setState({
            routeName: routeName,
            data: data
        })
    }

    render() {
        return (
            <div>
                <div id={'side-panel'} style={{ height: '100%', background: '#39474d', width: 240, position: 'fixed', top: 0, bottom: 0, color: '#FFF' }}>
                    <div>
                        <div style={{ fontSize: 32, textAlign: 'center', paddingTop: 20 }}>Enrich</div>
                        <ul id={'enrich-menu-wrap'}>
                            <li className={'enrich-menu-item'} onClick={() => { this.handleNavigatePress(CONSTANTS.ROUTE_ACCOUNTS)}}>Accounts</li>
                            <li className={'enrich-menu-item'} onClick={() => { this.handleNavigatePress(CONSTANTS.ROUTE_TRANSACTIONS)}}>Transactions</li>
                        </ul>
                    </div>
                </div>
                <div id={'app-content'} style={{ marginLeft: 240 }}>
                    <Navigator routeName={this.state.routeName} data={this.state.data} navigate={this.handleNavigatePress.bind(this)} />
                </div>
            </div>

        )
    }
}

export default EnrichContainer