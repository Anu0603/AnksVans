let Constants = {
    ROUTE_ACCOUNTS: 'ACCOUNTS_PAGE',
    ROUTE_TRANSACTIONS: 'TRANSACTIONS_PAGE',
}

export default Constants
