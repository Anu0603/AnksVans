import React from 'react'
import CONSTANTS from './Constant'

const AccountsPage = React.lazy(() => import('../modules/Account'))
const TransactionsPage = React.lazy(() => import('../modules/Transaction'))

const Navigator = ({ routeName, ...props }) => {
    let Route = null

    switch (routeName) {
        case CONSTANTS.ROUTE_ACCOUNTS:
            Route = AccountsPage
            break

        case CONSTANTS.ROUTE_TRANSACTIONS:
            Route = TransactionsPage
            break
    }

    if (Route) {
        return <Route {...props} />
    }

    return <div>404 - Enrich</div>
}

export default Navigator