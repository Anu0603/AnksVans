// import Application.BaseService from '../../../framework/app/services/Application.BaseService';

const TransactionService = {
    getTransactions: (_options, _callback) => {
        _options.data = {
            url : '/transactions',
            method: 'GET'
        }

        _options.callback = (_error, _response) => {
            _callback(null, _response)
        }

        Application.BaseService.makecall(_options, _callback)
    }
}

export default TransactionService