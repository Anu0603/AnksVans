// import Application.BaseService from '../../../framework/app/services/Application.BaseService';

const AccountsService = {
    getAccounts: (_options, _callback) => {
        _options.data = {
            url: "/1.1/accounts",
            method: 'GET'
        }

        _options.callback = (_error, _response) => {
            _callback(null, _response)
        }

        Application.BaseService.makecall(_options, _callback)
    }
}

export default AccountsService