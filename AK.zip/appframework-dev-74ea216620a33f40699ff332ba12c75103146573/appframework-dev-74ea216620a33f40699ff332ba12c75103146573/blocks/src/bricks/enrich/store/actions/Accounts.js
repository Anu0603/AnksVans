import * as actionTypes from '../constants'

export const storeSitesInfo = (_sitesInfo) => ({
    type: actionTypes.STORE_SITES_INFO,
    payload: {
        sitesInfo: _sitesInfo
    }
})

