import { combineReducers } from 'redux'
import Accounts from './Accounts'

export default combineReducers({
    Accounts: Accounts
})