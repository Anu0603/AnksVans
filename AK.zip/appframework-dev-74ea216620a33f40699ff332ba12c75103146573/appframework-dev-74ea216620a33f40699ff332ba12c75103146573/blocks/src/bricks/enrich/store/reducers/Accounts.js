import * as BrandInfoActions from '../actions/SiteInfo'

const initialState = {
    params: {},
    locale: {}
}

const brandInfo = (state = initialState, action) => {
    switch (action.type) {
        case BrandInfoActions.STORE_BRAND_INFO:
            let _updatedParams = { test : 'testing'}
            let _updatedLocale = {}

            return {
                ...state,
                params: _updatedParams,
                locale: _updatedLocale
            }
        default:
            return state
    }
}

export default brandInfo