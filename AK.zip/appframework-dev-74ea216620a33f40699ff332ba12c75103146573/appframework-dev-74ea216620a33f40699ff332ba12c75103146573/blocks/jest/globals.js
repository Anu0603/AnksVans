require('regenerator-runtime/runtime')

global.PARAM = {
	brandResourcePath: 'daflqa/static',
	baseParams: 'someBaseParams',
	userInfo: {
		prefs: {
			currencyCode: 'USD',
			dateFormat: 'MM/dd/yyyy',
			timeZone: 'PST',
			decimalSeparator: '.',
			groupingSeparator: ',',
			groupPattern: '###,##0.##',
			groupSize: 0,
			currencyNotation: 'SYMBOL',
			locale: 'en_US'
		},
		segmentInfo: {
			segmentId: '-1',
			segmentName: ''
		},
		userId: '10652389'
	},
	nsession: '354f150c828835446b94f1d78c46e9b30df34089db8aa263d40e8c6b5c81c4fd'
}

global.BrandUtils = {
	get: function(key) {
		return 'test'
	},

	getParam: function(key) {
		return key == 'client_callback_domains'
			? 'www.testing.com,www.test.com'
			: undefined
	},
	// getParam: function() {},
	getString: function() {},
	getRequestParameter: () => {}
}

global.Application = {
	Wrapper: {
		getRequestParameter: () => {},
		sendPostMessage: () => {}
	},
	BaseService: {
		getImageResourceServiceURL: () => {},
		getImageResourceCall: () => {},
		makecall: () => {},
		cancelLastRequest: () => {}
	},
	Utilities: {
		getAppMakeServiceURL: () => {
			return '/services/cobAppName/internal-provider/ysl'
		},
		getErrorRedirectUrl: () => {
			return '/apperror/cobAppName'
		},
		getAppGraphServiceURL: () => '',
		getPfileResourceServiceURL: () => '',
		getFavIconResourceServiceURL: () => '',
		getSiteLogoResourceServiceURL: () => '',
		getImageResourceServiceURL: () => '',
		isValidDomainCallbackUrl: () => ''
	}
}
