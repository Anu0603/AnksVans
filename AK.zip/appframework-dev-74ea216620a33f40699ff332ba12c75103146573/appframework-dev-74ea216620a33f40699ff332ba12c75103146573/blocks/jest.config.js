module.exports = {
	verbose: true,
	moduleNameMapper: {
		'\\.(css|scss)$': '<rootDir>/jest/mocks/styleMock.js',
		'^@framework(.*)$': '<rootDir>/src/framework$1',
		'@fastlinkRoot(.*)$': '<rootDir>/src/bricks/fastlink$1'
	},
	setupFiles: ['./jest/setup.js', '<rootDir>/jest/globals.js'],
	rootDir: '.',

	moduleFileExtensions: ['js'],
	notify: false,
	modulePathIgnorePatterns: ['__mocks__', '__snapshots__'],
	snapshotSerializers: ['enzyme-to-json/serializer'],
	reporters: [
		'default',
		[
			'./node_modules/jest-html-reporter',
			{
				pageTitle: 'Test Report',
				outputPath: './unit-test-reports/jest-report.html',
				includeFailureMsg: true,
				includeConsoleLog: true
			}
		]
	],
	//Testing particular folder/file, enable the following config option and add your folder/file path
	// testMatch: ['**/src/bricks/fastlink/router/__tests__/Navigator.test.js'],

	//--------------------------InstanbulJS - coverage report settings---------------
	coverageDirectory: './unit-test-reports/coverage',
	collectCoverage: true,
	coverageReporters: ['text-summary', 'html', 'cobertura'],
	collectCoverageFrom: ['src/**'],
	coveragePathIgnorePatterns: [
		'/node_modules/',
		'/jest/',
		'src/bricks/enrich/', //Enrich is now not in scope, this folder is added just for navigation testing purpose
		'src/ext/', //External Libraries which will not be included
		'src/index.js', //This is a entry point of the Application, self invoking function is added. This will not be tested.
		'src/bricks/fastlink/router/Navigator.js' //React and Enzyme not supporting the lazy load  testing hence added in the ignore paths
	]
}
