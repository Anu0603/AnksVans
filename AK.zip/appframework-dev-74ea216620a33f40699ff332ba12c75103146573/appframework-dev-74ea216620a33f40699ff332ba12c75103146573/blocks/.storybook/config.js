import { configure, addDecorator } from '@storybook/react';
import { jsxDecorator } from 'storybook-addon-jsx';
import { checkA11y } from "@storybook/addon-a11y"

addDecorator(jsxDecorator);
addDecorator(checkA11y)
// automatically import all files ending in *.stories.js
configure(require.context('../stories', true, /\.stories\.js$/), module);
