const path = require("path");

// Export a function. Accept the base config as the only param.
module.exports = async ({ config, mode }) => {
    // `mode` has a value of 'DEVELOPMENT' or 'PRODUCTION'
    // You can change the configuration based on that.
    // 'PRODUCTION' is used when building the static version of storybook.

    // Make whatever fine-grained changes you need
    config.module.rules.push({
        test: /\.scss$/,
        use: ["style-loader", "css-loader", "sass-loader"],
        include: path.resolve(__dirname, "../")
    });

    config.module.rules.push({
        test: /\.woff(2)?(\?v=[0-9]\.[0-9]\.[0-9])?$/,

        use: [
            {
                loader: 'url-loader',
                options: {
                    limit: 1000,
                    mimetype: 'application/font-woff'
                }
            }

        ]
    })

    config.module.rules.push({
        test: /\.(ttf|eot|svg)(\?v=[0-9]\.[0-9]\.[0-9])?$/,

        loader: 'file-loader'
    })

    config.module.rules.push({
        test: /\.stories\.js?$/,
        loaders: [
          {
            loader: require.resolve('@storybook/source-loader'),
            // options: { parser: 'typescript' },
          },
        ],
        enforce: 'pre',
      })

    // Return the altered config
    return config;
};